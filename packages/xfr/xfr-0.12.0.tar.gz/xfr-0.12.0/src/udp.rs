//! UDP data transfer with pacing and receiver-progress feedback
//!
//! Implements paced UDP sending to avoid buffer saturation and provides
//! jitter calculation per RFC 3550 and bounded sequence-based loss tracking.
//!
//! Also defines [`UdpFeedbackPacket`], the 36-byte cumulative-counts
//! receiver-progress packet emitted by the server's [`receive_udp`] task
//! at 2 Hz back to the client when both peers advertise the
//! `udp_feedback_v1` capability. The feedback path lets live UDP loss
//! visibility on the client sidestep the TCP control channel that may be
//! competing for ACKs against a saturated UDP uplink (issue #70). Demux
//! between data packets ([`UdpPacketHeader`], 16-byte header + payload)
//! and feedback packets is length-first (36 bytes for feedback vs.
//! 1416 bytes for data), so it never relies on inspecting
//! sequence-number bits.

use std::net::SocketAddr;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::net::UdpSocket;
use tokio::sync::watch;
use tokio::time::interval;
use tracing::{debug, warn};

use crate::protocol::{UdpIntervalProgress, UdpStats};
use crate::stats::StreamStats;

pub const UDP_PAYLOAD_SIZE: usize = 1400; // Leave room for IP + UDP headers
/// Largest UDP payload that fits in an IPv4 packet without IP options.
pub const MAX_UDP_PAYLOAD_SIZE: usize = 65_507;

/// Validate the complete UDP payload, including xfr's sequence/timestamp header.
pub fn validate_payload_size(size: usize) -> anyhow::Result<()> {
    anyhow::ensure!(
        (UDP_HEADER_SIZE..=MAX_UDP_PAYLOAD_SIZE).contains(&size),
        "UDP payload size must be between {UDP_HEADER_SIZE} and {MAX_UDP_PAYLOAD_SIZE} bytes"
    );
    Ok(())
}
pub const UDP_HEADER_SIZE: usize = 16; // sequence (8) + timestamp_us (8)
const UDP_INACTIVITY_TIMEOUT: Duration = Duration::from_secs(30); // Cleanup stale sessions

/// On-wire size of a v1 receiver-progress feedback packet
/// (`UdpFeedbackPacket`). Length is the primary discriminator between data
/// and feedback packets in the receive demux, and the magic byte sequence
/// is the secondary check; together they give a robust split that does
/// not rely on inspecting sequence-number bits in a data packet.
pub const UDP_FEEDBACK_SIZE: usize = 36;
/// Magic prefix on `UdpFeedbackPacket`. Distinct from any byte pattern
/// produced by `UdpPacketHeader::encode` for realistic test runs (the
/// first 4 bytes of every data packet are the high 32 bits of a u64
/// sequence counter starting at zero).
pub const UDP_FEEDBACK_MAGIC: [u8; 4] = *b"XFRF";
/// Currently-supported feedback packet protocol version.
pub const UDP_FEEDBACK_VERSION: u8 = 1;
/// `kind` byte for receiver-progress packets. Future packet types use a
/// new `kind` value so the parser stays selectable on length+kind.
pub const UDP_FEEDBACK_KIND_RECEIVER_PROGRESS: u8 = 1;

/// UDP receiver-feedback packet (`udp_feedback_v1`).
///
/// The server's UDP receive task emits these back to the client at 2 Hz
/// during upload-mode tests, sidestepping the TCP control channel for
/// live progress reporting. Cumulative counts let the client recover
/// from dropped feedback packets — the next tick carries the latest
/// truth without referring to anything we lost.
///
/// Wire layout, all multi-byte fields big-endian:
/// ```text
/// offset  size  field
///   0      4    magic = b"XFRF"
///   4      1    version = 1
///   5      1    kind = 1 (receiver_progress)
///   6      2    flags = 0 (reserved)
///   8      2    stream_id (u16)
///  10      2    reserved = 0
///  12      8    elapsed_ms
///  20      8    packets_received (cumulative)
///  28      8    packets_lost (cumulative)
/// total: 36 bytes, fixed
/// ```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct UdpFeedbackPacket {
    pub stream_id: u16,
    pub elapsed_ms: u64,
    pub packets_received: u64,
    pub packets_lost: u64,
}

impl UdpFeedbackPacket {
    /// Encode the packet into `buffer` in 36 bytes. Returns false if the
    /// buffer is too small.
    pub fn encode(&self, buffer: &mut [u8]) -> bool {
        if buffer.len() < UDP_FEEDBACK_SIZE {
            return false;
        }
        buffer[0..4].copy_from_slice(&UDP_FEEDBACK_MAGIC);
        buffer[4] = UDP_FEEDBACK_VERSION;
        buffer[5] = UDP_FEEDBACK_KIND_RECEIVER_PROGRESS;
        buffer[6..8].copy_from_slice(&0u16.to_be_bytes()); // flags
        buffer[8..10].copy_from_slice(&self.stream_id.to_be_bytes());
        buffer[10..12].copy_from_slice(&0u16.to_be_bytes()); // reserved
        buffer[12..20].copy_from_slice(&self.elapsed_ms.to_be_bytes());
        buffer[20..28].copy_from_slice(&self.packets_received.to_be_bytes());
        buffer[28..36].copy_from_slice(&self.packets_lost.to_be_bytes());
        true
    }

    /// Decode a 36-byte feedback packet. Returns `None` if length, magic,
    /// version, or kind don't match the v1 schema. Forward-compatible
    /// only via new `kind` values, not via larger v1 packets.
    pub fn decode(buffer: &[u8]) -> Option<Self> {
        if buffer.len() != UDP_FEEDBACK_SIZE {
            return None;
        }
        if buffer[0..4] != UDP_FEEDBACK_MAGIC {
            return None;
        }
        if buffer[4] != UDP_FEEDBACK_VERSION {
            return None;
        }
        if buffer[5] != UDP_FEEDBACK_KIND_RECEIVER_PROGRESS {
            return None;
        }
        let stream_id = u16::from_be_bytes(buffer[8..10].try_into().ok()?);
        let elapsed_ms = u64::from_be_bytes(buffer[12..20].try_into().ok()?);
        let packets_received = u64::from_be_bytes(buffer[20..28].try_into().ok()?);
        let packets_lost = u64::from_be_bytes(buffer[28..36].try_into().ok()?);
        Some(Self {
            stream_id,
            elapsed_ms,
            packets_received,
            packets_lost,
        })
    }

    /// Convert the cumulative counts into the shared
    /// `UdpIntervalProgress` shape consumed by the progress aggregator.
    pub fn to_progress(&self) -> UdpIntervalProgress {
        UdpIntervalProgress {
            packets_received: self.packets_received,
            packets_lost: self.packets_lost,
        }
    }
}

/// Magic prefix on single-port UDP hello/ack packets (issue #63). These
/// are the only xfr packets that ever cross the server's shared wildcard
/// socket, where QUIC traffic is demuxed by header bits: the first byte
/// must have the top two bits clear so it can never look like a QUIC
/// long header (0x80, RFC 8999) or short header (0x40 fixed bit). The
/// legacy `XFRF`/`XFRP` magics start with 'X' (0x58 = 0b0101_1000) and
/// stay off the shared socket entirely — they ride connected sockets
/// where the existing demux is unchanged.
pub const UDP_HELLO_MAGIC: [u8; 4] = *b"\x00XFR";
/// Fixed on-wire size of a hello/ack packet.
pub const UDP_HELLO_SIZE: usize = 24;
/// Currently-supported hello packet protocol version.
pub const UDP_HELLO_VERSION: u8 = 1;
/// `kind` byte for the client→server stream hello.
pub const UDP_HELLO_KIND_HELLO: u8 = 1;
/// `kind` byte for the server→client ack, sent from the per-stream
/// connected socket so the client learns the connected path is live.
pub const UDP_HELLO_KIND_ACK: u8 = 2;
/// Length of the per-test routing token carried in every hello/ack.
pub const UDP_HELLO_TOKEN_LEN: usize = 16;
/// How often the client re-sends an unacknowledged hello.
pub const UDP_HELLO_RETRY_INTERVAL: Duration = Duration::from_millis(100);
/// Total hello attempts before the handshake fails loudly (~5 s budget).
pub const UDP_HELLO_MAX_ATTEMPTS: u32 = 50;

/// Single-port UDP hello/ack packet (issue #63).
///
/// The client sends a hello per stream to the server's main port; the
/// server answers with an ack from a freshly connected same-port socket.
/// The token (server-generated, carried back in `TestAck.udp_token`) is
/// what routes the hello to the right test — source address alone would
/// break under NAT or multiple concurrent clients.
///
/// Wire layout, all multi-byte fields big-endian:
/// ```text
/// offset  size  field
///   0      4    magic = b"\x00XFR"
///   4      1    version = 1
///   5      1    kind (1 = hello, 2 = ack)
///   6      2    stream_index (u16)
///   8     16    token
/// total: 24 bytes, fixed
/// ```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct UdpHelloPacket {
    pub kind: u8,
    pub stream_index: u16,
    pub token: [u8; UDP_HELLO_TOKEN_LEN],
}

impl UdpHelloPacket {
    /// Encode the packet into a fixed 24-byte buffer.
    pub fn encode(&self) -> [u8; UDP_HELLO_SIZE] {
        let mut buffer = [0u8; UDP_HELLO_SIZE];
        buffer[0..4].copy_from_slice(&UDP_HELLO_MAGIC);
        buffer[4] = UDP_HELLO_VERSION;
        buffer[5] = self.kind;
        buffer[6..8].copy_from_slice(&self.stream_index.to_be_bytes());
        buffer[8..24].copy_from_slice(&self.token);
        buffer
    }

    /// Decode a hello/ack packet. Returns `None` if length, magic,
    /// version, or kind don't match the v1 schema — fixed-size like the
    /// feedback packet, forward-compatible only via new `kind` values.
    pub fn decode(buffer: &[u8]) -> Option<Self> {
        if buffer.len() != UDP_HELLO_SIZE {
            return None;
        }
        if buffer[0..4] != UDP_HELLO_MAGIC {
            return None;
        }
        if buffer[4] != UDP_HELLO_VERSION {
            return None;
        }
        let kind = buffer[5];
        if !matches!(kind, UDP_HELLO_KIND_HELLO | UDP_HELLO_KIND_ACK) {
            return None;
        }
        let stream_index = u16::from_be_bytes(buffer[6..8].try_into().ok()?);
        let token = buffer[8..24].try_into().ok()?;
        Some(Self {
            kind,
            stream_index,
            token,
        })
    }
}

/// Hex-encode a routing token for the `TestAck.udp_token` wire field.
pub fn encode_hello_token(token: &[u8; UDP_HELLO_TOKEN_LEN]) -> String {
    token.iter().map(|b| format!("{:02x}", b)).collect()
}

/// Parse a `TestAck.udp_token` hex string back into raw token bytes.
/// Returns `None` for anything that isn't exactly 32 hex digits.
pub fn parse_hello_token(s: &str) -> Option<[u8; UDP_HELLO_TOKEN_LEN]> {
    if s.len() != UDP_HELLO_TOKEN_LEN * 2 || !s.is_ascii() {
        return None;
    }
    let mut token = [0u8; UDP_HELLO_TOKEN_LEN];
    for (i, chunk) in s.as_bytes().chunks(2).enumerate() {
        token[i] = u8::from_str_radix(std::str::from_utf8(chunk).ok()?, 16).ok()?;
    }
    Some(token)
}

/// Which lane a datagram on the shared server socket belongs to.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SharedSocketLane {
    /// Single-port UDP hello — divert to the hello dispatcher.
    XfrHello,
    /// QUIC — pass through to quinn untouched.
    Quic,
    /// Neither: shouldn't normally happen, since once a stream's
    /// connected socket exists the kernel routes its data there and the
    /// shared socket never sees it. Logged at debug and dropped.
    XfrStray,
}

/// Classify a datagram arriving on the shared (QUIC + xfr hello) socket.
///
/// Order matters and matches the design for issue #63:
/// 1. exact match on the single-port hello framing → xfr hello lane;
/// 2. first byte with 0x80 set → QUIC long header (version-independent
///    per RFC 8999);
/// 3. first byte with 0x40 set → QUIC short header. Sound only because
///    the server endpoint sets `grease_quic_bit(false)`: RFC 9287
///    greasing is permission-based, so a server that doesn't advertise
///    the grease transport parameter stops compliant peers from clearing
///    the fixed bit toward it;
/// 4. anything else → stray xfr lane.
pub fn classify_shared_datagram(datagram: &[u8]) -> SharedSocketLane {
    if datagram.len() == UDP_HELLO_SIZE && datagram[0..4] == UDP_HELLO_MAGIC {
        return SharedSocketLane::XfrHello;
    }
    match datagram.first() {
        Some(b) if b & 0x80 != 0 => SharedSocketLane::Quic,
        Some(b) if b & 0x40 != 0 => SharedSocketLane::Quic,
        _ => SharedSocketLane::XfrStray,
    }
}

/// Client side of the single-port UDP stream handshake (issue #63).
///
/// Sends a hello datagram on the connected `socket` every
/// [`UDP_HELLO_RETRY_INTERVAL`] until the server's ack arrives, up to
/// [`UDP_HELLO_MAX_ATTEMPTS`]. Inbound datagrams are `peek`ed, not
/// consumed: a matching ack is consumed and completes the handshake; a
/// foreign hello-lane packet is consumed and dropped; anything else
/// (test data in download mode, where the server starts sending as soon
/// as the hello routes) is treated as an implicit ack and left queued
/// for the data path so it isn't lost from the receiver's accounting.
///
/// The caller must not start sending data until this returns Ok — that
/// ordering is what eliminates the race where data reaches the server's
/// shared socket before the per-stream connected socket exists.
pub async fn single_port_udp_handshake(
    socket: &UdpSocket,
    token: &[u8; UDP_HELLO_TOKEN_LEN],
    stream_index: u16,
) -> anyhow::Result<()> {
    let hello = UdpHelloPacket {
        kind: UDP_HELLO_KIND_HELLO,
        stream_index,
        token: *token,
    }
    .encode();
    // Full-size buffer: Windows fails peek/recv with WSAEMSGSIZE when the
    // buffer is smaller than the datagram, and download-mode data packets
    // can arrive here.
    let mut buf = vec![0u8; MAX_UDP_PAYLOAD_SIZE];

    for _ in 0..UDP_HELLO_MAX_ATTEMPTS {
        socket.send(&hello).await?;
        let retry_at = tokio::time::Instant::now() + UDP_HELLO_RETRY_INTERVAL;
        loop {
            let n = tokio::select! {
                result = socket.peek(&mut buf) => result?,
                _ = tokio::time::sleep_until(retry_at) => break,
            };
            if n == UDP_HELLO_SIZE && buf[0..4] == UDP_HELLO_MAGIC {
                let matched = UdpHelloPacket::decode(&buf[..n]).is_some_and(|pkt| {
                    pkt.kind == UDP_HELLO_KIND_ACK
                        && pkt.token == *token
                        && pkt.stream_index == stream_index
                });
                // Consume the hello-lane packet either way; only a full
                // match completes the handshake.
                let _ = socket.recv(&mut buf).await;
                if matched {
                    return Ok(());
                }
                continue;
            }
            // Non-hello-lane traffic from the server means our hello was
            // already routed (data only flows after that). Leave it queued.
            return Ok(());
        }
    }

    Err(anyhow::anyhow!(
        "single-port UDP handshake timed out for stream {}: no ack from the server \
         after {} attempts over {:?}. The server's UDP port may be reachable while \
         replies are filtered, or the server dropped the test.",
        stream_index,
        UDP_HELLO_MAX_ATTEMPTS,
        UDP_HELLO_RETRY_INTERVAL * UDP_HELLO_MAX_ATTEMPTS
    ))
}

/// Server-side ack responder for directions where no receive loop runs
/// on the connected socket (download mode). The first ack from the
/// dispatcher can be lost; the client's retried hellos then arrive on
/// the connected socket (the kernel routes them past the shared
/// wildcard), so someone must keep answering until one ack lands. Runs
/// until `cancel` fires; idles on recv once the client stops retrying.
pub async fn respond_single_port_hellos(
    socket: Arc<UdpSocket>,
    ack: [u8; UDP_HELLO_SIZE],
    mut cancel: watch::Receiver<bool>,
) {
    let mut buf = [0u8; UDP_PAYLOAD_SIZE + 100];

    let cancel_changed = async move {
        loop {
            if *cancel.borrow() {
                return;
            }
            if cancel.changed().await.is_err() {
                return;
            }
        }
    };
    tokio::pin!(cancel_changed);

    loop {
        tokio::select! {
            result = socket.recv(&mut buf) => {
                if let Ok(n) = result
                    && let Some(pkt) = UdpHelloPacket::decode(&buf[..n])
                    && pkt.kind == UDP_HELLO_KIND_HELLO
                {
                    let _ = socket.send(&ack).await;
                }
            }
            _ = &mut cancel_changed => break,
        }
    }
}

/// UDP packet header
/// [seq: u64][timestamp_us: u64][payload...]
///
/// Timestamps are relative to test start (not wall clock) to avoid
/// clock synchronization issues between client and server.
#[derive(Debug, Clone, Copy)]
pub struct UdpPacketHeader {
    pub sequence: u64,
    pub timestamp_us: u64,
}

impl UdpPacketHeader {
    pub fn encode(&self, buffer: &mut [u8]) -> bool {
        if buffer.len() < UDP_HEADER_SIZE {
            return false;
        }
        buffer[0..8].copy_from_slice(&self.sequence.to_be_bytes());
        buffer[8..16].copy_from_slice(&self.timestamp_us.to_be_bytes());
        true
    }

    pub fn decode(buffer: &[u8]) -> Option<Self> {
        if buffer.len() < UDP_HEADER_SIZE {
            return None;
        }
        let sequence = u64::from_be_bytes(buffer[0..8].try_into().ok()?);
        let timestamp_us = u64::from_be_bytes(buffer[8..16].try_into().ok()?);
        Some(Self {
            sequence,
            timestamp_us,
        })
    }
}

#[derive(Debug, Clone)]
pub struct UdpSendStats {
    pub packets_sent: u64,
    pub bytes_sent: u64,
}

/// Receiver-side jitter calculator per RFC 3550
pub struct JitterCalculator {
    last_send_time: Option<u64>,
    last_recv_time: Option<Instant>,
    jitter: f64,
    jitter_max: f64,
}

impl JitterCalculator {
    pub fn new() -> Self {
        Self {
            last_send_time: None,
            last_recv_time: None,
            jitter: 0.0,
            jitter_max: 0.0,
        }
    }

    /// Update jitter using RFC 3550 algorithm:
    /// D(i) = (R(i) - R(i-1)) - (S(i) - S(i-1))
    /// J(i) = J(i-1) + (|D(i)| - J(i-1)) / 16
    pub fn update(&mut self, send_time_us: u64, recv_time: Instant) -> f64 {
        if let (Some(last_send), Some(last_recv)) = (self.last_send_time, self.last_recv_time) {
            // Wire timestamps are untrusted u64 values. Wide signed deltas
            // preserve receive-order jitter without overflowing at either end.
            let recv_diff = recv_time.saturating_duration_since(last_recv).as_micros() as i128;
            let send_diff = i128::from(send_time_us) - i128::from(last_send);
            let d = (recv_diff - send_diff).abs() as f64;

            self.jitter += (d - self.jitter) / 16.0;
            if self.jitter > self.jitter_max {
                self.jitter_max = self.jitter;
            }
        }

        self.last_send_time = Some(send_time_us);
        self.last_recv_time = Some(recv_time);
        self.jitter
    }

    pub fn jitter_ms(&self) -> f64 {
        self.jitter / 1000.0
    }

    pub fn jitter_max_ms(&self) -> f64 {
        self.jitter_max / 1000.0
    }
}

impl Default for JitterCalculator {
    fn default() -> Self {
        Self::new()
    }
}

/// Number of sequence positions retained for duplicate/reordering detection.
/// One bit per position uses 8 KiB per stream, independent of test duration.
const PACKET_TRACKER_WINDOW: usize = 65_536;
const PACKET_TRACKER_WORD_BITS: usize = u64::BITS as usize;

/// Receiver-side packet tracker for loss and out-of-order detection.
///
/// Unique late packets repair gaps within the retained sequence window.
/// Older packets cannot be distinguished from duplicates and are ignored;
/// gaps outside the window remain counted as lost. Unseen trailing packets
/// cannot be inferred without an authoritative sender count.
///
/// A forward jump that would expire the whole window is held until a second
/// packet lands within a window of it, so one stray or spoofed datagram with
/// a far-future sequence cannot strand every real packet behind it as too
/// old. A real outage confirms on the next packet after recovery and the
/// held packet is replayed, so its gap is still counted in full.
pub struct PacketTracker {
    received: u64,
    lost: u64,
    out_of_order: u64,
    highest_seen: Option<u64>,
    unconfirmed_jump: Option<u64>,
    seen: Box<[u64]>,
}

impl PacketTracker {
    pub fn new() -> Self {
        Self {
            received: 0,
            lost: 0,
            out_of_order: 0,
            highest_seen: None,
            unconfirmed_jump: None,
            seen: vec![0; PACKET_TRACKER_WINDOW / PACKET_TRACKER_WORD_BITS].into_boxed_slice(),
        }
    }

    pub fn record(&mut self, sequence: u64) {
        self.record_unique(sequence);
    }

    /// Returns true only for a new packet whose sequence can still be tracked.
    fn record_unique(&mut self, sequence: u64) -> bool {
        // Distance past the high-water mark (sequence numbering starts at 0).
        let jump = match self.highest_seen {
            Some(highest) => sequence.saturating_sub(highest),
            None => sequence.saturating_add(1),
        };
        if jump > PACKET_TRACKER_WINDOW as u64 && !self.confirm_jump(sequence) {
            return false;
        }
        self.record_tracked(sequence)
    }

    /// Accept a far jump only when it agrees with the previously held one.
    /// ponytail: two strays within a window of each other still confirm;
    /// authenticated data packets are the upgrade if that ever matters.
    fn confirm_jump(&mut self, sequence: u64) -> bool {
        match self.unconfirmed_jump.take() {
            Some(held) if held.abs_diff(sequence) < PACKET_TRACKER_WINDOW as u64 => {
                self.record_tracked(held);
                true
            }
            _ => {
                self.unconfirmed_jump = Some(sequence);
                false
            }
        }
    }

    fn record_tracked(&mut self, sequence: u64) -> bool {
        let index = sequence as usize & (PACKET_TRACKER_WINDOW - 1);
        let word = index / PACKET_TRACKER_WORD_BITS;
        let bit = 1u64 << (index % PACKET_TRACKER_WORD_BITS);

        match self.highest_seen {
            None => {
                // Keep the initial gap: sequence numbering starts at zero.
                self.lost = sequence;
                self.highest_seen = Some(sequence);
            }
            Some(highest) if sequence > highest => {
                self.advance_window(highest, sequence);
                let gap = sequence - highest - 1;
                self.lost = self.lost.saturating_add(gap);
                self.highest_seen = Some(sequence);
            }
            Some(highest) => {
                if highest - sequence >= PACKET_TRACKER_WINDOW as u64 || self.seen[word] & bit != 0
                {
                    return false;
                }
                self.lost = self.lost.saturating_sub(1);
                self.out_of_order = self.out_of_order.saturating_add(1);
            }
        }

        self.seen[word] |= bit;
        self.received = self.received.saturating_add(1);
        true
    }

    fn advance_window(&mut self, previous: u64, next: u64) {
        let distance = next - previous;
        if distance >= PACKET_TRACKER_WINDOW as u64 {
            self.seen.fill(0);
            return;
        }
        // `previous + 1` is safe because a strictly greater `next` exists.
        let start = (previous + 1) as usize & (PACKET_TRACKER_WINDOW - 1);
        let end = start + distance as usize;
        self.clear_range(start, end.min(PACKET_TRACKER_WINDOW));
        if end > PACKET_TRACKER_WINDOW {
            self.clear_range(0, end - PACKET_TRACKER_WINDOW);
        }
    }

    /// Clear entering positions in bulk while retaining the partial words at
    /// the oldest window edge. Work is bounded by the bitmap, not the jump.
    fn clear_range(&mut self, start: usize, end: usize) {
        if start == end {
            return;
        }
        let first = start / PACKET_TRACKER_WORD_BITS;
        let last = (end - 1) / PACKET_TRACKER_WORD_BITS;
        let first_mask = u64::MAX << (start % PACKET_TRACKER_WORD_BITS);
        let end_bit = end % PACKET_TRACKER_WORD_BITS;
        let last_mask = if end_bit == 0 {
            u64::MAX
        } else {
            (1u64 << end_bit) - 1
        };
        if first == last {
            self.seen[first] &= !(first_mask & last_mask);
        } else {
            self.seen[first] &= !first_mask;
            self.seen[first + 1..last].fill(0);
            self.seen[last] &= !last_mask;
        }
    }

    pub fn stats(&self, packets_sent: u64) -> (u64, u64, f64) {
        let lost = self.lost;
        let ooo = self.out_of_order;
        let loss_percent = if packets_sent > 0 {
            (lost as f64 / packets_sent as f64) * 100.0
        } else {
            0.0
        };
        (lost, ooo, loss_percent)
    }
}

impl Default for PacketTracker {
    fn default() -> Self {
        Self::new()
    }
}

/// Bound timer wakeups for paced UDP. Tokio cannot reliably service the
/// ~89,000 wakes/second that a 1 Gbps, 1400-byte stream would otherwise
/// request, so faster streams send a small calculated batch per tick.
const MAX_PACING_TICKS_PER_SEC: u64 = 10_000;
/// Keep even absurd configured bitrates interruptible. Real rates hit socket
/// backpressure well before this cap; it only guards the inner burst loop.
const MAX_PACED_PACKETS_PER_TICK: u64 = 1024;
/// Unlimited mode yields after this many datagrams so cancellation and other
/// Tokio tasks remain responsive.
const UNLIMITED_BURST_PACKETS: u64 = 100;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct PacingSchedule {
    interval: Duration,
    packets_per_tick: u64,
}

/// Build a smooth paced-send schedule while capping timer wake frequency.
/// The old fixed breakpoint sent one packet per wake through 100,000 pps,
/// then jumped straight to 100-packet bursts. At 1400 bytes that put the
/// default 1 Gbps target below the batching threshold, where timer overhead
/// held localhost delivery near 630 Mbps, while requesting 1.2 Gbps crossed
/// the threshold and delivered the full rate. Calculated batches remove that
/// inversion and stay much smaller than the old high-rate burst.
fn pacing_schedule(target_bitrate: u64, packet_size: usize) -> PacingSchedule {
    debug_assert!(target_bitrate > 0);
    let bits_per_packet = (packet_size as u64).saturating_mul(8);
    let bitrate_per_tick = bits_per_packet.saturating_mul(MAX_PACING_TICKS_PER_SEC);
    let packets_per_tick = target_bitrate
        .div_ceil(bitrate_per_tick)
        .clamp(1, MAX_PACED_PACKETS_PER_TICK);

    // Round the interval up to the next nanosecond so integer conversion can
    // never make the sender run faster than requested. u128 keeps extreme
    // user-provided bitrates and future packet sizes overflow-safe.
    let interval_nanos = ((packets_per_tick as u128)
        .saturating_mul(bits_per_packet as u128)
        .saturating_mul(1_000_000_000))
    .div_ceil(target_bitrate as u128)
    .clamp(1, u64::MAX as u128) as u64;

    PacingSchedule {
        interval: Duration::from_nanos(interval_nanos),
        packets_per_tick,
    }
}

/// Suppression window for send errors near the test deadline. The server
/// tears down its socket at its own deadline, which can precede ours by
/// the path RTT plus scheduling slop (mirrors tcp.rs SEND_TEARDOWN_GRACE).
const SEND_TEARDOWN_GRACE: Duration = Duration::from_millis(250);

/// True when a failed send should be logged at debug instead of warn: the
/// test is already cancelled or within [`SEND_TEARDOWN_GRACE`] of its
/// deadline, so the peer closing its socket first (the kernel latches
/// ECONNREFUSED onto a connected UDP socket) is expected teardown, not a
/// failure. A mid-test send error still warns.
fn is_teardown_send_error(
    cancelled: bool,
    is_infinite: bool,
    now: Instant,
    deadline: Instant,
) -> bool {
    cancelled || (!is_infinite && now + SEND_TEARDOWN_GRACE >= deadline)
}

/// One warn per stream for repeated send failures; the first already warned
/// individually and the rest were logged at debug.
fn warn_send_error_summary(stats: &StreamStats) {
    if let Some(errors) = stats.udp_send_errors().filter(|e| e.count > 1) {
        warn!(
            "UDP send errors: {} total (last: {})",
            errors.count, errors.last_error
        );
    }
}

/// Send UDP data at a paced rate (or unlimited if target_bitrate is 0)
///
/// If `target` is Some, uses send_to() for unconnected sockets (server reverse mode).
/// If `target` is None, uses send() for connected sockets (client mode).
#[allow(clippy::too_many_arguments)]
pub async fn send_udp_paced(
    socket: Arc<UdpSocket>,
    target: Option<SocketAddr>,
    target_bitrate: u64,
    packet_size: usize,
    duration: Duration,
    stats: Arc<StreamStats>,
    mut cancel: watch::Receiver<bool>,
    mut pause: watch::Receiver<bool>,
    random_payload: bool,
    budget: Option<Arc<crate::budget::ByteBudget>>,
) -> anyhow::Result<UdpSendStats> {
    validate_payload_size(packet_size)?;

    // Unlimited mode: no pacing, send as fast as possible
    if target_bitrate == 0 {
        return send_udp_unlimited(
            socket,
            target,
            packet_size,
            duration,
            stats,
            cancel,
            pause,
            random_payload,
            budget,
        )
        .await;
    }

    let bits_per_packet = (packet_size * 8) as u64;
    let packets_per_sec_f64 = target_bitrate as f64 / bits_per_packet as f64;
    let PacingSchedule {
        interval: pacing_interval,
        packets_per_tick,
    } = pacing_schedule(target_bitrate, packet_size);

    debug!(
        "UDP pacing: {:.0} packets/sec, interval {:?}, {} packets/tick",
        packets_per_sec_f64, pacing_interval, packets_per_tick
    );

    let mut sequence: u64 = 0;
    let mut bytes_sent: u64 = 0;
    let mut budget_spent = false;
    let mut ticker = {
        let mut t = interval(pacing_interval);
        // Skip stale ticks accumulated during pause so the sender doesn't
        // burst-fire after resume (LAN-160 #14).
        t.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        t
    };
    let start = Instant::now();
    let mut deadline = start + duration;
    let is_infinite = duration == Duration::ZERO;

    let mut packet = vec![0u8; packet_size];
    if random_payload {
        rand::RngExt::fill(&mut rand::rng(), &mut packet[UDP_HEADER_SIZE..]);
    }

    loop {
        if *cancel.borrow() {
            debug!("UDP send cancelled");
            break;
        }
        if crate::pause::is_paused(&pause) {
            let (cancelled, paused) =
                crate::pause::wait_while_paused_timed(&mut pause, &mut cancel).await;
            if cancelled {
                break;
            }
            // Extend the deadline by the time spent paused (LAN-230)
            deadline += paused;
            // Reset the pacing ticker after resume so the first post-pause
            // tick fires a full interval from now, not immediately (the
            // queued tick from before pause would fire instantly and cause
            // a burst).  Combined with MissedTickBehavior::Skip, this
            // ensures no burst after resume (LAN-160 #14).
            ticker.reset();
            continue;
        }

        // Wait for ticker, interruptible by cancel/pause
        tokio::select! {
            biased;
            res = cancel.changed() => {
                if res.is_err() || *cancel.borrow() { break; }
                continue;
            }
            _ = pause.changed(), if crate::pause::channel_is_open(&pause) => { continue; } // re-check at top
            _ = ticker.tick() => {}
        }

        // Duration::ZERO means infinite - only check deadline if finite
        if !is_infinite && Instant::now() >= deadline {
            break;
        }

        // Send packets_per_tick packets in this burst
        for _ in 0..packets_per_tick {
            if *cancel.borrow() || crate::pause::is_paused(&pause) {
                break;
            }
            if !is_infinite && Instant::now() >= deadline {
                break;
            }

            let Some(send_len) = claim_datagram(budget.as_ref(), packet_size) else {
                budget_spent = true;
                break;
            };

            // Build packet with relative timestamp
            let now_us = start.elapsed().as_micros() as u64;
            let header = UdpPacketHeader {
                sequence,
                timestamp_us: now_us,
            };
            header.encode(&mut packet);

            let result = match target {
                Some(addr) => socket.send_to(&packet[..send_len], addr).await,
                None => socket.send(&packet[..send_len]).await,
            };

            match result {
                Ok(n) => {
                    stats.add_bytes_sent(n as u64);
                    bytes_sent += n as u64;
                    sequence += 1;
                }
                Err(e) => {
                    if is_teardown_send_error(
                        *cancel.borrow(),
                        is_infinite,
                        Instant::now(),
                        deadline,
                    ) {
                        debug!("UDP send error during teardown: {}", e);
                    } else if stats.record_udp_send_error(&e) {
                        warn!("UDP send error: {}", e);
                    } else {
                        debug!("UDP send error: {}", e);
                    }
                    crate::budget::refund_unwritten(budget.as_ref(), send_len, 0);
                    // Continue sending - UDP is best-effort
                }
            }
        }

        if budget_spent {
            debug!("UDP byte budget spent after {} packets", sequence);
            break;
        }
    }

    warn_send_error_summary(&stats);
    Ok(UdpSendStats {
        packets_sent: sequence,
        bytes_sent,
    })
}

/// Reserve one datagram's worth of a `-n` budget. `None` means the budget is
/// spent — including a leftover too small to carry a packet header, which is
/// dropped rather than refunded so the loop terminates. UDP therefore rounds
/// the budget down to a datagram boundary, with a short final datagram
/// carrying whatever remains above one header.
fn claim_datagram(
    budget: Option<&Arc<crate::budget::ByteBudget>>,
    packet_size: usize,
) -> Option<usize> {
    match crate::budget::claim_or_full(budget, packet_size) {
        n if n >= UDP_HEADER_SIZE => Some(n),
        _ => None,
    }
}

/// Send UDP data as fast as possible (unlimited mode)
#[allow(clippy::too_many_arguments)]
async fn send_udp_unlimited(
    socket: Arc<UdpSocket>,
    target: Option<SocketAddr>,
    packet_size: usize,
    duration: Duration,
    stats: Arc<StreamStats>,
    mut cancel: watch::Receiver<bool>,
    mut pause: watch::Receiver<bool>,
    random_payload: bool,
    budget: Option<Arc<crate::budget::ByteBudget>>,
) -> anyhow::Result<UdpSendStats> {
    let mut sequence: u64 = 0;
    let mut bytes_sent: u64 = 0;
    let mut budget_spent = false;
    let start = Instant::now();
    let mut deadline = start + duration;
    let is_infinite = duration == Duration::ZERO;
    let mut packet = vec![0u8; packet_size];
    if random_payload {
        rand::RngExt::fill(&mut rand::rng(), &mut packet[UDP_HEADER_SIZE..]);
    }

    debug!("UDP unlimited mode: sending as fast as possible");

    // Send in tight loop with periodic yield and cancel check
    loop {
        if *cancel.borrow() {
            debug!("UDP send cancelled");
            break;
        }
        if crate::pause::is_paused(&pause) {
            let (cancelled, paused) =
                crate::pause::wait_while_paused_timed(&mut pause, &mut cancel).await;
            if cancelled {
                break;
            }
            // Extend the deadline by the time spent paused (LAN-230)
            deadline += paused;
            continue;
        }

        // Duration::ZERO means infinite - only check deadline if finite
        if !is_infinite && Instant::now() >= deadline {
            break;
        }

        // Send a burst of packets before yielding
        for _ in 0..UNLIMITED_BURST_PACKETS {
            if *cancel.borrow() || crate::pause::is_paused(&pause) {
                break;
            }
            if !is_infinite && Instant::now() >= deadline {
                break;
            }

            let Some(send_len) = claim_datagram(budget.as_ref(), packet_size) else {
                budget_spent = true;
                break;
            };

            let now_us = start.elapsed().as_micros() as u64;
            let header = UdpPacketHeader {
                sequence,
                timestamp_us: now_us,
            };
            header.encode(&mut packet);

            let result = match target {
                Some(addr) => socket.send_to(&packet[..send_len], addr).await,
                None => socket.send(&packet[..send_len]).await,
            };

            match result {
                Ok(n) => {
                    stats.add_bytes_sent(n as u64);
                    bytes_sent += n as u64;
                    sequence += 1;
                }
                Err(e) => {
                    if is_teardown_send_error(
                        *cancel.borrow(),
                        is_infinite,
                        Instant::now(),
                        deadline,
                    ) {
                        debug!("UDP send error during teardown: {}", e);
                    } else if stats.record_udp_send_error(&e) {
                        warn!("UDP send error: {}", e);
                    } else {
                        debug!("UDP send error: {}", e);
                    }
                    crate::budget::refund_unwritten(budget.as_ref(), send_len, 0);
                }
            }
        }

        if budget_spent {
            debug!("UDP byte budget spent after {} packets", sequence);
            break;
        }

        // Yield to allow other tasks (cancel checks, etc.)
        tokio::task::yield_now().await;
    }

    warn_send_error_summary(&stats);
    Ok(UdpSendStats {
        packets_sent: sequence,
        bytes_sent,
    })
}

/// Receive UDP data and track statistics
///
/// `single_port_ack` is `Some` only on the server side of a single-port
/// UDP test (issue #63), where the socket is connected to the client:
/// retried stream hellos arriving here (the kernel routes them past the
/// shared wildcard once the connected socket exists) are answered with
/// the precomputed ack instead of being counted, and feedback packets
/// use `send()` rather than `send_to()` — macOS rejects `send_to` on a
/// connected UDP socket with EISCONN.
pub async fn receive_udp(
    socket: Arc<UdpSocket>,
    stats: Arc<StreamStats>,
    mut cancel: watch::Receiver<bool>,
    mut pause: watch::Receiver<bool>,
    feedback_enabled: bool,
    single_port_ack: Option<[u8; UDP_HELLO_SIZE]>,
) -> anyhow::Result<(UdpStats, u64)> {
    // Accept every supported payload without truncation, including jumbo
    // datagrams and short final datagrams from byte-budget tests.
    let mut buffer = vec![0u8; MAX_UDP_PAYLOAD_SIZE];
    let mut jitter_calc = JitterCalculator::new();
    let mut packet_tracker = PacketTracker::new();
    let mut packet_size = None;
    let mut last_recv = Instant::now();
    // Most-recently-observed client source address. The first successful
    // recv populates it; later recvs refresh it (handles NAT rebinding
    // mid-test as a side benefit). Feedback emission targets this address.
    let mut last_client_addr: Option<SocketAddr> = None;

    // Keep one inactivity timer for the life of the receive task. Do not
    // reset it for every datagram: at high packet rates that would still
    // churn Tokio's timer wheel. When it wakes, either the stream really is
    // idle or we re-arm it for the remainder since the most recent packet.
    let inactivity_timer = tokio::time::sleep(UDP_INACTIVITY_TIMEOUT);
    tokio::pin!(inactivity_timer);
    let mut pause_channel_open = crate::pause::channel_is_open(&pause);

    // 2 Hz feedback emission. Skip missed ticks: every feedback packet
    // carries cumulative counts, so the next tick is self-correcting and
    // there's no value in sending a backlog of stale snapshots when the
    // task wakes up after a busy period.
    let mut feedback_timer = if feedback_enabled {
        let mut t = tokio::time::interval(Duration::from_millis(500));
        // First tick fires immediately; advance past it so we don't emit
        // before any data has arrived.
        t.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        Some(t)
    } else {
        None
    };

    loop {
        if *cancel.borrow() {
            debug!("UDP receive cancelled");
            break;
        }

        if crate::pause::is_paused(&pause) {
            if crate::pause::wait_while_paused(&mut pause, &mut cancel).await {
                break;
            }
            last_recv = Instant::now();
            pause_channel_open = crate::pause::channel_is_open(&pause);
            inactivity_timer
                .as_mut()
                .reset(tokio::time::Instant::now() + UDP_INACTIVITY_TIMEOUT);
            continue;
        }

        // Use recv_from for unconnected sockets, recv for connected
        let recv_future = socket.recv_from(&mut buffer);

        tokio::select! {
            result = recv_future => {
                match result {
                    Ok((n, addr)) => {
                        let recv_time = Instant::now();
                        last_recv = recv_time;
                        last_client_addr = Some(addr);

                        // Length-first demux: a 36-byte packet whose first
                        // four bytes spell "XFRF" is a feedback packet that
                        // shouldn't be on this socket (server doesn't emit
                        // feedback to itself; client's feedback recv lives
                        // in a separate function). Skip it without feeding
                        // into the data tracker — its sequence-bytes would
                        // record as a wildly-out-of-band number and inflate
                        // PacketTracker's lost count by ~6e18. Also do not
                        // count it toward bytes_received: feedback is a
                        // control-plane sideband and bytes_received tracks
                        // test-data wire bandwidth. Defense-in-depth for
                        // any future change that lets feedback land on a
                        // shared socket.
                        let is_feedback = n == UDP_FEEDBACK_SIZE
                            && buffer[0..4] == UDP_FEEDBACK_MAGIC;
                        if is_feedback {
                            continue;
                        }
                        // Single-port hello lane (issue #63): skipped from all
                        // accounting on both ends for the same reasons as
                        // feedback — a 24-byte hello/ack would otherwise decode
                        // as a data header with a wild sequence number. On the
                        // server (ack configured), a retried hello also gets
                        // re-acked here in case the dispatcher's ack was lost.
                        if n == UDP_HELLO_SIZE && buffer[0..4] == UDP_HELLO_MAGIC {
                            if let Some(ack) = single_port_ack
                                && UdpHelloPacket::decode(&buffer[..n])
                                    .is_some_and(|pkt| pkt.kind == UDP_HELLO_KIND_HELLO)
                                && let Err(e) = socket.send(&ack).await
                            {
                                debug!("single-port hello re-ack failed: {}", e);
                            }
                            continue;
                        }
                        stats.add_bytes_received(n as u64);

                        if let Some(header) = UdpPacketHeader::decode(&buffer[..n]) {
                            packet_size = Some(packet_size.unwrap_or(0).max(n as u32));
                            // Only count valid xfr packets toward UDP loss
                            // accounting (both live and final). A short or
                            // foreign datagram still adds to `bytes_received`
                            // because it consumed wire, but counting it
                            // toward the loss denominator would understate
                            // the loss percent — the denominator must match
                            // what the sequence tracker actually saw.
                            if !packet_tracker.record_unique(header.sequence) {
                                continue;
                            }
                            stats.set_udp_progress(
                                packet_tracker.received,
                                packet_tracker.lost,
                            );

                            // Update live stats for interval reporting
                            let jitter_us = jitter_calc.update(header.timestamp_us, recv_time);
                            stats.set_udp_jitter_us(jitter_us as u64);

                        }
                    }
                    Err(e) => {
                        warn!("UDP receive error: {}", e);
                    }
                }
            }
            result = cancel.changed() => {
                if result.is_err() || *cancel.borrow() {
                    debug!("UDP receive cancelled");
                    break;
                }
            }
            result = pause.changed(), if pause_channel_open => {
                if result.is_err() {
                    // A closed pause channel means "not paused". Disable
                    // this always-ready arm so the receive loop cannot spin.
                    pause_channel_open = false;
                }
                // On a real change, restart the loop so the shared pause
                // helper can wait for resume while still observing cancel.
            }
            _ = &mut inactivity_timer => {
                let inactive_for = last_recv.elapsed();
                if inactive_for >= UDP_INACTIVITY_TIMEOUT {
                    debug!(
                        "UDP receive timeout: no packets for {:?}",
                        UDP_INACTIVITY_TIMEOUT
                    );
                    break;
                }
                inactivity_timer.as_mut().reset(
                    tokio::time::Instant::now()
                        + UDP_INACTIVITY_TIMEOUT.saturating_sub(inactive_for),
                );
            }
            _ = async { feedback_timer.as_mut().unwrap().tick().await }, if feedback_timer.is_some() => {
                // Emit a receiver-progress feedback packet back to the
                // sender. Gates: must have a peer address from at least
                // one prior recv, and must have decoded at least one
                // valid xfr packet (otherwise we're talking to phantom
                // traffic that doesn't expect feedback).
                if let Some(addr) = last_client_addr
                    && packet_tracker.received > 0
                {
                    let snap = stats.udp_progress_snapshot();
                    let elapsed_ms = stats.start_time.elapsed().as_millis() as u64;
                    let pkt = UdpFeedbackPacket {
                        stream_id: stats.stream_id as u16,
                        elapsed_ms,
                        packets_received: snap.packets_received,
                        packets_lost: snap.packets_lost,
                    };
                    let mut buf = [0u8; UDP_FEEDBACK_SIZE];
                    if pkt.encode(&mut buf) {
                        // Connected single-port sockets must use send():
                        // the address equals the connected peer anyway,
                        // and macOS rejects send_to with EISCONN.
                        let result = if single_port_ack.is_some() {
                            socket.send(&buf).await
                        } else {
                            socket.send_to(&buf, addr).await
                        };
                        if let Err(e) = result {
                            // Non-fatal: ICMP port-unreachable from a
                            // closed peer surfaces as ConnectionRefused
                            // here. Log at debug; next tick retries.
                            debug!(
                                "UDP feedback send to {} failed: {}",
                                addr, e
                            );
                        }
                    }
                }
            }
        }
    }

    let packets_received = packet_tracker.received;
    let (lost, out_of_order, _) =
        packet_tracker.stats(packets_received.saturating_add(packet_tracker.lost));
    let packets_sent = packets_received.saturating_add(lost);
    let loss_percent = if packets_sent > 0 {
        (lost as f64 / packets_sent as f64) * 100.0
    } else {
        0.0
    };

    Ok((
        UdpStats {
            packets_sent,
            packets_received,
            lost,
            lost_percent: loss_percent,
            jitter_ms: jitter_calc.jitter_ms(),
            out_of_order,
            jitter_max_ms: Some(jitter_calc.jitter_max_ms()),
            packet_size,
        },
        packets_sent,
    ))
}

/// Store a feedback snapshot only when it belongs to this socket's stream
/// and is at least as fresh as the slot's current cumulative denominator.
fn store_udp_feedback(
    slots: &mut [UdpIntervalProgress],
    expected_stream_index: usize,
    packet: UdpFeedbackPacket,
) -> bool {
    if usize::from(packet.stream_id) != expected_stream_index {
        return false;
    }

    let Some(slot) = slots.get_mut(expected_stream_index) else {
        return false;
    };
    let next = packet.to_progress();
    if !next.is_at_least_as_fresh_as(slot) {
        return false;
    }

    *slot = next;
    true
}

/// Receive `UdpFeedbackPacket`s from the server on the client's
/// upload-mode UDP socket.
///
/// Spawned alongside the client-side `send_udp_paced` task so the
/// connected socket carries data in one direction and feedback in the
/// other. Length-first demux: valid 36-byte feedback packets for this
/// stream are written into its aggregator slot for the per-test 1 Hz
/// consumer task to pick up. Anything else (including unexpected data
/// echoes or random short runts) is silently discarded — the client in
/// upload mode owns no PacketTracker for this socket and must not
/// pollute throughput or loss accounting from feedback noise.
///
/// Drains the socket for up to ~100 ms after `cancel` fires before
/// exiting, so feedback packets that landed just before the data
/// streams stopped are still observed in the per-test summary.
pub async fn receive_udp_feedback_only(
    socket: Arc<UdpSocket>,
    aggregator: crate::client::UdpFeedbackAggregator,
    stream_index: usize,
    mut cancel: watch::Receiver<bool>,
) -> anyhow::Result<()> {
    let mut buffer = vec![0u8; UDP_PAYLOAD_SIZE + 100];

    let cancel_changed = async move {
        // Wait until cancel becomes true. `changed()` returns on any
        // value transition, so loop until we see the actual `true`.
        loop {
            if *cancel.borrow() {
                return;
            }
            if cancel.changed().await.is_err() {
                return;
            }
        }
    };
    tokio::pin!(cancel_changed);

    loop {
        tokio::select! {
            result = socket.recv(&mut buffer) => {
                match result {
                    Ok(n) => {
                        // Length-first demux. Anything not exactly 36 bytes
                        // is not a feedback packet; ignore it.
                        if n != UDP_FEEDBACK_SIZE {
                            continue;
                        }
                        if let Some(pkt) = UdpFeedbackPacket::decode(&buffer[..n]) {
                            let mut slots = aggregator.lock();
                            if !store_udp_feedback(&mut slots, stream_index, pkt) {
                                debug!(
                                    "ignored stale or mismatched UDP feedback for stream {} (packet stream {})",
                                    stream_index, pkt.stream_id
                                );
                            }
                        }
                    }
                    Err(e) => {
                        debug!("UDP feedback recv error on stream {}: {}", stream_index, e);
                    }
                }
            }
            _ = &mut cancel_changed => {
                // Cancel fired. Drain for ~100ms so a final in-flight
                // feedback packet can still update our slot before the
                // consumer task stops emitting and the test summary
                // renders.
                let drain_deadline = Instant::now() + Duration::from_millis(100);
                while Instant::now() < drain_deadline {
                    let remaining = drain_deadline.saturating_duration_since(Instant::now());
                    tokio::select! {
                        result = socket.recv(&mut buffer) => {
                            if let Ok(n) = result
                                && n == UDP_FEEDBACK_SIZE
                                && let Some(pkt) = UdpFeedbackPacket::decode(&buffer[..n])
                            {
                                let mut slots = aggregator.lock();
                                if !store_udp_feedback(&mut slots, stream_index, pkt) {
                                    debug!(
                                        "ignored stale or mismatched final UDP feedback for stream {} (packet stream {})",
                                        stream_index, pkt.stream_id
                                    );
                                }
                            }
                        }
                        _ = tokio::time::sleep(remaining) => break,
                    }
                }
                break;
            }
        }
    }
    Ok(())
}

/// Server side of `--probe-mtu` (issue #64, `mtu_probe_v1`): answer each
/// incoming `XFRP` probe with a small ack plus a same-size echo, both
/// addressed to wherever the probe came from. The ack is header-sized so
/// it survives nearly any path and proves the forward direction; the
/// echo is padded to the probe's declared size and proves the reverse
/// direction. Runs until `cancel` fires (the control channel owns test
/// lifetime, same as the bulk handlers).
///
/// The echo is sent with don't-fragment set by the caller on the socket;
/// an oversized echo then dies at the constraining hop instead of being
/// fragmented into deceptive success. EMSGSIZE on the echo send means
/// the server's own interface MTU is the reverse-path limit — that's a
/// legitimate probe outcome, not an error, so it's logged at debug and
/// the ack still goes out.
///
/// `single_port_ack` is `Some` when the probe runs in single-port mode
/// (issue #63): the socket is connected, so replies use `send()` (macOS
/// rejects `send_to` on connected sockets), and retried stream hellos
/// that land here after the dispatcher's ack was lost get re-acked so
/// the client's handshake can complete.
pub async fn respond_mtu_probes(
    socket: Arc<UdpSocket>,
    mut cancel: watch::Receiver<bool>,
    single_port_ack: Option<[u8; UDP_HELLO_SIZE]>,
) -> anyhow::Result<()> {
    use crate::probe::{PROBE_KIND_ACK, PROBE_KIND_ECHO, PROBE_KIND_PROBE, ProbePacket};

    let mut recv_buf = vec![0u8; crate::probe::MAX_PROBE_PAYLOAD + 100];
    let mut send_buf = vec![0u8; crate::probe::MAX_PROBE_PAYLOAD];

    let cancel_changed = async move {
        loop {
            if *cancel.borrow() {
                return;
            }
            if cancel.changed().await.is_err() {
                return;
            }
        }
    };
    tokio::pin!(cancel_changed);

    loop {
        tokio::select! {
            result = socket.recv_from(&mut recv_buf) => {
                let (n, from) = match result {
                    Ok(v) => v,
                    Err(e) => {
                        debug!("MTU probe recv error: {}", e);
                        continue;
                    }
                };
                if let Some(hello_ack) = single_port_ack
                    && UdpHelloPacket::decode(&recv_buf[..n])
                        .is_some_and(|pkt| pkt.kind == UDP_HELLO_KIND_HELLO)
                {
                    if let Err(e) = socket.send(&hello_ack).await {
                        debug!("single-port hello re-ack failed during probe: {}", e);
                    }
                    continue;
                }
                let Some(pkt) = ProbePacket::decode(&recv_buf[..n]) else {
                    continue;
                };
                if pkt.kind != PROBE_KIND_PROBE {
                    continue;
                }
                // Connected single-port sockets must reply with send():
                // `from` equals the connected peer, and macOS rejects
                // send_to on a connected socket with EISCONN.
                let connected = single_port_ack.is_some();
                let ack = ProbePacket {
                    kind: PROBE_KIND_ACK,
                    seq: pkt.seq,
                    declared_size: pkt.declared_size,
                };
                if let Some(len) = ack.encode(&mut send_buf) {
                    let result = if connected {
                        socket.send(&send_buf[..len]).await
                    } else {
                        socket.send_to(&send_buf[..len], from).await
                    };
                    if let Err(e) = result {
                        debug!("MTU probe ack send failed (seq {}): {}", pkt.seq, e);
                    }
                }
                let echo = ProbePacket {
                    kind: PROBE_KIND_ECHO,
                    seq: pkt.seq,
                    declared_size: pkt.declared_size,
                };
                if let Some(len) = echo.encode(&mut send_buf) {
                    let result = if connected {
                        socket.send(&send_buf[..len]).await
                    } else {
                        socket.send_to(&send_buf[..len], from).await
                    };
                    if let Err(e) = result {
                        // EMSGSIZE here is the reverse path speaking, not a bug.
                        debug!("MTU probe echo send failed (seq {}, {}B): {}", pkt.seq, len, e);
                    }
                }
            }
            _ = &mut cancel_changed => break,
        }
    }
    Ok(())
}

/// Wait for the first packet from a client and return their address.
/// Used in server reverse mode to learn where to send data.
pub async fn wait_for_client(socket: &UdpSocket, timeout: Duration) -> anyhow::Result<SocketAddr> {
    // Bidir discovers the peer from its first bulk datagram. Windows
    // rejects oversized receives rather than truncating them.
    let mut buffer = vec![0u8; MAX_UDP_PAYLOAD_SIZE];

    tokio::select! {
        result = socket.recv_from(&mut buffer) => {
            match result {
                Ok((_, addr)) => {
                    debug!("UDP client connected from {}", addr);
                    Ok(addr)
                }
                Err(e) => Err(anyhow::anyhow!("Failed to receive from client: {}", e)),
            }
        }
        _ = tokio::time::sleep(timeout) => {
            Err(anyhow::anyhow!("Timeout waiting for UDP client"))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::Ordering;

    #[tokio::test]
    async fn custom_payloads_preserve_datagrams_and_byte_budgets() {
        for size in [UDP_HEADER_SIZE, 1368, 8192] {
            for bitrate in [0, 1_000_000] {
                let receiver = Arc::new(UdpSocket::bind("127.0.0.1:0").await.unwrap());
                let sender = Arc::new(UdpSocket::bind("127.0.0.1:0").await.unwrap());
                let addr = receiver.local_addr().unwrap();
                // Exercise connected and legacy send_to sockets.
                let target = if bitrate == 0 {
                    sender.connect(addr).await.unwrap();
                    None
                } else {
                    Some(addr)
                };
                let recv_stats = Arc::new(StreamStats::new(0));
                let observed = recv_stats.clone();
                let (cancel_tx, cancel) = watch::channel(false);
                let (_pause_tx, pause) = watch::channel(false);
                let recv_cancel = cancel.clone();
                let recv_pause = pause.clone();
                let recv = tokio::spawn(receive_udp(
                    receiver,
                    recv_stats,
                    recv_cancel,
                    recv_pause,
                    false,
                    None,
                ));
                let bytes = (size * 3 + UDP_HEADER_SIZE) as u64;
                let sent = send_udp_paced(
                    sender,
                    target,
                    bitrate,
                    size,
                    Duration::ZERO,
                    Arc::new(StreamStats::new(0)),
                    cancel,
                    pause,
                    true,
                    Some(crate::budget::ByteBudget::new(bytes)),
                )
                .await
                .unwrap();
                tokio::time::timeout(Duration::from_secs(2), async {
                    while observed.bytes_received.load(Ordering::Relaxed) < bytes {
                        tokio::task::yield_now().await;
                    }
                })
                .await
                .expect("all datagrams arrive intact");
                cancel_tx.send(true).unwrap();
                let (received, _) = recv.await.unwrap().unwrap();
                assert_eq!(sent.bytes_sent, bytes);
                assert_eq!(sent.packets_sent, 4);
                assert_eq!(received.packets_received, 4);
                assert_eq!(received.packet_size, Some(size as u32));
                assert_eq!(received.lost, 0);
            }
        }
    }

    #[test]
    fn test_packet_header_roundtrip() {
        let header = UdpPacketHeader {
            sequence: 12345,
            timestamp_us: 67890,
        };
        let mut buffer = [0u8; 16];
        assert!(header.encode(&mut buffer));

        let decoded = UdpPacketHeader::decode(&buffer).unwrap();
        assert_eq!(decoded.sequence, 12345);
        assert_eq!(decoded.timestamp_us, 67890);
    }

    /// Mid-test send failures must land in the stream's stats so the server
    /// can report them. An IPv4 socket cannot send to an IPv6 target, which
    /// fails every send deterministically without privileges or traffic.
    #[tokio::test]
    async fn mid_test_send_errors_are_counted() {
        for (bitrate, duration_ms, counted) in [
            (10_000_000, 500, true),
            (0, 500, true),
            // Shorter than SEND_TEARDOWN_GRACE: every failure is teardown.
            (10_000_000, 200, false),
            (0, 200, false),
        ] {
            let socket = Arc::new(UdpSocket::bind("127.0.0.1:0").await.unwrap());
            let test_stats = crate::stats::TestStats::new("t".into(), 1);
            let (_cancel_tx, cancel) = watch::channel(false);
            let (_pause_tx, pause) = watch::channel(false);
            let sent = send_udp_paced(
                socket,
                Some("[::1]:9".parse().unwrap()),
                bitrate,
                UDP_PAYLOAD_SIZE,
                Duration::from_millis(duration_ms),
                test_stats.streams[0].clone(),
                cancel,
                pause,
                false,
                None,
            )
            .await
            .unwrap();
            assert_eq!(sent.packets_sent, 0);
            let errors = test_stats.udp_send_errors();
            let case = format!("bitrate {bitrate}, {duration_ms} ms");
            if counted {
                let errors = errors.expect(&case);
                assert!(errors.count > 0, "{case}");
                assert!(!errors.last_error.is_empty(), "{case}");
            } else {
                assert_eq!(errors, None, "{case}");
            }
        }
    }

    #[test]
    fn teardown_send_error_gating() {
        let now = Instant::now();
        let far = now + Duration::from_secs(5);
        let near = now + Duration::from_millis(100);
        // Mid-test failure must still warn
        assert!(!is_teardown_send_error(false, false, now, far));
        // Cancelled: suppress
        assert!(is_teardown_send_error(true, false, now, far));
        // Within the grace window of the deadline: suppress
        assert!(is_teardown_send_error(false, false, now, near));
        // Infinite tests have no deadline to be near
        assert!(!is_teardown_send_error(false, true, now, far));
    }

    #[test]
    fn pacing_schedule_avoids_the_old_high_rate_cliff() {
        let bits_per_packet = (UDP_PAYLOAD_SIZE * 8) as u64;

        let hundred_mbps = pacing_schedule(100_000_000, UDP_PAYLOAD_SIZE);
        assert_eq!(hundred_mbps.packets_per_tick, 1);
        assert_eq!(hundred_mbps.interval, Duration::from_micros(112));

        let one_gbps = pacing_schedule(1_000_000_000, UDP_PAYLOAD_SIZE);
        assert_eq!(one_gbps.packets_per_tick, 9);
        assert_eq!(one_gbps.interval, Duration::from_nanos(100_800));

        // The old implementation jumped from one packet per tick to 100 at
        // 100,000 pps (1.12 Gbps for today's packet size). The new schedule
        // remains close on both sides: ten packets just below, eleven just
        // above, with an effective rate within 0.01% of the target.
        let old_breakpoint = bits_per_packet * 100_000;
        for target in [old_breakpoint - 1, old_breakpoint, old_breakpoint + 1] {
            let schedule = pacing_schedule(target, UDP_PAYLOAD_SIZE);
            assert!((10..=11).contains(&schedule.packets_per_tick));
            let scheduled_bitrate = schedule.packets_per_tick as f64 * bits_per_packet as f64
                / schedule.interval.as_secs_f64();
            let relative_error = (scheduled_bitrate - target as f64).abs() / target as f64;
            assert!(
                relative_error < 0.0001,
                "target {target}, scheduled {scheduled_bitrate}, error {relative_error}"
            );
        }
    }

    #[test]
    fn pacing_schedule_is_nonzero_and_bounded_at_extreme_rates() {
        let slowest = pacing_schedule(1, UDP_PAYLOAD_SIZE);
        assert_eq!(slowest.packets_per_tick, 1);
        assert_eq!(slowest.interval, Duration::from_secs(11_200));

        let fastest = pacing_schedule(u64::MAX, UDP_PAYLOAD_SIZE);
        assert_eq!(fastest.packets_per_tick, MAX_PACED_PACKETS_PER_TICK);
        assert!(fastest.interval >= Duration::from_nanos(1));
    }

    #[test]
    fn feedback_packet_roundtrip() {
        let pkt = UdpFeedbackPacket {
            stream_id: 7,
            elapsed_ms: 12_345,
            packets_received: 999_999,
            packets_lost: 4_242,
        };
        let mut buffer = [0u8; UDP_FEEDBACK_SIZE];
        assert!(pkt.encode(&mut buffer));
        let decoded = UdpFeedbackPacket::decode(&buffer).unwrap();
        assert_eq!(decoded, pkt);
    }

    #[test]
    fn feedback_packet_rejects_wrong_magic() {
        let pkt = UdpFeedbackPacket {
            stream_id: 0,
            elapsed_ms: 0,
            packets_received: 0,
            packets_lost: 0,
        };
        let mut buffer = [0u8; UDP_FEEDBACK_SIZE];
        assert!(pkt.encode(&mut buffer));
        // Corrupt the magic
        buffer[0..4].copy_from_slice(b"DATA");
        assert!(UdpFeedbackPacket::decode(&buffer).is_none());
    }

    #[test]
    fn feedback_packet_rejects_short_buffer() {
        let buffer = [0u8; UDP_FEEDBACK_SIZE - 1];
        assert!(UdpFeedbackPacket::decode(&buffer).is_none());
    }

    #[test]
    fn feedback_packet_rejects_oversize_buffer() {
        // A 36-byte feedback packet is fixed-size; a 37-byte buffer is
        // either a bug or an attempt to exploit length confusion.
        let buffer = [0u8; UDP_FEEDBACK_SIZE + 1];
        assert!(UdpFeedbackPacket::decode(&buffer).is_none());
    }

    #[test]
    fn feedback_packet_rejects_unknown_version() {
        let pkt = UdpFeedbackPacket {
            stream_id: 0,
            elapsed_ms: 0,
            packets_received: 0,
            packets_lost: 0,
        };
        let mut buffer = [0u8; UDP_FEEDBACK_SIZE];
        assert!(pkt.encode(&mut buffer));
        buffer[4] = 2; // version=2
        assert!(UdpFeedbackPacket::decode(&buffer).is_none());
    }

    #[test]
    fn feedback_packet_rejects_unknown_kind() {
        let pkt = UdpFeedbackPacket {
            stream_id: 0,
            elapsed_ms: 0,
            packets_received: 0,
            packets_lost: 0,
        };
        let mut buffer = [0u8; UDP_FEEDBACK_SIZE];
        assert!(pkt.encode(&mut buffer));
        buffer[5] = 99; // unknown kind
        assert!(UdpFeedbackPacket::decode(&buffer).is_none());
    }

    #[test]
    fn feedback_slot_rejects_wrong_stream_and_reordered_snapshot() {
        let mut slots = vec![UdpIntervalProgress {
            packets_received: 90,
            packets_lost: 10,
        }];
        let wrong_stream = UdpFeedbackPacket {
            stream_id: 1,
            elapsed_ms: 2_000,
            packets_received: 1_000,
            packets_lost: 0,
        };
        assert!(!store_udp_feedback(&mut slots, 0, wrong_stream));
        assert_eq!(slots[0].packets_received, 90);
        assert_eq!(slots[0].packets_lost, 10);

        let reordered = UdpFeedbackPacket {
            stream_id: 0,
            elapsed_ms: 500,
            packets_received: 40,
            packets_lost: 5,
        };
        assert!(!store_udp_feedback(&mut slots, 0, reordered));
        assert_eq!(slots[0].packets_received, 90);
        assert_eq!(slots[0].packets_lost, 10);
    }

    #[test]
    fn feedback_slot_accepts_fresh_and_loss_corrected_snapshots() {
        let mut slots = vec![UdpIntervalProgress::default()];
        let fresh = UdpFeedbackPacket {
            stream_id: 0,
            elapsed_ms: 500,
            packets_received: 90,
            packets_lost: 10,
        };
        assert!(store_udp_feedback(&mut slots, 0, fresh));

        // Equal denominators are still fresh enough: a receiver may later
        // reclassify a missing packet as reordered without changing the
        // number of sequence positions it has observed.
        let corrected = UdpFeedbackPacket {
            stream_id: 0,
            elapsed_ms: 1_000,
            packets_received: 91,
            packets_lost: 9,
        };
        assert!(store_udp_feedback(&mut slots, 0, corrected));
        assert_eq!(slots[0].packets_received, 91);
        assert_eq!(slots[0].packets_lost, 9);
    }

    #[test]
    fn feedback_slot_rejects_replayed_loss_and_backwards_received_counts() {
        let mut slots = [UdpIntervalProgress {
            packets_received: 9,
            packets_lost: 1,
        }];
        let corrected = UdpFeedbackPacket {
            stream_id: 0,
            elapsed_ms: 2000,
            packets_received: 10,
            packets_lost: 0,
        };
        assert!(store_udp_feedback(&mut slots, 0, corrected));
        for stale in [
            UdpFeedbackPacket {
                packets_received: 9,
                packets_lost: 1,
                ..corrected
            },
            UdpFeedbackPacket {
                packets_received: 9,
                packets_lost: 10,
                ..corrected
            },
        ] {
            assert!(!store_udp_feedback(&mut slots, 0, stale));
            assert_eq!(slots[0].packets_received, 10);
            assert_eq!(slots[0].packets_lost, 0);
        }
    }

    #[test]
    fn data_packet_at_collision_sequence_is_not_feedback() {
        // Length-first demux means a hypothetical data packet whose first
        // four bytes spell "XFRF" is still routed as data. Synthesize the
        // worst case: a full 1416-byte data packet with sequence chosen so
        // its big-endian top 4 bytes are b"XFRF". A naive magic-only
        // demux would misroute it; ours selects on length first.
        let collision_seq = u64::from_be_bytes([b'X', b'F', b'R', b'F', 0, 0, 0, 0]);
        let header = UdpPacketHeader {
            sequence: collision_seq,
            timestamp_us: 1_000,
        };
        let mut buffer = vec![0u8; UDP_HEADER_SIZE + UDP_PAYLOAD_SIZE];
        assert!(header.encode(&mut buffer));
        // Length is not 36, so feedback decode must reject.
        assert!(UdpFeedbackPacket::decode(&buffer).is_none());
        // Header decode still succeeds.
        let decoded = UdpPacketHeader::decode(&buffer).unwrap();
        assert_eq!(decoded.sequence, collision_seq);
    }

    #[test]
    fn test_jitter_calculator() {
        let mut calc = JitterCalculator::new();
        let start = Instant::now();

        // First packet doesn't produce jitter
        calc.update(0, start);
        assert_eq!(calc.jitter_ms(), 0.0);

        // Second packet with same timing should have minimal jitter
        calc.update(1000, start + Duration::from_micros(1000));
        // Jitter should be close to 0
        assert!(calc.jitter_ms() < 1.0);
    }

    #[test]
    fn test_jitter_max_tracks_peak_not_current() {
        let mut calc = JitterCalculator::new();
        let start = Instant::now();

        // Prime with two in-sync samples so the running jitter starts at zero.
        calc.update(0, start);
        calc.update(1000, start + Duration::from_micros(1000));
        assert_eq!(calc.jitter_max_ms(), 0.0);

        // Introduce a single large timing delta (recv arrives 10ms late).
        calc.update(2000, start + Duration::from_micros(12_000));
        let peak = calc.jitter_max_ms();
        assert!(peak > 0.0, "non-trivial delta should set a max");

        // Continue with *in-sync* samples (send delta == recv delta) so
        // |D| is zero and the running jitter decays by 15/16 each step.
        // jitter_ms should drop below peak, but jitter_max_ms must stick.
        let mut send_us: u64 = 3000;
        let mut recv_us: u64 = 13_000;
        for _ in 0..20 {
            calc.update(send_us, start + Duration::from_micros(recv_us));
            send_us += 1000;
            recv_us += 1000;
        }
        assert!(
            calc.jitter_ms() < peak,
            "running jitter should decay below peak when timing is in sync again"
        );
        assert_eq!(
            calc.jitter_max_ms(),
            peak,
            "jitter_max must retain the prior peak, not track the current value"
        );
    }

    #[test]
    fn hello_packet_roundtrip() {
        let pkt = UdpHelloPacket {
            kind: UDP_HELLO_KIND_HELLO,
            stream_index: 17,
            token: [0xAB; UDP_HELLO_TOKEN_LEN],
        };
        let buffer = pkt.encode();
        assert_eq!(UdpHelloPacket::decode(&buffer), Some(pkt));

        let ack = UdpHelloPacket {
            kind: UDP_HELLO_KIND_ACK,
            stream_index: 0,
            token: [0; UDP_HELLO_TOKEN_LEN],
        };
        let buffer = ack.encode();
        assert_eq!(UdpHelloPacket::decode(&buffer), Some(ack));
    }

    #[test]
    fn hello_packet_rejects_foreign() {
        let pkt = UdpHelloPacket {
            kind: UDP_HELLO_KIND_HELLO,
            stream_index: 1,
            token: [7; UDP_HELLO_TOKEN_LEN],
        };
        let good = pkt.encode();

        // Wrong magic
        let mut bad = good;
        bad[0..4].copy_from_slice(b"XFRF");
        assert!(UdpHelloPacket::decode(&bad).is_none());

        // Unknown version
        let mut bad = good;
        bad[4] = 2;
        assert!(UdpHelloPacket::decode(&bad).is_none());

        // Unknown kind
        let mut bad = good;
        bad[5] = 99;
        assert!(UdpHelloPacket::decode(&bad).is_none());

        // Wrong length, both directions — fixed-size framing
        assert!(UdpHelloPacket::decode(&good[..UDP_HELLO_SIZE - 1]).is_none());
        let mut oversize = [0u8; UDP_HELLO_SIZE + 1];
        oversize[..UDP_HELLO_SIZE].copy_from_slice(&good);
        assert!(UdpHelloPacket::decode(&oversize).is_none());
    }

    #[test]
    fn hello_token_hex_roundtrip() {
        let token: [u8; UDP_HELLO_TOKEN_LEN] = [
            0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD,
            0xEE, 0xFF,
        ];
        let hex = encode_hello_token(&token);
        assert_eq!(hex, "00112233445566778899aabbccddeeff");
        assert_eq!(parse_hello_token(&hex), Some(token));

        assert!(parse_hello_token("").is_none());
        assert!(parse_hello_token("0011").is_none()); // too short
        assert!(parse_hello_token("zz112233445566778899aabbccddeeff").is_none()); // non-hex
        assert!(parse_hello_token("00112233445566778899aabbccddeeff00").is_none()); // too long
    }

    #[test]
    fn classify_shared_datagram_all_lanes() {
        // 1. Exact hello framing → xfr hello lane.
        let hello = UdpHelloPacket {
            kind: UDP_HELLO_KIND_HELLO,
            stream_index: 0,
            token: [1; UDP_HELLO_TOKEN_LEN],
        }
        .encode();
        assert_eq!(classify_shared_datagram(&hello), SharedSocketLane::XfrHello);

        // 2. QUIC long header: 0x80 set (RFC 8999, version-independent).
        let long_header = [0xC3u8, 0, 0, 0, 1];
        assert_eq!(
            classify_shared_datagram(&long_header),
            SharedSocketLane::Quic
        );

        // 3. QUIC short header: 0x40 fixed bit set, 0x80 clear.
        let short_header = [0x41u8, 9, 9, 9];
        assert_eq!(
            classify_shared_datagram(&short_header),
            SharedSocketLane::Quic
        );

        // 4. Top two bits clear and not a hello → stray xfr lane. This is
        // what a *greased* short header (fixed bit cleared, RFC 9287)
        // would look like — it must never be possible toward this server
        // because the endpoint sets grease_quic_bit(false), so routing it
        // away from quinn is correct rather than lossy.
        let greased_looking = [0x05u8, 1, 2, 3];
        assert_eq!(
            classify_shared_datagram(&greased_looking),
            SharedSocketLane::XfrStray
        );
        assert_eq!(classify_shared_datagram(&[]), SharedSocketLane::XfrStray);

        // Hello magic with the wrong length is not the hello lane (fixed
        // size is part of the match), and its first byte is 0x00 → stray.
        let truncated_hello = &hello[..UDP_HELLO_SIZE - 4];
        assert_eq!(
            classify_shared_datagram(truncated_hello),
            SharedSocketLane::XfrStray
        );
    }

    /// The client handshake must skip an ack carrying the wrong token or
    /// stream index (token is the route key — a mismatched ack proves
    /// nothing about our stream) and complete on the matching one.
    #[tokio::test]
    async fn handshake_ignores_mismatched_ack() {
        let server = UdpSocket::bind("127.0.0.1:0").await.unwrap();
        let server_addr = server.local_addr().unwrap();
        let client = UdpSocket::bind("127.0.0.1:0").await.unwrap();
        client.connect(server_addr).await.unwrap();

        let token = [0x42u8; UDP_HELLO_TOKEN_LEN];
        let responder = tokio::spawn(async move {
            let mut buf = [0u8; 64];
            let (_, from) = server.recv_from(&mut buf).await.unwrap();
            // Wrong token first, then wrong stream, then the real ack.
            let wrong_token = UdpHelloPacket {
                kind: UDP_HELLO_KIND_ACK,
                stream_index: 3,
                token: [0xFFu8; UDP_HELLO_TOKEN_LEN],
            };
            let wrong_stream = UdpHelloPacket {
                kind: UDP_HELLO_KIND_ACK,
                stream_index: 4,
                token,
            };
            let good = UdpHelloPacket {
                kind: UDP_HELLO_KIND_ACK,
                stream_index: 3,
                token,
            };
            for pkt in [wrong_token, wrong_stream, good] {
                server.send_to(&pkt.encode(), from).await.unwrap();
            }
        });

        tokio::time::timeout(
            Duration::from_secs(5),
            single_port_udp_handshake(&client, &token, 3),
        )
        .await
        .expect("handshake should not hit the retry budget")
        .expect("handshake should succeed on the matching ack");
        responder.await.unwrap();
    }

    #[test]
    fn test_packet_tracker() {
        let mut tracker = PacketTracker::new();

        // Sequential packets
        tracker.record(0);
        tracker.record(1);
        tracker.record(2);
        assert_eq!(tracker.lost, 0);

        // Gap - packet 3 lost
        tracker.record(4);
        assert_eq!(tracker.lost, 1);

        // Out of order
        tracker.record(3);
        assert_eq!(tracker.out_of_order, 1);
        assert_eq!(tracker.lost, 0);
    }

    #[test]
    fn packet_tracker_repairs_reordering_without_counting_duplicates() {
        let mut tracker = PacketTracker::new();
        assert!(tracker.record_unique(0));
        assert!(tracker.record_unique(2));
        let (lost, reordered, percent) = tracker.stats(3);
        assert_eq!((lost, reordered), (1, 0));
        assert!((percent - 100.0 / 3.0).abs() < 1e-12);
        for duplicate in [0, 2, 0] {
            assert!(!tracker.record_unique(duplicate));
        }
        assert_eq!(tracker.received, 2);
        assert_eq!(tracker.lost, 1);
        assert!(tracker.record_unique(1));
        assert_eq!(tracker.received, 3);
        assert_eq!(tracker.stats(3), (0, 1, 0.0));
        assert!(!tracker.record_unique(1));
        assert_eq!(tracker.out_of_order, 1);
    }

    #[test]
    fn packet_tracker_retains_and_repairs_initial_gaps() {
        let mut tracker = PacketTracker::new();
        tracker.record(5);
        assert_eq!(tracker.lost, 5);
        for sequence in [3, 0, 1, 2, 4] {
            assert!(tracker.record_unique(sequence));
        }
        assert_eq!(tracker.received, 6);
        assert_eq!(tracker.stats(6), (0, 5, 0.0));
    }

    #[test]
    fn packet_tracker_wrap_keeps_partial_words_and_ignores_expired_packets() {
        let mut tracker = PacketTracker::new();
        let window = PACKET_TRACKER_WINDOW as u64;
        for sequence in 0..=window {
            if sequence != 62 {
                tracker.record(sequence);
            }
        }
        // The oldest partial word still contains sequence 1 despite its bit 0
        // being reused for sequence 65536. Clearing the whole word loses it.
        assert!(!tracker.record_unique(1));
        assert!(tracker.record_unique(62));
        assert_eq!(tracker.lost, 0);
        tracker.record(window + 63);
        assert_eq!(tracker.lost, 62);
        assert!(!tracker.record_unique(63)); // just outside the retained window
        assert!(!tracker.record_unique(64)); // oldest retained packet is a duplicate
        assert!(tracker.record_unique(window + 1)); // recycled position is now a real gap
        assert_eq!(tracker.lost, 61);
        assert_eq!(tracker.received, window + 3);
        assert_eq!(tracker.seen.len() * size_of::<u64>(), 8192);
    }

    #[test]
    fn packet_tracker_large_jumps_and_maximum_sequence_are_bounded() {
        let mut tracker = PacketTracker::new();
        tracker.record(0);
        tracker.record(1_000_000_000_000); // held until confirmed
        assert_eq!((tracker.received, tracker.lost), (1, 0));
        assert!(tracker.record_unique(1_000_000_000_001));
        assert_eq!(tracker.lost, 999_999_999_999);
        assert_eq!(tracker.received, 3);
        assert!(!tracker.record_unique(0));
        assert!(!tracker.record_unique(1_000_000_000_000));
        assert!(tracker.record_unique(999_999_999_999));
        assert_eq!(tracker.lost, 999_999_999_998);
        tracker.record(u64::MAX);
        assert!(tracker.record_unique(u64::MAX - 1));
        assert!(!tracker.record_unique(u64::MAX));

        let mut initial_maximum = PacketTracker::new();
        initial_maximum.record(u64::MAX);
        assert_eq!((initial_maximum.received, initial_maximum.lost), (0, 0));
        assert!(initial_maximum.record_unique(u64::MAX - 1));
        assert_eq!(initial_maximum.lost, u64::MAX - 1);
        assert_eq!(initial_maximum.received, 2);
    }

    /// One far-future datagram (stray, corrupt or spoofed) must not strand
    /// every later packet as too old; the run must count exactly as if it
    /// never arrived, including as the very first datagram.
    #[test]
    fn packet_tracker_ignores_a_lone_far_future_sequence() {
        let mut stream: Vec<u64> = (0..200_000u64).filter(|s| s % 97 != 3).collect();
        for pair in stream.chunks_mut(50) {
            pair.swap(0, pair.len() - 1); // reorder within the window
        }
        let run = |inject_at: Option<usize>| {
            let mut tracker = PacketTracker::new();
            for (index, &sequence) in stream.iter().enumerate() {
                if inject_at == Some(index) {
                    assert!(!tracker.record_unique(u64::MAX - 1));
                }
                tracker.record(sequence);
            }
            (tracker.received, tracker.lost, tracker.out_of_order)
        };
        let baseline = run(None);
        assert_eq!(baseline.0, stream.len() as u64);
        assert!(baseline.1 > 2000 && baseline.2 > 2000);
        assert_eq!(run(Some(100_000)), baseline);
        assert_eq!(run(Some(0)), baseline);
    }

    /// A real outage at a high packet rate is a far jump too; the packet
    /// after recovery confirms it and the whole gap still counts as lost.
    #[test]
    fn packet_tracker_counts_a_long_outage_as_loss() {
        let outage = 10_000_000 * 60; // 60 s at 10 Mpps
        let mut tracker = PacketTracker::new();
        for sequence in (0..1000).chain(1000 + outage..2000 + outage) {
            tracker.record(sequence);
        }
        assert_eq!(tracker.received, 2000);
        assert_eq!(tracker.lost, outage);
        assert_eq!(tracker.out_of_order, 0);
    }

    #[test]
    fn packet_tracker_matches_reference_across_reordering_and_window_wraps() {
        use std::collections::BTreeSet;
        let mut tracker = PacketTracker::new();
        let mut unique = BTreeSet::new();
        let mut highest: Option<u64> = None;
        let mut reordered = 0;
        let mut random = 0x1234_5678u64;
        // This test-only set has at most 6000 entries; production uses 8 KiB.
        for step in 0..6000 {
            random = random.wrapping_mul(6364136223846793005).wrapping_add(1);
            let previous = highest.unwrap_or(0);
            let sequence = match step % 6 {
                0 => previous + 1 + random % 257,
                1 => previous.saturating_sub(random % PACKET_TRACKER_WINDOW as u64),
                2 => previous.saturating_sub(random % (2 * PACKET_TRACKER_WINDOW) as u64),
                3 => previous,
                4 => previous + 1 + random % 70,
                _ => previous.saturating_sub(random % 4096),
            };
            let expired = highest
                .is_some_and(|h| sequence <= h && h - sequence >= PACKET_TRACKER_WINDOW as u64);
            let accepted = !expired && unique.insert(sequence);
            if accepted {
                if highest.is_some_and(|h| sequence < h) {
                    reordered += 1;
                }
                highest = Some(highest.map_or(sequence, |h| h.max(sequence)));
            }
            assert_eq!(tracker.record_unique(sequence), accepted, "step {step}");
            assert_eq!(tracker.received, unique.len() as u64, "step {step}");
            let expected_lost = highest.unwrap() + 1 - unique.len() as u64;
            assert_eq!(tracker.lost, expected_lost, "step {step}");
            assert_eq!(tracker.out_of_order, reordered, "step {step}");
        }
    }

    /// Differential check against an unbounded set over long streams. Unlike
    /// the oracle above, the stream is mostly sequential with drops replayed
    /// late, so recycled bitmap slots are probed for sequences that were
    /// never received; forward jumps hit both sides of the window size and
    /// word boundaries, and some streams start nonzero or run into u64::MAX.
    /// Far jumps are held until a nearby packet confirms them; the generator
    /// both confirms and narrowly misses held jumps.
    #[test]
    fn packet_tracker_matches_unbounded_reference_over_long_streams() {
        use std::collections::HashSet;
        const EVENTS: usize = 250_000;
        let window = PACKET_TRACKER_WINDOW as u64;
        let starts = [0, 7, window, 1 << 40];
        for (seed, start) in [0x9e37_79b9_7f4a_7c15u64, 1, 0xdead_beef, 42]
            .into_iter()
            .zip(starts)
        {
            let mut random = seed;
            let mut next_random = move || {
                random ^= random << 13;
                random ^= random >> 7;
                random ^= random << 17;
                random
            };
            let mut tracker = PacketTracker::new();
            let mut unique = HashSet::new();
            let mut highest: Option<u64> = None;
            let mut reordered = 0u64;
            let mut late = Vec::new();
            let mut held: Option<u64> = None;
            let (mut repairs, mut expired, mut duplicates, mut confirmed) = (0, 0, 0, 0);
            for step in 0..EVENTS {
                let top = highest.unwrap_or(start);
                let roll = next_random() % 1000;
                let sequence = if highest.is_none() {
                    start
                } else if (step == EVENTS - 2000 || step == EVENTS - 1999) && seed == 42 {
                    u64::MAX - 1000 + step as u64 % 2
                } else if roll < 700 {
                    let skip = if next_random() % 10 == 0 {
                        1 + next_random() % 4
                    } else {
                        0
                    };
                    for missing in 1..=skip {
                        if late.len() < 4096 {
                            late.push(top.saturating_add(missing));
                        }
                    }
                    top.saturating_add(1 + skip)
                } else if roll < 820 && !late.is_empty() {
                    let index = next_random() as usize % late.len();
                    late.swap_remove(index)
                } else if roll < 900 {
                    top.saturating_sub(next_random() % 128)
                } else if roll < 989 {
                    let back = [window - 1, window, window + 1, window - 64, window + 64];
                    top.saturating_sub(match next_random() % 6 {
                        5 => next_random() % (2 * window),
                        pick => back[pick as usize],
                    })
                } else if let Some(far) = held.filter(|_| roll < 993) {
                    // Confirm (or narrowly miss) a held jump, as recovery would.
                    far.saturating_sub(window / 2)
                        .saturating_add(next_random() % (window + 64))
                } else if roll < 999 {
                    let jump = [63, 64, 65, window - 1, window, window + 1, 2 * window];
                    top.saturating_add(match next_random() % 8 {
                        7 => 1 + next_random() % window,
                        pick => jump[pick as usize],
                    })
                } else {
                    top.saturating_add(1 << 40)
                };

                // A jump that would expire the whole window waits for a
                // second packet within a window of it, then both count.
                let jump =
                    highest.map_or(sequence.saturating_add(1), |h| sequence.saturating_sub(h));
                let mut candidates = vec![sequence];
                if jump > window {
                    match held.take() {
                        Some(far) if far.abs_diff(sequence) < window => {
                            candidates.insert(0, far);
                            confirmed += 1;
                        }
                        _ => {
                            held = Some(sequence);
                            candidates.clear();
                        }
                    }
                }
                let mut accepted = false;
                for candidate in candidates {
                    let too_old =
                        highest.is_some_and(|h| candidate <= h && h - candidate >= window);
                    accepted = !too_old && unique.insert(candidate);
                    if accepted {
                        if highest.is_some_and(|h| candidate < h) {
                            reordered += 1;
                            repairs += 1;
                        }
                        highest = Some(highest.map_or(candidate, |h| h.max(candidate)));
                    } else if too_old {
                        expired += 1;
                    } else {
                        duplicates += 1;
                    }
                }
                let context = format!("seed {seed:#x} step {step} sequence {sequence}");
                assert_eq!(tracker.record_unique(sequence), accepted, "{context}");
                assert_eq!(tracker.received, unique.len() as u64, "{context}");
                let expected_lost = highest.map_or(0, |h| u128::from(h) + 1) - unique.len() as u128;
                assert_eq!(u128::from(tracker.lost), expected_lost, "{context}");
                assert_eq!(tracker.out_of_order, reordered, "{context}");
            }
            assert!(repairs > 1000 && expired > 1000 && duplicates > 1000 && confirmed > 100);
        }
    }

    #[test]
    fn jitter_handles_extreme_timestamps_without_signed_overflow() {
        let mut jitter = JitterCalculator::new();
        let now = Instant::now();
        for (index, timestamp) in [u64::MAX, 0, u64::MAX, 1].into_iter().enumerate() {
            let value = jitter.update(timestamp, now + Duration::from_micros(index as u64));
            assert!(value.is_finite() && value >= 0.0);
        }
        assert!(jitter.jitter_max_ms().is_finite());
    }

    /// Verify the pacing ticker doesn't burst after resume from pause.
    ///
    /// `MissedTickBehavior::Skip` drops queued ticks during pause, and
    /// `ticker.reset()` after resume makes the first post-pause tick fire
    /// a full interval from resume.  Without both, the sender would
    /// fire immediately on resume, emitting a burst of packets.
    #[tokio::test]
    async fn test_udp_paced_no_burst_after_resume() {
        use std::sync::Arc;
        use tokio::sync::watch;

        // Bound the test so it can't hang.
        let overall = tokio::time::timeout(Duration::from_secs(10), async {
            // Two connected UDP sockets on localhost.
            let server = UdpSocket::bind("127.0.0.1:0").await.unwrap();
            let client = UdpSocket::bind("127.0.0.1:0").await.unwrap();
            let server_addr = server.local_addr().unwrap();
            client.connect(server_addr).await.unwrap();

            let socket = Arc::new(client);
            let stats = Arc::new(StreamStats::new(0));

            let (cancel_tx, cancel_rx) = watch::channel(false);
            let (pause_tx, pause_rx) = watch::channel(false);

            // 80kbps, 1200-byte payloads → ~8.3 packets/s → ~120ms interval.
            // Slow enough that a burst is observable; fast enough that the
            // test completes quickly.
            let bitrate: u64 = 80_000;

            let send_socket = socket.clone();
            let send_stats = stats.clone();
            let send_task = tokio::spawn(async move {
                send_udp_paced(
                    send_socket,
                    None,
                    bitrate,
                    UDP_PAYLOAD_SIZE,
                    Duration::ZERO, // infinite — cancel ends it
                    send_stats,
                    cancel_rx,
                    pause_rx,
                    false,
                    None,
                )
                .await
            });

            // The client socket is connected, so send_udp_paced must use
            // send(), not send_to(); macOS rejects send_to on connected UDP
            // sockets with EISCONN.
            let mut buf = [0u8; 2048];
            tokio::time::timeout(Duration::from_secs(2), server.recv(&mut buf))
                .await
                .expect("paced sender should deliver before pause")
                .expect("server recv should succeed");

            // Let it send for a bit, then pause.
            tokio::time::sleep(Duration::from_millis(300)).await;
            let _ = pause_tx.send(true);

            // Drain any in-flight packets.
            let drain_deadline = tokio::time::Instant::now() + Duration::from_millis(200);
            while let Ok(Ok(_)) =
                tokio::time::timeout_at(drain_deadline, server.recv(&mut buf)).await
            {}

            // Resume from pause.
            let _ = pause_tx.send(false);
            // The assertions below verify timing: no burst, then a packet.
            // The first post-resume packet must NOT arrive immediately
            // (that would indicate a burst from a queued tick).  It
            // should arrive after roughly one pacing interval (~120ms).
            // We assert nothing arrives in the first half-interval.
            let half_interval = Duration::from_millis(60);
            let early_result = tokio::time::timeout(half_interval, server.recv(&mut buf)).await;
            assert!(
                early_result.is_err(),
                "no packet should arrive in first {:?} after resume (burst detected)",
                half_interval
            );

            // Then a packet should arrive within a generous window.
            // The pacing interval is ~120ms; reset() makes the first
            // tick fire ~120ms from resume, but allow scheduling jitter.
            let recv_window = Duration::from_secs(2);
            let recv_result = tokio::time::timeout(recv_window, server.recv(&mut buf)).await;
            assert!(
                recv_result.is_ok(),
                "a packet should arrive within {:?} after resume",
                recv_window
            );

            // Clean up.
            let _ = cancel_tx.send(true);
            let _ = send_task.await;
        })
        .await;
        assert!(overall.is_ok(), "test should complete within 10s");
    }

    #[tokio::test(flavor = "current_thread")]
    async fn receive_udp_wakes_immediately_on_cancel() {
        let socket = Arc::new(UdpSocket::bind("127.0.0.1:0").await.unwrap());
        let stats = Arc::new(StreamStats::new(0));
        let (cancel_tx, cancel_rx) = watch::channel(false);
        let (_pause_tx, pause_rx) = watch::channel(false);

        let mut receive = Box::pin(receive_udp(socket, stats, cancel_rx, pause_rx, false, None));

        // Poll once to place the receiver inside its select, then signal
        // cancel and poll once more. The watch arm must make that second poll
        // ready without advancing a clock or relying on task scheduling.
        assert!(futures::poll!(receive.as_mut()).is_pending());
        cancel_tx.send(true).unwrap();
        let result = futures::poll!(receive.as_mut());
        assert!(
            matches!(&result, std::task::Poll::Ready(Ok(_))),
            "cancel should make the receiver ready immediately, got {result:?}"
        );
    }
}
