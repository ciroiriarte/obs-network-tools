//! TUI application state machine

use std::collections::VecDeque;
use std::hash::{DefaultHasher, Hash, Hasher};
use std::time::{Duration, Instant};

use ratatui::layout::Size;

use crate::client::TestProgress;
use crate::protocol::{Direction, Protocol, TestResult, TimestampFormat};

use super::settings::SettingsState;
use super::theme::Theme;

const SPARKLINE_HISTORY: usize = 60;
const LOG_HISTORY: usize = 100;
// Sparkline bar cadence. Server `Interval` messages arrive at 1 Hz, so in
// the normal path one bar per second comes straight from `on_progress`.
// When the TCP control channel stalls (upload-mode UDP saturation, issue
// #93), `tick()` keeps the graph advancing at the same cadence from the
// freshest UDP-feedback state. The stall threshold is two report intervals
// so ordinary delivery jitter on a healthy control channel never gets a
// synthesized bar in ahead of a slightly-late Interval.
const BAR_INTERVAL: Duration = Duration::from_secs(1);
const BAR_STALL_AFTER: Duration = Duration::from_secs(2);
// Rolling window for aggregate jitter display. Progress events fire at 1Hz,
// so 10 samples ≈ 10s smoothing window — long enough to damp per-second
// noise, short enough to still track real network changes.
const JITTER_HISTORY_SAMPLES: usize = 10;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AppState {
    Connecting,
    Running,
    Paused,
    Completed,
    Error,
}

pub struct StreamData {
    pub id: u8,
    pub bytes: u64,
    pub throughput_mbps: f64,
    pub retransmits: u64,
    pub jitter_ms: Option<f64>,
}

/// One throughput sparkline sample. The renderer uses `lost_packets`
/// against `interval_packets` to pick a tint, so a single-packet hiccup
/// renders distinct from a heavy drop burst instead of collapsing both to
/// "loss=true". `interval_packets = 0` means we couldn't measure loss
/// magnitude (no UDP progress yet, or pre-0.9.11 server) and the renderer
/// falls back to the primary color regardless of `lost_packets`.
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct ThroughputSample {
    pub mbps: f64,
    pub lost_packets: u64,
    pub interval_packets: u64,
}

impl ThroughputSample {
    /// Per-interval loss rate in percent, or `None` when we can't measure.
    pub fn loss_rate_percent(&self) -> Option<f64> {
        if self.interval_packets == 0 {
            None
        } else {
            Some((self.lost_packets as f64 / self.interval_packets as f64) * 100.0)
        }
    }
}

#[derive(Clone, Hash)]
pub struct LogEntry {
    pub timestamp: String,
    pub message: String,
}

pub struct App {
    // `reset_for_restart` reuses one App across multiple TUI test runs. When
    // adding run-specific fields, update that reset path as well.
    pub state: AppState,
    pub host: String,
    pub port: u16,
    pub protocol: Protocol,
    pub direction: Direction,
    pub streams_count: u8,
    pub duration: Duration,
    pub bitrate: Option<u64>,
    /// Byte budget for a `-n` test. When set, progress is measured against
    /// bytes transferred rather than time — a byte-budget test usually has no
    /// duration at all, and a full "∞" bar would read as already finished.
    pub byte_budget: Option<u64>,

    pub elapsed: Duration,
    pub total_bytes: u64,
    pub current_throughput_mbps: f64,
    pub throughput_history: VecDeque<ThroughputSample>,
    // Rolling history of aggregate jitter samples so the TUI can show a
    // smoothed reading instead of the noisy per-second snapshot.
    pub jitter_history: VecDeque<f64>,
    pub streams: Vec<StreamData>,

    // Bidirectional split stats (populated from AggregateInterval/TestResult
    // when the server reports per-direction totals). Zero for unidirectional tests.
    pub bidir_bytes_sent: u64,
    pub bidir_bytes_received: u64,
    pub throughput_send_mbps: f64,
    pub throughput_recv_mbps: f64,

    pub total_retransmits: u64,
    retransmits_are_authoritative: bool,
    pub rtt_us: u32,
    pub cwnd: u32,

    // UDP stats
    pub udp_jitter_ms: f64,
    /// Cumulative UDP loss percent. `None` when the server hasn't shipped a
    /// `udp_progress` snapshot yet (TCP run, very early UDP run before any
    /// packets, or paired with a pre-0.9.11 server). The TUI renders `--%`
    /// in that case so unknown is visually distinct from a real 0.0%
    /// observation — preserving "last known value" silently would let a
    /// pre-0.9.11 server display a misleading 0% reading next to actual
    /// loss bursts in the sparkline.
    pub udp_lost_percent: Option<f64>,
    pub udp_packets_sent: u64,
    pub udp_packets_lost: u64,

    pub result: Option<TestResult>,
    pub error: Option<String>,

    /// Deadline for the post-quit "waiting for server Result" grace period
    /// (issue #159). While set, the footer shows a countdown so a quit on a
    /// dead link reads as a bounded wait instead of a hang.
    pub cancel_deadline: Option<Instant>,

    pub start_time: Option<Instant>,
    pub show_help: bool,
    pub show_streams: bool,
    pub timestamp_format: TimestampFormat,
    pub theme: Theme,
    pub theme_index: usize,

    // Settings modal state
    pub settings: SettingsState,

    // History log
    pub history: VecDeque<LogEntry>,
    pub average_throughput_mbps: f64,
    throughput_count: u64,

    // Event tracking for history
    peak_throughput_mbps: f64,
    prev_retransmits: u64,
    prev_udp_lost: u64,
    /// Last cumulative `udp_progress` snapshot already rendered into a
    /// sparkline bar, kept so each new bar can compute its per-interval
    /// delta (lost_packets / total_packets) for the severity tint. Advanced
    /// only by the two bar-appending paths (`on_progress` full Intervals and
    /// `maybe_append_stalled_bar`), never by feedback-only updates — that's
    /// what keeps a resumed Interval from re-counting loss that
    /// feedback-derived bars already showed. None before the first UDP
    /// progress arrives.
    prev_udp_progress: Option<crate::protocol::UdpIntervalProgress>,
    /// Freshest cumulative `udp_progress` seen from either source: full TCP
    /// `Interval` messages or feedback-only updates (2 Hz UDP feedback under
    /// `udp_feedback_v1`). Both producer paths route through
    /// `UdpProgressFilter`, so denominators are monotonic and a plain
    /// overwrite is safe. `maybe_append_stalled_bar` deltas this against
    /// `prev_udp_progress` to tint bars while the control channel is stalled.
    latest_udp_progress: Option<crate::protocol::UdpIntervalProgress>,
    /// Instant the most recent sparkline bar was appended, by either path.
    /// `tick()` synthesizes a bar once this falls `BAR_STALL_AFTER` behind
    /// the wall clock. None until the first bar; before that, `start_time`
    /// serves as the baseline so a control channel that stalls before the
    /// first Interval still gets an advancing graph.
    last_bar_at: Option<Instant>,

    // Update notification
    pub update_available: Option<String>,

    /// Server-reported version (e.g. "xfr/0.9.8") captured from the `Hello`
    /// handshake. None until the handshake completes; surfaced in the UI so
    /// cross-version test pairings are visible at a glance.
    pub server_version: Option<String>,

    /// Wall-clock instant at which the current pause started. `Some` while
    /// `state == Paused`, `None` otherwise. On resume we advance `start_time`
    /// forward by the paused duration so `tick()`'s `start_time.elapsed()`
    /// naturally excludes time spent paused.
    pause_started_at: Option<Instant>,
}

impl App {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        host: String,
        port: u16,
        protocol: Protocol,
        direction: Direction,
        streams: u8,
        duration: Duration,
        bitrate: Option<u64>,
        timestamp_format: TimestampFormat,
        theme: Theme,
    ) -> Self {
        Self {
            state: AppState::Connecting,
            host,
            port,
            protocol,
            direction,
            streams_count: streams,
            duration,
            bitrate,
            byte_budget: None,

            elapsed: Duration::ZERO,
            total_bytes: 0,
            current_throughput_mbps: 0.0,
            throughput_history: VecDeque::with_capacity(SPARKLINE_HISTORY),
            jitter_history: VecDeque::with_capacity(JITTER_HISTORY_SAMPLES),
            bidir_bytes_sent: 0,
            bidir_bytes_received: 0,
            throughput_send_mbps: 0.0,
            throughput_recv_mbps: 0.0,
            streams: (0..streams)
                .map(|id| StreamData {
                    id,
                    bytes: 0,
                    throughput_mbps: 0.0,
                    retransmits: 0,
                    jitter_ms: None,
                })
                .collect(),

            total_retransmits: 0,
            retransmits_are_authoritative: false,
            rtt_us: 0,
            cwnd: 0,

            udp_jitter_ms: 0.0,
            udp_lost_percent: None,
            udp_packets_sent: 0,
            udp_packets_lost: 0,

            result: None,
            error: None,

            cancel_deadline: None,

            start_time: None,
            show_help: false,
            show_streams: false,
            timestamp_format,
            theme,
            theme_index: 0,

            settings: SettingsState::new(0, streams, protocol, duration, direction, bitrate),

            history: VecDeque::with_capacity(LOG_HISTORY),
            average_throughput_mbps: 0.0,
            throughput_count: 0,

            peak_throughput_mbps: 0.0,
            prev_retransmits: 0,
            prev_udp_lost: 0,
            prev_udp_progress: None,
            latest_udp_progress: None,
            last_bar_at: None,

            update_available: None,
            server_version: None,
            pause_started_at: None,
        }
    }

    /// Add a log entry with current timestamp
    pub fn log(&mut self, message: impl Into<String>) {
        let timestamp = if let Some(start) = self.start_time {
            let elapsed = start.elapsed();
            format!(
                "{:02}:{:02}:{:02}",
                elapsed.as_secs() / 3600,
                (elapsed.as_secs() % 3600) / 60,
                elapsed.as_secs() % 60
            )
        } else {
            "00:00:00".to_string()
        };

        self.history.push_front(LogEntry {
            timestamp,
            message: message.into(),
        });

        if self.history.len() > LOG_HISTORY {
            self.history.pop_back();
        }
    }

    /// Create app with theme by name, setting theme_index appropriately
    #[allow(clippy::too_many_arguments)]
    pub fn with_theme_name(
        host: String,
        port: u16,
        protocol: Protocol,
        direction: Direction,
        streams: u8,
        duration: Duration,
        bitrate: Option<u64>,
        timestamp_format: TimestampFormat,
        theme_name: &str,
    ) -> Self {
        let theme_list = Theme::list();
        let theme_index = theme_list
            .iter()
            .position(|&t| t == theme_name)
            .unwrap_or(0);
        let theme = Theme::by_name(theme_name);

        let mut app = Self::new(
            host,
            port,
            protocol,
            direction,
            streams,
            duration,
            bitrate,
            timestamp_format,
            theme,
        );
        app.theme_index = theme_index;
        app.settings.theme_index = theme_index;
        app
    }

    /// Cycle to the next theme
    pub fn cycle_theme(&mut self) {
        let theme_list = Theme::list();
        self.theme_index = (self.theme_index + 1) % theme_list.len();
        self.theme = Theme::by_name(theme_list[self.theme_index]);
        self.settings.theme_index = self.theme_index;
    }

    /// Set theme by index (from settings modal)
    pub fn set_theme_index(&mut self, index: usize) {
        let theme_list = Theme::list();
        if index < theme_list.len() {
            self.theme_index = index;
            self.theme = Theme::by_name(theme_list[index]);
            self.settings.theme_index = index;
        }
    }

    /// Get current theme name
    pub fn theme_name(&self) -> &str {
        self.theme.name()
    }

    /// Called when the run task is spawned, which is *before* any socket is
    /// established — so this only claims an attempt. The matching "Connected"
    /// line is logged from [`Self::set_server_version`], the first point at
    /// which a peer has actually answered. Claiming success here printed
    /// "Connected to server." above "Error: Connection refused" on a refused
    /// port.
    pub fn on_connected(&mut self) {
        self.state = AppState::Running;
        self.start_time = Some(Instant::now());
        self.log("Connecting to server...");
    }

    /// Apply new test parameters chosen in the settings modal. The caller is
    /// responsible for rebuilding the client and spawning the replacement run.
    pub fn apply_test_params(
        &mut self,
        protocol: Protocol,
        direction: Direction,
        streams: u8,
        duration: Duration,
        bitrate: Option<u64>,
    ) {
        self.protocol = protocol;
        self.direction = direction;
        self.streams_count = streams;
        self.duration = duration;
        self.bitrate = bitrate;
        self.streams = (0..streams)
            .map(|id| StreamData {
                id,
                bytes: 0,
                throughput_mbps: 0.0,
                retransmits: 0,
                jitter_ms: None,
            })
            .collect();
        self.settings.mark_applied();
    }

    /// Reset run-specific metrics before spawning a new test, preserving user
    /// preferences, settings, update notifications, and history.
    pub fn reset_for_restart(&mut self) {
        self.state = AppState::Connecting;
        self.elapsed = Duration::ZERO;
        self.total_bytes = 0;
        self.current_throughput_mbps = 0.0;
        self.throughput_history.clear();
        self.jitter_history.clear();
        for stream in &mut self.streams {
            stream.bytes = 0;
            stream.throughput_mbps = 0.0;
            stream.retransmits = 0;
            stream.jitter_ms = None;
        }

        self.bidir_bytes_sent = 0;
        self.bidir_bytes_received = 0;
        self.throughput_send_mbps = 0.0;
        self.throughput_recv_mbps = 0.0;

        self.total_retransmits = 0;
        self.retransmits_are_authoritative = false;
        self.rtt_us = 0;
        self.cwnd = 0;

        self.udp_jitter_ms = 0.0;
        self.udp_lost_percent = None;
        self.udp_packets_sent = 0;
        self.udp_packets_lost = 0;

        self.result = None;
        self.error = None;
        self.cancel_deadline = None;
        self.start_time = None;
        self.show_help = false;
        self.show_streams = false;
        self.peak_throughput_mbps = 0.0;
        self.prev_retransmits = 0;
        self.prev_udp_lost = 0;
        self.prev_udp_progress = None;
        self.latest_udp_progress = None;
        self.last_bar_at = None;
        self.pause_started_at = None;
        self.server_version = None;

        self.average_throughput_mbps = 0.0;
        self.throughput_count = 0;

        self.log("Test restarting...");
    }

    /// Refresh `elapsed` from the local wall clock. Called from the TUI loop
    /// once per iteration so the counter stays live even when server
    /// `Interval` progress messages are delayed (e.g. packet-drop bursts on
    /// the control channel). `elapsed` is wall-clock-authoritative during
    /// Running — `on_progress` does NOT update it (doing so was a visual
    /// no-op since the next tick immediately overwrote the server's value).
    /// `on_result` pins `self.duration` once completed.
    ///
    /// Also owns the sparkline's stall cadence (issue #93): when full
    /// Intervals stop arriving, bars keep advancing from the freshest
    /// feedback-derived state instead of freezing.
    pub fn tick(&mut self) {
        if self.state == AppState::Running
            && let Some(start) = self.start_time
        {
            self.elapsed = start.elapsed();
            self.maybe_append_stalled_bar(Instant::now());
        }
    }

    /// Append a synthesized sparkline bar when full `Interval` messages have
    /// stalled (issue #93). Under upload-mode UDP saturation the TCP control
    /// channel is exactly what stalls, so bar cadence can't depend on
    /// Interval arrival alone: without this the graph freezes while the
    /// numeric loss counter — fed by 2 Hz UDP feedback — keeps moving.
    ///
    /// Cadence: a bar is synthesized only once `BAR_STALL_AFTER` (two report
    /// intervals) has passed since the last appended bar, so normal 1 Hz
    /// Interval delivery never double-renders a window. During a sustained
    /// stall `last_bar_at` advances by one `BAR_INTERVAL` per bar, holding
    /// the regular one-bar-per-second rhythm; if it falls a full threshold
    /// behind even after advancing (TUI loop itself was blocked) it snaps to
    /// `now` so a long freeze yields one aggregated bar, not a catch-up
    /// flood. The aggregated bar stays honest because both its loss and
    /// packet counts span the same window.
    ///
    /// Loss tint: delta of the freshest cumulative `udp_progress` against
    /// `prev_udp_progress`, the last cumulative already rendered into a bar
    /// — the same monotonic-denominator trick `UdpProgressFilter` relies on.
    /// Advancing `prev_udp_progress` here is what keeps a resuming Interval
    /// from re-counting loss these bars already showed.
    ///
    /// Throughput: repeat-last-known. A zero-mbps sample renders as a blank
    /// cell in the Sparkline (no glyph, so nothing to tint), which would
    /// hide the loss signal entirely; repeating the stale height keeps the
    /// bar visible so the loss tint can mark the segment. A flat plateau
    /// with warning/error tint reads as "no fresh throughput reading, loss
    /// still arriving" rather than a frozen graph.
    fn maybe_append_stalled_bar(&mut self, now: Instant) {
        // Baseline from the last bar, or test start before any bar exists —
        // the control channel can stall before the first Interval lands.
        let Some(last) = self.last_bar_at.or(self.start_time) else {
            return;
        };
        if now.duration_since(last) < BAR_STALL_AFTER {
            return;
        }
        let (interval_packets, interval_lost) =
            match (self.latest_udp_progress, self.prev_udp_progress) {
                (Some(curr), Some(prev)) => {
                    let lost = curr.packets_lost.saturating_sub(prev.packets_lost);
                    let received = curr.packets_received.saturating_sub(prev.packets_received);
                    (received.saturating_add(lost), lost)
                }
                // First cumulative sample (or none at all): baseline
                // silently, mirroring `on_progress` — magnitude unknown,
                // renderer stays primary-colored.
                _ => (0, 0),
            };
        self.push_throughput_sample(ThroughputSample {
            mbps: self.current_throughput_mbps,
            lost_packets: interval_lost,
            interval_packets,
        });
        if let Some(latest) = self.latest_udp_progress {
            self.prev_udp_progress = Some(latest);
        }
        let advanced = last + BAR_INTERVAL;
        self.last_bar_at = Some(if now.duration_since(advanced) >= BAR_STALL_AFTER {
            now
        } else {
            advanced
        });
    }

    /// Append a sample to the sparkline history, evicting the oldest once
    /// the window is full. Shared by the Interval path (`on_progress`) and
    /// the stall path (`maybe_append_stalled_bar`).
    fn push_throughput_sample(&mut self, sample: ThroughputSample) {
        self.throughput_history.push_back(sample);
        if self.throughput_history.len() > SPARKLINE_HISTORY {
            self.throughput_history.pop_front();
        }
    }

    /// Record the server's advertised version (from the `Hello` handshake).
    /// Stored for UI display only. The string is sanitized before storage —
    /// see [`sanitize_server_version`] — since it crosses a network trust
    /// boundary and lands in a terminal. A hostile or compromised server
    /// could otherwise smuggle terminal escape sequences or an oversized
    /// payload into our display.
    /// Receiving it is also the first proof a peer actually answered, so the
    /// "Connected" line is logged here rather than optimistically at spawn.
    pub fn set_server_version(&mut self, version: String) {
        if self.server_version.is_none() {
            self.log("Connected to server.");
        }
        self.server_version = Some(sanitize_server_version(&version));
    }

    pub fn on_progress(&mut self, progress: TestProgress) {
        // Feedback-only updates carry just `udp_progress`; everything
        // else is sentinel/None and consumers must preserve their last
        // full-interval values. Record the freshest cumulative for the
        // numeric loss readout and for `tick()`'s stall-cadence bars,
        // then return — retransmits, jitter, RTT/cwnd, and byte-count
        // fields all keep their last full-interval values, and no bar is
        // appended here (bars come from full Intervals or from `tick()`
        // once those stall). `prev_udp_progress` is NOT advanced: it
        // tracks what's already rendered into a bar, and only the two
        // bar-appending paths move it.
        if progress.udp_feedback_only {
            if let Some(p) = progress.udp_progress {
                self.latest_udp_progress = Some(p);
                if let Some(percent) = p.lost_percent() {
                    self.udp_lost_percent = Some(percent);
                }
            }
            return;
        }
        // `elapsed` is intentionally NOT written here. `tick()` owns it during
        // Running from the local wall clock (pause-aware), so the TUI stays
        // live between progress messages. Writing from `progress.elapsed_ms`
        // on each message caused the next tick() to immediately overwrite it
        // anyway, producing a one-frame flash of the server-authoritative
        // value that users couldn't perceive. `on_result()` pins the final
        // once the test completes.
        self.total_bytes = self.total_bytes.saturating_add(progress.total_bytes);
        self.current_throughput_mbps = progress.throughput_mbps;

        // Bidirectional split: when the server reports per-direction counts
        // (all four Some), surface them to the UI so the live ↑/↓ panel works
        // during the test rather than only after it finishes.
        if let (Some(sent), Some(recv), Some(ts), Some(tr)) = (
            progress.bytes_sent,
            progress.bytes_received,
            progress.throughput_send_mbps,
            progress.throughput_recv_mbps,
        ) {
            self.bidir_bytes_sent += sent;
            self.bidir_bytes_received += recv;
            self.throughput_send_mbps = ts;
            self.throughput_recv_mbps = tr;
        }

        // Update stream data
        // Intervals are sent every second, so throughput = bytes * 8 / 1_000_000
        let mut total_jitter = 0.0;
        let mut total_lost = 0u64;
        let mut jitter_count = 0;

        for interval in &progress.streams {
            if let Some(stream) = self.streams.get_mut(interval.id as usize) {
                stream.bytes = interval.bytes;
                // Use 1-second interval for throughput calculation (intervals are 1s apart)
                stream.throughput_mbps = (interval.bytes as f64 * 8.0) / 1_000_000.0;
                stream.retransmits = interval.retransmits.unwrap_or(0);
                stream.jitter_ms = interval.jitter_ms;
            }

            // Accumulate UDP stats from intervals
            if let Some(jitter) = interval.jitter_ms {
                total_jitter += jitter;
                jitter_count += 1;
            }
            if let Some(lost) = interval.lost {
                total_lost += lost;
            }
        }

        // Update sparkline history. Tag the sample with the per-interval
        // packet/loss delta so the renderer can grade severity (clean,
        // light loss, heavy loss) instead of collapsing all loss to a flat
        // yellow bar.
        //
        // `progress.udp_progress` passed the producer-side monotonic filter,
        // so when it is `Some` it is fresher-or-equal to anything we hold;
        // when the filter swallowed a stale cumulative (delayed Interval) we
        // still have the freshest state from the 2 Hz feedback path.
        if let Some(curr) = progress.udp_progress {
            self.latest_udp_progress = Some(curr);
        }
        // Backlog-flush guard (#93 follow-up): when a stalled control channel
        // unclogs, the queued Intervals land within milliseconds. Their
        // windows were already rendered — by tick()'s stall-synthesized bars
        // or the preceding Interval — so appending one bar per flushed
        // message made the graph jump forward several bars at once, and
        // because those stale cumulatives were filtered to `None` the bars
        // rendered primary-colored ("green") right after a loss episode.
        // Append only when the last bar is at least half a bar interval old;
        // skipped messages still update every numeric readout.
        let now = Instant::now();
        let bar_due = self
            .last_bar_at
            .is_none_or(|last| now.duration_since(last) >= BAR_INTERVAL / 2);
        if bar_due {
            // Tint from the freshest cumulative vs the last one already
            // rendered into a bar — the same source the stall path uses, so
            // a bar appended right after a loss episode shows the loss that
            // actually accrued instead of "magnitude unknown" green. First
            // sample (or no progress at all) baselines silently: real
            // deltas start from sample 2.
            let (interval_packets, interval_lost) =
                match (self.latest_udp_progress, self.prev_udp_progress) {
                    (Some(curr), Some(prev)) => {
                        let lost = curr.packets_lost.saturating_sub(prev.packets_lost);
                        let received = curr.packets_received.saturating_sub(prev.packets_received);
                        (received.saturating_add(lost), lost)
                    }
                    _ => (0, 0),
                };
            self.push_throughput_sample(ThroughputSample {
                mbps: progress.throughput_mbps,
                lost_packets: interval_lost,
                interval_packets,
            });
            // Advance the rendered-into-a-bar baseline only when a bar was
            // actually appended, and reset the stall clock so `tick()`
            // doesn't synthesize a second bar for the same window.
            if let Some(latest) = self.latest_udp_progress {
                self.prev_udp_progress = Some(latest);
            }
            self.last_bar_at = Some(now);
        }

        // Use local TCP_INFO retransmits when available (sender-side).
        // Otherwise accumulate per-stream interval deltas ourselves so the
        // fallback stays cumulative instead of resetting to the last
        // interval's value.
        if let Some(total) = progress.total_retransmits {
            self.total_retransmits = total;
            self.retransmits_are_authoritative = true;
        } else if !self.retransmits_are_authoritative {
            let interval_total: u64 = progress
                .streams
                .iter()
                .map(|s| s.retransmits.unwrap_or(0))
                .sum();
            self.total_retransmits = self.total_retransmits.saturating_add(interval_total);
        }

        // Update live TCP_INFO from interval data
        if let Some(rtt) = progress.rtt_us {
            self.rtt_us = rtt;
        }
        if let Some(cwnd) = progress.cwnd {
            self.cwnd = cwnd;
        }

        // Update UDP stats (average jitter across streams) and push to the
        // rolling window so the stats panel can display a smoothed value.
        if jitter_count > 0 {
            self.udp_jitter_ms = total_jitter / jitter_count as f64;
            self.jitter_history.push_back(self.udp_jitter_ms);
            if self.jitter_history.len() > JITTER_HISTORY_SAMPLES {
                self.jitter_history.pop_front();
            }
        }
        self.udp_packets_lost = total_lost;

        // Live UDP loss percent. Derived locally from the server's cumulative
        // packet counts so absence-of-progress (None) is distinguishable from
        // a real 0.0% reading; the renderer turns None into "--%" instead of
        // pretending zero. Once `udp_progress` arrives at least once, we keep
        // the last derived value when subsequent intervals omit it (e.g. a
        // TCP path momentarily not reporting UDP), but a session that never
        // sees a `udp_progress` (pre-0.9.11 server) stays None for the whole
        // run — the unknown state we want users to see.
        if let Some(progress) = progress.udp_progress
            && let Some(p) = progress.lost_percent()
        {
            self.udp_lost_percent = Some(p);
        }

        // Average throughput is byte-weighted (total bytes over elapsed), not a
        // mean of the per-interval rates. Intervals are not equal length — the
        // first one covers the ~1ms sliver between test start and the first
        // report, so a plain mean weights a 1500 Mbps micro-sample the same as
        // a full second and roughly doubles the figure (LAN-1496). This also
        // makes stalls reduce the average exactly as they do in the final
        // result, which is what the previous comment here intended.
        self.throughput_count += 1;
        let elapsed_secs = progress.elapsed_ms as f64 / 1000.0;
        if elapsed_secs > 0.0 {
            self.average_throughput_mbps =
                (self.total_bytes as f64 * 8.0) / elapsed_secs / 1_000_000.0;
        }

        // Log significant events
        self.detect_events(progress.throughput_mbps);
    }

    /// Detect and log significant events for history
    fn detect_events(&mut self, throughput_mbps: f64) {
        // Peak throughput (only log if 10%+ above previous peak, after warmup)
        if self.throughput_count > 2 && throughput_mbps > self.peak_throughput_mbps * 1.1 {
            self.peak_throughput_mbps = throughput_mbps;
            self.log(format!("Peak: {:.0} Mbps", throughput_mbps));
        } else if throughput_mbps > self.peak_throughput_mbps {
            self.peak_throughput_mbps = throughput_mbps;
        }

        // Retransmit spike (TCP)
        if self.total_retransmits > self.prev_retransmits {
            let delta = self.total_retransmits - self.prev_retransmits;
            if delta >= 10 {
                self.log(format!("Retransmits: +{}", delta));
            }
        }
        self.prev_retransmits = self.total_retransmits;

        // UDP packet loss
        if self.udp_packets_lost > self.prev_udp_lost {
            let delta = self.udp_packets_lost - self.prev_udp_lost;
            if delta >= 5 {
                self.log(format!("UDP loss: +{} packets", delta));
            }
        }
        self.prev_udp_lost = self.udp_packets_lost;
    }

    pub fn on_result(&mut self, result: TestResult) {
        self.state = AppState::Completed;
        if self.is_infinite() {
            self.elapsed = Duration::from_millis(result.duration_ms);
        } else {
            self.elapsed = self.duration; // Show full duration on completion
        }
        self.total_bytes = result.bytes_total;
        // Pin the average to the server-authoritative figure rather than
        // whatever the last interval left behind, so the panel and the
        // "Test completed. Avg:" log agree with the JSON/CSV output.
        self.average_throughput_mbps = result.throughput_mbps;
        // Sum retransmits from streams (captured after transfer, accurate for download mode)
        self.total_retransmits = result.streams.iter().filter_map(|s| s.retransmits).sum();

        // Use tcp_info for RTT and cwnd (connection-level stats)
        if let Some(tcp_info) = &result.tcp_info {
            self.rtt_us = tcp_info.rtt_us;
            self.cwnd = tcp_info.cwnd;
        }
        if let Some(udp_stats) = &result.udp_stats {
            self.udp_jitter_ms = udp_stats.jitter_ms;
            self.udp_lost_percent = Some(udp_stats.lost_percent);
            self.udp_packets_sent = udp_stats.packets_sent;
            self.udp_packets_lost = udp_stats.lost;
        }
        // Bidirectional split stats: populated only by servers that know to
        // report them. Older servers leave these None, in which case we keep
        // the zero defaults and the UI falls back to the combined throughput.
        if let (Some(sent), Some(recv), Some(ts), Some(tr)) = (
            result.bytes_sent,
            result.bytes_received,
            result.throughput_send_mbps,
            result.throughput_recv_mbps,
        ) {
            self.bidir_bytes_sent = sent;
            self.bidir_bytes_received = recv;
            self.throughput_send_mbps = ts;
            self.throughput_recv_mbps = tr;
        }
        self.result = Some(result);
        self.log(format!(
            "Test completed. Avg: {:.0} Mbps.",
            self.average_throughput_mbps
        ));
    }

    pub fn on_error(&mut self, error: String) {
        self.state = AppState::Error;
        self.log(format!("Error: {}", error));
        self.error = Some(error);
    }

    pub fn toggle_pause(&mut self) {
        match self.state {
            AppState::Running => {
                self.state = AppState::Paused;
                self.pause_started_at = Some(Instant::now());
                self.log("Test paused");
            }
            AppState::Paused => {
                // Shift start_time forward by the paused duration so the
                // elapsed counter recomputed by `tick()` excludes the pause.
                // Server's own `elapsed_ms` already excludes pause time, so
                // this keeps the two sources in agreement and avoids a
                // visible forward-then-backward jump at resume.
                if let (Some(paused_at), Some(start)) =
                    (self.pause_started_at.take(), self.start_time.as_mut())
                {
                    *start += paused_at.elapsed();
                }
                self.state = AppState::Running;
                self.log("Test resumed");
            }
            _ => {}
        }
    }

    pub fn toggle_help(&mut self) {
        self.show_help = !self.show_help;
    }

    pub fn toggle_streams(&mut self) {
        // Only toggle if multiple streams exist
        if self.streams_count > 1 {
            self.show_streams = !self.show_streams;
        }
    }

    /// Check if test has infinite duration
    pub fn is_infinite(&self) -> bool {
        self.duration == Duration::ZERO
    }

    pub fn progress_percent(&self) -> f64 {
        // A `-n` test measures progress in bytes; it usually has no duration
        // to measure against at all.
        if let Some(budget) = self.byte_budget.filter(|b| *b > 0) {
            return (self.total_bytes as f64 / budget as f64 * 100.0).min(100.0);
        }
        if self.is_infinite() {
            0.0
        } else {
            (self.elapsed.as_secs_f64() / self.duration.as_secs_f64() * 100.0).min(100.0)
        }
    }

    pub fn time_remaining(&self) -> Duration {
        if self.is_infinite() {
            Duration::ZERO
        } else {
            self.duration.saturating_sub(self.elapsed)
        }
    }

    pub fn max_throughput(&self) -> f64 {
        self.throughput_history
            .iter()
            .map(|s| s.mbps)
            .fold(0.0f64, f64::max)
    }

    /// Mean of the last ~10s of jitter samples. Returns 0.0 before any
    /// samples have arrived (very early in the test or non-UDP runs).
    pub fn avg_jitter_ms(&self) -> f64 {
        if self.jitter_history.is_empty() {
            0.0
        } else {
            self.jitter_history.iter().sum::<f64>() / self.jitter_history.len() as f64
        }
    }

    /// Jitter values for the UDP stats panel.
    ///
    /// - `primary` is the latest per-interval aggregate while running, or
    ///   the server's authoritative final once the test has completed.
    /// - `smoothed` is the 10-second rolling mean, shown alongside `primary`
    ///   only during the running state so users can see both the
    ///   instantaneous reading and the smoothed view. None when completed
    ///   (the final value is the authoritative one — a smoothed comparison
    ///   would just be noise at that point).
    ///
    /// Surfacing both resolves the cognitive friction where the rolling mean
    /// could stay above a sample's minimum (issue #48 follow-up).
    pub fn jitter_display(&self) -> JitterDisplay {
        if self.state == AppState::Completed {
            JitterDisplay {
                primary: self.udp_jitter_ms,
                smoothed: None,
            }
        } else {
            JitterDisplay {
                primary: self.udp_jitter_ms,
                smoothed: Some(self.avg_jitter_ms()),
            }
        }
    }

    /// Whole seconds left in the post-quit grace period (issue #159), or
    /// `None` when no cancel is pending. Rendered by the footer countdown and
    /// hashed by `render_fingerprint` at this same one-second resolution.
    pub fn cancel_wait_secs(&self) -> Option<u64> {
        self.cancel_deadline.map(|d| {
            d.saturating_duration_since(Instant::now())
                .as_secs_f64()
                .ceil() as u64
        })
    }

    /// Hash of everything `ui::draw` puts on screen (LAN-1226). The TUI loop
    /// redraws only when this changes, so the result, paused and error
    /// screens stop rebuilding an identical frame twenty times a second, and
    /// a Running frame is rebuilt only when something visible moved.
    ///
    /// Wall-clock inputs are hashed at the resolution the renderer shows:
    /// `elapsed` as whole seconds, the progress bar as its filled width in
    /// eighths of a cell for the current terminal width
    /// (`ui::progress_bar_cells`, the same arithmetic the renderer uses, so a
    /// fill change is never skipped — the bar draws partial blocks, so whole
    /// cells would be too coarse a signal), and
    /// the cancel countdown as whole seconds remaining. The terminal size is
    /// hashed too: `terminal.draw`'s autoresize only runs when we draw, so a
    /// resize has to count as a change.
    ///
    /// The destructure is deliberately exhaustive (no `..`): adding a field
    /// to `App` fails to compile here until it is hashed or bound to `_`
    /// with the reason it does not affect the frame.
    pub fn render_fingerprint(&self, size: Size) -> u64 {
        let App {
            state,
            host,
            port,
            protocol,
            direction,
            streams_count,
            duration,
            bitrate: _, // the modal draws `settings.bitrate`; this copy is never shown
            byte_budget,
            elapsed,
            total_bytes,
            current_throughput_mbps,
            throughput_history,
            jitter_history,
            streams,
            bidir_bytes_sent: _,     // only the per-direction Mbps are drawn
            bidir_bytes_received: _, // (throughput_send/recv_mbps below)
            throughput_send_mbps,
            throughput_recv_mbps,
            total_retransmits,
            retransmits_are_authoritative: _, // accumulation policy, not shown
            rtt_us,
            cwnd: _, // never drawn
            udp_jitter_ms,
            udp_lost_percent,
            udp_packets_sent: _, // event-log inputs; the log line lands in `history`
            udp_packets_lost: _,
            result: _, // never read by draw; on_result mirrors what is shown into the fields above
            error,
            cancel_deadline: _, // hashed as whole seconds via cancel_wait_secs()
            start_time: _,      // tick() derives `elapsed` from it
            show_help,
            show_streams,
            timestamp_format: _, // log timestamps are formatted when the entry is logged
            theme,
            theme_index,
            settings,
            history,
            average_throughput_mbps,
            throughput_count: _,
            peak_throughput_mbps: _, // event-detection baselines; effects land in `history`
            prev_retransmits: _,
            prev_udp_lost: _,
            prev_udp_progress: _,   // bar-tint baselines; effects land in
            latest_udp_progress: _, // throughput_history and udp_lost_percent
            last_bar_at: _,         // stall cadence clock; effects land in throughput_history
            update_available,
            server_version,
            pause_started_at: _, // folded into start_time on resume
        } = self;

        let mut h = DefaultHasher::new();
        size.hash(&mut h);
        state.hash(&mut h);
        host.hash(&mut h);
        port.hash(&mut h);
        protocol.hash(&mut h);
        direction.hash(&mut h);
        streams_count.hash(&mut h);
        duration.hash(&mut h);
        byte_budget.hash(&mut h);
        elapsed.as_secs().hash(&mut h);
        // The Real-time Stats block spends one cell per side on its border.
        super::ui::progress_bar_cells(self, size.width.saturating_sub(2)).hash(&mut h);
        total_bytes.hash(&mut h);
        current_throughput_mbps.to_bits().hash(&mut h);
        throughput_history.len().hash(&mut h);
        for ThroughputSample {
            mbps,
            lost_packets,
            interval_packets,
        } in throughput_history
        {
            mbps.to_bits().hash(&mut h);
            lost_packets.hash(&mut h);
            interval_packets.hash(&mut h);
        }
        jitter_history.len().hash(&mut h);
        for jitter in jitter_history {
            jitter.to_bits().hash(&mut h);
        }
        streams.len().hash(&mut h);
        for StreamData {
            id,
            bytes: _, // StreamBar draws throughput, retransmits and jitter
            throughput_mbps,
            retransmits,
            jitter_ms,
        } in streams
        {
            id.hash(&mut h);
            throughput_mbps.to_bits().hash(&mut h);
            retransmits.hash(&mut h);
            jitter_ms.map(f64::to_bits).hash(&mut h);
        }
        throughput_send_mbps.to_bits().hash(&mut h);
        throughput_recv_mbps.to_bits().hash(&mut h);
        total_retransmits.hash(&mut h);
        rtt_us.hash(&mut h);
        udp_jitter_ms.to_bits().hash(&mut h);
        udp_lost_percent.map(f64::to_bits).hash(&mut h);
        error.hash(&mut h);
        self.cancel_wait_secs().hash(&mut h);
        show_help.hash(&mut h);
        show_streams.hash(&mut h);
        theme.hash(&mut h);
        theme_index.hash(&mut h);
        settings.hash(&mut h);
        history.hash(&mut h);
        average_throughput_mbps.to_bits().hash(&mut h);
        update_available.hash(&mut h);
        server_version.hash(&mut h);
        h.finish()
    }
}

/// Display-safe normalization of a server-advertised version string.
///
/// The input comes from a remote `Hello` message and is rendered verbatim
/// into the user's terminal, so it needs to be treated as untrusted:
/// - non-printable / control bytes are stripped (prevents ANSI escape
///   injection that could clear the screen, move the cursor, spoof
///   content, or run the terminal's exotic OSC commands)
/// - the result is clamped to a short length (prevents a malicious peer
///   from monopolizing the Configuration panel row or blowing up render
///   cost)
/// - an empty result falls back to `(unknown)` so the UI still makes sense
pub fn sanitize_server_version(raw: &str) -> String {
    const MAX_LEN: usize = 32;
    let cleaned: String = raw
        .chars()
        .filter(|c| !c.is_control())
        .take(MAX_LEN)
        .collect();
    if cleaned.is_empty() {
        "(unknown)".to_string()
    } else {
        cleaned
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct JitterDisplay {
    /// The value to color-code and show first. Latest per-interval aggregate
    /// while running; server's authoritative final when completed.
    pub primary: f64,
    /// 10-second rolling mean — shown in parentheses alongside `primary`
    /// while running, `None` when the test is complete.
    pub smoothed: Option<f64>,
}

impl Default for App {
    fn default() -> Self {
        Self::new(
            "localhost".to_string(),
            5201,
            Protocol::Tcp,
            Direction::Upload,
            1,
            Duration::from_secs(10),
            None,
            TimestampFormat::default(),
            Theme::default(),
        )
    }
}

#[cfg(test)]
#[allow(clippy::field_reassign_with_default)] // App has too many fields to spread-construct in tests
mod tests {
    use super::*;

    #[test]
    fn jitter_display_returns_both_instant_and_smoothed_while_running() {
        let mut app = App::default();
        app.state = AppState::Running;
        // Simulate 3 per-second jitter samples: 2, 4, 6 ms → rolling mean 4.0.
        // Latest per-interval aggregate is 6.0 ms (what the server just sent).
        app.udp_jitter_ms = 6.0;
        app.jitter_history.extend([2.0, 4.0, 6.0]);

        let jd = app.jitter_display();
        assert!(
            (jd.primary - 6.0).abs() < f64::EPSILON,
            "primary should be latest per-interval aggregate 6.0, got {}",
            jd.primary
        );
        assert!(
            jd.smoothed.is_some(),
            "running state must include the smoothed mean alongside primary"
        );
        let avg = jd.smoothed.unwrap();
        assert!(
            (avg - 4.0).abs() < f64::EPSILON,
            "smoothed mean should be 4.0, got {avg}"
        );
    }

    #[test]
    fn jitter_display_uses_authoritative_final_on_complete() {
        let mut app = App::default();
        // Run-level final jitter from the server (via on_result) is different
        // from whatever the last 10s of progress samples averaged to — the
        // completed screen must show the authoritative final, and suppress
        // the smoothed companion so the display stays unambiguous.
        app.state = AppState::Completed;
        app.udp_jitter_ms = 1.23;
        app.jitter_history.extend([9.9, 9.9, 9.9]); // stale tail samples

        let jd = app.jitter_display();
        assert!(
            (jd.primary - 1.23).abs() < f64::EPSILON,
            "expected authoritative 1.23, got {}",
            jd.primary
        );
        assert_eq!(
            jd.smoothed, None,
            "completed state must not show a smoothed companion"
        );
    }

    #[test]
    fn avg_jitter_ms_is_zero_with_no_samples() {
        let app = App::default();
        assert_eq!(app.avg_jitter_ms(), 0.0);
    }

    #[test]
    fn tick_refreshes_elapsed_while_running() {
        // When Running with start_time set, tick() should update elapsed from
        // the wall clock so the UI stays live between progress messages. This
        // is the core fix for issue #62: progress-message starvation during
        // packet-drop bursts left `elapsed` stale.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now() - Duration::from_secs(3));
        app.elapsed = Duration::ZERO; // stale — what a drop burst leaves behind

        app.tick();

        assert!(
            app.elapsed >= Duration::from_secs(3),
            "expected elapsed ≥ 3s from wall clock, got {:?}",
            app.elapsed
        );
    }

    #[test]
    fn tick_is_noop_outside_running() {
        // Only Running should advance elapsed from wall clock. Other states
        // either don't have a meaningful elapsed (Connecting/Error) or pin
        // their own value (Completed sets duration, Paused should freeze).
        for state in [
            AppState::Connecting,
            AppState::Paused,
            AppState::Completed,
            AppState::Error,
        ] {
            let mut app = App::default();
            app.state = state;
            app.start_time = Some(Instant::now() - Duration::from_secs(5));
            app.elapsed = Duration::from_secs(42); // sentinel

            app.tick();

            assert_eq!(
                app.elapsed,
                Duration::from_secs(42),
                "tick() must not mutate elapsed in state {state:?}"
            );
        }
    }

    #[test]
    fn set_server_version_populates_field() {
        let mut app = App::default();
        assert!(app.server_version.is_none());
        app.set_server_version("xfr/0.9.8".to_string());
        assert_eq!(app.server_version.as_deref(), Some("xfr/0.9.8"));
    }

    fn logged(app: &App) -> Vec<String> {
        app.history.iter().map(|e| e.message.clone()).collect()
    }

    #[test]
    fn refused_connection_never_claims_it_connected() {
        // Regression: `on_connected` runs when the task is spawned, before any
        // socket exists, and used to log "Connected to server." — so a refused
        // port showed that line sitting directly above the connection error.
        let mut app = App::default();
        app.on_connected();
        app.on_error("Connection refused (os error 111)".to_string());

        let messages = logged(&app);
        assert!(
            !messages.iter().any(|m| m.contains("Connected to server")),
            "must not claim a connection that never happened: {messages:?}"
        );
        assert!(messages.iter().any(|m| m.contains("Connecting to server")));
    }

    #[test]
    fn connected_is_logged_once_when_the_peer_answers() {
        let mut app = App::default();
        app.on_connected();
        app.set_server_version("xfr/0.10.0".to_string());
        // A second Hello (or a refreshed version) must not re-log.
        app.set_server_version("xfr/0.10.0".to_string());

        let connected = logged(&app)
            .iter()
            .filter(|m| m.contains("Connected to server"))
            .count();
        assert_eq!(connected, 1, "expected exactly one connected line");
    }

    #[test]
    fn apply_test_params_refreshes_displayed_config_and_settings_baseline() {
        let mut app = App::default();
        app.settings.streams = 4;
        app.settings.protocol = Protocol::Udp;
        app.settings.duration_secs = 15;
        app.settings.direction = Direction::Download;
        app.settings.bitrate = Some(100_000_000);
        assert!(app.settings.test_params_dirty());

        app.apply_test_params(
            Protocol::Udp,
            Direction::Download,
            4,
            Duration::from_secs(15),
            Some(100_000_000),
        );

        assert_eq!(app.protocol, Protocol::Udp);
        assert_eq!(app.direction, Direction::Download);
        assert_eq!(app.streams_count, 4);
        assert_eq!(app.duration, Duration::from_secs(15));
        assert_eq!(app.bitrate, Some(100_000_000));
        assert_eq!(app.streams.len(), 4);
        assert!(!app.settings.test_params_dirty());
    }

    #[test]
    fn reset_for_restart_clears_run_state_but_preserves_user_context() {
        let mut app = App::default();
        app.on_connected();
        app.total_bytes = 1234;
        app.current_throughput_mbps = 42.0;
        app.throughput_history.push_back(ThroughputSample {
            mbps: 42.0,
            lost_packets: 1,
            interval_packets: 10,
        });
        app.streams[0].bytes = 1234;
        app.result = Some(TestResult {
            id: "test".to_string(),
            duration_ms: 1000,
            bytes_total: 1234,
            throughput_mbps: 42.0,
            streams: vec![],
            tcp_info: None,
            udp_stats: None,
            bytes_sent: None,
            bytes_received: None,
            throughput_send_mbps: None,
            throughput_recv_mbps: None,
            mtu_probe: None,
        });
        app.set_server_version("xfr/0.9.18".to_string());
        app.update_available = Some("xfr/0.9.19".to_string());
        let history_len = app.history.len();

        app.reset_for_restart();

        assert_eq!(app.state, AppState::Connecting);
        assert_eq!(app.total_bytes, 0);
        assert_eq!(app.current_throughput_mbps, 0.0);
        assert!(app.throughput_history.is_empty());
        assert_eq!(app.streams[0].bytes, 0);
        assert!(app.result.is_none());
        assert!(app.error.is_none());
        assert!(app.server_version.is_none());
        assert_eq!(app.update_available.as_deref(), Some("xfr/0.9.19"));
        assert_eq!(app.history.len(), history_len + 1);
    }

    #[test]
    fn sanitize_server_version_strips_control_bytes() {
        // ANSI escape sequences a hostile server could send to e.g. clear the
        // screen or move the cursor. All control bytes (ESC, CR, LF, NUL,
        // etc.) must be stripped before the string lands in the terminal.
        let dirty = "xfr/\x1b[2J\x1b[Hmalicious\r\n\x00";
        assert_eq!(sanitize_server_version(dirty), "xfr/[2J[Hmalicious");
    }

    #[test]
    fn sanitize_server_version_caps_length() {
        // A peer advertising a 10 KB version string must not monopolize the
        // Configuration panel row or blow up render cost.
        let long = "x".repeat(10_000);
        let cleaned = sanitize_server_version(&long);
        assert!(cleaned.chars().count() <= 32);
        assert!(cleaned.starts_with("xxxxx"));
    }

    #[test]
    fn sanitize_server_version_falls_back_for_empty_or_all_control() {
        assert_eq!(sanitize_server_version(""), "(unknown)");
        // All control characters → empty after filter → fallback.
        assert_eq!(sanitize_server_version("\x1b\x00\r\n"), "(unknown)");
    }

    #[test]
    fn set_server_version_sanitizes_input() {
        // set_server_version routes through sanitize_server_version, so a
        // hostile Hello.server value never reaches the renderer as-is.
        let mut app = App::default();
        app.set_server_version("xfr/0.9.9\x1b[31m".to_string());
        assert_eq!(app.server_version.as_deref(), Some("xfr/0.9.9[31m"));
    }

    #[test]
    fn on_progress_does_not_overwrite_elapsed() {
        // Regression: before this fix, on_progress wrote self.elapsed from
        // progress.elapsed_ms, which the next tick() immediately overwrote
        // from the wall clock — so the server's authoritative value never
        // actually rendered. We removed the write entirely; elapsed is
        // wall-clock authoritative during Running. This test pins that
        // contract so we don't accidentally re-introduce the write.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now() - Duration::from_secs(5));
        app.elapsed = Duration::from_secs(5); // wall-clock derived

        app.on_progress(crate::client::TestProgress {
            elapsed_ms: 9_999, // a server value far off from wall clock
            total_bytes: 0,
            throughput_mbps: 0.0,
            streams: vec![],
            rtt_us: None,
            cwnd: None,
            total_retransmits: None,
            bytes_sent: None,
            bytes_received: None,
            throughput_send_mbps: None,
            throughput_recv_mbps: None,
            udp_progress: None,
            udp_feedback_only: false,
        });

        assert_eq!(
            app.elapsed,
            Duration::from_secs(5),
            "on_progress must not mutate elapsed; tick() owns it"
        );
    }

    #[test]
    fn tick_elapsed_excludes_paused_time() {
        // Timeline (simulated):
        //   T-5s: test started       (start_time = now - 5s)
        //   T-3s: user hit `p`       (pause_started_at backdated to 3s ago)
        //   T-0s: user hit `p` again (resume, now)
        // Wall-clock from start = 5s; of which 3s was paused, 2s actively
        // running. Resume must shift start_time forward by the pause duration
        // so tick() shows ~2s, not 5s.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now() - Duration::from_secs(5));

        app.toggle_pause();
        assert_eq!(app.state, AppState::Paused);
        // Backdate pause_started_at to 3s ago to simulate a 3s pause window.
        app.pause_started_at = Some(Instant::now() - Duration::from_secs(3));

        app.toggle_pause();
        assert_eq!(app.state, AppState::Running);
        app.tick();

        let elapsed = app.elapsed;
        assert!(
            elapsed >= Duration::from_secs(2) && elapsed < Duration::from_secs(3),
            "elapsed should be ~2s (wall-clock 5s minus 3s pause), got {:?}",
            elapsed
        );
    }

    /// Make the last appended bar read as one full interval old, simulating
    /// the ~1s gap between real Interval messages. Tests fire `on_progress`
    /// back-to-back, which the backlog-flush guard would otherwise treat as
    /// a flushed control-channel queue and skip.
    fn age_last_bar(app: &mut App) {
        // `checked_sub` only fails within BAR_INTERVAL of the Instant epoch,
        // where `None` also reads as "bar due" — the intended effect.
        app.last_bar_at = Instant::now().checked_sub(BAR_INTERVAL);
    }

    fn make_progress(
        throughput_mbps: f64,
        udp_progress: Option<crate::protocol::UdpIntervalProgress>,
    ) -> crate::client::TestProgress {
        crate::client::TestProgress {
            elapsed_ms: 1000,
            total_bytes: 0,
            throughput_mbps,
            streams: vec![],
            rtt_us: None,
            cwnd: None,
            total_retransmits: None,
            bytes_sent: None,
            bytes_received: None,
            throughput_send_mbps: None,
            throughput_recv_mbps: None,
            udp_progress,
            udp_feedback_only: false,
        }
    }

    #[test]
    fn on_progress_derives_lost_percent_from_udp_progress() {
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        app.on_progress(make_progress(
            50.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 197,
                packets_lost: 3,
            }),
        ));
        // 3 / (197 + 3) = 1.5%
        assert_eq!(app.udp_lost_percent, Some(1.5));
    }

    #[test]
    fn on_progress_with_no_udp_progress_keeps_unknown() {
        // Cross-version compat: a pre-0.9.11 server never ships
        // `udp_progress`, so the TUI must stay at "unknown" for the run
        // rather than silently displaying a stale 0.0% next to actual
        // loss bursts in the sparkline.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        app.on_progress(make_progress(50.0, None));
        app.on_progress(make_progress(50.0, None));
        assert_eq!(app.udp_lost_percent, None);
    }

    #[test]
    fn on_progress_preserves_last_percent_when_progress_drops_out() {
        // Once a real reading lands, an interval that omits `udp_progress`
        // (rare but possible mid-test) must not clobber the last-known
        // percent — that would produce a flicker between a real value and
        // unknown that mid-run users would find more confusing than
        // helpful. Initial unknown still stays unknown until the first
        // real sample.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        app.on_progress(make_progress(
            50.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 195,
                packets_lost: 5,
            }),
        ));
        assert_eq!(app.udp_lost_percent, Some(2.5));
        app.on_progress(make_progress(50.0, None));
        assert_eq!(app.udp_lost_percent, Some(2.5));
    }

    #[test]
    fn feedback_only_progress_updates_udp_loss_only() {
        // A feedback-only update carries just `udp_progress`. It must
        // update `udp_lost_percent` but leave throughput history,
        // bytes, retransmits, and other full-interval fields untouched —
        // those values came from the most recent full TCP interval and
        // the feedback path doesn't know any of them.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        // Land a full interval first to populate throughput, bytes,
        // and the sparkline history.
        app.on_progress(make_progress(
            500.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 100,
                packets_lost: 5,
            }),
        ));
        assert_eq!(app.current_throughput_mbps, 500.0);
        let initial_history_len = app.throughput_history.len();

        // Now a feedback-only update with a higher cumulative loss.
        let mut feedback = make_progress(
            // sentinel throughput — feedback updates don't carry it.
            0.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 200,
                packets_lost: 50,
            }),
        );
        feedback.udp_feedback_only = true;
        app.on_progress(feedback);

        // udp_lost_percent updates to the feedback's reading.
        let expected = (50.0 / 250.0) * 100.0;
        assert!((app.udp_lost_percent.unwrap() - expected).abs() < 0.001);
        // Throughput, bytes, sparkline history all preserved.
        assert_eq!(app.current_throughput_mbps, 500.0);
        assert_eq!(app.throughput_history.len(), initial_history_len);
    }

    #[test]
    fn throughput_sample_records_per_interval_loss() {
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        // First interval baselines silently — magnitude unknown, renderer
        // stays primary-colored. Without this, a delayed first progress
        // (control-channel stall, batched intervals) would paint one bar
        // with multi-interval loss as if it were a single 1s burst.
        app.on_progress(make_progress(
            100.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 1000,
                packets_lost: 0,
            }),
        ));
        let baseline = app.throughput_history.back().copied().unwrap();
        assert_eq!(baseline.mbps, 100.0);
        assert_eq!(baseline.interval_packets, 0);
        assert_eq!(baseline.loss_rate_percent(), None);

        // Second interval: +500 received, 0 lost — clean.
        age_last_bar(&mut app);
        app.on_progress(make_progress(
            100.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 1500,
                packets_lost: 0,
            }),
        ));
        let clean = app.throughput_history.back().copied().unwrap();
        assert_eq!(clean.lost_packets, 0);
        assert_eq!(clean.loss_rate_percent(), Some(0.0));

        // Third interval: +800 received, +200 lost — heavy loss (20%).
        age_last_bar(&mut app);
        app.on_progress(make_progress(
            80.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 2300,
                packets_lost: 200,
            }),
        ));
        let lossy = app.throughput_history.back().copied().unwrap();
        assert_eq!(lossy.mbps, 80.0);
        assert_eq!(lossy.lost_packets, 200);
        assert_eq!(lossy.loss_rate_percent(), Some(20.0));
    }

    #[test]
    fn throughput_sample_loss_rate_unknown_without_progress() {
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        // No udp_progress on this Interval — magnitude unknown, renderer
        // must fall back to primary (graph) color rather than fake a tint.
        app.on_progress(make_progress(50.0, None));
        let s = app.throughput_history.back().copied().unwrap();
        assert_eq!(s.interval_packets, 0);
        assert_eq!(s.loss_rate_percent(), None);
    }

    fn make_feedback(packets_received: u64, packets_lost: u64) -> crate::client::TestProgress {
        let mut p = make_progress(
            0.0, // sentinel — feedback updates don't carry throughput
            Some(crate::protocol::UdpIntervalProgress {
                packets_received,
                packets_lost,
            }),
        );
        p.udp_feedback_only = true;
        p
    }

    #[test]
    fn stalled_intervals_synthesize_bars_from_feedback_deltas() {
        // Issue #93: full Intervals stall (saturated control channel) while
        // 2 Hz UDP feedback keeps flowing. tick()'s stall path must keep
        // appending bars at the report cadence, tinted from feedback-derived
        // deltas, with throughput repeating the last-known reading.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        // Two full Intervals land normally: baseline + one clean bar.
        app.on_progress(make_progress(
            100.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 1000,
                packets_lost: 0,
            }),
        ));
        age_last_bar(&mut app);
        app.on_progress(make_progress(
            100.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 2000,
                packets_lost: 0,
            }),
        ));
        assert_eq!(app.throughput_history.len(), 2);
        let t0 = app.last_bar_at.unwrap();

        // Control channel stalls; feedback advances the cumulative counts.
        app.on_progress(make_feedback(2500, 100));

        // Below the stall threshold — no synthesized bar yet.
        app.maybe_append_stalled_bar(t0 + Duration::from_millis(1900));
        assert_eq!(app.throughput_history.len(), 2);

        // Threshold reached: one bar with the feedback delta (+500 received,
        // +100 lost since the last rendered cumulative) and repeated mbps.
        app.maybe_append_stalled_bar(t0 + Duration::from_secs(2));
        assert_eq!(app.throughput_history.len(), 3);
        let bar = app.throughput_history.back().copied().unwrap();
        assert_eq!(bar.mbps, 100.0, "stall bars repeat last-known throughput");
        assert_eq!(bar.lost_packets, 100);
        assert_eq!(bar.interval_packets, 600);

        // Sustained stall holds the 1 Hz rhythm: nothing mid-window, then
        // the next bar carries only the loss accrued since the previous one.
        app.on_progress(make_feedback(3000, 150));
        app.maybe_append_stalled_bar(t0 + Duration::from_millis(2500));
        assert_eq!(app.throughput_history.len(), 3, "no bar mid-window");
        app.maybe_append_stalled_bar(t0 + Duration::from_secs(3));
        assert_eq!(app.throughput_history.len(), 4);
        let bar = app.throughput_history.back().copied().unwrap();
        assert_eq!(bar.lost_packets, 50);
        assert_eq!(bar.interval_packets, 550);
    }

    #[test]
    fn resumed_interval_does_not_recount_loss_from_stall_bars() {
        // When full Intervals resume after feedback-derived bars, the
        // resuming bar's delta must start from the last cumulative already
        // rendered — not from the last full Interval — or loss shown during
        // the stall would be double-counted.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        app.on_progress(make_progress(
            100.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 1000,
                packets_lost: 0,
            }),
        ));
        let t0 = app.last_bar_at.unwrap();

        // Stall: feedback brings cumulative loss to 100, one bar renders it.
        app.on_progress(make_feedback(1500, 100));
        app.maybe_append_stalled_bar(t0 + Duration::from_secs(2));
        assert_eq!(
            app.throughput_history.back().unwrap().lost_packets,
            100,
            "stall bar shows the feedback-derived loss"
        );

        // Control channel resumes with cumulative {2000, 150}. Only the 50
        // not-yet-rendered losses may appear on the new bar.
        age_last_bar(&mut app);
        app.on_progress(make_progress(
            80.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 2000,
                packets_lost: 150,
            }),
        ));
        let bar = app.throughput_history.back().copied().unwrap();
        assert_eq!(bar.mbps, 80.0);
        assert_eq!(bar.lost_packets, 50, "loss from stall bars not re-counted");
        assert_eq!(bar.interval_packets, 550);

        // Total loss across all bars equals the cumulative total exactly.
        let rendered: u64 = app.throughput_history.iter().map(|s| s.lost_packets).sum();
        assert_eq!(rendered, 150);
    }

    #[test]
    fn backlog_flush_appends_one_bar_not_one_per_message() {
        // #93 follow-up (brettowe): when a loss episode ends and the clogged
        // control channel flushes its queued Intervals within milliseconds,
        // at most one bar may render for the flush — previously each message
        // appended its own, jumping the graph forward 4-5 columns at once.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());
        app.on_progress(make_progress(
            100.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 1000,
                packets_lost: 0,
            }),
        ));
        assert_eq!(app.throughput_history.len(), 1);

        // Flush: four queued Intervals land back-to-back. Their stale
        // cumulatives were already swallowed by the producer-side monotonic
        // filter, so udp_progress arrives as None.
        age_last_bar(&mut app);
        for _ in 0..4 {
            app.on_progress(make_progress(90.0, None));
        }
        assert_eq!(
            app.throughput_history.len(),
            2,
            "one bar for the whole flush, not one per flushed message"
        );
        // Numeric state still tracked the flushed messages.
        assert_eq!(app.current_throughput_mbps, 90.0);
    }

    #[test]
    fn flushed_interval_bar_tints_from_freshest_feedback_not_green() {
        // The one bar that does render right after a loss episode must carry
        // the loss accrued since the last rendered bar (known via the 2 Hz
        // feedback path), not reset to "magnitude unknown" (primary/green)
        // just because the flushed Interval's own cumulative was
        // stale-filtered to None.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());
        app.on_progress(make_progress(
            100.0,
            Some(crate::protocol::UdpIntervalProgress {
                packets_received: 1000,
                packets_lost: 0,
            }),
        ));
        // Loss arrives via feedback while the control channel is clogged.
        app.on_progress(make_feedback(1400, 100));

        age_last_bar(&mut app);
        app.on_progress(make_progress(80.0, None));
        let bar = app.throughput_history.back().copied().unwrap();
        assert_eq!(bar.lost_packets, 100, "feedback-known loss, not green");
        assert_eq!(bar.interval_packets, 500);
        assert_eq!(bar.loss_rate_percent(), Some(20.0));
    }

    #[test]
    fn normal_interval_cadence_never_synthesizes_bars() {
        // The common case: full Intervals arriving at 1 Hz. tick() runs ~20×
        // a second between them, but must never add a bar of its own — one
        // bar per Interval, exactly as before issue #93.
        let mut app = App::default();
        app.state = AppState::Running;
        app.start_time = Some(Instant::now());

        for i in 1..=3u64 {
            if i > 1 {
                age_last_bar(&mut app);
            }
            app.on_progress(make_progress(
                100.0,
                Some(crate::protocol::UdpIntervalProgress {
                    packets_received: i * 1000,
                    packets_lost: 0,
                }),
            ));
            // Simulate ticks across the full window up to (but not at) the
            // next Interval, including one arriving late at +1.9s.
            let last = app.last_bar_at.unwrap();
            app.maybe_append_stalled_bar(last + Duration::from_millis(50));
            app.maybe_append_stalled_bar(last + Duration::from_millis(999));
            app.maybe_append_stalled_bar(last + Duration::from_millis(1900));
            assert_eq!(
                app.throughput_history.len(),
                i as usize,
                "exactly one bar per Interval, none synthesized"
            );
        }
    }

    #[test]
    fn stall_before_first_interval_still_advances_bars() {
        // The control channel can stall before the first full Interval ever
        // lands (saturation from t=0). start_time seeds the cadence so the
        // graph advances on feedback alone; the first bar baselines silently
        // (magnitude unknown), real deltas start from the second.
        let mut app = App::default();
        app.state = AppState::Running;
        let t0 = Instant::now();
        app.start_time = Some(t0);

        app.on_progress(make_feedback(1000, 200));
        app.maybe_append_stalled_bar(t0 + Duration::from_secs(2));
        assert_eq!(app.throughput_history.len(), 1);
        let baseline = app.throughput_history.back().copied().unwrap();
        assert_eq!(baseline.interval_packets, 0);
        assert_eq!(baseline.loss_rate_percent(), None);

        app.on_progress(make_feedback(2000, 400));
        app.maybe_append_stalled_bar(t0 + Duration::from_secs(3));
        assert_eq!(app.throughput_history.len(), 2);
        let bar = app.throughput_history.back().copied().unwrap();
        assert_eq!(bar.lost_packets, 200);
        assert_eq!(bar.interval_packets, 1200);
    }

    #[test]
    fn average_throughput_is_byte_weighted_not_a_mean_of_rates() {
        // Regression (LAN-1496): the average was a plain mean of the
        // per-interval rates, so the first interval — a ~1ms sliver between
        // test start and the first report, reported at a huge rate — carried
        // the same weight as a full second and roughly doubled the figure.
        let mut app = App::default();
        app.state = AppState::Running;

        // 1ms sliver at ~1548 Mbps, then a full second at 200 Mbps.
        let mut sliver = make_progress(1547.9, None);
        sliver.elapsed_ms = 1;
        sliver.total_bytes = 193_488;
        app.on_progress(sliver);

        let mut steady = make_progress(200.0, None);
        steady.elapsed_ms = 1001;
        steady.total_bytes = 25_000_000;
        app.on_progress(steady);

        // Byte-weighted: 25_193_488 B * 8 / 1.001 s ~= 201.3 Mbps.
        // A mean of the two rates would report ~874 Mbps instead.
        let avg = app.average_throughput_mbps;
        assert!(
            (avg - 201.3).abs() < 1.0,
            "expected ~201 Mbps byte-weighted, got {avg}"
        );

        // Preserved from the original regression this test covered: an
        // interval that moves no bytes while the clock advances must pull the
        // average down rather than leaving it untouched.
        let mut stalled = make_progress(0.0, None);
        stalled.elapsed_ms = 2001;
        stalled.total_bytes = 0;
        app.on_progress(stalled);
        assert!(
            app.average_throughput_mbps < avg,
            "a zero-byte interval must reduce the average, got {}",
            app.average_throughput_mbps
        );
    }

    #[test]
    fn retransmit_fallback_is_cumulative_across_intervals() {
        // When the server omits progress.total_retransmits, the TUI must
        // accumulate per-stream interval deltas instead of resetting the
        // display to each interval's value.
        let mut app = App::default();
        app.state = AppState::Running;

        let mut p1 = make_progress(1.0, None);
        p1.streams = vec![crate::protocol::StreamInterval {
            id: 0,
            bytes: 0,
            retransmits: Some(5),
            jitter_ms: None,
            lost: None,
            error: None,
            rtt_us: None,
            cwnd: None,
        }];
        app.on_progress(p1);
        assert_eq!(app.total_retransmits, 5);

        let mut p2 = make_progress(1.0, None);
        p2.streams = vec![crate::protocol::StreamInterval {
            id: 0,
            bytes: 0,
            retransmits: Some(3),
            jitter_ms: None,
            lost: None,
            error: None,
            rtt_us: None,
            cwnd: None,
        }];
        app.on_progress(p2);
        assert_eq!(app.total_retransmits, 8);
    }

    #[test]
    fn total_retransmits_overrides_cumulative_fallback() {
        // Servers that ship progress.total_retransmits use the authoritative
        // cumulative count directly.
        let mut app = App::default();
        app.state = AppState::Running;

        let mut p = make_progress(1.0, None);
        p.total_retransmits = Some(42);
        p.streams = vec![crate::protocol::StreamInterval {
            id: 0,
            bytes: 0,
            retransmits: Some(5),
            jitter_ms: None,
            lost: None,
            error: None,
            rtt_us: None,
            cwnd: None,
        }];
        app.on_progress(p);
        assert_eq!(app.total_retransmits, 42);
    }

    #[test]
    fn retransmit_fallback_does_not_mix_after_authoritative_total() {
        let mut app = App::default();
        app.state = AppState::Running;

        let mut authoritative = make_progress(1.0, None);
        authoritative.total_retransmits = Some(42);
        app.on_progress(authoritative);
        assert_eq!(app.total_retransmits, 42);

        let mut fallback = make_progress(1.0, None);
        fallback.streams = vec![crate::protocol::StreamInterval {
            id: 0,
            bytes: 0,
            retransmits: Some(5),
            jitter_ms: None,
            lost: None,
            error: None,
            rtt_us: None,
            cwnd: None,
        }];
        app.on_progress(fallback);
        assert_eq!(
            app.total_retransmits, 42,
            "once authoritative cumulative totals arrive, fallback deltas must not be added on top"
        );
    }
    #[test]
    fn byte_budget_progress_tracks_bytes_not_time() {
        let mut app = App::default();
        // A `-n` test normally has no duration at all: with time-based
        // progress the bar would sit at "infinite", which renders full and
        // reads as already finished.
        app.duration = Duration::ZERO;
        app.byte_budget = Some(1000);
        assert!(app.is_infinite());

        assert_eq!(app.progress_percent(), 0.0);
        app.total_bytes = 250;
        assert_eq!(app.progress_percent(), 25.0);
        app.total_bytes = 1000;
        assert_eq!(app.progress_percent(), 100.0);
        // Overshoot (bidir counts both directions) must not exceed the bar.
        app.total_bytes = 5000;
        assert_eq!(app.progress_percent(), 100.0);
    }

    #[test]
    fn timed_tests_keep_time_based_progress() {
        let mut app = App::default();
        app.duration = Duration::from_secs(10);
        app.byte_budget = None;
        app.elapsed = Duration::from_secs(3);
        app.total_bytes = 999_999;
        assert_eq!(app.progress_percent(), 30.0);
    }

    #[test]
    fn on_progress_accumulates_total_bytes_across_intervals() {
        let mut app = App::default();
        assert_eq!(app.total_bytes, 0);

        let mut progress = TestProgress {
            elapsed_ms: 1000,
            total_bytes: 1000,
            throughput_mbps: 8.0,
            streams: vec![],
            rtt_us: None,
            cwnd: None,
            total_retransmits: None,
            bytes_sent: None,
            bytes_received: None,
            throughput_send_mbps: None,
            throughput_recv_mbps: None,
            udp_progress: None,
            udp_feedback_only: false,
        };
        app.on_progress(progress.clone());
        assert_eq!(app.total_bytes, 1000);

        progress.elapsed_ms = 2000;
        progress.total_bytes = 1500;
        app.on_progress(progress);
        assert_eq!(app.total_bytes, 2500);
    }

    #[test]
    fn on_result_sets_elapsed_and_total_bytes_for_byte_budget_test() {
        let mut app = App::default();
        app.duration = Duration::ZERO;
        app.byte_budget = Some(10_000);
        assert!(app.is_infinite());

        let result = TestResult {
            id: "test-123".to_string(),
            duration_ms: 3500,
            bytes_total: 10_000,
            throughput_mbps: 22.8,
            streams: vec![],
            tcp_info: None,
            udp_stats: None,
            bytes_sent: None,
            bytes_received: None,
            throughput_send_mbps: None,
            throughput_recv_mbps: None,
            mtu_probe: None,
        };
        app.on_result(result);
        assert_eq!(app.elapsed, Duration::from_millis(3500));
        assert_eq!(app.total_bytes, 10_000);
        assert_eq!(app.progress_percent(), 100.0);
    }

    #[test]
    fn render_fingerprint_changes_only_when_the_frame_would() {
        type AppMutation = (&'static str, fn(&mut App));

        let size = Size::new(120, 40);
        let mut app = App::default();
        // Long test so one progress-bar cell (duration / bar width) is far
        // coarser than the sub-second steps below.
        app.duration = Duration::from_secs(3600);
        app.on_connected();
        assert_eq!(app.render_fingerprint(size), app.render_fingerprint(size));

        // Sub-second elapsed drift with nothing else changed renders the same
        // "0s" and the same bar fill, so a Running frame must be skippable.
        app.elapsed = Duration::from_millis(100);
        let fp = app.render_fingerprint(size);
        app.elapsed = Duration::from_millis(900);
        assert_eq!(fp, app.render_fingerprint(size), "sub-second drift only");
        app.elapsed = Duration::from_millis(1000);
        assert_ne!(fp, app.render_fingerprint(size), "whole-second crossing");

        // A bar-fill boundary is visible even within one second: a 10s test on
        // an 86-cell bar advances a cell every ~116ms.
        app.duration = Duration::from_secs(10);
        app.elapsed = Duration::from_millis(1000);
        let fp = app.render_fingerprint(size);
        app.elapsed = Duration::from_millis(1200);
        assert_ne!(fp, app.render_fingerprint(size), "bar fill advanced");

        // ...and the bar draws partial blocks, so an eighth of a cell (~15ms
        // here) is already visible movement. Hashing whole cells would call
        // these two frames identical and hold a stale bar on screen.
        app.elapsed = Duration::from_millis(1000);
        let fp = app.render_fingerprint(size);
        app.elapsed = Duration::from_millis(1040);
        assert_ne!(fp, app.render_fingerprint(size), "bar advanced one eighth");

        // Every representative mutation dirties the frame.
        let mutations: &[AppMutation] = &[
            ("on_progress", |a| a.on_progress(make_progress(100.0, None))),
            ("log", |a| a.log("line")),
            ("toggle_help", |a| a.toggle_help()),
            ("cycle_theme", |a| a.cycle_theme()),
            ("set_server_version", |a| {
                a.set_server_version("xfr/0.9.25".to_string())
            }),
            ("update_available", |a| {
                a.update_available = Some("v9.9.9".to_string())
            }),
            ("toggle_pause", |a| a.toggle_pause()),
            ("settings.toggle", |a| a.settings.toggle()),
            ("settings.move_down", |a| a.settings.move_down()),
            ("cancel countdown 60s", |a| {
                a.cancel_deadline = Some(Instant::now() + Duration::from_secs(60))
            }),
            ("cancel countdown 30s", |a| {
                a.cancel_deadline = Some(Instant::now() + Duration::from_secs(30))
            }),
            ("on_result", |a| {
                a.on_result(TestResult {
                    id: "test".to_string(),
                    duration_ms: 10_000,
                    bytes_total: 1234,
                    throughput_mbps: 42.0,
                    streams: vec![],
                    tcp_info: None,
                    udp_stats: None,
                    bytes_sent: None,
                    bytes_received: None,
                    throughput_send_mbps: None,
                    throughput_recv_mbps: None,
                    mtu_probe: None,
                })
            }),
        ];
        for &(name, mutate) in mutations {
            let before = app.render_fingerprint(size);
            mutate(&mut app);
            assert_ne!(
                before,
                app.render_fingerprint(size),
                "{name} must dirty the frame"
            );
        }

        // A resize re-flows the layout with identical state.
        assert_ne!(
            app.render_fingerprint(size),
            app.render_fingerprint(Size::new(100, 30))
        );

        // Hash the palette itself, not just the built-in theme name. This
        // keeps the cache correct if a caller customizes Theme's public
        // colors without changing its name.
        let before = app.render_fingerprint(size);
        app.theme.text = ratatui::style::Color::Magenta;
        assert_ne!(before, app.render_fingerprint(size));
    }
}
