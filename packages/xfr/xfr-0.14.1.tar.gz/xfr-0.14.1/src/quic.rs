//! QUIC transport implementation using quinn
//!
//! QUIC provides:
//! - Built-in TLS 1.3 encryption
//! - Multiplexed streams over a single connection
//! - Stream 0 for control, streams 1-N for data
//!
//! # Connection Flow
//!
//! ```text
//! Client                                 Server
//!   │                                      │
//!   │── QUIC handshake (TLS 1.3) ─────────>│
//!   │<─────────────────────────────────────│
//!   │                                      │
//!   │== Stream 0 (bidirectional) =========│  Control channel
//!   │   Hello, TestStart, Interval, etc.  │
//!   │                                      │
//!   │== Stream 1 (unidirectional) ========│  Data stream 1
//!   │== Stream 2 (unidirectional) ========│  Data stream 2
//!   │== ...                               │
//!   │                                      │
//! ```
//!
//! # Security Model
//!
//! QUIC provides transport encryption via TLS 1.3, but xfr uses self-signed
//! certificates by default, so unauthenticated sessions do not verify server
//! identity. For authenticated connections, combine QUIC with PSK authentication
//! (`--psk`): xfr binds the PSK handshake to the exact TLS connection using the
//! RFC 9266 exporter, preventing a terminating relay from splicing two QUIC legs.
//!
//! The self-signed approach is chosen because:
//! 1. xfr is typically used on trusted networks (LAN, VPN)
//! 2. PSK authentication provides mutual authentication when needed
//! 3. CA infrastructure is impractical for ephemeral test servers

use std::io;
use std::net::SocketAddr;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};
use std::time::Duration;

use hkdf::Hkdf;
use quinn::{
    AsyncUdpSocket, ClientConfig, Connection, ConnectionError, Endpoint, EndpointConfig,
    RecvStream, SendStream, ServerConfig, TransportConfig, UdpPoller, VarInt, WriteError,
    crypto::rustls::{QuicClientConfig, QuicServerConfig},
};
use rustls::pki_types::{CertificateDer, PrivateKeyDer};
use sha2::Sha256;
use socket2::{Protocol, Socket, Type};
use tokio::sync::{mpsc, watch};
use tracing::{debug, error, info};

use crate::net::AddressFamily;
use crate::stats::StreamStats;
use crate::udp::SharedSocketLane;

/// A single-port UDP hello diverted off the shared server socket:
/// raw datagram bytes plus the client's source address.
pub type XfrHelloDatagram = (Vec<u8>, SocketAddr);

/// Default buffer size for QUIC send/receive operations (128 KB)
const DEFAULT_BUFFER_SIZE: usize = 128 * 1024;
/// Maximum data-stream count accepted by the CLI (`-P 128`). QUIC data
/// streams are unidirectional, so both endpoints must advertise this much
/// incoming unidirectional-stream credit or Quinn's default of 100 silently
/// strands the final 28 streams.
const MAX_CONCURRENT_DATA_STREAMS: u32 = 128;
/// Maximum consecutive divert-only batches in `XfrLaneTee::poll_recv`
/// before rescheduling quinn's receive task, preventing starvation under heavy
/// xfr-hello load (LAN-170 #32).
const MAX_DIVERT_ITERATIONS: u32 = 16;
/// Suppression window for peer-initiated stream stops near the test
/// deadline. The peer stops streams / closes the connection at its own
/// deadline, which can precede ours by the path RTT plus scheduling slop
/// (mirrors tcp.rs SEND_TEARDOWN_GRACE).
const SEND_TEARDOWN_GRACE: Duration = Duration::from_millis(250);
/// Application close code: the test finished normally.
pub(crate) const QUIC_CLOSE_DONE: VarInt = VarInt::from_u32(0);
/// Application close code: the server is shutting down.
pub(crate) const QUIC_CLOSE_SHUTDOWN: VarInt = VarInt::from_u32(1);
/// Upper bound on lingering at teardown so a CONNECTION_CLOSE can be sent
/// and re-sent. Quinn withholds a close while the congestion window is full
/// of unacknowledged data, so neither side may depend on the peer's close
/// arriving.
pub(crate) const QUIC_CLOSE_GRACE: Duration = Duration::from_secs(1);
/// How long the client waits without hearing anything from the server before
/// it gives up, both while connecting and mid-test. Quinn's 30 s default kept
/// a client hanging that long after the server vanished. 5 s was too short:
/// on a 1.2 s RTT link with 20% loss, PTO exponential backoff leaves a healthy
/// connection silent for longer than that. QUIC negotiates the smaller of the
/// two peers' values, so this also applies to the server side of a connection
/// from this client.
pub(crate) const QUIC_IDLE_TIMEOUT: Duration = Duration::from_secs(10);
/// Client keep-alive, well inside `QUIC_IDLE_TIMEOUT`, so a paused or idle
/// test still exchanges packets (the server's 5 s keep-alive alone leaves
/// little margin when keep-alives are lost).
const QUIC_KEEP_ALIVE_INTERVAL: Duration = Duration::from_secs(1);
/// TLS exporter label for binding application PSK authentication to the QUIC
/// connection. RFC 9266 defines this exact label; it is wire-stable.
const PSK_CHANNEL_BINDING_EXPORTER_LABEL: &[u8] = b"EXPORTER-Channel-Binding";
/// HKDF info for the per-connection PSK. This is also wire-stable.
const PSK_SESSION_INFO: &[u8] = b"xfr-quic-psk-session-v1";

/// Derive the per-connection PSK used by QUIC authentication and control
/// protection. The TLS exporter is a public HKDF salt; the configured PSK is
/// the input keying material, preserving the PSK as the secret input.
pub(crate) fn derive_psk_session_key(
    connection: &Connection,
    configured_psk: &str,
) -> anyhow::Result<[u8; 32]> {
    let mut exporter = [0u8; 32];
    connection
        .export_keying_material(&mut exporter, PSK_CHANNEL_BINDING_EXPORTER_LABEL, b"")
        .map_err(|_| anyhow::anyhow!("failed to export QUIC TLS channel-binding material"))?;
    derive_psk_session_key_from_exporter(configured_psk, &exporter)
}

fn derive_psk_session_key_from_exporter(
    configured_psk: &str,
    exporter: &[u8; 32],
) -> anyhow::Result<[u8; 32]> {
    let hk = Hkdf::<Sha256>::new(Some(exporter), configured_psk.as_bytes());
    let mut session_psk = [0u8; 32];
    hk.expand(PSK_SESSION_INFO, &mut session_psk)
        .map_err(|_| anyhow::anyhow!("failed to derive QUIC PSK session key"))?;
    Ok(session_psk)
}

/// Generate a self-signed certificate for QUIC
///
/// xfr uses its own PSK authentication mechanism, so we don't need
/// proper certificate validation. This generates a temporary cert
/// for the QUIC handshake.
pub fn generate_self_signed_cert()
-> anyhow::Result<(Vec<CertificateDer<'static>>, PrivateKeyDer<'static>)> {
    let cert = rcgen::generate_simple_self_signed(vec!["xfr".to_string()])?;
    let key = PrivateKeyDer::Pkcs8(cert.signing_key.serialize_der().into());
    let cert_der = CertificateDer::from(cert.cert);
    Ok((vec![cert_der], key))
}

/// Create a QUIC server endpoint
///
/// Uses socket2 to create the UDP socket with proper dual-stack handling.
/// On Windows, `std::net::UdpSocket::bind("[::]:port")` does NOT accept IPv4
/// connections by default — we must explicitly set `IPV6_V6ONLY=false`.
///
/// When `xfr_hello_tx` is `Some` (single-port UDP enabled, issue #63),
/// the socket also joins an SO_REUSEPORT group so per-stream connected
/// data sockets can bind the same port later, and quinn receives a tee
/// wrapper that diverts xfr hello datagrams to the dispatcher while
/// passing QUIC through untouched. The endpoint then disables QUIC-bit
/// greasing — see the `XfrLaneTee` tee for why that is load-bearing.
pub fn create_server_endpoint(
    addr: SocketAddr,
    family: AddressFamily,
    cert: Vec<CertificateDer<'static>>,
    key: PrivateKeyDer<'static>,
    xfr_hello_tx: Option<mpsc::Sender<XfrHelloDatagram>>,
) -> anyhow::Result<Endpoint> {
    let mut crypto = rustls::ServerConfig::builder()
        .with_no_client_auth()
        .with_single_cert(cert, key)?;

    crypto.alpn_protocols = vec![b"xfr".to_vec()];

    let mut transport = TransportConfig::default();
    // Preserve the existing bidirectional allowance; the control channel is
    // bidirectional, while all xfr data streams use `open_uni`.
    transport.max_concurrent_bidi_streams(VarInt::from_u32(MAX_CONCURRENT_DATA_STREAMS + 1));
    transport.max_concurrent_uni_streams(VarInt::from_u32(MAX_CONCURRENT_DATA_STREAMS));
    transport.keep_alive_interval(Some(Duration::from_secs(5)));

    let quic_crypto = QuicServerConfig::try_from(crypto)?;
    let mut server_config = ServerConfig::with_crypto(Arc::new(quic_crypto));
    server_config.transport_config(Arc::new(transport));

    // Create the UDP socket ourselves so we can set IPV6_V6ONLY properly.
    // Quinn's Endpoint::server() uses std::net::UdpSocket::bind() which
    // doesn't configure dual-stack, breaking IPv4 on Windows (#39).
    let socket = Socket::new(family.domain(), Type::DGRAM, Some(Protocol::UDP))?;
    if family != AddressFamily::V4Only {
        let v6only = family == AddressFamily::V6Only;
        socket.set_only_v6(v6only)?;
        debug!("QUIC socket IPV6_V6ONLY={} for {} mode", v6only, family);
    }
    if xfr_hello_tx.is_some() {
        // Both options must be set BEFORE bind for later same-port
        // connected sockets to be admitted to the group.
        socket.set_reuse_address(true)?;
        #[cfg(unix)]
        socket.set_reuse_port(true)?;
    }
    socket.bind(&socket2::SockAddr::from(addr))?;
    socket.set_nonblocking(true)?;
    let std_socket: std::net::UdpSocket = socket.into();

    let runtime =
        quinn::default_runtime().ok_or_else(|| anyhow::anyhow!("no async runtime found"))?;
    let mut endpoint_config = EndpointConfig::default();
    // Wrap the runtime's own quinn-udp-backed socket object so the
    // GSO/GRO/ECN metadata paths are preserved — the tee only inspects
    // and reroutes, it never reimplements IO.
    let inner = runtime.wrap_udp_socket(std_socket)?;
    let socket: Arc<dyn AsyncUdpSocket> = match xfr_hello_tx {
        Some(hello_tx) => {
            // The shared-socket classifier routes short-header QUIC by its
            // fixed bit (0x40). Quinn greases that bit by default (RFC
            // 9287); greasing is permission-based, so a server that never
            // advertises the grease transport parameter stops compliant
            // peers from clearing the bit toward us — which is what makes
            // the classifier sound.
            endpoint_config.grease_quic_bit(false);
            // Late bulk UDP datagrams can reach the wildcard after a
            // connected stream closes. Drain them intact before classifying:
            // Quinn's default 1472-byte buffers truncate jumbo xfr payloads
            // (and quinn-udp's macOS recv path can spin after MSG_TRUNC).
            endpoint_config.max_udp_payload_size(crate::udp::MAX_UDP_PAYLOAD_SIZE as u16)?;
            Arc::new(XfrLaneTee { inner, hello_tx })
        }
        None => inner,
    };
    let endpoint =
        Endpoint::new_with_abstract_socket(endpoint_config, Some(server_config), socket, runtime)?;
    info!("QUIC server listening on {} ({})", addr, family);

    Ok(endpoint)
}

/// Tee on the shared server UDP socket (issue #63): inbound datagrams
/// matching the xfr single-port hello lane divert to the dispatcher
/// channel; everything else flows through to quinn untouched. Delegates
/// every `AsyncUdpSocket` operation to the real quinn-udp-backed socket,
/// so send-side GSO/ECN and recv-side GRO behavior are unchanged.
///
/// This is a low-rate hello/straggler lane ONLY. Per-stream data rides
/// connected sockets that the kernel scores above this wildcard, so
/// after the handshake the tee never sees test traffic.
#[derive(Debug)]
struct XfrLaneTee {
    inner: Arc<dyn AsyncUdpSocket>,
    hello_tx: mpsc::Sender<XfrHelloDatagram>,
}

impl AsyncUdpSocket for XfrLaneTee {
    fn create_io_poller(self: Arc<Self>) -> Pin<Box<dyn UdpPoller>> {
        self.inner.clone().create_io_poller()
    }

    fn try_send(&self, transmit: &quinn::udp::Transmit) -> io::Result<()> {
        self.inner.try_send(transmit)
    }

    fn poll_recv(
        &self,
        cx: &mut Context,
        bufs: &mut [io::IoSliceMut<'_>],
        meta: &mut [quinn::udp::RecvMeta],
    ) -> Poll<io::Result<usize>> {
        // Bound consecutive divert-only batches to prevent starving quinn
        // under heavy xfr-hello load. After this many iterations with zero
        // QUIC packets kept, yield this poll and ask the executor to
        // reschedule us.
        let mut divert_iterations: u32 = 0;

        loop {
            let n = match self.inner.poll_recv(cx, bufs, meta) {
                Poll::Ready(Ok(n)) => n,
                other => return other,
            };
            // Divert xfr-lane entries and compact the QUIC ones down so
            // quinn sees a contiguous prefix of buffers it owns.
            let mut kept = 0;
            for i in 0..n {
                let len = meta[i].len.min(bufs[i].len());
                match crate::udp::classify_shared_datagram(&bufs[i][..len]) {
                    SharedSocketLane::Quic => {
                        if kept != i {
                            let (front, back) = bufs.split_at_mut(i);
                            if front[kept].len() < len {
                                // Can't happen with quinn's equal-size recv
                                // buffers; drop rather than panic in poll.
                                debug!("shared-socket tee: buffer too small to compact");
                                continue;
                            }
                            front[kept][..len].copy_from_slice(&back[0][..len]);
                            meta[kept] = meta[i];
                        }
                        kept += 1;
                    }
                    SharedSocketLane::XfrHello => {
                        // Low-rate lane with client-side retry: dropping on
                        // a full channel is safe, blocking quinn's recv
                        // path is not.
                        let _ = self
                            .hello_tx
                            .try_send((bufs[i][..len].to_vec(), meta[i].addr));
                    }
                    SharedSocketLane::XfrStray => {
                        debug!(
                            "shared-socket tee: dropping {}-byte non-QUIC datagram from {}",
                            meta[i].len, meta[i].addr
                        );
                    }
                }
            }
            if kept > 0 || n == 0 {
                return Poll::Ready(Ok(kept));
            }
            // Every datagram in the batch was diverted; poll the inner
            // socket again instead of handing quinn an empty result.
            divert_iterations += 1;
            if divert_iterations >= MAX_DIVERT_ITERATIONS {
                debug!(
                    "shared-socket tee: {} consecutive divert-only batches, yielding receive task",
                    divert_iterations
                );
                cx.waker().wake_by_ref();
                return Poll::Pending;
            }
        }
    }

    fn local_addr(&self) -> io::Result<SocketAddr> {
        self.inner.local_addr()
    }

    fn max_transmit_segments(&self) -> usize {
        self.inner.max_transmit_segments()
    }

    fn max_receive_segments(&self) -> usize {
        self.inner.max_receive_segments()
    }

    fn may_fragment(&self) -> bool {
        self.inner.may_fragment()
    }
}

/// Create a QUIC client endpoint with optional local bind address
pub fn create_client_endpoint(
    remote_addr: SocketAddr,
    local_bind: Option<SocketAddr>,
) -> anyhow::Result<Endpoint> {
    // Client accepts any certificate (xfr uses its own auth mechanism)
    let mut crypto = rustls::ClientConfig::builder()
        .dangerous()
        .with_custom_certificate_verifier(Arc::new(SkipServerVerification))
        .with_no_client_auth();

    // Must match server ALPN
    crypto.alpn_protocols = vec![b"xfr".to_vec()];

    let mut transport = TransportConfig::default();
    transport.max_concurrent_bidi_streams(VarInt::from_u32(MAX_CONCURRENT_DATA_STREAMS + 1));
    transport.max_concurrent_uni_streams(VarInt::from_u32(MAX_CONCURRENT_DATA_STREAMS));
    transport.max_idle_timeout(Some(QUIC_IDLE_TIMEOUT.try_into()?));
    transport.keep_alive_interval(Some(QUIC_KEEP_ALIVE_INTERVAL));

    let quic_crypto = QuicClientConfig::try_from(crypto)?;
    let mut client_config = ClientConfig::new(Arc::new(quic_crypto));
    client_config.transport_config(Arc::new(transport));

    // Use provided bind address, or match the remote address family
    let bind_addr: SocketAddr = match local_bind {
        Some(addr) => crate::net::match_bind_family(addr, remote_addr),
        None => {
            if remote_addr.is_ipv6() {
                "[::]:0".parse().unwrap()
            } else {
                "0.0.0.0:0".parse().unwrap()
            }
        }
    };

    let mut endpoint = Endpoint::client(bind_addr)?;
    endpoint.set_default_client_config(client_config);

    Ok(endpoint)
}

/// Skip certificate verification (xfr uses PSK auth instead)
#[derive(Debug)]
struct SkipServerVerification;

impl rustls::client::danger::ServerCertVerifier for SkipServerVerification {
    fn verify_server_cert(
        &self,
        _end_entity: &CertificateDer<'_>,
        _intermediates: &[CertificateDer<'_>],
        _server_name: &rustls::pki_types::ServerName<'_>,
        _ocsp: &[u8],
        _now: rustls::pki_types::UnixTime,
    ) -> Result<rustls::client::danger::ServerCertVerified, rustls::Error> {
        Ok(rustls::client::danger::ServerCertVerified::assertion())
    }

    fn verify_tls12_signature(
        &self,
        _: &[u8],
        _: &CertificateDer<'_>,
        _: &rustls::DigitallySignedStruct,
    ) -> Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error> {
        Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
    }

    fn verify_tls13_signature(
        &self,
        _: &[u8],
        _: &CertificateDer<'_>,
        _: &rustls::DigitallySignedStruct,
    ) -> Result<rustls::client::danger::HandshakeSignatureValid, rustls::Error> {
        Ok(rustls::client::danger::HandshakeSignatureValid::assertion())
    }

    fn supported_verify_schemes(&self) -> Vec<rustls::SignatureScheme> {
        vec![
            rustls::SignatureScheme::ECDSA_NISTP256_SHA256,
            rustls::SignatureScheme::RSA_PKCS1_SHA256,
            rustls::SignatureScheme::ED25519,
        ]
    }
}

/// Log a data stream's error. Once the whole connection is gone, every
/// stream fails with the same "connection lost" that the control path
/// reports as the test's error, so that is debug-level; a stream failing on a
/// live connection gets an ERROR line.
pub(crate) fn log_stream_error(conn: &Connection, what: &str, e: impl std::fmt::Display) {
    if conn.close_reason().is_some() {
        debug!("{what}: {e}");
    } else {
        error!("{what}: {e}");
    }
}

/// Send data over a QUIC stream. Errors are returned, not logged: callers
/// log them with `log_stream_error`.
pub async fn send_quic_data(
    mut send: SendStream,
    stats: Arc<StreamStats>,
    duration: Duration,
    bitrate: Option<u64>,
    mut cancel: watch::Receiver<bool>,
    mut pause: watch::Receiver<bool>,
    budget: Option<Arc<crate::budget::ByteBudget>>,
) -> anyhow::Result<()> {
    // Cap buffer size for rate-limited sends to prevent large first-write burst
    let buf_size = match bitrate {
        Some(bps) if bps > 0 => {
            let bytes_per_sec = bps / 8;
            // Target ~10 writes/sec minimum, capped at default buffer size
            DEFAULT_BUFFER_SIZE.min((bytes_per_sec / 10).max(1) as usize)
        }
        _ => DEFAULT_BUFFER_SIZE,
    };
    let buffer = vec![0u8; buf_size];
    let start = tokio::time::Instant::now();
    let mut deadline = start + duration;
    let is_infinite = duration == Duration::ZERO;
    let mut pace_start = start;
    let mut pace_bytes_offset: u64 = 0;
    loop {
        if *cancel.borrow() {
            debug!("QUIC send cancelled");
            break;
        }

        if crate::pause::is_paused(&pause) {
            let (cancelled, paused) =
                crate::pause::wait_while_paused_timed(&mut pause, &mut cancel).await;
            if cancelled {
                break;
            }
            // Extend the deadline by the time spent paused (LAN-230)
            deadline += paused;
            // Reset pacing baseline after resume to prevent catch-up burst
            pace_start = tokio::time::Instant::now();
            pace_bytes_offset = stats.bytes_sent.load(std::sync::atomic::Ordering::Relaxed);
            continue;
        }

        // Duration::ZERO means infinite - only check deadline if finite
        if !is_infinite && tokio::time::Instant::now() >= deadline {
            break;
        }

        // Reserve this write's share of the `-n` budget; 0 means done.
        let claimed = crate::budget::claim_or_full(budget.as_ref(), buffer.len());
        if claimed == 0 {
            debug!("QUIC byte budget spent");
            break;
        }

        // Race the write against cancel, deadline, and pause so a blocked
        // write can be interrupted (LAN-230).
        tokio::select! {
            biased;
            res = cancel.changed() => {
                crate::budget::refund_unwritten(budget.as_ref(), claimed, 0);
                if res.is_err() || *cancel.borrow() {
                    debug!("QUIC send cancelled during write");
                    break;
                }
            }
            _ = pause.changed(), if crate::pause::channel_is_open(&pause) => {
                // Pause toggled during write — loop back to handle it
                // and extend the deadline (LAN-230).
                crate::budget::refund_unwritten(budget.as_ref(), claimed, 0);
                continue;
            }
            _ = tokio::time::sleep_until(deadline), if !is_infinite => {
                debug!("QUIC send deadline reached during write");
                crate::budget::refund_unwritten(budget.as_ref(), claimed, 0);
                break;
            }
            result = send.write(&buffer[..claimed]) => {
                match result {
                    Ok(n) => {
                        crate::budget::refund_unwritten(budget.as_ref(), claimed, n);
                        stats.add_bytes_sent(n as u64);

                        // Pace sends to target bitrate using byte-budget approach
                        if let Some(bps) = bitrate
                            && bps > 0
                        {
                            let bytes_per_sec = bps as f64 / 8.0;
                            let elapsed = pace_start.elapsed().as_secs_f64();
                            let expected = elapsed * bytes_per_sec;
                            let total = (stats.bytes_sent.load(std::sync::atomic::Ordering::Relaxed)
                                - pace_bytes_offset) as f64;
                            if total > expected {
                                let overshoot = Duration::from_secs_f64((total - expected) / bytes_per_sec);
                                tokio::select! {
                                    biased;
                                    _ = cancel.changed() => {
                                        debug!("QUIC send cancelled during pacing sleep");
                                        break;
                                    }
                                    _ = pause.changed(), if crate::pause::channel_is_open(&pause) => {}
                                    _ = tokio::time::sleep(overshoot) => {}
                                }
                            }
                        }
                    }
                    Err(e) => {
                        crate::budget::refund_unwritten(budget.as_ref(), claimed, 0);
                        let now = tokio::time::Instant::now();
                        let deadline_reached = !is_infinite && now >= deadline;
                        let near_deadline = !is_infinite && now + SEND_TEARDOWN_GRACE >= deadline;
                        let peer_closed = matches!(
                            e,
                            WriteError::Stopped(_) | WriteError::ConnectionLost(_)
                        );
                        // Treat a peer-initiated stop as clean teardown only when we
                        // are already cancelling or very close to the configured end
                        // time (mirrors the TCP send path). A mid-test stop still
                        // surfaces as an error (the caller logs it).
                        if *cancel.borrow() || deadline_reached || (peer_closed && near_deadline) {
                            debug!("QUIC send ended by peer during teardown: {}", e);
                            break;
                        }
                        return Err(e.into());
                    }
                }
            }
        }
    }

    // finish() only fails if the stream is already finished or stopped
    // (e.g. by the peer during teardown above) — never data loss, so it
    // isn't worth failing the whole send task over.
    if let Err(e) = send.finish() {
        debug!("QUIC stream finish after send loop: {}", e);
    }
    // `-n`: the transfer ends when the peer has ACKed the last byte, not when
    // it entered quinn's send buffer.
    // Capped: with older peers the negotiated idle timeout is 30 s.
    if budget.is_some() && !*cancel.borrow() {
        tokio::select! {
            _ = send.stopped() => {}
            _ = cancel.changed() => {}
            _ = tokio::time::sleep(crate::budget::ACK_WAIT_CAP) => {
                debug!("QUIC -n delivery not acknowledged in time; ending anyway");
            }
        }
    }
    Ok(())
}

/// Decision returned by [`handle_cancel_change`] — extracted from
/// `receive_quic_data` so the cancel-sender-drop logic is unit-testable
/// without a live QUIC stream.
enum CancelAction {
    /// Keep receiving
    Continue,
    /// Stop — cancelled or sender dropped
    Stop,
}

/// Handle a `cancel.changed()` result the way `receive_quic_data` does.
/// `Err` (sender dropped) → `Stop` to avoid busy-loop (LAN-170 #33).
/// `Ok` with `true` → `Stop` (cancelled). `Ok` with `false` → `Continue`.
fn handle_cancel_change(
    res: Result<(), watch::error::RecvError>,
    cancel: &watch::Receiver<bool>,
) -> CancelAction {
    if res.is_err() {
        debug!("QUIC receive: cancel sender dropped, stopping");
        return CancelAction::Stop;
    }
    if *cancel.borrow() {
        debug!("QUIC receive cancelled");
        return CancelAction::Stop;
    }
    CancelAction::Continue
}

/// Receive data from a QUIC stream
pub async fn receive_quic_data(
    mut recv: RecvStream,
    stats: Arc<StreamStats>,
    mut cancel: watch::Receiver<bool>,
) -> anyhow::Result<()> {
    let mut buffer = vec![0u8; DEFAULT_BUFFER_SIZE];

    loop {
        tokio::select! {
            result = recv.read(&mut buffer) => {
                match result? {
                    Some(n) => stats.add_bytes_received(n as u64),
                    None => break, // Stream finished
                }
            }
            res = cancel.changed() => {
                if matches!(handle_cancel_change(res, &cancel), CancelAction::Stop) {
                    break;
                }
            }
        }
    }

    Ok(())
}

/// Connect to a QUIC server
pub async fn connect(endpoint: &Endpoint, addr: SocketAddr) -> anyhow::Result<Connection> {
    let connection = endpoint.connect(addr, "xfr")?.await.map_err(|e| match e {
        ConnectionError::TimedOut => anyhow::anyhow!(
            "could not reach {} over QUIC (no response within {}s)",
            addr,
            QUIC_IDLE_TIMEOUT.as_secs()
        ),
        e => e.into(),
    })?;
    debug!("QUIC connected to {}", addr);
    Ok(connection)
}

#[cfg(test)]
mod tests {
    use super::*;
    use tokio::sync::watch;

    #[test]
    fn psk_session_key_derivation_matches_fixed_vector() {
        assert_eq!(
            PSK_CHANNEL_BINDING_EXPORTER_LABEL,
            b"EXPORTER-Channel-Binding"
        );
        let exporter = [0x11; 32];
        let session = derive_psk_session_key_from_exporter("shared-psk", &exporter).unwrap();
        // d53bc3e727a6432f421cee4ed63490d79f11bb86a1a961e4137ef4bc40c0213c
        assert_eq!(
            session,
            [
                0xd5, 0x3b, 0xc3, 0xe7, 0x27, 0xa6, 0x43, 0x2f, 0x42, 0x1c, 0xee, 0x4e, 0xd6, 0x34,
                0x90, 0xd7, 0x9f, 0x11, 0xbb, 0x86, 0xa1, 0xa9, 0x61, 0xe4, 0x13, 0x7e, 0xf4, 0xbc,
                0x40, 0xc0, 0x21, 0x3c,
            ]
        );
    }

    #[test]
    fn psk_session_keys_are_bound_to_one_tls_exporter() {
        let exporter_a = [0x11; 32];
        let exporter_b = [0x22; 32];
        let session_a = derive_psk_session_key_from_exporter("shared-psk", &exporter_a).unwrap();
        let session_b = derive_psk_session_key_from_exporter("shared-psk", &exporter_b).unwrap();
        assert_ne!(session_a, session_b);

        // An auth response relayed from one QUIC connection must not verify
        // on another connection, even when both endpoints share the PSK.
        let response = crate::auth::compute_response_with_key("challenge", &session_a);
        assert!(!crate::auth::verify_response_with_key(
            "challenge",
            &session_b,
            &response,
        ));

        // The later server proof and protected control keys remain bound too.
        let proof = crate::control_crypto::compute_server_proof_with_key(
            b"client hello",
            b"server hello",
            "client nonce",
            "server nonce",
            &session_a,
        )
        .unwrap();
        assert!(
            !crate::control_crypto::verify_server_proof_with_key(
                b"client hello",
                b"server hello",
                "client nonce",
                "server nonce",
                &session_b,
                &proof,
            )
            .unwrap()
        );

        let (mut sender, _) = crate::control_crypto::ControlCodec::derive_pair_with_key(
            "client nonce",
            "server nonce",
            &session_a,
        )
        .unwrap();
        let (mut wrong_receiver, _) = crate::control_crypto::ControlCodec::derive_pair_with_key(
            "client nonce",
            "server nonce",
            &session_b,
        )
        .unwrap();
        let frame = sender.seal(b"bound control message").unwrap();
        assert!(wrong_receiver.open(&frame).is_err());
    }

    /// The CLI accepts `-P 128`, and upload/download data use unidirectional
    /// QUIC streams. Quinn otherwise advertises only 100 incoming uni streams,
    /// leaving exactly 28 transfer tasks blocked forever. Exercise both
    /// endpoint configs because each side receives data in one direction.
    #[tokio::test]
    async fn endpoint_configs_admit_all_128_data_streams() -> anyhow::Result<()> {
        let (cert, key) = generate_self_signed_cert()?;
        let server = create_server_endpoint(
            "127.0.0.1:0".parse()?,
            AddressFamily::V4Only,
            cert,
            key,
            None,
        )?;
        let server_addr = server.local_addr()?;
        let client = create_client_endpoint(server_addr, None)?;

        let accept = async {
            let incoming = server
                .accept()
                .await
                .ok_or_else(|| anyhow::anyhow!("server endpoint closed before accept"))?;
            Ok::<_, anyhow::Error>(incoming.await?)
        };
        let (client_connection, server_connection) =
            tokio::time::timeout(Duration::from_secs(5), async {
                tokio::try_join!(connect(&client, server_addr), accept)
            })
            .await
            .map_err(|_| anyhow::anyhow!("QUIC loopback handshake timed out"))??;

        let mut client_streams = Vec::with_capacity(MAX_CONCURRENT_DATA_STREAMS as usize);
        let mut server_streams = Vec::with_capacity(MAX_CONCURRENT_DATA_STREAMS as usize);
        for stream_number in 1..=MAX_CONCURRENT_DATA_STREAMS {
            let client_stream =
                tokio::time::timeout(Duration::from_secs(1), client_connection.open_uni())
                    .await
                    .map_err(|_| {
                        anyhow::anyhow!("client blocked opening data stream {stream_number}")
                    })??;
            client_streams.push(client_stream);

            let server_stream =
                tokio::time::timeout(Duration::from_secs(1), server_connection.open_uni())
                    .await
                    .map_err(|_| {
                        anyhow::anyhow!("server blocked opening data stream {stream_number}")
                    })??;
            server_streams.push(server_stream);
        }

        assert_eq!(client_streams.len(), 128);
        assert_eq!(server_streams.len(), 128);
        Ok(())
    }

    /// The short client idle timeout must not end a healthy connection that
    /// simply has nothing to send: the client keep-alive carries it. Real
    /// time, because quinn reads the std clock rather than tokio's.
    #[tokio::test]
    async fn idle_connection_outlives_the_idle_timeout() -> anyhow::Result<()> {
        let (cert, key) = generate_self_signed_cert()?;
        let server = create_server_endpoint(
            "127.0.0.1:0".parse()?,
            AddressFamily::V4Only,
            cert,
            key,
            None,
        )?;
        let server_addr = server.local_addr()?;
        let client = create_client_endpoint(server_addr, None)?;
        let accept = async {
            let incoming = server
                .accept()
                .await
                .ok_or_else(|| anyhow::anyhow!("server endpoint closed before accept"))?;
            Ok::<_, anyhow::Error>(incoming.await?)
        };
        let (client_connection, server_connection) =
            tokio::time::timeout(Duration::from_secs(5), async {
                tokio::try_join!(connect(&client, server_addr), accept)
            })
            .await
            .map_err(|_| anyhow::anyhow!("QUIC loopback handshake timed out"))??;

        tokio::time::sleep(QUIC_IDLE_TIMEOUT + Duration::from_millis(1500)).await;

        let mut send = client_connection.open_uni().await?;
        send.write_all(b"still here").await?;
        send.finish()?;
        let mut recv = tokio::time::timeout(Duration::from_secs(2), server_connection.accept_uni())
            .await
            .map_err(|_| anyhow::anyhow!("server never saw the stream"))??;
        assert_eq!(recv.read_to_end(64).await?, b"still here");
        Ok(())
    }

    /// Regression for LAN-170 #33: `handle_cancel_change` must return
    /// `Stop` when the cancel sender drops (RecvError), preventing the
    /// busy-loop that the old `_ = cancel.changed()` pattern caused.
    #[test]
    fn test_handle_cancel_change_sender_dropped() {
        let (_tx, rx) = watch::channel(false);
        drop(_tx);
        // Derive a real RecvError: has_changed() returns Err when closed.
        let res = rx.has_changed().map(|_| ());
        assert!(res.is_err(), "has_changed() should Err when sender dropped");
        let (_tx2, rx2) = watch::channel(false);
        let action = handle_cancel_change(res, &rx2);
        assert!(
            matches!(action, CancelAction::Stop),
            "sender drop must Stop"
        );
    }

    /// Regression for LAN-170 #33: `handle_cancel_change` must return
    /// `Stop` when cancel is true.
    #[test]
    fn test_handle_cancel_change_cancel_true() {
        let (cancel_tx, cancel_rx) = watch::channel(false);
        cancel_tx.send(true).unwrap();
        let action = handle_cancel_change(Ok(()), &cancel_rx);
        assert!(
            matches!(action, CancelAction::Stop),
            "cancel=true must Stop"
        );
    }

    /// `handle_cancel_change` must return `Continue` when cancel is false.
    #[test]
    fn test_handle_cancel_change_cancel_false() {
        let (_cancel_tx, cancel_rx) = watch::channel(false);
        let action = handle_cancel_change(Ok(()), &cancel_rx);
        assert!(
            matches!(action, CancelAction::Continue),
            "cancel=false must Continue"
        );
    }

    /// Regression for LAN-170 #32: the module-level
    /// `MAX_DIVERT_ITERATIONS` must be reasonable.  Testing the actual
    /// `poll_recv` would require a mock `AsyncUdpSocket`; here we at
    /// least verify the real constant the production code uses.
    #[test]
    fn test_divert_bound_is_reasonable() {
        let bound = MAX_DIVERT_ITERATIONS;
        assert!(bound > 0, "bound must be > 0");
        assert!(bound <= 64, "bound too high, starvation risk");
    }
}
