//! Network utilities for IPv4/IPv6 socket creation, MPTCP, and address resolution.
//!
//! Provides proper dual-stack socket handling using socket2 for cross-platform
//! compatibility, MPTCP auto-negotiation (Linux 5.6+), and IPv6 flow label support.

use std::io;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr, ToSocketAddrs};

use socket2::{Domain, Protocol, SockAddr, Socket, Type};
use tokio::net::{TcpListener, TcpStream, UdpSocket};
use tracing::{debug, info};

/// Address family preference for socket creation
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum AddressFamily {
    /// IPv4 only (bind to 0.0.0.0)
    V4Only,
    /// IPv6 only (bind to :: with IPV6_V6ONLY=true)
    V6Only,
    /// Dual-stack: accept both IPv4 and IPv6 (bind to :: with IPV6_V6ONLY=false)
    #[default]
    DualStack,
}

impl std::str::FromStr for AddressFamily {
    type Err = ();

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "4" | "v4" | "ipv4" | "v4only" | "ipv4-only" => Ok(Self::V4Only),
            "6" | "v6" | "ipv6" | "v6only" | "ipv6-only" => Ok(Self::V6Only),
            "dual" | "dualstack" | "dual-stack" | "both" => Ok(Self::DualStack),
            _ => Err(()),
        }
    }
}

impl AddressFamily {
    /// Get the bind address for this family
    pub fn bind_addr(&self, port: u16) -> SocketAddr {
        match self {
            Self::V4Only => SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), port),
            Self::V6Only | Self::DualStack => {
                SocketAddr::new(IpAddr::V6(Ipv6Addr::UNSPECIFIED), port)
            }
        }
    }

    /// Get the domain for socket creation
    pub fn domain(&self) -> Domain {
        match self {
            Self::V4Only => Domain::IPV4,
            Self::V6Only | Self::DualStack => Domain::IPV6,
        }
    }
}

impl std::fmt::Display for AddressFamily {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::V4Only => write!(f, "IPv4"),
            Self::V6Only => write!(f, "IPv6"),
            Self::DualStack => write!(f, "dual-stack"),
        }
    }
}

/// Get the socket protocol for TCP or MPTCP.
/// Returns an error on non-Linux platforms when `mptcp: true`, safe for library use.
fn tcp_protocol(mptcp: bool) -> io::Result<Protocol> {
    if mptcp {
        #[cfg(target_os = "linux")]
        {
            Ok(Protocol::MPTCP)
        }
        #[cfg(not(target_os = "linux"))]
        {
            Err(io::Error::new(
                io::ErrorKind::Unsupported,
                "MPTCP is only supported on Linux (kernel 5.6+ with CONFIG_MPTCP=y)",
            ))
        }
    } else {
        Ok(Protocol::TCP)
    }
}

/// Validate that MPTCP is available on this platform.
pub fn validate_mptcp() -> io::Result<()> {
    #[cfg(target_os = "linux")]
    {
        Ok(())
    }
    #[cfg(not(target_os = "linux"))]
    {
        Err(io::Error::new(
            io::ErrorKind::Unsupported,
            "MPTCP is only supported on Linux (kernel 5.6+ with CONFIG_MPTCP=y)",
        ))
    }
}

/// Wrap MPTCP socket creation errors with a clear message.
fn wrap_mptcp_error(e: io::Error, mptcp: bool) -> io::Error {
    if mptcp && is_mptcp_unavailable_error(&e) {
        return io::Error::new(
            io::ErrorKind::Unsupported,
            format!(
                "MPTCP not available (kernel 5.6+ with CONFIG_MPTCP=y required): {}",
                e
            ),
        );
    }
    e
}

/// Returns true if an error means MPTCP is unavailable and TCP fallback is appropriate.
#[cfg(unix)]
fn is_mptcp_unavailable_error(e: &io::Error) -> bool {
    e.kind() == io::ErrorKind::Unsupported
        || matches!(
            e.raw_os_error(),
            Some(libc::EPROTONOSUPPORT) | Some(libc::EINVAL) | Some(libc::ENOPROTOOPT)
        )
}

#[cfg(not(unix))]
fn is_mptcp_unavailable_error(e: &io::Error) -> bool {
    e.kind() == io::ErrorKind::Unsupported
}

/// Create a TCP listener with proper address family handling
pub async fn create_tcp_listener(
    port: u16,
    family: AddressFamily,
    mptcp: bool,
) -> io::Result<TcpListener> {
    let socket = Socket::new(family.domain(), Type::STREAM, Some(tcp_protocol(mptcp)?))
        .map_err(|e| wrap_mptcp_error(e, mptcp))?;

    // Allow address reuse
    socket.set_reuse_address(true)?;

    // Configure IPv6 behavior
    if family != AddressFamily::V4Only {
        // IPV6_V6ONLY: true = IPv6 only, false = dual-stack
        let v6only = family == AddressFamily::V6Only;
        socket.set_only_v6(v6only)?;
        debug!("Set IPV6_V6ONLY={} for {} mode", v6only, family);
    }

    let addr = family.bind_addr(port);
    socket.bind(&SockAddr::from(addr))?;
    socket.listen(128)?;

    // Convert to non-blocking for tokio
    socket.set_nonblocking(true)?;
    let std_listener: std::net::TcpListener = socket.into();
    let listener = TcpListener::from_std(std_listener)?;

    let proto_label = if mptcp { "MPTCP" } else { "TCP" };
    info!("{} listening on {} ({})", proto_label, addr, family);
    Ok(listener)
}

/// Create a TCP listener bound to a specific address
///
/// Used when `--bind` is specified to bind to a concrete IP address.
/// Tries MPTCP first on Linux, falling back to regular TCP.
pub async fn create_tcp_listener_on_addr(addr: SocketAddr) -> io::Result<TcpListener> {
    let domain = if addr.is_ipv4() {
        Domain::IPV4
    } else {
        Domain::IPV6
    };

    // Concrete IPv6 addresses are single-family; set V6ONLY explicitly
    // rather than relying on platform defaults (Linux=false, Windows/macOS=true)
    let set_v6only = addr.is_ipv6();

    // Try MPTCP first on Linux
    #[cfg(target_os = "linux")]
    {
        match Socket::new(domain, Type::STREAM, Some(Protocol::MPTCP)) {
            Ok(socket) => {
                socket.set_reuse_address(true)?;
                if set_v6only {
                    socket.set_only_v6(true)?;
                }
                socket.bind(&SockAddr::from(addr))?;
                socket.listen(128)?;
                socket.set_nonblocking(true)?;
                let std_listener: std::net::TcpListener = socket.into();
                let listener = TcpListener::from_std(std_listener)?;
                info!("MPTCP listening on {}", addr);
                return Ok(listener);
            }
            Err(e) if is_mptcp_unavailable_error(&e) => {
                debug!("MPTCP not available, falling back to TCP: {}", e);
            }
            Err(e) => return Err(e),
        }
    }

    let socket = Socket::new(domain, Type::STREAM, Some(Protocol::TCP))?;
    socket.set_reuse_address(true)?;
    if set_v6only {
        socket.set_only_v6(true)?;
    }
    socket.bind(&SockAddr::from(addr))?;
    socket.listen(128)?;
    socket.set_nonblocking(true)?;
    let std_listener: std::net::TcpListener = socket.into();
    let listener = TcpListener::from_std(std_listener)?;
    info!("TCP listening on {}", addr);
    Ok(listener)
}

/// Create a TCP listener that tries MPTCP first, falling back to regular TCP silently.
///
/// On Linux, MPTCP listeners accept both MPTCP and regular TCP connections transparently
/// (the kernel handles the fallback). This means a server can always use MPTCP sockets
/// without requiring clients to use MPTCP — regular TCP clients connect normally.
///
/// If the kernel doesn't support MPTCP (missing CONFIG_MPTCP or kernel < 5.6), this
/// falls back to a regular TCP listener with a debug-level log message.
pub async fn create_tcp_listener_auto_mptcp(
    port: u16,
    family: AddressFamily,
) -> io::Result<TcpListener> {
    #[cfg(target_os = "linux")]
    {
        match create_tcp_listener(port, family, true).await {
            Ok(listener) => return Ok(listener),
            Err(e) if is_mptcp_unavailable_error(&e) => {
                debug!("MPTCP not available, falling back to TCP: {}", e);
            }
            Err(e) => return Err(e), // Real error (bind/listen failure), don't mask it
        }
    }
    create_tcp_listener(port, family, false).await
}

/// Create a UDP socket with proper address family handling
pub async fn create_udp_socket(port: u16, family: AddressFamily) -> io::Result<UdpSocket> {
    let socket = Socket::new(family.domain(), Type::DGRAM, Some(Protocol::UDP))?;

    // Allow address reuse
    socket.set_reuse_address(true)?;

    // Configure IPv6 behavior
    if family != AddressFamily::V4Only {
        let v6only = family == AddressFamily::V6Only;
        socket.set_only_v6(v6only)?;
    }

    let addr = family.bind_addr(port);
    socket.bind(&SockAddr::from(addr))?;

    // Convert to non-blocking for tokio
    socket.set_nonblocking(true)?;
    let std_socket: std::net::UdpSocket = socket.into();
    let udp = UdpSocket::from_std(std_socket)?;

    debug!("UDP socket bound to {} ({})", addr, family);
    Ok(udp)
}

/// Re-family a bind address to match the remote address's IP version.
/// Preserves the port but swaps UNSPECIFIED IPv4 ↔ IPv6 as needed.
/// If the bind IP is not unspecified (i.e., user specified a concrete IP), it is left unchanged.
pub fn match_bind_family(bind: SocketAddr, remote: SocketAddr) -> SocketAddr {
    if bind.ip().is_unspecified() && bind.is_ipv4() != remote.is_ipv4() {
        // Swap unspecified address to match remote family
        let ip = if remote.is_ipv6() {
            IpAddr::V6(Ipv6Addr::UNSPECIFIED)
        } else {
            IpAddr::V4(Ipv4Addr::UNSPECIFIED)
        };
        SocketAddr::new(ip, bind.port())
    } else {
        bind
    }
}

/// Create a UDP socket bound to a specific address
pub async fn create_udp_socket_bound(addr: SocketAddr) -> io::Result<UdpSocket> {
    let domain = if addr.is_ipv4() {
        Domain::IPV4
    } else {
        Domain::IPV6
    };
    let socket = Socket::new(domain, Type::DGRAM, Some(Protocol::UDP))?;
    socket.set_reuse_address(true)?;
    socket.bind(&SockAddr::from(addr))?;
    socket.set_nonblocking(true)?;

    let std_socket: std::net::UdpSocket = socket.into();
    UdpSocket::from_std(std_socket)
}

/// Create a UDP socket matching the address family of the remote address.
/// This ensures cross-platform compatibility (macOS dual-stack differs from Linux).
pub async fn create_udp_socket_for_remote(remote: SocketAddr) -> io::Result<UdpSocket> {
    let domain = if remote.is_ipv4() {
        Domain::IPV4
    } else {
        Domain::IPV6
    };
    let socket = Socket::new(domain, Type::DGRAM, Some(Protocol::UDP))?;
    socket.set_reuse_address(true)?;

    // Bind to appropriate unspecified address
    let bind_addr = if remote.is_ipv4() {
        SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0)
    } else {
        SocketAddr::new(IpAddr::V6(Ipv6Addr::UNSPECIFIED), 0)
    };
    socket.bind(&SockAddr::from(bind_addr))?;
    socket.set_nonblocking(true)?;

    let std_socket: std::net::UdpSocket = socket.into();
    UdpSocket::from_std(std_socket)
}

/// Resolve a hostname to addresses, filtered by address family preference
pub fn resolve_host(host: &str, port: u16, family: AddressFamily) -> io::Result<Vec<SocketAddr>> {
    // Handle zone IDs for link-local IPv6 (e.g., fe80::1%eth0)
    let host_for_lookup = if host.contains('%') {
        // Strip zone ID for lookup, we'll add it back
        host.split('%').next().unwrap_or(host)
    } else {
        host
    };

    let addr_str = format!("{}:{}", host_for_lookup, port);
    let addrs: Vec<SocketAddr> = addr_str.to_socket_addrs()?.collect();

    if addrs.is_empty() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!("Could not resolve host: {}", host),
        ));
    }

    // Filter by address family
    let filtered: Vec<SocketAddr> = match family {
        AddressFamily::V4Only => addrs.into_iter().filter(|a| a.is_ipv4()).collect(),
        AddressFamily::V6Only => addrs.into_iter().filter(|a| a.is_ipv6()).collect(),
        AddressFamily::DualStack => addrs, // Accept any
    };

    if filtered.is_empty() {
        return Err(io::Error::new(
            io::ErrorKind::AddrNotAvailable,
            format!("No {} addresses found for host: {}", family, host),
        ));
    }

    // Re-add zone ID for link-local addresses if present
    if host.contains('%') {
        let zone_id = host.split('%').nth(1);
        if let Some(_zone) = zone_id {
            // Note: Rust's SocketAddr doesn't support zone IDs directly
            // This would need platform-specific handling for link-local
            debug!("Zone ID specified but not directly supported in SocketAddr");
        }
    }

    Ok(filtered)
}

/// Connect to a host with address family preference and optional bind address
pub async fn connect_tcp(
    host: &str,
    port: u16,
    family: AddressFamily,
    bind_addr: Option<SocketAddr>,
    mptcp: bool,
) -> io::Result<(TcpStream, SocketAddr)> {
    let addrs = resolve_host(host, port, family)?;

    let mut last_err = None;

    for addr in addrs {
        debug!("Trying to connect to {}", addr);
        // When bind IP is unspecified (0.0.0.0 / ::), match the remote family
        // so dual-stack clients can connect across IPv4/IPv6 targets.
        let local_bind = bind_addr.map(|local| match_bind_family(local, addr));
        let result = connect_tcp_with_bind(addr, local_bind, mptcp).await;
        match result {
            Ok(stream) => {
                info!("Connected to {}", addr);
                return Ok((stream, addr));
            }
            Err(e) => {
                debug!("Failed to connect to {}: {}", addr, e);
                last_err = Some(e);
            }
        }
    }

    Err(last_err.unwrap_or_else(|| {
        io::Error::new(io::ErrorKind::NotConnected, "No addresses to connect to")
    }))
}

/// Connect TCP socket with optional local bind address
pub async fn connect_tcp_with_bind(
    remote: SocketAddr,
    bind_addr: Option<SocketAddr>,
    mptcp: bool,
) -> io::Result<TcpStream> {
    if bind_addr.is_some() || mptcp {
        // Use socket2 path for bind address or MPTCP (tokio's TcpStream::connect
        // doesn't support setting the socket protocol)
        let domain = if remote.is_ipv6() {
            Domain::IPV6
        } else {
            Domain::IPV4
        };
        let socket = Socket::new(domain, Type::STREAM, Some(tcp_protocol(mptcp)?))
            .map_err(|e| wrap_mptcp_error(e, mptcp))?;
        socket.set_nonblocking(true)?;

        if let Some(local) = bind_addr {
            if local.port() != 0 {
                socket.set_reuse_address(true)?;
            }
            socket.bind(&SockAddr::from(local))?;
        }

        // Connect (non-blocking) - handle platform-specific "in progress" errors
        match socket.connect(&SockAddr::from(remote)) {
            Ok(()) => {}
            #[cfg(unix)]
            Err(e)
                if e.raw_os_error() == Some(libc::EINPROGRESS)
                    || e.raw_os_error() == Some(libc::EALREADY)
                    || e.raw_os_error() == Some(libc::EWOULDBLOCK) => {}
            #[cfg(windows)]
            Err(e) if e.kind() == io::ErrorKind::WouldBlock => {}
            Err(e) => return Err(wrap_mptcp_error(e, mptcp)),
        }

        // Convert to tokio TcpStream
        let std_stream: std::net::TcpStream = socket.into();
        let stream = TcpStream::from_std(std_stream)?;

        // Wait for connection to complete
        stream.writable().await?;

        // Check for connection errors
        if let Some(e) = stream.take_error()? {
            return Err(wrap_mptcp_error(e, mptcp));
        }

        if let Some(local) = bind_addr {
            debug!("Connected to {} from {}", remote, local);
        } else {
            debug!("Connected to {} (MPTCP)", remote);
        }
        Ok(stream)
    } else {
        // No bind address and no MPTCP, use normal connect
        Ok(TcpStream::connect(remote).await?)
    }
}

/// Set DSCP/TOS marking on a raw fd. Uses IP_TOS for IPv4, IPV6_TCLASS for IPv6.
#[cfg(unix)]
fn set_tos_on_fd(fd: std::os::unix::io::RawFd, tos: u8, ipv6: bool) -> io::Result<()> {
    let tos_val = tos as libc::c_int;
    let (level, optname) = if ipv6 {
        (libc::IPPROTO_IPV6, libc::IPV6_TCLASS)
    } else {
        (libc::IPPROTO_IP, libc::IP_TOS)
    };
    // SAFETY: fd is a valid file descriptor, tos_val is a valid c_int on the stack.
    let ret = unsafe {
        libc::setsockopt(
            fd,
            level,
            optname,
            &tos_val as *const libc::c_int as *const libc::c_void,
            std::mem::size_of::<libc::c_int>() as libc::socklen_t,
        )
    };
    if ret != 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(())
}

/// Set IP_TOS / IPV6_TCLASS on a TCP stream for DSCP/QoS marking.
#[cfg(unix)]
pub fn set_tos_on_tcp(stream: &TcpStream, tos: u8) -> io::Result<()> {
    use std::os::unix::io::AsRawFd;
    let ipv6 = stream.local_addr().map(|a| a.is_ipv6()).unwrap_or(false);
    set_tos_on_fd(stream.as_raw_fd(), tos, ipv6)
}

#[cfg(not(unix))]
pub fn set_tos_on_tcp(_stream: &TcpStream, _tos: u8) -> io::Result<()> {
    tracing::warn!("--dscp is not supported on this platform");
    Ok(())
}

/// Set IP_TOS / IPV6_TCLASS on a UDP socket for DSCP/QoS marking.
#[cfg(unix)]
pub fn set_tos_on_udp(socket: &UdpSocket, tos: u8) -> io::Result<()> {
    use std::os::unix::io::AsRawFd;
    let ipv6 = socket.local_addr().map(|a| a.is_ipv6()).unwrap_or(false);
    set_tos_on_fd(socket.as_raw_fd(), tos, ipv6)
}

#[cfg(not(unix))]
pub fn set_tos_on_udp(_socket: &UdpSocket, _tos: u8) -> io::Result<()> {
    tracing::warn!("--dscp is not supported on this platform");
    Ok(())
}

/// Set IPv6 flow label on a socket (Linux only)
#[cfg(target_os = "linux")]
pub fn set_flow_label(socket: &Socket, flow_label: u32) -> io::Result<()> {
    use std::os::unix::io::AsRawFd;

    if flow_label > 0xFFFFF {
        return Err(io::Error::new(
            io::ErrorKind::InvalidInput,
            "Flow label must be 0-1048575 (20 bits)",
        ));
    }

    // IPV6_FLOWLABEL_MGR and IPV6_FLOWINFO are needed
    // This is complex on Linux - requires flow label manager
    // For now, we'll set it via IPV6_FLOWINFO on send
    debug!(
        "Flow label {} requested (will be set on packets)",
        flow_label
    );

    // Set IPV6_FLOWINFO to include flow label in sent packets
    let fd = socket.as_raw_fd();
    let enable: libc::c_int = 1;
    // SAFETY: fd is a valid file descriptor from socket.as_raw_fd(),
    // enable is a valid c_int pointer, and size_of::<c_int>() is correct.
    // setsockopt may fail but we check the return value.
    unsafe {
        let ret = libc::setsockopt(
            fd,
            libc::IPPROTO_IPV6,
            libc::IPV6_FLOWINFO,
            &enable as *const _ as *const libc::c_void,
            std::mem::size_of::<libc::c_int>() as libc::socklen_t,
        );
        if ret != 0 {
            return Err(io::Error::last_os_error());
        }
    }

    Ok(())
}

#[cfg(not(target_os = "linux"))]
pub fn set_flow_label(_socket: &Socket, _flow_label: u32) -> io::Result<()> {
    // Flow labels are Linux-specific
    debug!("IPv6 flow labels not supported on this platform");
    Ok(())
}

/// Check if an address is IPv4-mapped IPv6 (::ffff:x.x.x.x)
pub fn is_ipv4_mapped(addr: &IpAddr) -> bool {
    match addr {
        IpAddr::V6(v6) => v6.to_ipv4_mapped().is_some(),
        IpAddr::V4(_) => false,
    }
}

/// Convert IPv4-mapped IPv6 to IPv4 if applicable
pub fn normalize_addr(addr: SocketAddr) -> SocketAddr {
    match addr {
        SocketAddr::V6(v6) => {
            if let Some(v4) = v6.ip().to_ipv4_mapped() {
                SocketAddr::new(IpAddr::V4(v4), v6.port())
            } else {
                addr
            }
        }
        _ => addr,
    }
}

/// Normalize an IP address for comparison.
///
/// Converts IPv4-mapped IPv6 addresses (::ffff:x.x.x.x) to their IPv4 form.
/// This ensures that addresses representing the same endpoint compare equal
/// regardless of whether they arrived via dual-stack or IPv4-only.
pub fn normalize_ip(addr: IpAddr) -> IpAddr {
    match addr {
        IpAddr::V6(v6) => {
            if let Some(v4) = v6.to_ipv4_mapped() {
                IpAddr::V4(v4)
            } else {
                addr
            }
        }
        IpAddr::V4(_) => addr,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_address_family_from_str() {
        assert_eq!("4".parse::<AddressFamily>(), Ok(AddressFamily::V4Only));
        assert_eq!("ipv4".parse::<AddressFamily>(), Ok(AddressFamily::V4Only));
        assert_eq!("6".parse::<AddressFamily>(), Ok(AddressFamily::V6Only));
        assert_eq!("ipv6".parse::<AddressFamily>(), Ok(AddressFamily::V6Only));
        assert_eq!(
            "dual".parse::<AddressFamily>(),
            Ok(AddressFamily::DualStack)
        );
        assert_eq!(
            "both".parse::<AddressFamily>(),
            Ok(AddressFamily::DualStack)
        );
        assert_eq!("invalid".parse::<AddressFamily>(), Err(()));
    }

    #[test]
    fn test_bind_addr() {
        let v4 = AddressFamily::V4Only.bind_addr(5201);
        assert!(v4.is_ipv4());
        assert_eq!(v4.port(), 5201);

        let v6 = AddressFamily::V6Only.bind_addr(5201);
        assert!(v6.is_ipv6());
        assert_eq!(v6.port(), 5201);

        let dual = AddressFamily::DualStack.bind_addr(5201);
        assert!(dual.is_ipv6()); // Dual-stack uses IPv6 socket
    }

    #[test]
    fn test_normalize_addr() {
        // Regular IPv4
        let v4 = "192.168.1.1:5201".parse().unwrap();
        assert_eq!(normalize_addr(v4), v4);

        // Regular IPv6
        let v6: SocketAddr = "[::1]:5201".parse().unwrap();
        assert_eq!(normalize_addr(v6), v6);

        // IPv4-mapped IPv6 should convert to IPv4
        let mapped: SocketAddr = "[::ffff:192.168.1.1]:5201".parse().unwrap();
        let normalized = normalize_addr(mapped);
        assert!(normalized.is_ipv4());
        assert_eq!(normalized.port(), 5201);
    }

    #[test]
    fn test_is_ipv4_mapped() {
        assert!(!is_ipv4_mapped(&"192.168.1.1".parse().unwrap()));
        assert!(!is_ipv4_mapped(&"::1".parse().unwrap()));
        assert!(is_ipv4_mapped(&"::ffff:192.168.1.1".parse().unwrap()));
    }

    #[test]
    fn test_normalize_ip() {
        // Regular IPv4 unchanged
        let v4: IpAddr = "192.168.1.1".parse().unwrap();
        assert_eq!(normalize_ip(v4), v4);

        // Regular IPv6 unchanged
        let v6: IpAddr = "::1".parse().unwrap();
        assert_eq!(normalize_ip(v6), v6);

        // IPv4-mapped IPv6 should convert to IPv4
        let mapped: IpAddr = "::ffff:192.168.1.1".parse().unwrap();
        let normalized = normalize_ip(mapped);
        assert!(normalized.is_ipv4());
        assert_eq!(normalized.to_string(), "192.168.1.1");

        // Comparing normalized addresses should work across representations
        let v4_addr: IpAddr = "127.0.0.1".parse().unwrap();
        let mapped_addr: IpAddr = "::ffff:127.0.0.1".parse().unwrap();
        assert_eq!(normalize_ip(v4_addr), normalize_ip(mapped_addr));
    }

    #[test]
    fn test_match_bind_family() {
        // IPv4 bind + IPv6 remote → swap to IPv6 unspecified
        let bind: SocketAddr = "0.0.0.0:5300".parse().unwrap();
        let remote: SocketAddr = "[::1]:5201".parse().unwrap();
        let result = match_bind_family(bind, remote);
        assert!(result.is_ipv6());
        assert_eq!(result.port(), 5300);
        assert!(result.ip().is_unspecified());

        // IPv6 bind + IPv4 remote → swap to IPv4 unspecified
        let bind: SocketAddr = "[::]:5300".parse().unwrap();
        let remote: SocketAddr = "192.168.1.1:5201".parse().unwrap();
        let result = match_bind_family(bind, remote);
        assert!(result.is_ipv4());
        assert_eq!(result.port(), 5300);
        assert!(result.ip().is_unspecified());

        // Matching families → unchanged
        let bind: SocketAddr = "0.0.0.0:5300".parse().unwrap();
        let remote: SocketAddr = "192.168.1.1:5201".parse().unwrap();
        assert_eq!(match_bind_family(bind, remote), bind);

        // Concrete (non-unspecified) IP → unchanged even if family mismatches
        let bind: SocketAddr = "10.0.0.1:5300".parse().unwrap();
        let remote: SocketAddr = "[::1]:5201".parse().unwrap();
        assert_eq!(match_bind_family(bind, remote), bind);
    }

    #[tokio::test]
    async fn test_resolve_localhost_v4() {
        let addrs = resolve_host("localhost", 5201, AddressFamily::V4Only).unwrap();
        assert!(!addrs.is_empty());
        assert!(addrs.iter().all(|a| a.is_ipv4()));
    }

    #[tokio::test]
    async fn test_resolve_localhost_v6() {
        // May fail if IPv6 is not configured
        if let Ok(addrs) = resolve_host("localhost", 5201, AddressFamily::V6Only) {
            assert!(addrs.iter().all(|a| a.is_ipv6()));
        }
    }

    #[tokio::test]
    async fn test_connect_tcp_refamilies_unspecified_bind() {
        let listener = match tokio::net::TcpListener::bind("[::1]:0").await {
            Ok(listener) => listener,
            Err(_) => return, // IPv6 not configured in this environment
        };
        let port = listener.local_addr().unwrap().port();

        let accept_task = tokio::spawn(async move {
            let _ = listener.accept().await;
        });

        let bind: SocketAddr = "0.0.0.0:0".parse().unwrap();
        let result = connect_tcp("::1", port, AddressFamily::V6Only, Some(bind), false).await;

        assert!(
            result.is_ok(),
            "connect_tcp should re-family unspecified bind addr for IPv6 target"
        );

        let _ = accept_task.await;
    }

    #[test]
    fn test_validate_mptcp() {
        #[cfg(target_os = "linux")]
        assert!(validate_mptcp().is_ok());

        #[cfg(not(target_os = "linux"))]
        assert!(validate_mptcp().is_err());
    }

    #[test]
    fn test_is_mptcp_unavailable_error_by_kind() {
        let unsupported = io::Error::new(io::ErrorKind::Unsupported, "mptcp unavailable");
        assert!(is_mptcp_unavailable_error(&unsupported));

        let other = io::Error::new(io::ErrorKind::AddrInUse, "address in use");
        assert!(!is_mptcp_unavailable_error(&other));
    }

    #[cfg(unix)]
    #[test]
    fn test_wrap_mptcp_error_marks_unsupported() {
        let wrapped = wrap_mptcp_error(io::Error::from_raw_os_error(libc::EPROTONOSUPPORT), true);
        assert_eq!(wrapped.kind(), io::ErrorKind::Unsupported);
        assert!(is_mptcp_unavailable_error(&wrapped));
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn test_mptcp_socket_creation() {
        // Attempt to create an MPTCP socket — may fail if kernel lacks support
        let result = Socket::new(Domain::IPV4, Type::STREAM, Some(Protocol::MPTCP));
        match result {
            Ok(_) => {} // MPTCP available
            Err(e) => {
                // Expected on kernels without CONFIG_MPTCP
                assert!(
                    e.raw_os_error() == Some(libc::EPROTONOSUPPORT)
                        || e.raw_os_error() == Some(libc::EINVAL)
                        || e.raw_os_error() == Some(libc::ENOPROTOOPT),
                    "Unexpected error: {}",
                    e
                );
            }
        }
    }
}
