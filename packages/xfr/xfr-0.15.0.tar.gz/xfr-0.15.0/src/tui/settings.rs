//! Settings modal for TUI

use std::time::Duration;

pub use crate::protocol::TimestampFormat;
use crate::protocol::{Direction, Protocol};

use super::theme::Theme;

/// Settings category tabs
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum SettingsCategory {
    #[default]
    Display,
    Test,
}

impl SettingsCategory {
    pub fn next(&self) -> Self {
        match self {
            Self::Display => Self::Test,
            Self::Test => Self::Display,
        }
    }
}

/// Display units preference
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum Units {
    #[default]
    Auto,
    Bits,
    Bytes,
}

impl Units {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Auto => "auto",
            Self::Bits => "bits",
            Self::Bytes => "bytes",
        }
    }

    pub fn next(&self) -> Self {
        match self {
            Self::Auto => Self::Bits,
            Self::Bits => Self::Bytes,
            Self::Bytes => Self::Auto,
        }
    }

    pub fn prev(&self) -> Self {
        match self {
            Self::Auto => Self::Bytes,
            Self::Bits => Self::Auto,
            Self::Bytes => Self::Bits,
        }
    }
}

/// State for the settings modal.
///
/// `Hash` feeds `App::render_fingerprint`: every field here is either drawn
/// by the settings modal or changes in lockstep with one that is, and a new
/// field is fingerprinted automatically.
#[derive(Debug, Clone, Hash)]
pub struct SettingsState {
    /// Whether the modal is visible
    pub visible: bool,
    /// Current category tab
    pub category: SettingsCategory,
    /// Selected item index within category
    pub selected_index: usize,
    /// Whether a button is focused (vs a setting)
    pub button_focused: bool,
    /// Which button is selected (0 = Apply & Restart, 1 = Close)
    pub button_index: usize,

    // Display settings (live-editable, auto-persist)
    pub theme_index: usize,
    pub timestamp_format: TimestampFormat,
    pub units: Units,
    /// Whether the background update check is enabled (persisted to prefs).
    pub update_check: bool,
    /// Higher-priority override preventing a saved preference change.
    pub update_check_lock_reason: Option<&'static str>,
    /// Set once the user toggles `update_check`, so only an explicit choice is
    /// persisted (not the env/config-derived initial state).
    pub update_check_touched: bool,

    // Test settings (require restart)
    pub streams: u8,
    pub protocol: Protocol,
    pub duration_secs: u64,
    pub direction: Direction,
    /// Target bitrate in bits/sec (`None` = unlimited).
    pub bitrate: Option<u64>,

    // Original values to detect changes
    original_streams: u8,
    original_protocol: Protocol,
    original_duration_secs: u64,
    original_direction: Direction,
    original_bitrate: Option<u64>,
}

impl Default for SettingsState {
    fn default() -> Self {
        Self {
            visible: false,
            category: SettingsCategory::Display,
            selected_index: 0,
            button_focused: false,
            button_index: 0,

            theme_index: 0,
            timestamp_format: TimestampFormat::Relative,
            units: Units::Auto,
            update_check: true,
            update_check_lock_reason: None,
            update_check_touched: false,

            streams: 1,
            protocol: Protocol::Tcp,
            duration_secs: 10,
            direction: Direction::Upload,
            bitrate: None,

            original_streams: 1,
            original_protocol: Protocol::Tcp,
            original_duration_secs: 10,
            original_direction: Direction::Upload,
            original_bitrate: None,
        }
    }
}

impl SettingsState {
    /// Create settings state from current app state
    pub fn new(
        theme_index: usize,
        streams: u8,
        protocol: Protocol,
        duration: Duration,
        direction: Direction,
        bitrate: Option<u64>,
    ) -> Self {
        let duration_secs = duration.as_secs();
        Self {
            visible: false,
            category: SettingsCategory::Display,
            selected_index: 0,
            button_focused: false,
            button_index: 0,

            theme_index,
            timestamp_format: TimestampFormat::Relative,
            units: Units::Auto,
            update_check: true,
            update_check_lock_reason: None,
            update_check_touched: false,

            streams,
            protocol,
            duration_secs,
            direction,
            bitrate,

            original_streams: streams,
            original_protocol: protocol,
            original_duration_secs: duration_secs,
            original_direction: direction,
            original_bitrate: bitrate,
        }
    }

    /// Commit the current test parameters as the new clean baseline.
    pub fn mark_applied(&mut self) {
        self.original_streams = self.streams;
        self.original_protocol = self.protocol;
        self.original_duration_secs = self.duration_secs;
        self.original_direction = self.direction;
        self.original_bitrate = self.bitrate;
    }

    /// Toggle visibility
    pub fn toggle(&mut self) {
        self.visible = !self.visible;
        if self.visible {
            // Reset to first item when opening
            self.selected_index = 0;
            self.button_focused = false;
        }
    }

    /// Revert uncommitted test parameter edits back to the clean baseline.
    pub fn revert_test_params(&mut self) {
        self.streams = self.original_streams;
        self.protocol = self.original_protocol;
        self.duration_secs = self.original_duration_secs;
        self.direction = self.original_direction;
        self.bitrate = self.original_bitrate;
    }

    /// Close the modal
    pub fn close(&mut self) {
        self.revert_test_params();
        self.visible = false;
    }

    /// Check if test parameters have changed
    pub fn test_params_dirty(&self) -> bool {
        self.streams != self.original_streams
            || self.protocol != self.original_protocol
            || self.duration_secs != self.original_duration_secs
            || self.direction != self.original_direction
            || self.bitrate != self.original_bitrate
    }

    /// Number of items in current category
    fn items_in_category(&self) -> usize {
        match self.category {
            SettingsCategory::Display => 4, // Theme, Timestamp, Units, Update check
            SettingsCategory::Test => 5,    // Streams, Protocol, Duration, Direction, Bitrate
        }
    }

    /// Move selection up (or to buttons if at top)
    pub fn move_up(&mut self) {
        if self.button_focused {
            // Move from buttons to last item
            self.button_focused = false;
            self.selected_index = self.items_in_category().saturating_sub(1);
        } else if self.selected_index > 0 {
            self.selected_index -= 1;
        }
    }

    /// Move selection down (or to buttons if at bottom)
    pub fn move_down(&mut self) {
        if self.button_focused {
            // Stay on buttons
            return;
        }

        if self.selected_index < self.items_in_category().saturating_sub(1) {
            self.selected_index += 1;
        } else {
            // Move to buttons
            self.button_focused = true;
            // Select first visible button (Apply if dirty, else Close)
            self.button_index = if self.test_params_dirty() { 0 } else { 1 };
        }
    }

    /// Switch category tab
    pub fn switch_tab(&mut self) {
        self.category = self.category.next();
        self.selected_index = 0;
        self.button_focused = false;
    }

    /// Toggle the update-check setting and mark it as an explicit user choice.
    fn toggle_update_check(&mut self) {
        if self.update_check_lock_reason.is_some() {
            return;
        }
        self.update_check = !self.update_check;
        self.update_check_touched = true;
    }

    /// Cycle selected value to next
    pub fn value_next(&mut self) {
        if self.button_focused {
            // Only cycle if both buttons are visible
            if self.test_params_dirty() {
                self.button_index = (self.button_index + 1) % 2;
            }
            return;
        }

        match self.category {
            SettingsCategory::Display => match self.selected_index {
                0 => {
                    // Theme
                    let theme_list = Theme::list();
                    self.theme_index = (self.theme_index + 1) % theme_list.len();
                }
                1 => self.timestamp_format = self.timestamp_format.next(),
                2 => self.units = self.units.next(),
                3 => self.toggle_update_check(),
                _ => {}
            },
            SettingsCategory::Test => match self.selected_index {
                0 => self.streams = self.streams.saturating_add(1).min(128),
                1 => self.protocol = self.protocol.next(),
                2 => self.duration_secs = duration_next(self.duration_secs),
                3 => self.direction = self.direction.next(),
                4 => self.bitrate = bitrate_next(self.bitrate),
                _ => {}
            },
        }
    }

    /// Cycle selected value to previous
    pub fn value_prev(&mut self) {
        if self.button_focused {
            // Only cycle if both buttons are visible
            if self.test_params_dirty() {
                self.button_index = if self.button_index == 0 { 1 } else { 0 };
            }
            return;
        }

        match self.category {
            SettingsCategory::Display => match self.selected_index {
                0 => {
                    // Theme
                    let theme_list = Theme::list();
                    self.theme_index = if self.theme_index == 0 {
                        theme_list.len() - 1
                    } else {
                        self.theme_index - 1
                    };
                }
                1 => self.timestamp_format = self.timestamp_format.prev(),
                2 => self.units = self.units.prev(),
                3 => self.toggle_update_check(),
                _ => {}
            },
            SettingsCategory::Test => match self.selected_index {
                0 => self.streams = self.streams.saturating_sub(1).max(1),
                1 => self.protocol = self.protocol.prev(),
                2 => self.duration_secs = duration_prev(self.duration_secs),
                3 => self.direction = self.direction.prev(),
                4 => self.bitrate = bitrate_prev(self.bitrate),
                _ => {}
            },
        }
    }

    /// Get current theme name
    pub fn theme_name(&self) -> &str {
        let list = Theme::list();
        list.get(self.theme_index).copied().unwrap_or("default")
    }

    /// Handle Enter key - returns true if should restart test
    pub fn on_enter(&mut self) -> SettingsAction {
        if !self.button_focused {
            // Move to buttons when pressing enter on a setting
            self.button_focused = true;
            // Select first visible button (Apply if dirty, else Close)
            self.button_index = if self.test_params_dirty() { 0 } else { 1 };
            return SettingsAction::None;
        }

        match self.button_index {
            0 => {
                // Apply & Restart
                if self.test_params_dirty() {
                    self.visible = false;
                    SettingsAction::Restart
                } else {
                    self.close();
                    SettingsAction::Close
                }
            }
            1 => {
                // Close
                self.close();
                SettingsAction::Close
            }
            _ => SettingsAction::None,
        }
    }
}

/// Action to take after settings interaction
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SettingsAction {
    None,
    Close,
    Restart,
}

/// Step duration up by 5s, snapping to a clean multiple of 5 (min 5s, max 3600s).
fn duration_next(secs: u64) -> u64 {
    ((secs / 5 + 1) * 5).min(3600)
}

/// Step duration down by 5s, snapping to a clean multiple of 5 (min 5s).
fn duration_prev(secs: u64) -> u64 {
    (secs.saturating_sub(1) / 5 * 5).max(5)
}

/// Discrete bitrate steps cycled in the settings modal (bits/sec). `None`
/// means unlimited.
const BITRATE_STEPS: [Option<u64>; 6] = [
    None,
    Some(1_000_000),
    Some(10_000_000),
    Some(100_000_000),
    Some(1_000_000_000),
    Some(10_000_000_000),
];

fn bitrate_index(current: Option<u64>) -> usize {
    BITRATE_STEPS
        .iter()
        .position(|&step| step == current)
        .unwrap_or(0)
}

pub fn bitrate_next(current: Option<u64>) -> Option<u64> {
    let i = bitrate_index(current);
    BITRATE_STEPS[(i + 1) % BITRATE_STEPS.len()]
}

pub fn bitrate_prev(current: Option<u64>) -> Option<u64> {
    let i = bitrate_index(current);
    let prev = if i == 0 {
        BITRATE_STEPS.len() - 1
    } else {
        i - 1
    };
    BITRATE_STEPS[prev]
}

pub fn bitrate_display(bitrate: Option<u64>) -> String {
    match bitrate {
        None => "unlimited".to_string(),
        Some(bps) if bps % 1_000_000_000 == 0 => format!("{} Gbps", bps / 1_000_000_000),
        Some(bps) if bps % 1_000_000 == 0 => format!("{} Mbps", bps / 1_000_000),
        Some(bps) if bps % 1_000 == 0 => format!("{} Kbps", bps / 1_000),
        Some(bps) => format!("{} bps", bps),
    }
}

// Add helper methods to Protocol and Direction for cycling
impl Protocol {
    fn next(&self) -> Self {
        match self {
            Self::Tcp => Self::Udp,
            Self::Udp => Self::Quic,
            Self::Quic => Self::Tcp,
        }
    }

    fn prev(&self) -> Self {
        match self {
            Self::Tcp => Self::Quic,
            Self::Udp => Self::Tcp,
            Self::Quic => Self::Udp,
        }
    }
}

impl Direction {
    fn next(&self) -> Self {
        match self {
            Self::Upload => Self::Download,
            Self::Download => Self::Bidir,
            Self::Bidir => Self::Upload,
        }
    }

    fn prev(&self) -> Self {
        match self {
            Self::Upload => Self::Bidir,
            Self::Download => Self::Upload,
            Self::Bidir => Self::Download,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn duration_steps_snap_to_clean_five_second_boundaries() {
        assert_eq!(duration_next(1), 5);
        assert_eq!(duration_next(5), 10);
        assert_eq!(duration_next(11), 15);
        assert_eq!(duration_next(3599), 3600);
        assert_eq!(duration_next(3600), 3600);

        assert_eq!(duration_prev(1), 5);
        assert_eq!(duration_prev(6), 5);
        assert_eq!(duration_prev(11), 10);
    }

    #[test]
    fn bitrate_steps_cycle_and_display() {
        assert_eq!(bitrate_next(None), Some(1_000_000));
        assert_eq!(bitrate_next(Some(1_000_000)), Some(10_000_000));
        assert_eq!(bitrate_prev(None), Some(10_000_000_000));
        assert_eq!(bitrate_prev(Some(10_000_000)), Some(1_000_000));

        assert_eq!(bitrate_display(None), "unlimited");
        assert_eq!(bitrate_display(Some(1_000_000)), "1 Mbps");
        assert_eq!(bitrate_display(Some(10_000_000_000)), "10 Gbps");
    }

    #[test]
    fn locked_update_check_cannot_be_changed() {
        for enabled in [true, false] {
            let mut s = SettingsState {
                selected_index: 3,
                update_check: enabled,
                update_check_lock_reason: Some("locked: config.toml"),
                ..SettingsState::default()
            };
            s.value_next();
            s.value_prev();
            s.on_enter();
            assert_eq!(s.update_check, enabled);
            assert!(!s.update_check_touched);
        }
    }

    #[test]
    fn update_check_toggle_flips_and_marks_touched() {
        let mut s = SettingsState::default();
        assert!(s.update_check, "enabled by default");
        assert!(!s.update_check_touched, "untouched until the user acts");

        // Display tab, 4th item is the update-check toggle.
        s.category = SettingsCategory::Display;
        s.selected_index = 3;
        s.value_next();
        assert!(!s.update_check);
        assert!(s.update_check_touched);

        s.value_prev();
        assert!(s.update_check, "toggles back");
    }

    #[test]
    fn mark_applied_commits_test_settings_baseline() {
        let mut settings = SettingsState::new(
            0,
            1,
            Protocol::Tcp,
            Duration::from_secs(10),
            Direction::Upload,
            None,
        );

        settings.streams = 4;
        settings.protocol = Protocol::Udp;
        settings.duration_secs = 15;
        settings.direction = Direction::Download;
        settings.bitrate = Some(100_000_000);
        assert!(settings.test_params_dirty());

        settings.mark_applied();
        assert!(!settings.test_params_dirty());
    }

    #[test]
    fn close_reverts_unapplied_test_param_edits() {
        let mut settings = SettingsState::new(
            0,
            2,
            Protocol::Tcp,
            Duration::from_secs(10),
            Direction::Upload,
            None,
        );
        settings.toggle();
        assert!(settings.visible);

        settings.streams = 8;
        settings.protocol = Protocol::Quic;
        settings.duration_secs = 30;
        settings.direction = Direction::Bidir;
        settings.bitrate = Some(1_000_000_000);
        assert!(settings.test_params_dirty());

        settings.close();
        assert!(!settings.visible);
        assert!(!settings.test_params_dirty());
        assert_eq!(settings.streams, 2);
        assert_eq!(settings.protocol, Protocol::Tcp);
        assert_eq!(settings.duration_secs, 10);
        assert_eq!(settings.direction, Direction::Upload);
        assert_eq!(settings.bitrate, None);

        // Apply & Restart must preserve the pending edits until the caller commits them.
        settings.toggle();
        settings.streams = 4;
        settings.button_focused = true;
        settings.button_index = 0;
        assert_eq!(settings.on_enter(), SettingsAction::Restart);
        assert!(!settings.visible);
        assert_eq!(settings.streams, 4);
        assert!(settings.test_params_dirty());
    }
}
