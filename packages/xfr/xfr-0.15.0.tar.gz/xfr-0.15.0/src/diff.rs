//! Diff mode - compare two test results
//!
//! Compares bandwidth test results and reports regressions.

use std::fs;
use std::path::Path;

use anyhow::Context;

use crate::protocol::TestResult;
use crate::stats::normalize_for_display;

pub const DEFAULT_DIFF_THRESHOLD_PERCENT: f64 = 5.0;

#[derive(Debug)]
pub struct DiffConfig {
    pub threshold_percent: f64,
}

impl Default for DiffConfig {
    fn default() -> Self {
        Self {
            threshold_percent: DEFAULT_DIFF_THRESHOLD_PERCENT,
        }
    }
}

impl DiffConfig {
    /// Reject thresholds that would silently disable regression detection.
    pub fn validate(&self) -> anyhow::Result<()> {
        anyhow::ensure!(
            self.threshold_percent.is_finite() && self.threshold_percent >= 0.0,
            "Regression threshold must be finite and non-negative"
        );
        Ok(())
    }
}

#[derive(Debug)]
pub struct DiffResult {
    pub baseline: TestResult,
    pub current: TestResult,
    pub throughput_change_percent: f64,
    pub retransmit_change_percent: f64,
    pub rtt_change_percent: f64,
    pub threshold_percent: f64,
    pub is_regression: bool,
}

impl DiffResult {
    pub fn format_plain(&self) -> String {
        let mut output = String::new();
        let throughput_change = normalize_for_display(self.throughput_change_percent, 1);

        output.push_str(&format!(
            "Throughput: {:.1} Mbps → {:.1} Mbps ({:+.1}%)",
            normalize_for_display(self.baseline.throughput_mbps, 1),
            normalize_for_display(self.current.throughput_mbps, 1),
            throughput_change
        ));

        if self.throughput_change_percent < -self.threshold_percent {
            output.push_str(" [FAIL]");
        } else if throughput_change < 0.0 {
            output.push_str(" [WARN]");
        } else {
            output.push_str(" [OK]");
        }
        output.push('\n');

        if let (Some(baseline_tcp), Some(current_tcp)) =
            (&self.baseline.tcp_info, &self.current.tcp_info)
        {
            let retransmit_change = normalize_for_display(self.retransmit_change_percent, 1);
            output.push_str(&format!(
                "Retransmits: {} → {} ({:+.1}%)",
                baseline_tcp.retransmits, current_tcp.retransmits, retransmit_change
            ));
            if self.retransmit_change_percent > self.threshold_percent {
                output.push_str(" [FAIL]");
            } else if retransmit_change > 0.0 {
                output.push_str(" [WARN]");
            }
            output.push('\n');

            let baseline_rtt_ms = baseline_tcp.rtt_us as f64 / 1000.0;
            let current_rtt_ms = current_tcp.rtt_us as f64 / 1000.0;
            let rtt_change = normalize_for_display(self.rtt_change_percent, 1);
            output.push_str(&format!(
                "RTT: {:.2} ms → {:.2} ms ({:+.1}%)",
                baseline_rtt_ms, current_rtt_ms, rtt_change
            ));
            if self.rtt_change_percent > self.threshold_percent {
                output.push_str(" [FAIL]");
            } else if rtt_change > 0.0 {
                output.push_str(" [WARN]");
            }
            output.push('\n');
        }

        output.push('\n');
        if self.is_regression {
            output.push_str("Verdict: REGRESSION DETECTED\n");
        } else {
            output.push_str("Verdict: OK\n");
        }

        output
    }
}

pub fn load_result(path: &Path) -> anyhow::Result<TestResult> {
    let content = fs::read_to_string(path)
        .with_context(|| format!("failed to read result file {}", path.display()))?;
    let result: TestResult = serde_json::from_str(&content)
        .with_context(|| format!("failed to parse result file {}", path.display()))?;
    Ok(result)
}

/// Compare results using a config checked with [`DiffConfig::validate`].
pub fn compare(baseline: TestResult, current: TestResult, config: &DiffConfig) -> DiffResult {
    let throughput_change_percent = if baseline.throughput_mbps > 0.0 {
        ((current.throughput_mbps - baseline.throughput_mbps) / baseline.throughput_mbps) * 100.0
    } else {
        0.0
    };

    let retransmit_change_percent = match (&baseline.tcp_info, &current.tcp_info) {
        (Some(b), Some(c)) if b.retransmits > 0 => {
            ((c.retransmits as f64 - b.retransmits as f64) / b.retransmits as f64) * 100.0
        }
        (Some(b), Some(c)) if b.retransmits == 0 && c.retransmits > 0 => f64::INFINITY,
        _ => 0.0,
    };

    let rtt_change_percent = match (&baseline.tcp_info, &current.tcp_info) {
        (Some(b), Some(c)) if b.rtt_us > 0 => {
            ((c.rtt_us as f64 - b.rtt_us as f64) / b.rtt_us as f64) * 100.0
        }
        (Some(b), Some(c)) if b.rtt_us == 0 && c.rtt_us > 0 => f64::INFINITY,
        _ => 0.0,
    };

    let is_regression = throughput_change_percent < -config.threshold_percent
        || retransmit_change_percent > config.threshold_percent
        || rtt_change_percent > config.threshold_percent;

    DiffResult {
        baseline,
        current,
        throughput_change_percent,
        retransmit_change_percent,
        rtt_change_percent,
        threshold_percent: config.threshold_percent,
        is_regression,
    }
}

pub fn run_diff(
    baseline_path: &Path,
    current_path: &Path,
    config: &DiffConfig,
) -> anyhow::Result<DiffResult> {
    config.validate()?;
    let baseline = load_result(baseline_path)?;
    let current = load_result(current_path)?;
    Ok(compare(baseline, current, config))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::protocol::TcpInfoSnapshot;

    #[test]
    fn invalid_thresholds_fail_before_loading_result_files() {
        for threshold in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY, -1.0] {
            let config = DiffConfig {
                threshold_percent: threshold,
            };
            let error = run_diff(
                Path::new("missing-baseline.json"),
                Path::new("missing-current.json"),
                &config,
            )
            .unwrap_err();
            assert!(error.to_string().contains("threshold"), "{error}");
        }
        for threshold in [0.0, 5.0, 12.5, 100.0] {
            assert!(
                DiffConfig {
                    threshold_percent: threshold
                }
                .validate()
                .is_ok()
            );
        }
    }

    fn make_result(throughput: f64, retransmits: u64, rtt_us: u32) -> TestResult {
        TestResult {
            udp_stats_send: None,
            udp_stats_recv: None,
            id: "test".to_string(),
            bytes_total: 1_000_000_000,
            duration_ms: 10_000,
            throughput_mbps: throughput,
            streams: vec![],
            tcp_info: Some(TcpInfoSnapshot {
                retransmits,
                rtt_us,
                rtt_var_us: 100,
                cwnd: 65535,
                bytes_acked: None,
            }),
            udp_stats: None,
            bytes_sent: None,
            bytes_received: None,
            throughput_send_mbps: None,
            throughput_recv_mbps: None,
            mtu_probe: None,
            server_udp_send_errors: None,
            client_udp_send_errors: None,
            zero_byte_streams: None,
        }
    }

    #[test]
    fn test_no_regression() {
        let baseline = make_result(1000.0, 10, 1000);
        let current = make_result(1050.0, 8, 900);

        let diff = compare(baseline, current, &DiffConfig::default());
        assert!(!diff.is_regression);
        assert!(diff.throughput_change_percent > 0.0);
    }

    #[test]
    fn test_default_threshold_ignores_small_tcp_metric_noise() {
        let baseline = make_result(1000.0, 100, 1000);
        let current = make_result(1000.0, 104, 1040);

        let diff = compare(baseline, current, &DiffConfig::default());
        assert!(!diff.is_regression);
        let output = diff.format_plain();
        assert!(output.contains("Retransmits: 100 → 104 (+4.0%) [WARN]"));
        assert!(output.contains("RTT: 1.00 ms → 1.04 ms (+4.0%) [WARN]"));
        assert!(output.contains("Verdict: OK"));
    }

    #[test]
    fn test_equal_throughput_no_negative_zero() {
        let baseline = make_result(1000.0, 10, 1000);
        let current = make_result(1000.0, 10, 1000);

        let diff = compare(baseline, current, &DiffConfig::default());
        let output = diff.format_plain();
        // Should show +0.0%, not -0.0%
        assert!(output.contains("+0.0%"), "got: {}", output);
        assert!(!output.contains("-0.0"), "got: {}", output);
    }

    #[test]
    fn test_regression() {
        let baseline = make_result(1000.0, 10, 1000);
        let current = make_result(800.0, 50, 1500);

        let diff = compare(
            baseline,
            current,
            &DiffConfig {
                threshold_percent: 5.0,
            },
        );
        assert!(diff.is_regression);
        assert!(diff.throughput_change_percent < -10.0);
    }

    #[test]
    fn test_zero_baseline_retransmits_flagged() {
        let baseline = make_result(1000.0, 0, 1000);
        let current = make_result(1000.0, 20, 1000);

        let diff = compare(
            baseline,
            current,
            &DiffConfig {
                threshold_percent: 5.0,
            },
        );
        assert!(diff.is_regression);
        assert!(diff.retransmit_change_percent.is_infinite());
        assert!(diff.retransmit_change_percent.is_sign_positive());
        let output = diff.format_plain();
        assert!(
            output.contains("+inf%"),
            "expected +inf% output, got: {}",
            output
        );
        assert!(
            output.contains("[FAIL]"),
            "expected [FAIL] for retransmits, got: {}",
            output
        );
    }

    #[test]
    fn test_zero_baseline_rtt_flagged() {
        let baseline = make_result(1000.0, 10, 0);
        let current = make_result(1000.0, 10, 500);

        let diff = compare(
            baseline,
            current,
            &DiffConfig {
                threshold_percent: 5.0,
            },
        );
        assert!(diff.is_regression);
        assert!(diff.rtt_change_percent.is_infinite());
        assert!(diff.rtt_change_percent.is_sign_positive());
        let output = diff.format_plain();
        assert!(
            output.contains("+inf%"),
            "expected +inf% output, got: {}",
            output
        );
        assert!(
            output.contains("[FAIL]"),
            "expected [FAIL] for rtt, got: {}",
            output
        );
    }

    #[test]
    fn sub_tenth_percent_changes_normalize_without_negative_zero_or_warn() {
        let baseline = make_result(10_000.0, 10_000, 10_000);
        let current = make_result(9_999.0, 9_999, 9_999);

        let diff = compare(baseline, current, &DiffConfig::default());
        let output = diff.format_plain();
        assert!(!output.contains("-0.0%"), "got: {output}");
        assert!(!output.contains("[WARN]"), "got: {output}");
        assert!(output.contains("(+0.0%) [OK]"), "got: {output}");
    }

    #[test]
    fn load_result_errors_name_the_file_path() {
        let missing = Path::new("definitely-missing-diff-baseline.json");
        let err = format!("{:#}", load_result(missing).unwrap_err());
        assert!(
            err.contains("definitely-missing-diff-baseline.json"),
            "got: {err}"
        );
    }
}
