//! End-to-end push coverage, also run by the normal all/no-default-features CI jobs.

use std::sync::atomic::{AtomicU16, Ordering};
use std::time::Duration;

use tokio::io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader};
use tokio::net::{TcpListener, TcpStream};
use tokio::time::timeout;
use xfr::protocol::{Direction, Protocol};
use xfr::serve::{Server, ServerConfig};

static SERVER_PORT: AtomicU16 = AtomicU16::new(26000);

async fn gateway(statuses: Vec<u16>) -> (String, tokio::task::JoinHandle<Vec<(String, String)>>) {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let url = format!(
        "http://{}/api/v1/import/prometheus/",
        listener.local_addr().unwrap()
    );
    let task = tokio::spawn(async move {
        let mut pushes = Vec::new();
        for status in statuses {
            let (stream, _) = timeout(Duration::from_secs(20), listener.accept())
                .await
                .unwrap()
                .unwrap();
            let mut reader = BufReader::new(stream);
            let mut request = String::new();
            reader.read_line(&mut request).await.unwrap();
            assert!(request.starts_with("POST ") || request.starts_with("PUT "));
            let mut length = None;
            loop {
                let mut line = String::new();
                assert!(reader.read_line(&mut line).await.unwrap() > 0);
                if line == "\r\n" {
                    break;
                }
                if let Some(value) = line.to_ascii_lowercase().strip_prefix("content-length:") {
                    length = Some(value.trim().parse::<usize>().unwrap());
                }
            }
            let length = length.expect("push must have a Content-Length");
            assert!(length < 1_000_000);
            let mut body = vec![0; length];
            reader.read_exact(&mut body).await.unwrap();
            reader
                .get_mut()
                .write_all(
                    format!(
                        "HTTP/1.1 {status} Test\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
                    )
                    .as_bytes(),
                )
                .await
                .unwrap();
            pushes.push((request, String::from_utf8(body).unwrap()));
        }
        pushes
    });
    (url, task)
}

async fn server(push_gateway_url: Option<String>) -> (u16, tokio::task::JoinHandle<()>) {
    // Keep server TCP+UDP ports outside the ephemeral range used by concurrent clients.
    let port = SERVER_PORT.fetch_add(1, Ordering::SeqCst);
    let task = tokio::spawn(async move {
        Server::new(ServerConfig {
            port,
            push_gateway_url,
            no_mdns: true,
            ..Default::default()
        })
        .run()
        .await
        .unwrap();
    });
    timeout(Duration::from_secs(5), async {
        loop {
            if TcpStream::connect(("127.0.0.1", port)).await.is_ok() {
                break;
            }
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    })
    .await
    .unwrap();
    (port, task)
}

fn sample(body: &str, name: &str) -> f64 {
    let value = body
        .lines()
        .find_map(|line| line.strip_prefix(&format!("{name} ")))
        .unwrap_or_else(|| panic!("missing {name}: {body}"));
    // Match the result JSON's parser so rounding differences do not weaken exact equality.
    serde_json::from_str(value).unwrap()
}

#[test]
fn metric_and_result_floats_use_the_same_parser() {
    let result: xfr::protocol::TestResult = serde_json::from_str(
        r#"{
        "id":"float-parser", "bytes_total":1234, "duration_ms":1000,
        "throughput_mbps":1.9896207584830339, "streams":[]
    }"#,
    )
    .unwrap();
    assert_eq!(
        sample(
            "xfr_throughput_mbps 1.9896207584830339\n",
            "xfr_throughput_mbps"
        ),
        result.throughput_mbps
    );
}

async fn read_final_json(
    reader: &mut (impl tokio::io::AsyncBufRead + Unpin),
    streaming: bool,
) -> xfr::protocol::TestResult {
    let mut text = String::new();
    loop {
        if streaming {
            text.clear();
        }
        assert!(reader.read_line(&mut text).await.unwrap() > 0);
        if let Ok(result) = serde_json::from_str(&text) {
            return result;
        }
    }
}

#[tokio::test]
async fn final_json_reader_accepts_extra_stream_intervals_and_pretty_json() {
    let result: xfr::protocol::TestResult = serde_json::from_value(serde_json::json!({
        "id": "reader-fixture", "bytes_total": 1234, "duration_ms": 1000,
        "throughput_mbps": 1.25, "streams": []
    }))
    .unwrap();
    for (streaming, text) in [
        (
            true,
            format!(
                "{{\"elapsed_secs\":1.0}}\n{{\"elapsed_secs\":2.0}}\n{}\n",
                serde_json::to_string(&result).unwrap()
            ),
        ),
        (false, xfr::output::output_json(&result).unwrap()),
    ] {
        let actual = read_final_json(&mut BufReader::new(text.as_bytes()), streaming).await;
        assert_eq!(actual.id, result.id);
        assert_eq!(actual.bytes_total, result.bytes_total);
    }
}

async fn client(port: u16, gateway: &str, host: &str, flags: &[&str]) -> std::process::Output {
    timeout(
        Duration::from_secs(15),
        tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
            .args([
                host,
                "-p",
                &port.to_string(),
                "-t",
                "1",
                "-P",
                "2",
                "-b",
                "2M",
                "--json",
                "--no-update-check",
                "--push-gateway",
                gateway,
            ])
            .args(flags)
            .kill_on_drop(true)
            .output(),
    )
    .await
    .unwrap()
    .unwrap()
}

#[tokio::test]
async fn closed_summary_stdout_preserves_saved_result_and_metrics() {
    let (url, pushes) = gateway(vec![202]).await;
    let (port, server) = server(None).await;
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("result.json");
    let (reader, writer) = std::io::pipe().unwrap();
    drop(reader);
    let output = timeout(
        Duration::from_secs(10),
        tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
            .args([
                "127.0.0.1",
                "-p",
                &port.to_string(),
                "-t",
                "1",
                "-b",
                "2M",
                "--json",
                "--no-update-check",
                "--push-gateway",
                &url,
                "--output",
            ])
            .arg(&path)
            .stdout(writer)
            .stderr(std::process::Stdio::piped())
            .kill_on_drop(true)
            .spawn()
            .unwrap()
            .wait_with_output(),
    )
    .await
    .unwrap()
    .unwrap();
    server.abort();
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(output.status.success(), "{stderr}");
    assert!(!stderr.contains("panicked"), "{stderr}");
    let saved: xfr::protocol::TestResult = serde_json::from_slice(
        &std::fs::read(&path).expect("a closed stdout must not discard the completed result"),
    )
    .unwrap();
    assert!(saved.bytes_total > 0);
    let pushes = timeout(Duration::from_secs(2), pushes)
        .await
        .expect("a closed stdout must not skip requested metrics delivery")
        .unwrap();
    assert_eq!(pushes.len(), 1);
    assert_eq!(
        sample(&pushes[0].1, "xfr_bytes_total"),
        saved.bytes_total as f64
    );
    assert_eq!(
        sample(&pushes[0].1, "xfr_throughput_mbps"),
        saved.throughput_mbps
    );
}

#[tokio::test]
async fn finalized_snapshot_values_are_not_recomputed() {
    let (url, pushes) = gateway(vec![202]).await;
    let result = serde_json::from_value(serde_json::json!({
        "id": "snapshot", "bytes_total": 4242, "duration_ms": 2000,
        "throughput_mbps": 7.25,
        "streams": [{"id": 9, "bytes": 123, "throughput_mbps": 0.75, "retransmits": 4}],
        "bytes_sent": 1000, "bytes_received": 3242,
        "throughput_send_mbps": 1.5, "throughput_recv_mbps": 5.75,
        "udp_stats_send": {"packets_sent": 100, "packets_received": 97, "lost": 3,
                      "lost_percent": 3.0, "jitter_ms": 1.5, "out_of_order": 0},
        "udp_stats_recv": {"packets_sent": 200, "packets_received": 120, "lost": 80,
                      "lost_percent": 40.0, "jitter_ms": 8.5, "out_of_order": 0},
        "tcp_info": {"rtt_us": 1250, "rtt_var_us": 100, "cwnd": 65536, "retransmits": 4},
        "udp_stats": {"packets_sent": 100, "packets_received": 97, "lost": 3,
                      "lost_percent": 3.0, "jitter_ms": 1.5, "out_of_order": 0}
    }))
    .unwrap();
    xfr::output::push_gateway::PushGatewayClient::new(url)
        .unwrap()
        .with_test(Protocol::Udp, Direction::Bidir)
        .push_test_result(&result)
        .await
        .unwrap();
    let pushes = pushes.await.unwrap();
    let body = &pushes[0].1;
    assert_eq!(sample(body, "xfr_bytes_total"), 4242.0);
    assert_eq!(sample(body, "xfr_duration_seconds"), 2.0);
    assert_eq!(sample(body, "xfr_throughput_mbps"), 7.25);
    assert_eq!(sample(body, "xfr_tcp_rtt_microseconds"), 1250.0);
    assert_eq!(sample(body, "xfr_udp_packets_lost"), 3.0);
    assert_eq!(sample(body, "xfr_udp_lost_percent"), 3.0);
    assert_eq!(sample(body, "xfr_udp_jitter_ms"), 1.5);
    for (name, expected) in [
        (
            "xfr_udp_direction_bytes{direction=\"upload\",view=\"receiver\"}",
            1000.0,
        ),
        (
            "xfr_udp_direction_bytes{direction=\"download\",view=\"receiver\"}",
            3242.0,
        ),
        (
            "xfr_udp_direction_throughput_mbps{direction=\"upload\",view=\"receiver\"}",
            1.5,
        ),
        (
            "xfr_udp_direction_throughput_mbps{direction=\"download\",view=\"receiver\"}",
            5.75,
        ),
        (
            "xfr_udp_direction_packets_expected{direction=\"upload\"}",
            100.0,
        ),
        ("xfr_udp_direction_packets_lost{direction=\"upload\"}", 3.0),
        (
            "xfr_udp_direction_packets_lost{direction=\"download\"}",
            80.0,
        ),
        (
            "xfr_udp_direction_lost_percent{direction=\"download\"}",
            40.0,
        ),
        ("xfr_udp_direction_jitter_ms{direction=\"download\"}", 8.5),
    ] {
        assert_eq!(sample(body, name), expected, "{name}");
    }
    assert_eq!(
        body.matches("# TYPE xfr_udp_direction_packets_lost gauge")
            .count(),
        1
    );

    assert!(body.contains("xfr_stream_bytes_total{test_id=\"snapshot\",stream_id=\"9\"} 123\n"));
    assert!(
        body.contains("xfr_stream_throughput_mbps{test_id=\"snapshot\",stream_id=\"9\"} 0.75\n")
    );
}

#[tokio::test]
async fn client_and_server_pushes_are_distinct_and_match_final_results() {
    let (url, pushes) = gateway(vec![202; 12]).await;
    let (port, server) = server(Some(url.clone())).await;
    let mut results = Vec::new();
    for (protocol, direction) in [
        (Protocol::Tcp, Direction::Upload),
        (Protocol::Udp, Direction::Upload),
        (Protocol::Udp, Direction::Download),
        (Protocol::Udp, Direction::Bidir),
        (Protocol::Quic, Direction::Download),
        (Protocol::Quic, Direction::Bidir),
    ] {
        let mut flags = Vec::new();
        match protocol {
            Protocol::Udp => flags.push("-u"),
            Protocol::Quic => flags.push("-Q"),
            Protocol::Tcp => {}
        }
        match direction {
            Direction::Download => flags.push("-R"),
            Direction::Bidir => flags.push("--bidir"),
            Direction::Upload => {}
        }
        let output = client(port, &url, "127.0.0.1", &flags).await;
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let result: xfr::protocol::TestResult = serde_json::from_slice(&output.stdout).unwrap();
        assert!(result.bytes_total > 0);
        results.push(result);
    }
    let pushes = timeout(Duration::from_secs(10), pushes)
        .await
        .unwrap()
        .unwrap();
    for result in results {
        let prefix = format!(
            "POST /api/v1/import/prometheus/metrics/job/xfr_test_{}/role/",
            result.id
        );
        let (_, body) = pushes
            .iter()
            .find(|(request, _)| {
                request.starts_with(&format!("{prefix}client/server/127.0.0.1:{port} "))
            })
            .expect("client push with server label");
        assert_eq!(sample(body, "xfr_bytes_total"), result.bytes_total as f64);
        assert_eq!(sample(body, "xfr_throughput_mbps"), result.throughput_mbps);
        assert_eq!(
            sample(body, "xfr_duration_seconds"),
            result.duration_ms as f64 / 1000.0
        );
        for stream in &result.streams {
            assert!(body.contains(&format!(
                "xfr_stream_bytes_total{{test_id=\"{}\",stream_id=\"{}\"}} {}\n",
                result.id, stream.id, stream.bytes as f64
            )));
        }
        if let Some(udp) = &result.udp_stats {
            assert_eq!(sample(body, "xfr_udp_packets_lost"), udp.lost as f64);
            assert_eq!(
                sample(body, "xfr_udp_packets_received"),
                udp.packets_received as f64
            );
        }
        assert!(
            pushes
                .iter()
                .any(|(request, _)| request
                    .starts_with(&format!("{prefix}server/client/127.0.0.1 "))),
            "server push with normalized client IP"
        );
    }
    server.abort();
}

#[cfg(target_os = "linux")]
#[tokio::test]
async fn client_cli_environment_and_config_precedence() {
    let (url, pushes) = gateway(vec![202; 3]).await;
    let (port, server) = server(None).await;
    let dir = tempfile::tempdir().unwrap();
    let config_dir = dir.path().join("xfr");
    std::fs::create_dir(&config_dir).unwrap();
    for source in ["config", "env", "cli"] {
        let config_url = if source == "config" {
            &url
        } else {
            "invalid-config-url"
        };
        std::fs::write(config_dir.join("config.toml"), format!("[client]\npush_gateway = {config_url:?}\n[server]\npush_gateway = \"invalid-server-url\"\n")).unwrap();
        let mut cmd = tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"));
        cmd.env("XDG_CONFIG_HOME", dir.path())
            .env_remove("XFR_PUSH_GATEWAY")
            .env_remove("XFR_CONFIG")
            .args([
                "127.0.0.1",
                "-p",
                &port.to_string(),
                "-t",
                "1",
                "-b",
                "2M",
                "--json",
                "--no-update-check",
            ])
            .kill_on_drop(true);
        if source != "config" {
            cmd.env(
                "XFR_PUSH_GATEWAY",
                if source == "env" {
                    &url
                } else {
                    "invalid-env-url"
                },
            );
        }
        if source == "cli" {
            cmd.args(["--push-gateway", &url]);
        }
        let output = timeout(Duration::from_secs(15), cmd.output())
            .await
            .unwrap()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let result: xfr::protocol::TestResult = serde_json::from_slice(&output.stdout).unwrap();
        assert!(result.bytes_total > 0);
    }
    assert_eq!(
        timeout(Duration::from_secs(5), pushes)
            .await
            .unwrap()
            .unwrap()
            .len(),
        3
    );
    server.abort();
}

#[tokio::test]
async fn failed_pushes_retry_without_failing_the_test() {
    let (url, pushes) = gateway(vec![500; 3]).await;
    let url =
        url.replacen("http://", "http://mesh-user:gateway-secret@", 1) + "?token=gateway-secret";
    let (port, server) = server(None).await;
    let output = client(port, &url, "127.0.0.1", &[]).await;
    assert!(output.status.success());
    let result: xfr::protocol::TestResult = serde_json::from_slice(&output.stdout).unwrap();
    assert!(result.bytes_total > 0);
    let stderr = String::from_utf8(output.stderr).unwrap();
    // One final warning; intermediate attempts log at debug level.
    assert_eq!(stderr.matches("not confirmed").count(), 1, "{stderr}");
    assert!(!stderr.contains("Retrying"), "{stderr}");
    assert!(
        !stderr.contains("mesh-user") && !stderr.contains("gateway-secret"),
        "{stderr}"
    );
    let pushes = pushes.await.unwrap();
    assert_eq!(pushes.len(), 3);
    assert!(pushes.windows(2).all(|pair| pair[0] == pair[1]));
    server.abort();
}

#[tokio::test]
async fn failed_test_does_not_push() {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let unavailable = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = unavailable.local_addr().unwrap().port();
    drop(unavailable);
    let output = client(
        port,
        &format!("http://{}", listener.local_addr().unwrap()),
        "127.0.0.1",
        &["--connect-timeout", "1s"],
    )
    .await;
    assert!(!output.status.success());
    assert!(
        timeout(Duration::from_millis(100), listener.accept())
            .await
            .is_err()
    );
}

#[tokio::test]
async fn concurrent_ipv4_and_ipv6_clients_keep_their_own_labels() {
    let (url, pushes) = gateway(vec![202; 4]).await;
    let (port, server) = server(Some(url.clone())).await;
    let (v4, v6) = tokio::join!(
        client(port, &url, "127.0.0.1", &[]),
        client(port, &url, "[::1]", &[])
    );
    assert!(v4.status.success() && v6.status.success());
    let v4: xfr::protocol::TestResult = serde_json::from_slice(&v4.stdout).unwrap();
    let v6: xfr::protocol::TestResult = serde_json::from_slice(&v6.stdout).unwrap();
    assert_ne!(v4.id, v6.id);
    let pushes = pushes.await.unwrap();
    for (result, host, peer) in [(v4, "127.0.0.1", "127.0.0.1"), (v6, "[::1]", "::1")] {
        let prefix = format!(
            "POST /api/v1/import/prometheus/metrics/job/xfr_test_{}/role/",
            result.id
        );
        assert!(pushes.iter().any(|(request, _)| {
            request.starts_with(&format!("{prefix}client/server/{host}:{port} "))
        }));
        assert!(
            pushes
                .iter()
                .any(|(request, _)| request.starts_with(&format!("{prefix}server/client/{peer} ")))
        );
    }
    server.abort();
}

#[tokio::test]
async fn invalid_gateway_is_rejected_before_connecting() {
    for url in [
        "not-a-url",
        "file:///tmp/metrics",
        "ftp://localhost/metrics",
    ] {
        let output = client(1, url, "127.0.0.1", &[]).await;
        assert!(!output.status.success());
        assert!(output.stdout.is_empty());
        assert!(!String::from_utf8_lossy(&output.stderr).contains("Connecting to"));
    }
}

async fn stalled_gateway_preserves_result(interrupt: bool, cancel_measurement: bool) {
    let gateway = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let url = format!(
        "http://mesh-user:gateway-secret@{}/?token=gateway-secret",
        gateway.local_addr().unwrap()
    );
    let (port, server) = server(None).await;
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("result.json");
    let mut child = tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
        .args([
            "127.0.0.1",
            "-p",
            &port.to_string(),
            "-t",
            if cancel_measurement { "0" } else { "1" },
            "-b",
            "2M",
            if cancel_measurement {
                "--json-stream"
            } else {
                "--json"
            },
            "--no-update-check",
            "--push-gateway",
            &url,
            "--output",
        ])
        .arg(&path)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .kill_on_drop(true)
        .spawn()
        .unwrap();
    let mut stdout = BufReader::new(child.stdout.take().unwrap());
    if cancel_measurement {
        let mut interval = String::new();
        timeout(Duration::from_secs(5), stdout.read_line(&mut interval))
            .await
            .unwrap()
            .unwrap();
        let interval: serde_json::Value = serde_json::from_str(&interval).unwrap();
        assert!(interval["elapsed_secs"].as_f64().unwrap() > 0.0);
        #[cfg(unix)]
        assert_eq!(
            unsafe { libc::kill(child.id().unwrap() as libc::pid_t, libc::SIGINT) },
            0
        );
    }
    // Hold the HTTP connection open without a response, after the measurement completes.
    let (_connection, _) = timeout(Duration::from_secs(10), gateway.accept())
        .await
        .unwrap()
        .unwrap();
    let result = timeout(
        Duration::from_secs(2),
        read_final_json(&mut stdout, cancel_measurement),
    )
    .await
    .expect("final JSON must be flushed before gateway delivery finishes");
    assert!(result.bytes_total > 0);
    let saved: xfr::protocol::TestResult =
        serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
    assert_eq!(saved.id, result.id);
    assert_eq!(saved.bytes_total, result.bytes_total);
    #[cfg(unix)]
    if interrupt {
        // The PID belongs to this still-running child, which is waiting for the HTTP reply.
        assert_eq!(
            unsafe { libc::kill(child.id().unwrap() as libc::pid_t, libc::SIGINT) },
            0
        );
    }
    let limit = if interrupt { 3 } else { 8 };
    let output = timeout(Duration::from_secs(limit), child.wait_with_output())
        .await
        .unwrap()
        .unwrap();
    let stderr = String::from_utf8(output.stderr).unwrap();
    assert!(output.status.success(), "{stderr}");
    assert!(
        !stderr.contains("mesh-user") && !stderr.contains("gateway-secret"),
        "{stderr}"
    );
    assert!(stderr.contains("not confirmed"), "{stderr}");
    assert!(
        !stderr.contains("partial results") && !stderr.contains("before any data"),
        "{stderr}"
    );
    if !interrupt {
        assert!(stderr.contains("timed out after 5 seconds"), "{stderr}");
    }
    assert_eq!(
        std::fs::read(&path).unwrap(),
        xfr::output::output_json(&result).unwrap().as_bytes()
    );
    server.abort();
}

#[cfg(unix)]
#[tokio::test]
async fn ctrl_c_during_metrics_delivery_keeps_completed_json_and_file() {
    stalled_gateway_preserves_result(true, false).await;
}

#[tokio::test]
async fn stalled_metrics_delivery_has_a_total_deadline_and_keeps_result() {
    stalled_gateway_preserves_result(false, false).await;
}

#[cfg(unix)]
#[tokio::test]
async fn stopping_a_test_then_skipping_metrics_keeps_successful_result() {
    stalled_gateway_preserves_result(true, true).await;
}

#[tokio::test]
#[ignore = "fixture generator invoked by the real-backend smoke"]
async fn stable_backend_fixtures() {
    use std::collections::BTreeMap;
    use xfr::output::push_gateway::PushGatewayClient;
    let output = std::env::var("XFR_STABLE_FIXTURES").expect("fixture output path");
    let base: xfr::protocol::TestResult = serde_json::from_value(serde_json::json!({
        "id":"fixture", "bytes_total":900,"duration_ms":1000,"throughput_mbps":0.0072,
        "streams":[{"id":0,"bytes":123,"throughput_mbps":0.5}],
        "tcp_info":{"rtt_us":1250,"rtt_var_us":100,"cwnd":65536,"retransmits":4},
        "bytes_sent":300,"bytes_received":600,"throughput_send_mbps":0.0024,"throughput_recv_mbps":0.0048,
        "udp_stats_send":{"packets_sent":10,"packets_received":9,"lost":1,"lost_percent":10.0,"jitter_ms":1.0,"out_of_order":0},
        "udp_stats_recv":{"packets_sent":20,"packets_received":12,"lost":8,"lost_percent":40.0,"jitter_ms":3.0,"out_of_order":0}
    })).unwrap();
    let mut cases = Vec::new();
    for i in 0..10 {
        let mut result = base.clone();
        result.id = format!("different-uuid-{i}");
        result.bytes_total += i;
        if i == 9 {
            result.streams.clear();
        }
        cases.push((
            "repeat",
            Protocol::Tcp,
            Direction::Upload,
            "home",
            "mesh-server",
            "relay/a\"x\\z\n\tλ\u{2028}\r",
            result,
        ));
    }
    let mut missing = base.clone();
    missing.tcp_info = None;
    cases.push((
        "missing-tcp",
        Protocol::Tcp,
        Direction::Upload,
        "home",
        "mesh-server",
        "relay/a\"x\\z\n\tλ\u{2028}\r",
        missing,
    ));
    cases.push((
        "udp-full",
        Protocol::Udp,
        Direction::Bidir,
        "home",
        "mesh-server",
        "relay/a\"x\\z\n\tλ\u{2028}\r",
        base.clone(),
    ));
    let mut missing = base.clone();
    missing.bytes_sent = None;
    missing.throughput_send_mbps = None;
    missing.udp_stats_send = None;
    missing.udp_stats_recv = None;
    cases.push((
        "udp-missing",
        Protocol::Udp,
        Direction::Bidir,
        "home",
        "mesh-server",
        "relay/a\"x\\z\n\tλ\u{2028}\r",
        missing,
    ));
    let mut all_lost = base.clone();
    all_lost.bytes_sent = None;
    all_lost.throughput_send_mbps = None;
    all_lost.udp_stats_send = None;
    all_lost.bytes_received = Some(0);
    all_lost.throughput_recv_mbps = Some(0.0);
    let quality = all_lost.udp_stats_recv.as_mut().unwrap();
    quality.packets_sent = 5;
    quality.packets_received = 0;
    quality.lost = 5;
    quality.lost_percent = 100.0;
    cases.push((
        "udp-all-lost",
        Protocol::Udp,
        Direction::Bidir,
        "home",
        "mesh-server",
        "relay/a\"x\\z\n\tλ\u{2028}\r",
        all_lost,
    ));
    for (tag, protocol, direction, instance, server, path) in [
        (
            "dot-job",
            Protocol::Tcp,
            Direction::Upload,
            "dot-single",
            "mesh-server",
            "..",
        ),
        (
            "dotdot-job",
            Protocol::Tcp,
            Direction::Upload,
            "dot-double",
            "mesh-server",
            ".",
        ),
        (
            "instance",
            Protocol::Tcp,
            Direction::Upload,
            "other",
            "mesh-server",
            "relay/a\"x\\z\n\tλ\u{2028}\r",
        ),
        (
            "target",
            Protocol::Tcp,
            Direction::Upload,
            "home",
            "other-server",
            "relay/a\"x\\z\n\tλ\u{2028}\r",
        ),
        (
            "path",
            Protocol::Tcp,
            Direction::Upload,
            "home",
            "mesh-server",
            "direct",
        ),
        (
            "direction",
            Protocol::Udp,
            Direction::Download,
            "home",
            "mesh-server",
            "relay/a\"x\\z\n\tλ\u{2028}\r",
        ),
        (
            "protocol",
            Protocol::Quic,
            Direction::Upload,
            "home",
            "mesh-server",
            "relay/a\"x\\z\n\tλ\u{2028}\r",
        ),
    ] {
        cases.push((
            tag,
            protocol,
            direction,
            instance,
            server,
            path,
            base.clone(),
        ));
    }
    cases.push((
        "legacy",
        Protocol::Tcp,
        Direction::Upload,
        "home",
        "mesh-server",
        "direct",
        base,
    ));
    let (url, pushes) = gateway(vec![202; cases.len()]).await;
    let mut metadata = Vec::new();
    for (tag, protocol, direction, instance, server, path, result) in cases {
        let job = match tag {
            "dot-job" => ".".to_string(),
            "dotdot-job" => "..".to_string(),
            "legacy" => format!("xfr_test_{}", result.id),
            _ => "xfr-stable-smoke".to_string(),
        };
        let mut client = PushGatewayClient::new(url.clone())
            .unwrap()
            .with_labels(BTreeMap::from([
                ("instance".into(), instance.into()),
                ("path".into(), path.into()),
                ("empty".into(), "".into()),
            ]))
            .unwrap()
            .with_server(server, 5201)
            .with_test(protocol, direction);
        if tag != "legacy" {
            client = client.with_job(job.clone()).unwrap();
        }
        client.push_test_result(&result).await.unwrap();
        metadata.push(serde_json::json!({"job":job,"tag":tag,"protocol":protocol,"test_direction":direction,"instance":instance,"server":format!("{server}:5201"),"path":path,"result":result}));
    }
    let pushes = pushes.await.unwrap();
    let fixtures: Vec<_> = metadata
        .into_iter()
        .zip(pushes)
        .map(|(mut meta, (request, body))| {
            meta["request"] = request.into();
            meta["body"] = body.into();
            meta
        })
        .collect();
    std::fs::write(output, serde_json::to_string(&fixtures).unwrap()).unwrap();
}

#[cfg(target_os = "linux")]
#[tokio::test]
async fn invalid_push_options_fail_before_connecting() {
    let config_directory = tempfile::tempdir().unwrap();
    let empty_config = config_directory.path().join("empty.toml");
    std::fs::write(&empty_config, "").unwrap();
    for (flags, expected) in [
        (
            vec!["--push-label", "host=home"],
            "--push-label requires a push gateway",
        ),
        (
            vec!["--push-job", "mesh"],
            "--push-job requires a push gateway",
        ),
        (
            vec!["--push-gateway", "http://127.0.0.1:1", "--push-job", "mesh"],
            "stable push job requires a nonempty instance label",
        ),
        (
            vec![
                "--push-gateway",
                "http://127.0.0.1:1",
                "--push-label",
                "role=wrong",
            ],
            "invalid or reserved push label name \"role\"",
        ),
        (
            vec![
                "--push-gateway",
                "http://127.0.0.1:1",
                "--push-label",
                "host=a",
                "--push-label",
                "host=b",
            ],
            "duplicate push label \"host\"",
        ),
    ] {
        let output = tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
            .args(["127.0.0.1", "-p", "1", "--no-update-check", "--json"])
            .args(flags)
            .arg("--config")
            .arg(&empty_config)
            .env_remove("XFR_PUSH_GATEWAY")
            .output()
            .await
            .unwrap();
        assert!(!output.status.success());
        assert!(output.stdout.is_empty());
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(stderr.contains(expected), "{stderr}");
        assert!(!stderr.contains("Connection refused"), "{stderr}");
    }
}

#[tokio::test]
async fn config_push_options_without_gateway_are_ignored() {
    let directory = tempfile::tempdir().unwrap();
    let config_dir = directory.path().join("xfr");
    std::fs::create_dir(&config_dir).unwrap();
    std::fs::write(
        config_dir.join("config.toml"),
        "[client]\npush_job = \"mesh\"\npush_labels = { site = \"lab\" }\n[server]\npush_labels = { site = \"lab\" }\n",
    )
    .unwrap();
    let (port, running) = server(None).await;
    let output = tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
        .args(["127.0.0.1", "-p", &port.to_string(), "-t", "1", "-b", "1M"])
        .args(["--json", "--no-update-check"])
        .env("XDG_CONFIG_HOME", directory.path())
        .env_remove("XFR_PUSH_GATEWAY")
        .env_remove("XFR_CONFIG")
        .output()
        .await
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    running.abort();

    let port = SERVER_PORT.fetch_add(1, Ordering::SeqCst);
    let mut child = tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
        .args(["serve", "-p", &port.to_string(), "--no-mdns"])
        .env("XDG_CONFIG_HOME", directory.path())
        .env_remove("XFR_PUSH_GATEWAY")
        .env_remove("XFR_CONFIG")
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::null())
        .kill_on_drop(true)
        .spawn()
        .unwrap();
    timeout(Duration::from_secs(5), async {
        while TcpStream::connect(("127.0.0.1", port)).await.is_err() {
            assert!(child.try_wait().unwrap().is_none(), "server exited");
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    })
    .await
    .unwrap();

    let output = tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
        .args(["serve", "--push-label", "site=lab"])
        .env("XDG_CONFIG_HOME", directory.path())
        .env_remove("XFR_PUSH_GATEWAY")
        .env_remove("XFR_CONFIG")
        .output()
        .await
        .unwrap();
    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("--push-label requires a push gateway"),
        "{stderr}"
    );
}

#[cfg(target_os = "linux")]
#[tokio::test]
async fn stable_client_labels_merge_cli_over_config() {
    let (url, pushes) = gateway(vec![202; 2]).await;
    let (port, running) = server(None).await;
    let directory = tempfile::tempdir().unwrap();
    let config_dir = directory.path().join("xfr");
    std::fs::create_dir(&config_dir).unwrap();
    std::fs::write(config_dir.join("config.toml"), format!(
        "[client]\npush_gateway = {url:?}\npush_job = \"config-job\"\npush_labels = {{ instance = \"config\", site = \"lab\" }}\n"
    )).unwrap();
    for extra in [vec![], vec!["--push-job", "cli-job"]] {
        let output = tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
            .args([
                "127.0.0.1",
                "-p",
                &port.to_string(),
                "-t",
                "1",
                "-b",
                "2M",
                "--json",
                "--no-update-check",
                "--push-label",
                "instance=cli=a",
            ])
            .args(extra)
            .env("XDG_CONFIG_HOME", directory.path())
            .env_remove("XFR_PUSH_GATEWAY")
            .env_remove("XFR_CONFIG")
            .output()
            .await
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
    }
    let pushes = pushes.await.unwrap();
    for ((request, body), job) in pushes.iter().zip(["config-job", "cli-job"]) {
        assert!(request.starts_with("PUT "));
        assert!(request.contains(&format!("/job/{job}/")), "{request}");
        assert!(request.contains("/instance/cli=a"), "{request}");
        assert!(request.contains("/site/lab"), "{request}");
        assert!(body.contains("xfr_last_test_bytes"));
        assert!(!body.contains("test_id"));
    }
    running.abort();
}

#[tokio::test]
async fn server_cli_push_labels_are_portable() {
    let (url, pushes) = gateway(vec![202]).await;
    let port = SERVER_PORT.fetch_add(1, Ordering::SeqCst);
    let child = tokio::process::Command::new(env!("CARGO_BIN_EXE_xfr"))
        .args([
            "serve",
            "-p",
            &port.to_string(),
            "--one-off",
            "--no-mdns",
            "--push-gateway",
            &url,
            "--push-label",
            "instance=central",
        ])
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::piped())
        .kill_on_drop(true)
        .spawn()
        .unwrap();
    timeout(Duration::from_secs(5), async {
        while TcpStream::connect(("127.0.0.1", port)).await.is_err() {
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    })
    .await
    .unwrap();
    let result = xfr::client::Client::new(xfr::client::ClientConfig {
        host: "127.0.0.1".into(),
        port,
        duration: Duration::from_secs(1),
        bitrate: Some(2_000_000),
        ..Default::default()
    })
    .run(None)
    .await
    .unwrap();
    assert!(result.bytes_total > 0);
    let output = timeout(Duration::from_secs(10), child.wait_with_output())
        .await
        .unwrap()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let pushes = pushes.await.unwrap();
    assert!(pushes[0].0.starts_with("POST "));
    assert!(pushes[0].0.contains("/role/server/"));
    assert!(pushes[0].0.contains("/instance/central"));
}
