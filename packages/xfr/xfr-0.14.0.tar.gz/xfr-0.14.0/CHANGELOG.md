# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.14.0] - 2026-10-31

### Added
- **Client port from config or the target** — `[client] port` sets the port clients connect to, so a server moved off 5201 (for example because iperf3 holds it) no longer needs `-p` on every run. Targets also accept `host:port`, `[IPv6]:port` and `[fe80::1%eth0]:port`; `[::1]` and a bare IPv6 address such as `::1` or `fe80::1%eth0` are hosts with no port. The port comes from a `host:port` target, then `-p`/`--port`, then `XFR_PORT`, then `[client] port`, then 5201. A target port that disagrees with `-p`/`--port` is an error; `XFR_PORT` yields to the target. Port 0 is rejected from every source (#273).
- **`--config`, `XFR_CONFIG` and `/etc/xfr/config.toml`** — `--config <PATH>` (before or after `serve`) or `XFR_CONFIG` names the config file to read, with no fallback; a missing explicit file is an error that names the path and whether it came from `--config` or `XFR_CONFIG`. Without one, xfr reads the user config file as before, then `/etc/xfr/config.toml` on Unix; the first that exists wins and files are not merged. With no home directory, only `/etc/xfr/config.toml` is searched, never the working directory. The file in use is logged as `Using config <path>`, so a root shell, container or service whose `$HOME` differs no longer drops its settings silently (#273). PSK-bearing files keep the owner-only permission check wherever they live. A search-path file the user cannot open (such as a root-only `/etc/xfr/config.toml`) makes a client warn and use its defaults, while `xfr serve` refuses to start rather than run without its PSK or ACL settings. A config path that is, or runs through, a symlink to a missing path is an error for both client and `serve`, instead of being treated as no config. `prefs.toml` still saves to the user config directory.

### Changed
- **`xfr discover` brackets IPv6 answers** — `fe80::2%eth0:5201` now prints as `[fe80::2%eth0]:5201`, which can be passed to `xfr` as a target with its port.

### Fixed
- **UDP no longer counts packets still in flight at the end of a test as lost** — on a path with jitter, the receiver stopped having already seen packets that overtook earlier ones still on the wire, and those gaps were finalized as loss. A netem `delay 20ms 10ms` path with no drops reported a fixed 25–47 lost packets per test at 50 Mbps (0.3% of a 2 s test) in every direction. Each receiver (the server for uploads, the client for `-R`, both for `--bidir`) now waits up to 200 ms for those packets before it finalizes loss, ending as soon as every gap fills, so the same path reports 0. Packets sent after the receiver stopped are ignored rather than opening new gaps, and real loss still counts in full. The server's test duration no longer includes that wait. A receiver still running v0.13.0 or earlier keeps the old behavior.
- **PSK mismatches say which side is missing the key** — a client with `--psk` against a server without one failed with `PSK session but no server nonce` (TCP/UDP) or `QUIC PSK session key was not derived` (QUIC). It now reads `the server does not use a pre-shared key; remove --psk/--psk-file or configure the server with one`. The opposite case now reads `authentication failed: the server requires a pre-shared key (set --psk/--psk-file)`, matching the wrong-key message. Client-side only; no protocol change.
- **`-n` durations measure the transfer** — a TCP upload of a few megabytes reported `Duration: 0.10s`, because the server stopped its clock at the client's `Finish`, which trails the last byte by the client's 100 ms stream-setup pause. The server now stops at receive EOF. In the other direction the server stopped at its last write into the kernel (or QUIC) send buffer, so a paced `-R -b 100M -n 20M` reported 1.46 s and 114.6 Mbps; TCP and QUIC senders now wait for the peer to acknowledge the last byte (1.65 s, 101.9 Mbps), giving up after five seconds if the peer never acknowledges. JSON `duration_ms` follows; a sub-millisecond transfer rounds up to 1 ms rather than 0, and plain output shows milliseconds for durations under a second (`0.001s`).
- **Link-local targets without a zone say so** — `xfr fe80::2` and client `--bind fe80::1` failed with a bare `Invalid argument (os error 22)`, and `xfr fe80::2 --quic` waited out the connect. They now fail before connecting with `link-local address fe80::2 needs an interface zone, e.g. fe80::2%eth0`.
- **A failed metrics push warns once** — an unreachable push gateway printed two `Failed to push metrics (attempt N) … Retrying...` warnings before the final `metrics delivery … was not confirmed` warning. The intermediate attempts now log at debug level.
- **`xfr discover` prints one line per server** — since 0.11.0 every address of every server got its own row, so a handful of servers on a host with Docker or VPN interfaces produced hundreds of rows. Each server is now listed once with its preferred address (IPv4, with 172.16/12 after other IPv4, then global or ULA IPv6, then link-local, then loopback); `xfr discover -v` lists all of them. A server reachable only by link-local addresses shows the first and how many more `-v` lists. The per-address `Found server:` log line on stderr is now debug-level.
- **`xfr discover` no longer pairs a server on the same host with every local interface** — mdns-sd publishes all of a host's link-local addresses on every interface, and each answer was paired with every interface it was heard on. A server that advertises exactly this host's hostname and answers with this host's own link-local address on the interface the answer arrived on is on this host, and its link-local addresses are now shown only with the interfaces that own them. Any other server's link-local addresses are still each listed with the interface they arrived on, even one that matches an address of this host, since the answer does not say which is the sender's address on that link.
- **Closing xfr's stdout no longer panics** — `xfr discover | head -1`, `xfr diff ... | head -1` and plain client output piped into a reader that exits early ended with `failed printing to stdout: Broken pipe` and exit status 101. xfr now exits quietly with status 0 when stdout is a closed pipe. A completed client summary still saves any requested result file and delivers metrics after its stdout reader closes.
- **QUIC clients give up on a silent server in seconds** — a QUIC client whose server died mid-test (crash, power loss, `kill -9`) printed nothing for about 30 seconds and then failed with `connection lost: timed out`, and connecting to a port with no QUIC server waited 30 seconds for `timed out`. The client now sends a keep-alive every second and gives up after 5 seconds with nothing from the server, printing `connection lost: the server stopped responding` or `could not reach <addr> over QUIC (no response within 5s)`. QUIC uses the smaller of the two peers' idle timeouts, so the server also drops a vanished new client after 5 seconds; older clients still get 30. Paused tests are unaffected, since keep-alives and interval reports keep flowing. `--connect-timeout` still bounds the handshake when set lower.
- **Closing xfr's stdout no longer panics** — `xfr discover | head -1`, `xfr diff ... | head -1` and plain client output piped into a reader that exits early ended with `failed printing to stdout: Broken pipe` and exit status 101. xfr now exits quietly with status 0 when stdout is a closed pipe.
- **QUIC clients give up on a silent server in seconds** — a QUIC client whose server died mid-test (crash, power loss, `kill -9`) printed nothing for about 30 seconds and then failed with `connection lost: timed out`, and connecting to a port with no QUIC server waited 30 seconds for `timed out`. The client now sends a keep-alive every second and gives up after 10 seconds with nothing from the server, printing `connection lost: the server stopped responding` or `could not reach <addr> over QUIC (no response within 10s)`. QUIC uses the smaller of the two peers' idle timeouts, so the server also drops a vanished new client after 10 seconds; older clients still get 30. Paused tests are unaffected, since keep-alives and interval reports keep flowing. `--connect-timeout` still bounds the handshake when set lower.

### Library API (pre-1.0 break)
- Struct-literal constructors must supply the new public field `config::ClientDefaults.port`. The struct implements `Default`, so literals ending in `..Default::default()` are unaffected.
- `discover::DiscoveredServer` is one server instance: its `ip` and `zone` fields are replaced by `addresses: Vec<DiscoveredAddress>` (preferred first), and `discover()` returns one entry per instance rather than one per address. `Display` shows the preferred address.

## [0.13.0] - 2026-10-30

### Security
- **Updated `ctutils` to 0.4.6** — closes [RUSTSEC-2026-0385](https://rustsec.org/advisories/RUSTSEC-2026-0385) (#275). v0.12.1 shipped `ctutils` 0.4.2, which `digest` (HMAC-SHA256) and `universal-hash` (Poly1305 in ChaCha20-Poly1305) use for constant-time tag comparison. Before 0.4.4, its `const fn` mask helpers could compile to a branch on common platforms, and its `u128` comparisons branched on 32-bit targets; branching on secret values can leak them through timing. xfr's MAC and AEAD tag checks compare `[u8]` slices through the `cmov`-backed path, not those helpers, so the exposure is believed to be theoretical. Lockfile-only; no source or API changes.

### Added
- **Portable push labels and bounded client snapshots** — client/server `--push-label` and TOML `push_labels` merge by key; client-only `--push-job` reuses aggregate `xfr_last_test_*` gauges without UUID or stream labels. An explicit `instance` distinguishes source peers, complete-group replacement removes omitted Pushgateway samples, and availability gauges mask old optional values in VictoriaMetrics. Config labels and job are ignored until a gateway is configured; `--push-label`/`--push-job` without one is an error, as is either flag before `serve` (`xfr --push-label k=v serve`). Legacy exports remain the default; server bounded grouping is separate.
- **Directional UDP push metrics** — new `xfr_udp_direction_*` gauges export upload/download bytes, throughput, and each receiver's loss/jitter. Directions are client-relative; server download traffic is labeled as a sender view. Missing observations stay absent, legacy metrics are unchanged, and TUI restarts retain the completed run's protocol/direction. A run cut short by a TUI restart is not pushed, so it cannot replace the last full snapshot. Library callers opt in with `PushGatewayClient::with_test`.
- **Read systemd PSK credentials on Linux** — `--psk-file` accepts root-owned read-only credential files whose ACL grants read access only to the service's effective UID and root. Ordinary group-readable keys and PSK-bearing config files keep their existing permission checks; `CREDENTIALS_DIRECTORY` does not bypass validation.
- **Push final client results to Prometheus or vmagent** — `xfr <host> --push-gateway <url>`, `XFR_PUSH_GATEWAY`, and `[client] push_gateway` reuse the existing exporter after local result corrections. Client pushes carry `role="client"` and `server="host:port"`; server pushes carry `role="server"` and `client="peer IP"`. Existing job names and metric names are preserved. HTTP failures remain best effort and do not fail a completed test (#276).
- **Completed results survive a stalled metrics gateway** — client stdout and result files are written before delivery, the TUI shows completion immediately, and delivery has a five-second total deadline. Ctrl-C skips delivery while preserving the successful measurement. Delivery status appears on stderr or in TUI history; invalid URLs fail before testing and gateway credentials are omitted from delivery logs.
- **Library API:** `PushGatewayClient::with_server` and fallible `push_test_result` export finalized client results explicitly after they have been consumed or saved. `ClientConfig` and `Client::run` keep their existing measurement-only behavior; the existing `TestStats` exporter API is preserved.

### Changed
- **Clients also read `XFR_PUSH_GATEWAY`** — the variable was server-only; an environment that exports it for `xfr serve` now makes `xfr <host>` push its results too. Unset it for clients that should not push.
- **Second Ctrl-C only forces exit while stopping a measurement** — after a real result is finalized, Ctrl-C skips outstanding metric delivery and preserves the successful exit status and saved result.
- **Server timeouts waiting for a connection's first line say how far it got** — `Initial read timeout (...) from <peer>` and the bare `Handshake timeout` now read `Initial read timeout (5s): local=Ok(...), peer=Ok(...), bytes_read=N, native_peek=Ok(M)` (likewise `Handshake timeout (30s): ...`), giving both endpoints, the bytes of a partial line already read, and how many bytes are queued unread on the socket. The queued count is a non-consuming peek. Log filters matching the old wording need updating. The client logs its Hello write, with both endpoints, at debug level (#282).

### Maintenance
- **Dependency refresh** — `tokio` 1.54.1, `serde_json` 1.0.154, `mdns-sd` 0.21.6, `toml` 1.1.8, `base64` 0.22 → 0.23, `sha2` 0.11.1 and `libc` 0.2.191 (#274); `taiki-e/install-action` 2.87.30 in CI (#269).

### Documentation
- **Homebrew installs lead with the core formula** — xfr is in Homebrew core, so the README and `docs/INSTALL.md` now give `brew install xfr`; the `lance0/tap` tap remains available (#272).

### Fixed
- **`--help` no longer prints `XFR_PSK` or `XFR_PUSH_GATEWAY` values** — help output showed the current environment value beside each option, exposing the pre-shared key or gateway credentials in scrollback and pasted help text.
- **Server metric pushes have a five-second total deadline** — a gateway that accepted the connection but never answered held `xfr serve` for 30 seconds per attempt across three attempts, so `xfr serve --one-off` exited about 90 seconds after the test, and the stalled handler kept its connection slot all that time. Server pushes now share the client's five-second limit, retries included, and log one warning when it expires. v0.12.1 behaved the same way.
- **Legacy per-test push bodies keep each per-stream family together** — with `-P` above 1, the `HELP`/`TYPE` lines for `xfr_stream_bytes_total`, `xfr_stream_throughput_mbps` and `xfr_stream_retransmits_total` came first and the samples followed stream by stream. Each family now lists its header and then all of its samples, as the text exposition format expects.
- **Invalid push gateway URLs name the setting** — `--push-gateway "not a url"` failed with only `Error: relative URL without a base`. The error now reads `invalid push gateway URL "not a url": relative URL without a base`, for the flag, `XFR_PUSH_GATEWAY` and config `push_gateway` alike, on the client and on `xfr serve`. Any userinfo in the rejected URL is masked as `***`.
- **`xfr serve` names the port when it is already taken** — a server whose TCP or QUIC port was held by another process (for example an iperf3 server on the shared default port 5201) failed with only `Address already in use (os error 98)`. The error now names the port and address, says when only the UDP (QUIC) port is taken, and suggests another port with `-p`, keeping any `--bind` address. On Windows, where a held or reserved port fails with `WSAEACCES` (os error 10013), the message reads "already in use or reserved". `xfr serve --tui` reports startup failures after restoring the terminal instead of exiting silently with status 0 (#273).
- **A rejected pre-shared key says so once, over every protocol** — TCP and UDP clients printed `Authentication failed: Authentication failed`, and QUIC clients printed only `connection lost: closed by peer: 0` because the server closed the connection before its reply arrived. Clients now print `authentication failed: the server rejected the pre-shared key (check --psk/--psk-file)`, and the QUIC server waits (up to one second) for the reply to be acknowledged before closing, so v0.12.1 QUIC clients also see the server's reason. A new client against an older QUIC server still reports the lost connection.

### Library API (pre-1.0 break)
- Struct-literal constructors must supply new public fields: `config::ClientDefaults.{push_gateway, push_labels, push_job}` and `config::ServerDefaults.push_labels`. Both structs implement `Default`, so literals ending in `..Default::default()` are unaffected.

## [0.12.1] - 2026-10-21

### Security
- **Distrusted emSign intermediates are rejected** — updated `webpki-roots` and `webpki-root-certs` to 1.0.10 and `rustls-webpki` to 0.103.16, closing [RUSTSEC-2026-0381](https://rustsec.org/advisories/RUSTSEC-2026-0381), [RUSTSEC-2026-0383](https://rustsec.org/advisories/RUSTSEC-2026-0383) and [RUSTSEC-2026-0382](https://rustsec.org/advisories/RUSTSEC-2026-0382). The private keys of several emSign intermediate CAs are now public. The bundled roots still included `emSign ECC Root CA - G3`, and certificate verification did not reject the compromised intermediates, so a network attacker holding one of those keys could impersonate an HTTPS server xfr talks to: the update check and the Prometheus push gateway. The new roots drop that CA and verification rejects paths through those intermediates. QUIC tests are unaffected, since xfr authenticates QUIC peers with the PSK channel binding, not the public CA set. Lockfile-only; no source or API changes.

## [0.12.0] - 2026-10-17

### Security
- **Updated `rustls` to 0.23.46** — closes [RUSTSEC-2026-0346](https://rustsec.org/advisories/RUSTSEC-2026-0346) (`Debug` impls could expose TLS session secrets), [RUSTSEC-2026-0349](https://rustsec.org/advisories/RUSTSEC-2026-0349) (a `ServerHello` could downgrade the handshake to classical key exchange), [RUSTSEC-2026-0347](https://rustsec.org/advisories/RUSTSEC-2026-0347) (data leak after an ECH rejection; xfr does not use ECH), and [RUSTSEC-2026-0348](https://rustsec.org/advisories/RUSTSEC-2026-0348) (brotli certificate decompression; xfr does not enable rustls's `brotli` feature). rustls backs xfr's QUIC transport and its HTTPS clients (update check, Prometheus push gateway). Lockfile-only; no source or API changes.

### Added
- **`xfr::persistence::atomic_write(path, bytes)`** — the library's crash-safe save routine (used for JSON and CSV results and preferences) is public, so other output paths can share it.

### Changed
- **Behavior change: client options given with a subcommand are now a usage error** — `xfr --json -t 5 -P 4 diff a b` or `xfr -p 9000 serve` used to run with those options silently dropped, so `xfr -p 9000 serve` listened on the default port instead of 9000. Top-level test, output and connection options typed alongside `serve`, `diff` or `discover` now fail with a usage error (exit 2) naming the option. When the subcommand takes the same option, the error's tip shows the corrected command (`tip: put serve options after the subcommand: xfr serve --port 9000`); otherwise it says the option only applies to client tests. **Scripts and service units that put options before `serve` must move them after it** (`xfr serve -p 9000`). `--theme`, `--log-file`, `--log-level`, `--no-update-check` and `--completions` still work with any subcommand, but as top-level options they go before it: `xfr --no-update-check serve` works, `xfr serve --no-update-check` is a usage error. Only `--theme` is also accepted after the subcommand, and `serve` has its own `--log-file` and `--log-level`, which go after it. Options set through environment variables (`XFR_DURATION`, `XFR_PORT`, `XFR_PSK`, ...) are not affected.

### Maintenance
- **Less allocation in interval aggregation** — jitter and RTT averages and the total TCP congestion window are computed without temporary vectors. Missing and measured-zero values, RTT rounding, and saturating congestion-window totals retain their existing meaning.
- **Less allocation in TUI reporting** — help paging counts wrapped rows without building a temporary vector, and server tables format only visible cells while borrowing protocol and direction labels.
- **Native Windows tests in CI** — the Windows job now runs Clippy on all targets and the all-features test suite, including integration tests, instead of `cargo check`. The job is informational and does not fail the workflow while Windows support is experimental. The two QUIC upload pacing tests are skipped on Windows, where QUIC delivers far below the `-b` target (see [Known Issues](KNOWN_ISSUES.md#windows-support-is-experimental)).
- **Dropped the typos CI check** — it mostly flagged false positives (test fixtures, changelog wording); spelling is left to review.
- **Less allocation in Push Gateway formatting** — Prometheus metric lines are written directly into the payload buffer instead of allocating a temporary string for each line. Metric names, labels, ordering, and text formatting are unchanged.
- **Less allocation in plain and CSV reporting** — formatted report fragments and CSV summary rows are written directly into their output buffer, and plain reports reuse a static separator. Output text and CSV column ordering are unchanged.

### Documentation
- **README restructured** — the README is now a short entry point; installation moved to `docs/INSTALL.md`, a documentation index to `docs/README.md`, and the detailed reference into `docs/FEATURES.md`. Old README anchors are kept so existing links still land. `docs/COMPARISON.md` no longer says iperf3 uses a port per stream, describes its authentication as username/password with RSA-encrypted credentials, and credits its `--json-stream`.
- **README demo re-recorded** — the GIF opens on a populated throughput view in colour at real-time speed, from `docs/demo.tape`.

### Fixed
- **QUIC servers no longer hang up to 30 s after a test, and SIGTERM closes QUIC clients** — the client closed its connection the moment the result arrived. Quinn holds back a CONNECTION_CLOSE while the congestion window is full, which an upload's is, so the client's acknowledgement of the result, carried in that close, often never left. The server waits for that acknowledgement before it lets go of a test, so it waited out the 30 s idle timeout instead. `serve --one-off` exited 30 s late, and other servers held the test's slot for 30 s. The client now waits up to 1 s for the server to close before closing itself, the server closes the connection once the result is acknowledged, and `xfr serve` handles SIGINT and SIGTERM (now exit status 0) by closing its QUIC connections before it exits. A client whose server is stopped mid-test fails within a few hundred milliseconds instead of after 30 s. Servers still wait up to 30 s for older clients.
- **Every TCP stream carries data at high stream counts** — unpaced TCP tests with many streams on a fast link left some streams with zero bytes while the run exited 0 and reported a plausible total: about 10 of 64 streams on loopback, and 60–90 of 128. The send loop (since zero-copy sends) waited for socket readiness and wrote with calls that bypass tokio's cooperative scheduling budget, so on a socket that stayed writable it never gave up its worker thread. The remaining streams' connects and the server's routing of them, and wakeups for sockets that had filled, then waited until the test ended. The send loop now yields to the scheduler regularly. With the fix, `-P 4` on loopback also splits throughput evenly across streams and raises the total by about 60% (before, the slowest stream ran at a fraction of the others' rate). If a TCP stream still carries nothing in a direction it was meant to use, the client warns (`Warning: N of M streams carried no data; the totals cover only the rest`, and `zero_byte_streams` in `--json`), and the server logs it. `-n` tests are exempt, since a small budget can leave streams empty by design.
- **Prometheus `/metrics` no longer grows with every test** — the server exported each finished test's `xfr_stream_*` and `xfr_tcp_*` series (labelled with `test_id`) forever, so a long-running `serve --prometheus` grew in scrape size and memory with every test: in a 20-minute soak of 120 short tests the series count rose from 14 to 1626. Per-test series are now kept for the 16 most recently finished tests, including tests that errored or were cancelled, and removed after that. A test's final values therefore stay visible to the next scrapes. The aggregate `xfr_bytes_total`, `xfr_tests_total` and `xfr_test_duration_seconds` still count every test.
- **Ctrl-C works throughout both TUIs** — client Settings no longer swallows interrupts (Ctrl-C closes it and cancels the test), and the server dashboard now accepts Ctrl-C. Terminals that send a literal ETX are supported too. Client cancellation keeps the existing summary wait and second-interrupt force exit.
- **Preference, JSON result and CSV result saves are atomic** — writes now complete and sync beside the destination before replacing it, preserving the previous save on failure, Unix permission bits, and valid symlinks. Read-only files, broken symlinks, and directories are rejected; devices, FIFOs, and pipes (`-o /dev/null`, `-o /dev/stdout`) are written in place as before. A writable file in a directory that is not writable is still overwritten in place, as before, with a warning that the save is not atomic. Save errors name the destination and the cause (`Cannot save to out/x.json: directory does not exist`) instead of the temporary file's path.
- **TUI theme readability** — the default theme uses the terminal foreground for light and dark terminals, and RGB themes use brighter secondary text on their intended dark backgrounds. Per-stream bar labels and empty tracks now follow the theme's dim text color instead of a fixed dark gray. Secondary text in the default theme (labels, footer key names, stream IDs, empty bar tracks) is a fixed mid grey (xterm 244, #808080) rather than a named ANSI grey: Solarized Dark draws ANSI 8 in its background colour, which made all of it invisible, and light palettes put ANSI 7 next to theirs. The monochrome theme's borders and secondary text, which had the same ANSI 8 problem, use that grey too. Loss indicators retain their existing styles.
- **TUIs stay readable in small terminals** — the client prioritizes live throughput and progress on short terminals and never cuts the rate mid-unit (the state label is shortened or dropped first), and its footer now leads with the `?` help hint so narrow widths drop the other hints first, then the `Status:` label, then the status itself; the server dashboard omits optional table columns on narrow terminals, drops its Blocked / Auth Fail and then Tests / Failed header stats instead of running them into the bandwidth figure, names how many active tests don't fit in the table title (`Active Tests (3, 2 hidden)`), and keeps its header and help hint on short terminals; its footer now lists help first in the client's hint style (`?:Help q:Quit`, or `[?] Help | [q] Quit` on wide terminals); both help overlays page with PgUp/PgDn and Home/End and show `PgDn more` in the border when they overflow, and draw their descriptions in the body text colour, aligned in one column past the widest key.
- **TUI History reports the UDP loss of each interval** — `UDP loss: +N packets` treated the per-interval loss count as cumulative, so a steady ~700 packets lost per second logged `+708` once and then the small interval-to-interval differences (`+8`, `+73`, ...). Each line now gives the packets newly lost since the previous report, and `-u -R` runs, whose loss is measured by the client, log it too.
- **Update-check overrides stay locked in Settings** — builds without the checker, environment opt-outs, `--no-update-check`, and explicit config values show their reason and cannot overwrite saved preferences. A locked row reads dimmed and no longer shows the `◀ ▶` change arrows when selected.
- **Bounded Prometheus HTTP connections** — request headers have a 5-second total deadline and connections have a 10-second total lifetime, including stalled response writes. HTTP keep-alive is disabled; each connection serves one request. At most 64 connections are served at once; further connections wait in the accept backlog. An accept error (e.g. `Too many open files` during a connection flood) no longer stops the metrics server: it is logged and retried after 100 ms. Per-connection errors are logged at debug level instead of being printed to stderr, which corrupted the server TUI.
- **`--connect-timeout` now bounds hostname resolution** — the client resolved the target with the blocking system resolver on a runtime thread, so a stuck DNS lookup hung the connect and the timeout could never fire; QUIC also resolved outside its connect deadline entirely. Lookups now run on tokio's blocking pool inside the deadline for TCP, UDP and QUIC. Library: `xfr::net::resolve_host` is now `async`.
- **`--csv -o FILE` saves CSV** — the file always received the JSON result, even though `--csv -o data.csv` is the documented way to save CSV. With `--csv` the file now holds the same header and summary row printed to stdout; every other mode still saves JSON.
- **`-o` destinations are checked before the test starts** — `-o ro.json`, `-o somedir/` and `-o nodir/x.json` failed only after the whole test had run, discarding its result. The client now checks the destination before connecting and exits 1 with the save error (`Cannot save to nodir/x.json: directory does not exist`). The check creates and truncates nothing, and skips devices, FIFOs and pipes such as `/dev/null` and `/dev/stdout`.
- **No terminal no longer breaks the client (LAN-2197)** — with stdout piped (`xfr <host> | cat`) or no controlling terminal (`setsid xfr <host> </dev/null`) and no `--no-tui`, the client failed with `Error: No such device or address (os error 6)`; with stdout redirected to a file from a terminal, the TUI wrote its escape sequences into the file and hung. The TUI now starts only when stdout and stdin are both terminals; otherwise the client prints plain output, as with `--no-tui`. `xfr serve --tui` without a terminal likewise runs the plain server and logs a warning that `--tui` needs a terminal.
- **QUIC runs no longer warn about random payloads unless `--random` is given (LAN-2199)** — every `-Q` run printed `Warning: random payloads are ignored with QUIC (payload is already encrypted)`, because random payloads are the default. The warning now appears only with an explicit `--random`.
- **`--json-stream` and `-q` are rejected together** — `-q` suppresses interval output, so the combination silently emitted only the final summary line instead of a stream. Use `--json` for the summary alone.
- **UDP streams could lose their traffic to another socket on the same port** — every UDP data socket set `SO_REUSEADDR`, including the ones bound to an ephemeral port. With that option the kernel can give a new socket a port another live socket already holds: on Linux, after a few hundred live sockets in one process, and Windows shares ports the same way. The newer socket then receives every datagram sent to that port. A server's per-stream UDP socket (on servers that don't support single-port UDP, such as Windows, or with clients that predate it) could count zero packets for an upload, or never learn the client's address in a `-R` or `--bidir` test. The odds grew with stream count and concurrent tests. Ephemeral UDP sockets no longer set `SO_REUSEADDR`. Sockets on an explicit port (`--cport`) still set it.

### Library API (pre-1.0 break)
- **`net::resolve_host` is now `async`** — callers must `.await` it. Lookups run on tokio's blocking pool so a surrounding timeout can abandon a stuck resolver.
- Struct-literal constructors must supply new public fields: `tui::server::ServerApp.help_scroll`, `tui::widgets::StreamBar.dim_color` (`StreamBar::new` sets it; `StreamBar::dim_color` overrides it), and `protocol::TestResult.zero_byte_streams` (serde-optional, so the wire format stays compatible).
- **`protocol::TestResult.mtu_probe` is now `Option<Box<probe::MtuProbeReport>>`** — boxed to keep `ControlMessage` small; wrap assignments in `Box::new`. JSON is unchanged.
- **`net::create_udp_socket*` no longer set `SO_REUSEADDR` on a port-0 bind** — `create_udp_socket` and `create_udp_socket_bound` set it only for an explicit port, and `create_udp_socket_for_remote`, which always binds port 0, no longer sets it.
- Additive: `tui::ui::help_scroll` (help-overlay paging for a key press), `tui::ui::draw_help_overlay` (now public, with `scroll` and `server` parameters), `update::check_lock_reason`, `impl Display for tui::app::AppState`, `persistence::check_destination` (validates an `-o` destination without creating or truncating anything), `serve::Server::run_until` (stops on a caller's shutdown future and closes QUIC connections on the way out), and `protocol::TestResult::count_zero_byte_streams` / `describe_zero_byte_streams`.

## [0.11.0] - 2026-10-13

### Security
- **Updated `rustls` to 0.23.45** — closes [RUSTSEC-2026-0285](https://rustsec.org/advisories/RUSTSEC-2026-0285) / GHSA-2mjx-qc3c-rqvc. rustls 0.23.13 through 0.23.44 accepted TLS 1.3 handshake messages sent at the wrong encryption level when they followed a key-changing message in the same record — for example a plaintext `EncryptedExtensions` packed behind the `ServerHello` — instead of terminating the connection as RFC 8446 section 5.1 requires. The handshake transcript remains authenticated, so a network-position attacker cannot alter or complete a handshake; the effect is that a peer could send handshake messages in plaintext that should have been encrypted without the connection being rejected. rustls backs xfr's QUIC transport and its HTTPS clients (update check, Prometheus push gateway). Lockfile-only; QUIC interoperates with 0.10.0 peers in both directions, with and without a PSK.

### Added
- **Bidirectional UDP receiver statistics for both directions** — `-u --bidir` now keeps and reports download loss/jitter from the client receiver alongside upload measurements from the server receiver. Download quality updates continue on a local clock when server reports stall. Final JSON exposes `udp_stats_send` / `udp_stats_recv`, streaming JSON exposes `udp_send` / `udp_recv`, and plain output, CSV, and the TUI show both directions. CSV appends eight directional columns to every interval and summary row (empty outside `-u --bidir`); existing column positions are unchanged, but parsers that check the column count need updating. Bidirectional stream intervals and results also carry separate byte/rate fields; the client corrects each UDP download stream from local receive counters by stream ID. Optional fields preserve wire compatibility, and older servers' missing upload splits remain unknown (#91 follow-up).
- **The TUI reports test status to the terminal (OSC 7501)** — terminals that implement the [Program Status Protocol](https://www.superlogical.com/rex/docs/build/program-status), such as Rex and Ghostty, can now show what xfr is doing in tab headers and session pickers without you watching the tab: connecting, running with a progress percentage and the current rate (`TCP ↓ 941.0 Mbps`), paused, finished with a one-line summary, or the error that stopped it. A finished or failed result stays visible after you quit; a cancelled or paused test clears its status on exit. `xfr serve --tui` reports how many tests are active. Terminals without support ignore the sequence, and plain, JSON and CSV output never emit it, so piped output is unchanged.
- **Set the UDP datagram size (`-l`/`--length`)** — UDP payloads were fixed at 1400 bytes, which fragments every datagram on a path whose MTU is below 1428 bytes (1448 over IPv6) — WireGuard's 1420 default among them. Fragmented runs lost far more than the link explained and sometimes reported 0.0 Mbit/s delivered (#213). `xfr <host> -u -l 1368` now sends 1368-byte datagrams, which fit a 1420 MTU over either address family. The size counts xfr's 16-byte sequence/timestamp header, accepts 16–65507 bytes, and applies to every stream in upload, `-R` and `--bidir`, paced or unlimited. Receive buffers now hold any size in that range, including late jumbo datagrams that reach the server's shared UDP port after a stream closes. It needs a server advertising the new `udp_payload_size_v1` capability: against an older server the client refuses to start rather than letting the server send 1400-byte datagrams the user asked to avoid. Without `-l` nothing changes on the wire, and old and new peers interoperate as before. `--probe-mtu` finds the largest size that survives each direction; the default stays 1400 and is not chosen automatically.

### Changed
- **A measured 0.0 ms UDP jitter is now reported as a reading, not as missing** — per-stream intervals can now carry `jitter_ms: 0.0` where the field used to be absent, and the live aggregate jitter now averages in those streams instead of skipping them, so live jitter for plain `-u` runs can read slightly lower than before. Streams that have not received any packets are still left out.
- **JSON `udp_stats.packet_size` reports what the receiver actually saw** — it was hard-coded to 1400. It is now the largest xfr datagram received, so it reflects `-l`, and it is omitted when no data arrived instead of claiming a size for packets that never came. Multi-stream results take the largest across streams.
- **Dependency refresh** — `dirs` 6 → 7, `toml` 1.1.7, `uuid` 1.26.1, `tokio` 1.53.2, `clap` 4.6.7 / `clap_complete` 4.6.11, `hyper` 1.12.0 / `hyper-util` 0.1.21, `quinn` 0.11.12 / `quinn-proto` 0.11.19, `rand` 0.10.3, `libc` 0.2.190, and `mdns-sd` 0.21.5 (bug fixes only: monotonic timers, and record TTLs that stay correct across system sleep). The `dirs` major bump changes one thing: on Windows, `preference_dir()` now resolves to the roaming rather than the local AppData folder. xfr locates `config.toml` and `prefs.toml` through `config_dir()`, which is unchanged, so no configuration or saved preference moves on any platform.

### Maintenance
- **CI action pins** — `crate-ci/typos` 1.50.1 → 1.50.2 and `taiki-e/install-action` 2.87.4 → 2.87.14.
- **Network-namespace regression for #213** — the MTU-probe CI job, renamed *UDP MTU + link-local regressions*, now also runs `test-udp-payload-ns.sh`: on a 1420-byte-MTU veth pair shaped to 50 Mbit/s, the 1400-byte default must produce IP fragments and `-l 1368` must produce none while delivering traffic, over IPv4 and IPv6 in all three directions.
- **Network-namespace regression for link-local hosts** — `test-link-local-ns.sh` runs TCP, UDP (upload, `-R`, `--bidir`) and QUIC against `fe80::2%v0` and `fe80::2%<ifindex>` on a veth pair, plus client `--bind` with a zone and the unknown-interface error. It runs in the netns CI job alongside the MTU checks.
- **Network-namespace regression for UDP reordering** — `test-udp-reorder-ns.sh` adds netem jitter (`delay 10ms 3ms`) to UDP only on a veth pair, so datagrams arrive out of order but none are dropped, and requires `-R` and both `--bidir` directions to see more than 100 out-of-order packets and report under 0.5% loss. It runs in the same netns CI job.
- **Rust 1.99 lint** — `AtomicU64::fetch_update` is deprecated in favour of `try_update`, which needs Rust 1.95. The remaining call site allows the lint to keep the 1.88 MSRV.

### Fixed
- **UDP reordering no longer creates permanent packet loss** — receiving sequences `0, 2, 1` previously reported 25% loss even though every packet arrived, and duplicate datagrams diluted real loss. A fixed 8 KiB bitmap per receiver now deduplicates the latest 65,536 sequence numbers and repairs gaps when late packets arrive within that window. Live feedback, interval snapshots, final results, and the TUI agree on the corrected counts; delayed reports cannot restore a repaired gap. Wire byte counts still include duplicate datagrams. No protocol fields, dependencies, or MSRV changes.
- **One stray UDP datagram could freeze loss accounting for the rest of a test** — a datagram carrying a far-future sequence number (corrupt, misdirected, or spoofed onto a server's per-stream UDP port) became the receiver's high-water mark, so every real packet after it was discarded as too old: received stopped counting and loss read near 100% until the test ended. A forward jump of more than 65,536 sequences is now held until a second packet lands near it, so a lone stray is ignored, while a real outage still counts in full once traffic resumes.
- **UDP send errors are reported instead of only logged** — in `-u -R` and the server half of `--bidir`, a server whose datagrams failed to send (for example `Connection refused` once the client's port went away, or a firewall rejecting the traffic) only logged a warning on its own console; the client saw lower or zero throughput with no explanation. The final result now carries the number of failed sends and the last error message, and the client prints `Warning: Server reported N UDP send errors (last: ...)` in the summary, adds it to the TUI history, and includes `server_udp_send_errors` in `--json`. The client's own failed sends in upload and `--bidir` are counted the same way (`client_udp_send_errors`). Failures in the last 250 ms before the deadline are expected teardown and still not counted. The sender also stops logging a warning per failed datagram: each stream warns on its first failure and, if more followed, once more with the total when it stops sending. The same goes for a single-port UDP test whose server cannot create or ack its per-stream socket toward the client (for example a firewall rejecting UDP before the test starts): the server warns once per stream instead of on every retried hello, and the client's handshake-timeout error now ends with the server's report, e.g. `Server reported 30 UDP send errors (last: failed to create UDP socket to 10.9.0.2:40435: Permission denied (os error 13))`. The field is optional: older clients ignore it and older servers simply never send it, so no capability is needed. CSV columns are unchanged.
- **IPv6 link-local hosts work (`xfr fe80::2%eth0`)** — the zone after `%` was parsed and then thrown away, so every connection to a link-local address failed with `Invalid argument (os error 22)` and a QUIC test hung until it timed out. Link-local addresses are the natural way to test two machines joined by a cable with no IP configuration. The zone — an interface name such as `eth0`, or its numeric index — now reaches every socket the test opens: the control connection, TCP and UDP data streams (single-port and legacy per-stream), `--probe-mtu` and the QUIC endpoint, in upload, `-R` and `--bidir`. The bracketed form `[fe80::2%eth0]` is accepted, client `--bind fe80::1%eth0` works alone or with `--cport`, an unknown interface is rejected with an error naming it, and `xfr discover` prints link-local servers with their zone so the address can be pasted back in. Interface names need a Unix host; elsewhere use the numeric index.
- **A stalled control reader could hold a server test open indefinitely** — report writes blocked sampling, Pause/Resume/Cancel, and duration limits on TCP and QUIC. The server now resumes partial frames independently of sampling and coalesces pending interval deltas with their real sampling durations. Data stops promptly at cancellation or completion; terminal output has a bounded flush deadline. Variable report windows also retain correct per-stream TUI rates.
- **UDP tests to a server's secondary address no longer time out** — on a server with more than one address on an interface (a secondary IPv4 or VIP, IPv6 static plus SLAAC or privacy addresses, a manual `fe80::` next to the automatic one), a client that targeted an address other than the one the kernel prefers as source never got its single-port UDP hello acked: the server's per-stream socket was bound to the wildcard address, so acks and data left from the preferred address, and the client's connected UDP socket dropped them. `-u`, `-R`, `--bidir` and `-P` all failed with `single-port UDP handshake timed out`. Legacy per-stream UDP (older clients) had the same fault in `-R` and `--bidir`, where the client received nothing. The server now binds its UDP data sockets to the address the client's control connection reached, keeping the IPv6 scope for link-local; `xfr serve --bind` behaves as before, and TCP and QUIC were never affected. `test-udp-source-addr-ns.sh` covers it over IPv4 and IPv6 in the netns CI job, and `test-link-local-ns.sh` no longer suppresses the kernel's automatic link-local address, which had hidden it.
- **A single malformed mDNS packet could silently disable discovery** — mdns-sd 0.21.1 indexed past the end of a packet when parsing an HINFO record whose character-string length byte was missing. Any host on the local network could send one 23-byte multicast packet and panic the mDNS daemon thread inside `xfr serve`: the server kept running and tests kept working, but it stopped answering mDNS queries until restarted, so `xfr discover` found nothing, and nothing after the one-time panic message indicated why. Fixed in mdns-sd 0.21.3 (the lockfile now carries 0.21.5, see Changed), which skips the truncated record instead. The same packet now leaves discovery intact.
- **`--json` output could not be piped to a JSON parser** — `xfr <host> --json --no-tui | jq` failed because plain-text interval rows were printed ahead of the summary, and `--json-stream` ended with a multi-line summary. `--json` now prints only the summary document, and the `--json-stream` summary is a single line. An explicit `--json-stream` or `--csv` now also takes precedence over `json_output = true` in the config file.
- **`--interval inf` panicked the client** — non-finite, zero, negative or enormous report intervals were accepted and then crashed the interval printer or silently stopped reporting. `--interval` and `[client] interval_secs` must now be a positive, finite number of seconds and are rejected with a clear error before the test starts; a valid `--interval` still overrides a bad config value.
- **`xfr diff --threshold NaN` hid regressions** — a NaN or infinite threshold made every comparison false, so a 99% throughput drop reported `Verdict: OK` and exited 0; a negative threshold produced misleading verdicts. `--threshold` must now be a finite, non-negative percentage (0 still flags any regression), and invalid values exit with status 2 before any verdict is printed.
- **Lossy intervals vanished from the throughput graph when throughput was zero or too low to draw** — with no bar glyph there was nothing to carry the loss underline, so a column that lost packets looked identical to a clean one (only monochrome heavy loss, which stipples the column, stayed visible). The underline now stays at the graph's baseline without drawing a bar that would invent throughput.
- **Quitting a QUIC test on a stalled link could wait for the QUIC idle timeout** — the client wrote Cancel with no deadline and only then stopped its own data streams, so a control stream with no send room (a dead link, or upload data filling the connection's send buffer) held the quit. Local streams now stop first and the Cancel write shares the three-second result deadline TCP and UDP already used.
- **`xfr serve --rate-limit-window` mishandled sub-second values, and the config setting was ignored** — `--rate-limit-window 500ms` truncated to zero and panicked the rate limiter's cleanup task, other fractional windows were silently shortened, and `[server] rate_limit_window` in the config file never took effect. The window must now be a whole number of seconds (at least 1; `1000ms`, `60s` and `5min` still work), and resolves from the CLI, then the config file, then the 60-second default.
- **A QUIC download could hang the server's test teardown** — a client that never granted stream credit left the server's download handler waiting on the stream open forever, so a Cancel was acknowledged but no Result followed and the test stayed registered. Opening the download stream now gives way to cancellation and the 30-second handshake timeout, as uploads and bidirectional tests already did.
- **The TUI history ignored `--timestamp-format`** — it always logged relative `HH:MM:SS`, and the settings modal showed `relative` and changed nothing. History now starts in the selected format, and changing Timestamp in the settings modal reformats existing and new entries immediately.
- **`xfr serve --port 5201` was ignored when the config file set a port** — the default port number doubled as the "not specified" marker, so an explicit `--port 5201` or `XFR_PORT=5201` fell through to `[server] port` and bound the config port instead. The server port now resolves from `--port`, then `XFR_PORT`, then the config file, then 5201.
- **Cancelling a legacy UDP reverse or bidirectional test before data flowed delayed the summary** — on the legacy per-stream UDP path (older clients, or a server whose single-port self-test failed), the server waits for the client's first datagram to learn its address, and that wait ignored Cancel. If the datagram never arrived, the summary came up to 10 seconds late, after the client had already given up waiting. Cancel now ends the wait immediately.
- **Changing protocol or streams in the TUI settings carried stale transport options into the next run** — `--mptcp` and zero-copy stayed on for UDP and QUIC, and `--cport` kept its old single-port or sequential assignment. Each run now applies only the options its protocol supports and recomputes port assignment; switching back restores them.
- **Switching a UDP or QUIC session to TCP in the TUI left zero-copy off** — zero-copy was resolved once against the startup protocol, so a session started with `-u` or `-Q` and switched to TCP in the settings modal ran with regular writes instead of the TCP default. The TCP run now uses zero-copy unless `--no-zerocopy` was passed.
- **`-4` and `-6` together, or an unknown `address_family` in `config.toml`, no longer pick a family silently** — `-4 -6` used to mean IPv4 and a typo such as `address_family = "ip4"` fell back to dual-stack, which on `xfr serve` widens the listener to both families. Contradictory flags are now a usage error and an unrecognised config value fails with the key and the accepted values (`ipv4`, `ipv6`, `dual`, plus the existing aliases); an explicit `-4`/`-6` or `serve --bind` still overrides the config.
- **The TUI settings modal lost its controls in short terminals** — below about 15 rows the tabs and Apply/Close buttons were squeezed out while the keys still moved focus onto them, lower settings could be changed off-screen, and a long value such as `tokyo_night` was clipped. The modal now keeps tabs and actions on screen, scrolls the selected setting into view, and drops the `◀ ▶` arrows before clipping a value.
- **Cancelling a test could hang when progress updates were not being read** — the client delivered each interval update with a blocking send outside its cancel branch, so once a stalled consumer filled the progress queue, `Client::cancel` was never acted on. Interval delivery now gives way to a cancel request, UDP feedback updates no longer block, and a `Client::run` future that is dropped (a timeout or `select!` around it) now stops its data streams instead of leaving them running. `Client::cancel` returns an error once no run is left to receive it.
- **`-P 1` now overrides `parallel_streams` in `config.toml`** — an explicit `-P 1` was indistinguishable from the default, so `parallel_streams = 8` still ran eight streams. Effective client defaults are also validated up front: `parallel_streams` outside 1–128 and a malformed `window_size` such as `"1MiB"` (previously ignored in favour of kernel buffer sizes) now fail with the config key, and durations above 4,294,967,295 seconds are rejected instead of wrapping to the protocol's infinite-duration `0`.
- **`--theme default` was ignored, and `NO_COLOR` made monochrome stick** — an explicit `--theme default` was treated as no choice, so it could not override a config or saved theme, and the client TUI saved whatever palette it ended on, so one run under `NO_COLOR` wrote `theme = "monochrome"` to `prefs.toml` for every later run. Only palettes changed in the TUI are saved now. `--theme` is also accepted after `serve --tui`, and aliases such as `mono` select the right entry in Settings.
- **An idle QUIC peer could hold a server handler slot indefinitely** — after the TLS handshake the server waited without a deadline for the client to open its control stream, and QUIC keepalives kept such a connection open, so a peer that connected and sent nothing tied up one of the concurrent-handler slots for as long as it stayed connected. The wait is now bounded by the 30-second handshake timeout.

### Library API (pre-1.0 break)
- Struct-literal constructors must supply new public fields (the `protocol` ones are serde-optional, so the wire format stays compatible): `client::ClientConfig.udp_payload_size` and `protocol::ControlMessage::TestStart.udp_payload_size` (exhaustive `TestStart` patterns too); `protocol::TestResult.{udp_stats_send, udp_stats_recv, server_udp_send_errors, client_udp_send_errors}`; `protocol::StreamResult` and `protocol::StreamInterval` `.{bytes_sent, bytes_received, throughput_send_mbps, throughput_recv_mbps}`; `client::TestProgress.{udp_send, udp_recv}`; `discover::DiscoveredServer.zone`; and `throughput_send_mbps` / `throughput_recv_mbps` on `tui::app::StreamData` and `tui::widgets::StreamBar`.
- `tui::app::LogEntry` gained private fields and can no longer be built with a struct literal.
- `udp::send_udp_paced` takes a `packet_size: usize` parameter after `target_bitrate` (10 parameters, was 9) and rejects sizes outside 16–65507 bytes.
- `client::UdpProgressFilter` is no longer `RefUnwindSafe`: it now keeps its latest snapshot behind a `Mutex`.
- **Removed the unused `xfr::tui::widgets::ProgressBar`** — a public library item, but nothing in xfr drew with it: the TUI's transfer bar is rendered by `tui::ui` with eighth-block glyphs, and this widget's `━`/`─` line had drifted from it. Library users who imported it should copy the ~40 lines from 0.10.1 or use ratatui's `Gauge`/`LineGauge`.
- **`StreamStats` UDP counters are only reachable through `set_udp_progress`/`udp_progress_snapshot`** — the public `udp_lost` and `udp_packets_received` atomics and the unused `add_udp_lost`/`add_udp_received` helpers are gone, so nothing can update half of the received/lost pair outside the per-stream lock.

## [0.10.1] - 2026-09-04

### Security
- **Updated `quinn-proto` to 0.11.17** — 0.10.0 shipped 0.11.16, which closed [RUSTSEC-2026-0185](https://rustsec.org/advisories/RUSTSEC-2026-0185) / GHSA-4w2j-m93h-cj5j. 0.11.17 closes three further remote memory-exhaustion issues that `cargo audit` does not yet list: [GHSA-qfwj-vfxf-92j2](https://github.com/quinn-rs/quinn/security/advisories/GHSA-qfwj-vfxf-92j2) (the 0.11.15 stream-reassembly guard can be bypassed), [GHSA-2hv7-gw8g-gpq5](https://github.com/quinn-rs/quinn/security/advisories/GHSA-2hv7-gw8g-gpq5) (zero-length DATAGRAM frames bypass `datagram_receive_buffer_size`), and [GHSA-hmxj-32vh-65vr](https://github.com/quinn-rs/quinn/security/advisories/GHSA-hmxj-32vh-65vr) (unbounded `retire_cids` growth from already-retired NEW_CONNECTION_ID frames). Public QUIC servers (`xfr serve`) are in the blast radius. Lockfile-only; no source or API changes.

### Changed
- **The TUI title bar no longer pitches the project** — the header read `[ xfr - Modern Rust TUI for Network Testing ]`, a README subtitle in the viewport of an operator running a benchmark. It now reads `[ xfr vX.Y.Z ]`, which answers the question a title bar is actually asked.
- **The transfer progress bar is drawn with block glyphs instead of ASCII** — a `[=====>------]` arrow bar sat directly beneath a sparkline rendered in Unicode blocks, two decades of terminal aesthetics in adjacent rows. The bar now fills with `█` against a `░` track and carries a partial-block tip (`▏`–`▉`), so it advances an eighth of a cell at a time rather than jumping a whole character. Fill and track differ in texture, not only hue, so progress stays legible on the hue-free themes and under `NO_COLOR`.
- **The throughput graph and the transfer bar no longer touch** — the sparkline band ran straight into the `Transfer:` line while a blank row sat unused against the panel's bottom border, so the layout was spending 7 of its 8 inner rows. That row now separates the graph from the bar, at no cost in height. The gap is conditional: on a terminal too short for the full panel a row spent on whitespace is a row taken from the data, so below full height it collapses to zero and the panel fills in priority order — transfer bar, gap, current speed, average speed, then the graph.
- **Plain streaming output holds its columns still** — `mbps_to_human` and `bytes_to_human` return variable-width strings, so an interval line re-flowed every second as the transfer crossed `KB`→`MB`→`GB` or `Mbps`→`Gbps` and the numbers slid sideways under the eye. Every column that has another column after it is now right-aligned to a fixed width.
- **Dependency refresh** — all semver-compatible updates taken, including `mdns-sd` 0.21.0 → 0.21.1 (goodbye packets after conflict rename; skip only a malformed name instead of the whole packet), `hyper` 1.11.1, `toml` 1.1.5, `rcgen` 0.14.10, and `rustls-webpki` 0.103.15. No `Cargo.toml` constraint changes.

### Maintenance
- **CI action pins** — `crate-ci/typos` 1.50.0 → 1.50.1 and `taiki-e/install-action` 2.87.0 → 2.87.4. `cargo-deny` stays pinned at 0.19.8.

### Fixed
- **The TUI footer dropped its status on an 80-column terminal** — the key hints and `Status:` were laid out as one line running about 107 columns, so on the 80-column default (macOS Terminal, tmux splits, the Linux console) ratatui clipped the right edge and the casualty was Status: the only field down there that changes, and the one that says `Waiting for server (3s)...` when a run is hanging. Status is now anchored in its own right-hand chunk and the hints absorb the loss instead, switching to a compact `q:Quit p:Pause` form when the full labels don't fit and dropping whole hints rather than clipping one mid-word.
- **The server dashboard ignored the theme engine** — `xfr serve --tui` hardcoded `Color::White`/`Cyan`/`Green`/`Red`, so it rendered white-on-nothing (unreadable on a light terminal background) and was deaf to `--theme` and to the `NO_COLOR`-derived monochrome default that the client TUI has honoured since v0.9.24. It now resolves its palette through the same precedence the client uses — `--theme` > saved pref > `NO_COLOR` — so both halves of the tool share one set of colours.
- **Heavy-loss sparkline columns rendered upside-down in hue-free themes** — the monochrome heavy-loss marker applied reverse video to the whole column. Reverse video swaps ink and background *within a cell*, so a full block painted in the background colour and vanished while the empty cells above it painted solid: the visible shape was the bar's complement, and a marked column read as a bar of inverted height (10% looked nearly full, 90% nearly empty) while its unmarked neighbours in the same row still read normally. Under sustained loss every column is marked, so the graph became a solid slab floating at the top with the data invisible — the same "fragments at the top" symptom reported against v0.9.24 that the pillar was meant to cure. The bar is now drawn normally and the empty cells above it are stippled, so the column is still unmistakably marked but its height stays true.
- **mDNS registration no longer silently fails on a 64-byte Linux hostname** — DNS labels are capped at 63 bytes, but Linux `HOST_NAME_MAX` is 64. xfr passed the nodename through to mdns-sd unchanged, which then skipped the oversize records at encode time while still returning success, so `xfr serve` logged a registration that `xfr discover` could not see. Oversized names are now truncated at a UTF-8 boundary with a short stable suffix so two long hostnames that share a prefix stay distinct. (#194)
- **QUIC rate-limiter slot leak on handler semaphore saturation** — the QUIC acceptor now acquires the handler permit before checking rate limits, preventing connections rejected by concurrency limits from leaking per-IP quota.
- **TUI "Transferred" showed only the most recent interval, not the test total** — `on_progress` overwrote the running total with each interval's byte delta instead of accumulating it, so the figure was wrong for *every* TUI test, and `-n` progress bars (which divide it by the byte budget) barely moved. Deltas now accumulate, and `on_result` pins the server-authoritative total plus the real elapsed time on completion, which also fixes the `0s` duration previously shown for `-n` tests.
- **Multi-instance mDNS discovery** — servers on the same host with distinct ports are no longer deduplicated away, and discovery polling is non-blocking.
- **Constant-time comparison in protected control channel** — padded comparison avoids early return on length mismatch.
- **ACL rule matching for IPv4-mapped IPv6** — `matched_rule` now normalizes addresses before checking network rules.
- **Zerocopy sendfile EINTR retry** — interrupted syscalls in `sendfile_once` are retried rather than failing the transfer.
- **TUI terminal restoration guard** — RAII guard restores normal terminal mode and leaves the alternate screen on panic or error unwinding. The guard is armed before entering the alternate screen, so a failure on that step also restores cooked mode.
- **The throughput graph was flattened by a bogus opening sample** — `tokio::time::interval` fires its first tick immediately, so the server recorded a stats interval roughly 1ms into the test. Dividing the bytes sent so far by that sliver produced rates around 1500 Mbps on a 200 Mbps run, and that outlier set the sparkline's Y-scale, rendering every real sample as a one-eighth stub for the whole test. It also led `--json-stream` output. The first tick is now one full period out, matching the client's UDP metronome. Note that a `-t 1sec` test consequently emits no interval rows at all in `--json-stream`/`--csv`, where it previously emitted the one bogus row; an *N*-second test still reports *N-1* interval rows, as before. (LAN-1496)
- **TUI "Average Speed" was a mean of interval rates** — averaging per-interval rates weights a 1ms opening sample the same as a full second, so a steady 200 Mbps test displayed roughly 355 Mbps and the completion log agreed with it. The average is now byte-weighted (total bytes over elapsed) and is pinned to the server-authoritative figure on completion, so the panel, the log line, and the JSON/CSV output agree. One visible consequence: in `-u -R`, the live figure tracks the client's *received* rate while the pinned final figure is the server's *sent* rate, so on a lossy download the average now steps up at completion instead of disagreeing with the summary. (LAN-1496)
- **The throughput sparkline could paint over a panel border, or panic** — it was rendered into a hand-built rect with a hardcoded height of 3 rows instead of the chunk the layout allotted. On terminals under about 16 rows the bars spilled onto the Real-time Stats bottom border, and on a sufficiently small window the write went outside the frame buffer and panicked. It now renders into its allotted chunk and degrades cleanly; regression tests render the full UI from 1×1 up.
- **The TUI claimed it had connected before it had** — "Connected to server." was logged when the run task was spawned, before any socket existed, so a refused port printed it directly above the connection error. Spawning now logs "Connecting to server...", and the connected line is emitted when the peer's version arrives, which is the first proof anything answered.
- **QUIC transport now honours `-b/--bitrate` pacing** — QUIC previously ran unthrottled at line rate because bitrate was dropped on that path. Both client upload and server download streams now pace data transmission to the requested bandwidth using byte-budget scheduling, and buffer sizes are capped to avoid initial write bursts. (LAN-1497)

## [0.10.0] - 2026-08-31

### Security
- **QUIC PSK authentication is now bound to the exact TLS connection** — previously the PSK challenge, server proof, and protected-control keys did not include QUIC channel-binding material, so an active terminating relay could forward the application handshake across two TLS connections and access the bulk payload. QUIC + PSK now mixes the RFC 9266 `EXPORTER-Channel-Binding` value into its per-connection PSK before authentication or control-key derivation, preventing that splice without knowledge of the PSK. The protection is mandatory: client and server fail closed unless both advertise `quic_channel_binding_v1`, so mixed old/new QUIC + PSK deployments must upgrade both sides together. QUIC without PSK remains encrypted with an unverified self-signed server certificate.
- **Config-file PSKs now require owner-only permissions on Unix** — `--psk-file` already rejected group/other access, but embedding the same key under `[client]` or `[server]` accepted a typical `0644` config readable by every local user. Secret-bearing configs now fail with their path and mode unless they are private (for example, `chmod 600`); ordinary configs without a PSK keep working with normal permissions.
- **PSK files are now permission-checked and read through the same open handle** — `--psk-file` previously called `metadata(path)` and then reopened the path with `read_to_string`, so a concurrent path or symlink swap could make xfr validate one inode and consume key bytes from another. The file is now opened once, its handle metadata is checked, and that same handle supplies the key; I/O errors also include the affected path.
- **Library clients and servers now validate PSKs at their execution boundaries** — the CLI rejected empty and oversized keys, but callers constructing the exported `ClientConfig` or `ServerConfig` types could bypass that check. In particular, `Some("")` enabled authentication with a publicly computable HMAC and control-channel key. `Client::run` now validates before DNS or connect, and `Server::run` validates before bind; the config types also expose explicit preflight validation.
- **Rate-limit cleanup can no longer unlink an admission in progress** — the limiter previously cloned an `Arc` to a zero-count per-IP state and dropped the map guard before incrementing it. Concurrent cleanup could remove that state, letting another request create a replacement and exceed `max_per_ip`; releasing the orphaned admission then decremented the replacement. Admission, release, and cleanup now mutate the same DashMap-guarded value, with a synchronized concurrency regression test.

### Changed
- **The TUI no longer rebuilds an unchanged frame twenty times a second** — the client loop drew on every 50 ms tick, and although ratatui only writes cells that differ, every `format!`, `Line` and `Span` in the frame was rebuilt regardless, so a finished, paused or errored test sat at ~0.6% of a core doing nothing visible. The loop now hashes everything the renderer reads (state, stats, sparkline and log history, overlays, settings, theme, terminal size, and the wall-clock values at the resolution they are shown: whole-second elapsed, cell-quantized progress bar, whole-second cancel countdown) and skips the draw when the hash matches the last frame drawn. Idle-screen CPU drops to near zero; a running test redraws only when a visible value changes. The fingerprint destructures `App` exhaustively, so a new field must be classified before the code compiles, and the terminal size is part of it so a resize while idle still re-flows the layout. (LAN-1226)
- **The server dashboard now skips unchanged frames too** — it previously rebuilt the full header and active-test table before every 100 ms input poll even though its clocks render only whole seconds. An exhaustive render fingerprint now reduces an idle dashboard from ten frame builds per second to one, while test events, help toggles, and terminal resizes still redraw immediately.
- **High-rate UDP pacing now uses small calculated batches instead of a timer-wakeup cliff** — the old sender scheduled one wake per datagram up to 100,000 packets/sec, then abruptly switched to 100-packet bursts. With 1400-byte packets the default 1 Gbps target sat just below that breakpoint and requested roughly 89,000 Tokio timer wakes/sec, under-running badly, while a higher 1.2 Gbps request crossed the batching threshold and reached line rate. Pacing now caps timer wakeups at 10,000/sec and derives the smallest batch needed for each bitrate, preserving low-rate smoothness without the high-rate inversion.
- **The UDP receive hot path no longer creates and cancels a Tokio timer for every datagram** — its 100 ms polling sleep was reconstructed on every loop iteration, producing one timer-wheel registration per packet at high rates even though the timer existed only to notice cancel, pause, and 30-second inactivity. Cancel and pause are now direct `select!` inputs, while a single persistent inactivity timer re-arms only when it wakes. This removes timer churn from the data path and makes control changes immediate instead of up to 100 ms late.

### Fixed
- **QUIC now honors the advertised 128-stream CLI maximum** — upload and download data use unidirectional streams, but both endpoints raised only Quinn's bidirectional limit and left its unidirectional credit at the default 100. A `-Q -P 128` run therefore started exactly 100 active streams and left 28 blocked. Client and server now advertise all 128 unidirectional data streams, with a loopback regression opening the full set in both directions.
- **Linux congestion windows are now reported in bytes, matching every output label and macOS** — Linux `TCP_INFO.tcpi_snd_cwnd` is a count of MSS-sized segments, but xfr passed the raw segment count into fields rendered as bytes, so a normal ten-segment window displayed as `0 KB`. The Linux collector now multiplies by `tcpi_snd_mss`; multi-stream aggregates saturate at the protocol field limit instead of overflowing when many large windows are summed.
- **Existing config files now fail closed when they cannot be read or parsed** — startup previously used `unwrap_or_default()`, silently discarding the whole file on any error. A malformed file could therefore drop a server PSK, ACL, or rate limit while still launching with permissive defaults. Missing files still use defaults; present but unusable files now stop startup with the config path and underlying error.
- **Reordered UDP feedback can no longer roll live loss statistics backward** — each upload stream now rejects a feedback packet whose embedded stream ID does not match its connected socket or whose cumulative sequence denominator predates the snapshot already stored. Previously a delayed datagram could overwrite a newer per-stream slot; aggregate-level filtering could miss that regression when another stream advanced at the same time.

## [0.9.25] - 2026-07-31

### Fixed
- **Heavy-loss columns no longer render as red fragments floating at the top of the sparkline** — v0.9.24's hue-free severity marking applied reverse video in every theme, but reverse video swaps foreground and background *within each cell*, and a partial bar glyph only covers the cell's bottom — so the swap painted the empty top fraction and hid the bar (reported by brettowe within a day). Color themes now carry heavy loss as a red bar plus an underline (the artifact-free modifier), and the reverse-video treatment is reserved for the monochrome theme — where the widget now fills the whole column so heavy loss renders as one solid full-height pillar with the throughput bar as a negative silhouette inside it, instead of fragments at whatever height each bar's top cell sat. (#93 follow-up, #158)

## [0.9.24] - 2026-07-30

### Fixed
- **Quitting on an effectively-dead link no longer discards your stats** — on a zombie connection (e.g. WiFi that is associated but passing nothing), pressing `q`/Ctrl+C in the TUI waits up to 5 seconds for the server's final summary with a visible `Waiting for server (Ns)...` countdown, then exits with a partial summary built from locally accumulated counters and a warning — previously it printed "Test cancelled." and dropped everything. One genuinely unbounded hang is also closed: the control-channel Cancel write ran before its timeout was armed, so a full send buffer could stall quit until the test-duration deadline. Partial summaries are never written to `--output` files. (#159)

### Changed
- **The monochrome theme is now actually usable in sunlight** — it was built from hardcoded RGB grays whose mid-tone distinctions are exactly what glare washes out, and its fixed white text was invisible on light terminal backgrounds (the setup that works best outdoors, since dark screens mirror). It now renders in the terminal's own default colors at maximum contrast with just three levels, adapting to dark and light backgrounds alike. Loss severity in the throughput sparkline is additionally encoded without color in every theme: light loss underlines the bar, heavy loss reverses the cell into a bright pillar — so lossy intervals survive glare, monochrome, `NO_COLOR`, and colorblindness. Setting the standard `NO_COLOR` environment variable now selects the monochrome theme by default (an explicit `--theme`, config value, or saved preference still wins, and the env-induced choice is never persisted). (#158)

## [0.9.23] - 2026-07-29

### Added
- **Test by transfer size, not time (`-n`/`--bytes`)** — `xfr <host> -n 1G` sends exactly 1 GiB and stops, instead of running for a fixed number of seconds. Runs are then comparable across links of different speeds, which is what CI and benchmarking usually want; a timed test moves a different amount of data on every link. Binary suffixes (`K`/`M`/`G` = KiB/MiB/GiB), and the count is the total across all streams rather than per stream — `-P 8 -n 1G` still transfers 1 GiB, with faster streams simply carrying more of it. Without an explicit `-t` there is no clock at all; with one, `-t` becomes an upper bound and the test reports however much it managed. Works for TCP, UDP and QUIC in all three directions, and needs a server advertising the new `byte_budget_v1` capability — against an older server the client refuses to start rather than quietly running a timed test instead. UDP transfers whole datagrams, so its final one may be short — and a budget below one packet header warns rather than silently transferring nothing. Under the TUI the progress bar tracks bytes against the requested size instead of showing an "infinite" bar.

### Changed
- **`--help` is now grouped into sections** — Test, Connection, Output, and Authentication options on the client help; `serve --help` adds Server Options and Access Control — instead of one flat list, mirroring iperf3's man-page structure. Help text only; no flag names, defaults, or behavior changed.
- **Control-channel crypto moved onto one RustCrypto generation** — `chacha20poly1305` 0.10 → 0.11 and `hkdf` 0.12 → 0.13, which lets the protected control channel share `sha2` 0.11 / `hmac` 0.13 with PSK authentication instead of pinning a second copy of the older `crypto-common` 0.1 stack alongside it. Two duplicate dependencies (the renamed `sha2_010` / `hmac_012`) are gone and the build no longer compiles two generations of the same crates. The wire format is unchanged: key derivation, AEAD framing, and the server proof are byte-for-byte identical, verified against fixed vectors captured from the previous release and by running PSK-protected tests in both directions between old and new binaries.

### Fixed
- **No more spurious send-error noise at the end of timed UDP/QUIC tests** — when the server tears down its sockets at its own deadline slightly before the client stops sending, the client logged `Connection refused (os error 111)` (UDP) or `sending stopped by peer: error 0` (QUIC, once per stream) on tests that succeeded. These are now logged at debug level when the test is cancelling or within 250 ms of its deadline, mirroring the existing TCP teardown-grace handling; a genuine mid-test failure still surfaces as a warning/error and a failed run.
- **Dropped an unused dependency** — `async-trait` was declared in `Cargo.toml` but never referenced in the source.
- **Scripted output now reports loss while upload saturation stalls interval reports** — `--json-stream` and plain interval rows print on control-channel `Interval` arrival, which is exactly what upload-mode UDP saturation clogs; the numbers went dark during loss episodes and then landed in a burst. When full reports stall for two report periods, the locally-clocked 2 Hz receiver feedback now surfaces directly: plain text prints a `(reports stalled)` line with cumulative loss, and `--json-stream` emits an explicitly marked `udp_feedback` event carrying cumulative packet counts — interval rows are unchanged, and CSV keeps its fixed columns. (#70 follow-up, the scripted half of #93)
- **UDP download (`-u -R`) display no longer stalls when saturation clogs the control channel** — in download mode the server's `Interval` messages ride the same server→client path as the UDP flood, so pacing the display off their arrival froze it exactly when the link got interesting: rows and sparkline bars stopped, then a backlog burst landed all at once. Since every displayed value in `-u -R` is already receiver-side truth (bytes and loss since #81, jitter since #143), progress now runs on a local 1 Hz clock built entirely from the client's own receive counters, and the server's Intervals are ignored — the display keeps its rhythm, with per-second loss and true degraded throughput, no matter what happens to the control channel. (#93)
- **Sparkline no longer jumps forward with green bars after a loss episode** — when upload saturation clogs the control channel, the queued `Interval` messages flush in a burst once the loss eases; each one appended its own bar (the graph "jumped" several columns) and, because their stale cumulative loss counts were filtered out, those bars rendered primary-colored right after heavy loss. Bar appends are now rate-limited to the report cadence, and the bar that does render takes its loss tint from the freshest feedback state — the same source the stall-synthesized bars already use. (#93)

## [0.9.22] - 2026-07-24

### Fixed
- **Live jitter now updates during UDP download (`-u -R`)** — the TUI's jitter readout averaged the per-stream jitter reported in the server's `Interval` messages, but in download mode the server is the sender and never measures jitter, so the display stayed frozen at 0.00 ms until the final summary (and forever with `-t 0`). Per-stream intervals now overlay the client's own receiver-side jitter, the same receiver-truth substitution already used for byte counts and packet loss. (#143)
- **`--locked` builds no longer warn about a yanked dependency** — bumped transitive `spin` 0.9.8 → 0.9.9 (0.9.8 was yanked on crates.io; pulled in via `mdns-sd` → `flume`). (#142)

### Added
- **Opt out of the update check** — the background "newer release available" check can now be turned off several ways: the `--no-update-check` flag, the `DO_NOT_TRACK` (cross-tool standard) or `XFR_NO_UPDATE_CHECK` environment variables, `no_update_check = true` under `[client]` in `config.toml`, or the new **Update check** toggle in the TUI settings (Display tab, persisted to `prefs.toml`). It can also be compiled out entirely with `--no-default-features` — the `update-check` cargo feature is on by default, so package builds can drop the phone-home code. (LAN-235)
- **Client transport defaults in `config.toml`** — `[client]` now supports `bitrate`, `congestion`, `dscp`, `interval_secs`, `bind`, and `cport`, closing the gap with their CLI counterparts. Values use the same forms as the flags (for example, `bitrate = "100M"` and `dscp = "EF"`), and an explicit CLI value takes precedence.

### Changed
- **Dependency refresh** — all semver-compatible updates taken (152 packages, including tokio 1.53, clap 4.6.4, rustls 0.23.42, socket2 0.6.5); cleared the crossbeam-epoch RUSTSEC-2026-0204 advisory (dev-dependency only, via criterion). The `chacha20poly1305`/`hkdf` major bumps are deliberately deferred to a dedicated control-crypto port. The published crate also no longer bundles the README demo recording.

## [0.9.21] - 2026-07-06

### Security
- **Preset allowlists are now enforced by `xfr serve --preset`** — selecting a server preset now applies its `allowed_clients` CIDRs as an additional allowlist, enforced at TCP and QUIC accept time before auth, handshake, or test allocation. The preset allowlist is combined with the normal ACL using AND semantics, so a client must pass both. Unknown preset names fail fast at startup. (LAN-158)
- **PSK handling is stricter and safer by default** — `constant_time_eq` no longer short-circuits on length mismatch or accepts trailing-zero variants, Unix `--psk-file` inputs with group/other permissions are rejected, and both client and server warn when inline `--psk`/`XFR_PSK` is used because those paths can leak through process listings, shell history, or environment inspection. (LAN-171)
- **PSK sessions now require AEAD-protected control channels (LAN-159)** — when PSK authentication is configured, the control channel is encrypted with ChaCha20-Poly1305 AEAD after the handshake. Separate c2s/s2c keys are derived from the PSK and both peers' nonces via HKDF-SHA256. The server sends a transcript proof (`server_proof`) in `AuthSuccess` binding the exact wire bytes of both Hello messages, so a MITM cannot strip the `protected_control_v1` capability to force a plaintext downgrade. PSK sessions fail closed if either peer lacks the capability — no silent fallback. Non-PSK sessions remain plaintext with full backward compatibility.

### Fixed
- **Dual-stack sockets now apply address-family policy consistently** — TCP listeners, UDP sockets, and QUIC endpoints share the same V6ONLY handling so dual-stack binds accept IPv4-mapped traffic where requested, while v6-only mode stays strict. DSCP marking on dual-stack IPv6 sockets still sets `IPV6_TCLASS` and now surfaces unexpected `IP_TOS` failures while tolerating the known unsupported case on BSD-derived platforms. (LAN-169)
- **Cancel, MPTCP validation, and the QUIC UDP tee no longer spin on closed or diverted channels** — cancel-watch sender drops are treated as terminal instead of repeatedly waking TCP/UDP/QUIC loops, MPTCP validation probes actual kernel socket support instead of trusting platform assumptions, and the single-port UDP lane tee yields with `Poll::Pending` after divert-only batches so Quinn is not hot-looped on `Ok(0)`. (LAN-170)
- **Client control reads no longer desynchronize on cancel or pause** — TCP and QUIC clients now use a dedicated control-reader task so the event loop can react to cancel and pause requests without cancelling a partially consumed control frame. This preserves AEAD/plaintext frame boundaries and keeps response timeouts intact. (LAN-229)
- **Pause time is excluded from test clocks** — sender deadlines, server interval/final elapsed time, and client response waits now account for real paused duration, including cancel-while-paused so the bounded post-cancel wait is not frozen by an active pause. (LAN-230)
- **Cancel and pause take effect immediately on the server** — the TCP and QUIC server test loops read control on a dedicated task and `select!` on it alongside the interval tick, so a client cancel/pause is acted on in well under a second instead of waiting up to the 1-second stats interval. (LAN-160)
- **UDP paced sender no longer bursts after resume** — the pacing ticker uses `MissedTickBehavior::Skip` and resets on resume, so ticks queued during a pause no longer fire all at once when the test resumes. (LAN-160)
- **Pause channel closure and QUIC task teardown** — a closed pause channel is treated as non-paused instead of busy-looping the send loops, and QUIC data tasks are awaited on teardown instead of being dropped unawaited. (LAN-161)
- **TCP send paths no longer replay bytes after short writes** — both the regular `try_write` path and zero-copy `sendfile(2)` path now maintain a caller-owned chunk offset, so partial sends resume from the byte after the short write instead of replaying the buffer prefix. Bidirectional send halves also record final retransmits from their TCP_INFO snapshot. (#113)
- **Server active-test state is cleaned up on abort, cancel, and early error** — TCP and QUIC test handlers now run their data-plane body inside a cleanup wrapper so `active_tests` entries are removed, data handlers receive cancel, the Prometheus active-test gauge is decremented, and the server TUI does not retain stale active rows when a test exits before normal completion. (#114)
- **Server final TCP_INFO now aggregates all TCP streams** — previously the server's final `TestResult.tcp_info` was built from the last snapshot stored in the legacy `TestStats.tcp_info` vector, which could reflect a single stream or a pre-test snapshot. The server now saves each data socket's final `TcpInfoSnapshot` on its per-stream `StreamStats` and uses `TestStats::final_local_tcp_info()` for the final result, matching the client path. (LAN-155)
- **TCP RTT averages no longer truncate fractional microseconds** — `TestStats::poll_local_tcp_info()` and `TestStats::final_local_tcp_info()` computed RTT averages with integer division, silently dropping fractional microseconds. They now use floating-point division with `.round()`, so e.g. averaging 100 µs and 101 µs reports 101 µs instead of 100 µs. (LAN-164)
- **Diff zero baselines now register as regressions** — when the baseline reported zero retransmits or zero RTT and the current run reported a nonzero value, `xfr --diff` returned a 0.0 % change and `Verdict: OK`, masking a real regression. The change percent is now `+inf%`, `is_regression` now considers retransmit and RTT increases against the configured threshold, and the plain-text summary flags the line as `[FAIL]`/`[WARN]`. (LAN-162)
- **Push Gateway timeout no longer silently dropped** — `PushGatewayClient::new()` built the `reqwest` client with `.build().unwrap_or_default()`, so if the builder ever failed (or was misconfigured) the code fell back to a default client and ignored the 30-second timeout. The constructor now returns `anyhow::Result`, and `maybe_push_metrics()` logs the error instead of falling back. (LAN-156)
- **JSON output now propagates serialization errors** — `output_json()` and `output_interval_json()` used `.unwrap_or_else(|_| "{}".to_string())`, so a serialization failure would silently emit an empty JSON object. Both functions now return `anyhow::Result<String>`, and callers either propagate the error or log it and skip the interval. (LAN-156)
- **Push Gateway metrics emit `# HELP`/`# TYPE` once per family** — the text formatter previously wrote `# TYPE xfr_stream_*` before every stream sample, producing invalid Prometheus exposition with repeated headers. Headers are now emitted once per metric family, followed by all samples for that family. (LAN-157)
- **Release workflow no longer references stale completions artifact path** — the `Generate checksums` step moves every tarball to `artifacts/`, but the release job still listed `artifacts/completions/completions.tar.gz`, which no longer exists after the move. The stale path is removed; `artifacts/*.tar.gz` already covers the completions tarball after the move. (LAN-157)
- **Installer no longer points Intel Macs to a removed artifact** — `install.sh` still resolved `x86_64-apple-darwin` on Intel Macs, but release builds for that target were removed. The script now prints a clear message directing users to `cargo install xfr`. (LAN-157)
- **Malformed protocol versions are no longer treated as compatible** — `versions_compatible()` now rejects malformed strings instead of defaulting parse failures to major version `0`. (LAN-166)
- **Receive-side TCP resets at normal teardown are treated as EOF without hiding mid-test failures** — `receive_data()` and `receive_data_half()` now handle peer-close errors such as Linux `SO_LINGER=0` abortive sender teardown as graceful end-of-stream only after cancel or near the expected test deadline; mid-test resets remain fatal so truncated runs are not reported as successful. (LAN-166)
- **Socket buffer tuning once again degrades gracefully on OS rejection** — invalid `-w` values still fail up front, but `SO_SNDBUF`/`SO_RCVBUF` rejections from platform limits are warning-only again so oversized window requests do not abort otherwise valid tests. (LAN-165)
- **`xfr diff` no longer fails default comparisons on tiny TCP metric noise** — the default threshold is now 5%, and retransmit/RTT row labels use the same threshold as the final verdict. Zero-baseline TCP metric regressions still show as `+inf%` and fail when above threshold. (LAN-162)
- **Server bidirectional TCP no longer double-counts send-half retransmits** — the send-half path records the final TCP_INFO snapshot once, and the server result/prometheus paths no longer add the same retransmit count a second time.
- **Failed tests are distinct in the server TUI** — TCP and QUIC error paths now emit a failed-test event instead of the completed-test event, and the server dashboard tracks failed tests separately.
- **Bare-major protocol versions are accepted again** — version compatibility still rejects malformed versions, but a peer that sends `1` is treated as protocol-major `1` for compatibility with earlier loose parsing. (LAN-166)
- **TestAck and MTU probe packets reject invalid wire shapes** — `TestAck` deserialization now rejects messages that contain both `udp_token` and per-stream `data_ports`, and padded MTU probes now reject declared sizes below the header or beyond the received datagram. (LAN-167)
- **MTU probing handles echo-only success and IPv6 literals correctly** — an MTU echo now proves forward-path success even when the ack is lost, and literal IPv6 probe targets are bracketed before address resolution. (LAN-168)
- **TUI average speed and retransmit fallback are no longer biased** — zero-throughput intervals now count toward the live average, and the fallback path for older servers accumulates per-stream retransmit deltas instead of replacing the total with each interval's latest snapshot. (LAN-163)
- **Server preset max duration is applied with CLI precedence** — `max_duration_secs` from `xfr serve --preset` now applies when `--max-duration` is not supplied on the CLI, and `bandwidth_limit` is documented as reserved/unused rather than implied to be enforced. (LAN-173)
- **Explicit `--probe-mtu -t 10s` duration is preserved** — `-t`/`--time` is now tracked as optional input, so an explicit 10-second MTU probe is no longer mistaken for the default and replaced with the longer probe default. (LAN-172)
- **IPv6 MTU probe ladder uses IPv6 overhead for both bounds** — the probe size ladder now brackets IPv6 at 1232..=9168 bytes instead of mixing IPv4-derived payload bounds into IPv6 probes. (LAN-172)

### Maintenance
- **MPTCP CI skips are visible** — the namespace test job name and `::warning::` output now make missing kernel MPTCP/netem support explicit instead of looking like an ordinary green MPTCP validation run. (LAN-174)
- **Rate-limit integration coverage now asserts rejection** — the second concurrent client in `test_rate_limit` must fail promptly, and the long-running first client is aborted so the test remains fast. (LAN-172)
- **`--no-default-features` no longer warns on the mDNS fallback stub** — the discovery fallback `register_server` stub is explicitly allowed as dead code when discovery support is compiled out. (LAN-172)
- **Dependency and workflow action updates** — `actions/checkout` v6→v7, `actions/cache` v5→v6, plus Rust lockfile updates for ratatui 0.30.2, mdns-sd 0.20.1, anyhow 1.0.103, uuid 1.23.4, quinn 0.11.11, rustls 0.23.41, and their transitives. (#109, #111, #112)
- **Local review marker is ignored by git** — `.last_review_sha` is now listed in `.gitignore`.

## [0.9.20] - 2026-06-23

### Security
- **Updated `quinn-proto` to 0.11.15** to address [RUSTSEC-2026-0185](https://rustsec.org/advisories/RUSTSEC-2026-0185) (High, 7.5) — a remote memory-exhaustion denial of service in QUIC stream reassembly, where unbounded buffering of out-of-order stream data could let a peer drive a server's memory usage without bound. This affects xfr's QUIC server path (any host running `xfr -s` reachable by an untrusted QUIC client). Lockfile-only update — no source or API changes, and no configuration change is required.

### Maintenance
- **CI: bumped the Docker publish actions** used by the GHCR release job — `setup-buildx-action` v3→v4, `login-action` v3→v4, `setup-qemu-action` v3→v4, `build-push-action` v6→v7, and `metadata-action` v5→v6. These track the actions' Node 24 runtimes; the published multi-arch image is unchanged.

## [0.9.19] - 2026-06-14

### Added
- **Restart a test from the TUI** (issue #100) — the `r` key, and Settings → Test → *Apply & Restart*, now cancel and drain the current run before spawning a fresh one in place, instead of requiring a full client restart. Each restarted run gets its own client task and progress channel, so stale progress from the prior run cannot bleed into the next. A settings restart applies stream count, protocol, duration, direction, and bitrate; QUIC-incompatible knobs (`-b`/`-w`/`--congestion`/`--tcp-nodelay`/`--dscp`) are surfaced in the TUI history the same way the CLI warns about them. The settings modal gains a Bitrate row (stepping through unlimited / 1M / 10M / 100M / 1G / 10G), and the footer and help overlay list the `r` key. Based on the contribution in #101/#102 by @flotpg.

### Fixed
- **Repeated `q` no longer skips the test summary** — while a cancel was already in flight, a second `q` (or key-repeat from a held key) was treated as "exit now" and could leave before the server's final Result arrived. Now `q` stays graceful while cancelling (the existing 3-second deadline still bounds the wait), and a second Ctrl+C remains the explicit force-exit, matching the documented signal behavior.

## [0.9.18] - 2026-06-11

### Added
- **CSV interval rows carry the bidirectional split** (issue #56 follow-up) — `--csv` interval output gains `bytes_sent`, `bytes_received`, `throughput_send_mbps`, and `throughput_recv_mbps` columns, matching the fields the CSV summary row and final JSON already expose. The new columns are appended at the end of the row so existing parsers that index columns by position keep working; unidirectional tests leave them empty, like the summary row already does.
- **Single-port UDP data plane (`single_port_udp_v1` capability)** (issue #63) — all per-stream UDP test traffic now flows to the server's main port (default 5201/UDP) instead of per-stream ephemeral ports, so firewalls only need one UDP port open. Per stream, the client sends a small token-bearing hello datagram to the main port (retried at 100 ms up to ~5 s, then the test fails loudly); the server creates a fresh UDP socket, binds it to the same port via `SO_REUSEADDR`+`SO_REUSEPORT`, `connect()`s it to the client's source address, and acks from that socket. The kernel's UDP lookup scores connected sockets above the wildcard, so line-rate data rides the connected socket and the shared socket only ever sees hellos. The per-test token (16 random bytes, returned in `TestAck.udp_token`) routes hellos to the right test across NAT and concurrent clients. The main UDP port is owned by the quinn QUIC endpoint; it now gets a tee implementing `quinn::AsyncUdpSocket` that delegates to the runtime's quinn-udp-backed socket (GSO/GRO/ECN paths intact) and diverts only xfr hello datagrams. The classifier (hello framing first, then QUIC long-header bit 0x80, then short-header fixed bit 0x40) is made sound by disabling QUIC-bit greasing on the server endpoint — RFC 9287 greasing is permission-based, so not advertising it stops compliant peers from clearing the fixed bit toward us. The hello/ack magic `b"\x00XFR"` lives in the 0b00 first-byte space QUIC can never use. With `--no-quic`, a plain shared socket serves the hello lane instead. The server advertises the capability only after a startup self-test proves the running kernel actually routes a connected-socket datagram past a same-port wildcard (SO_REUSEPORT semantics vary by platform); on failure — and against older peers — the legacy per-stream ephemeral-port path is used unchanged. Single-port is the default when both peers advertise, mirroring `single_port_tcp`, and covers upload, download, bidir, and `--probe-mtu`.

- **`--connect-timeout <DURATION>`** — bound the control-connection establishment (TCP connect or QUIC handshake) and fail with a clear error instead of waiting on OS defaults, which against a dead or filtered server can mean minutes. Off by default (behavior unchanged unless set); aimed at CI and scripted runs.

### Changed
- **QUIC tests now warn about ignored flags** — `-b/--bitrate`, `-w/--window`, `--congestion`, and `--tcp-nodelay` have never applied to QUIC (pacing and socket tuning are not implemented on that path), but the client accepted them silently, so a rate-limited or buffer-tuned QUIC test ran untuned with no indication. Each now prints a warning, matching what `--dscp` already did. Actually implementing QUIC pacing remains on the roadmap.
- **The server log now answers "which client was that"** — every control connection logs the client software string and protocol version, plus a line listing any server capabilities the client doesn't share (i.e., the features that silently fall back for that session). Previously the log showed only the peer address.
- **`--tcp-nodelay` now propagates to the server** — the flag previously shaped only client-created sockets; the client now forwards the request in `TestStart.tcp_nodelay` (wire-additive, absent = false) and the server ORs it into its data-socket configuration. The server has always enabled `TCP_NODELAY` on its data sockets, so the OR cannot regress existing behavior — the field makes the client's intent explicit on the wire and keeps it honored if the server-side default ever changes. Older servers ignore the field, an acceptable degradation since they already run with nodelay on (same call as `window_size`; no new capability).

### Maintenance
- **Control-channel skew CI test recalibrated** — packet captures showed the test's FIFO-bloat profile has two stable delivery rhythms (~2 s batches of 2 interval lines, ~4 s batches of 3) on a *correctly functioning* NODELAY control channel, and which rhythm a run locks onto is decided by startup phase; the single-port UDP handshake shifted that phase and made the previously-rare rhythm dominant. The assertion now targets what the #70 bug actually does (total collapse to one timestamp: 5+ lines in one bunch or fewer than 3 distinct timestamps) instead of a threshold that sat between the two physical rhythms. Findings documented in KNOWN_ISSUES.md.

### Library API (pre-1.0 break)
- `client::ClientConfig` gains `connect_timeout: Option<Duration>` (`Default` is `None`); struct-literal constructors must supply it.
- `protocol::ControlMessage::TestStart` gains `tcp_nodelay: bool` (serde-default, omitted when false); struct-literal constructors must supply it.
- `protocol::ControlMessage::TestAck` gains `udp_token: Option<String>` (serde-default, wire-additive); struct-literal constructors must supply it.
- `udp::receive_udp` and `udp::respond_mtu_probes` gain a trailing `single_port_ack: Option<[u8; 24]>` parameter.
- New public items: `udp::{UdpHelloPacket, SharedSocketLane, classify_shared_datagram, single_port_udp_handshake, respond_single_port_hellos, encode_hello_token, parse_hello_token, UDP_HELLO_*}`; `net::{create_shared_udp_socket, create_connected_udp_same_port, single_port_udp_self_test}`; `quic::XfrHelloDatagram`; `protocol::{SINGLE_PORT_UDP_CAPABILITY, supported_capabilities, supported_capabilities_without}`; `ControlMessage::{server_hello_with_capabilities, server_hello_with_auth_and_capabilities}`.
- `quic::create_server_endpoint` gains a trailing `xfr_hello_tx: Option<mpsc::Sender<XfrHelloDatagram>>` parameter.

## [0.9.17] - 2026-06-11

### Added
- **Path-MTU probe: `--probe-mtu`** (issue #64) — discovers the largest UDP payload that survives the path in each direction, instead of running a throughput test. The client walks a ladder of common wire MTUs (576, 1280, 1492, 1500, 4352, 9000, 9216) and binary-searches the gap, RFC 8899 style, with the IP don't-fragment flag set so middleboxes must drop oversized packets rather than quietly fragment them. Each probe gets two replies from the server: a small ack (proves the client→server direction) and a same-size echo (proves server→client), so an asymmetric path shows up as ack-without-echo — per-direction attribution was brettowe's suggestion on the issue. Output is a per-size table plus the largest surviving payload and derived path MTU per direction; `--json` carries the full report. Requires a server advertising the new `mtu_probe_v1` capability (the client refuses old servers up front, since they'd silently swallow probes). Validated in a netns harness with a 1500-byte middle hop on a jumbo-framed client (`test-mtu-probe-ns.sh`, now a CI job).

### Changed
- **Zero-copy TCP sends are now on by default** (issue #33 follow-up) — `sendfile(2)` needs only Linux 3.17+ and every unsupported configuration (non-Linux, old kernels, old servers, sockets that reject `sendfile`) already falls back to regular writes, so there is no reason to make users opt in to the cheaper send path. `-Z`/`--zerocopy` is kept: passing it explicitly upgrades the silent fallback to a warning (non-Linux client sends, or a `-R`/`--bidir` server that doesn't advertise `zerocopy_v1`). New `--no-zerocopy` flag opts out. Payload semantics are unchanged, and on links where the sender isn't CPU-bound results are identical — where it is, throughput now reflects the network rather than the sender's copy overhead.

### Fixed
- **TUI sparkline keeps advancing when the control channel stalls** (issue #93, split from #70) — bars were appended only on full TCP `Interval` arrivals, and upload-mode saturation stalls exactly that channel, so the graph froze while the `udp_feedback_v1` loss counter stayed live. `tick()` now synthesizes a bar at the regular cadence once two report intervals pass without one, taking loss tint from feedback deltas not yet rendered into any bar and repeating the last known bar height (a zero-height bar draws no glyph, leaving nothing to tint — the flat tinted plateau reads as "no fresh throughput, loss still arriving"). Cumulative loss is tracked against what's been *drawn*, so a resuming `Interval` never re-counts loss already shown during the stall. Normal 1 Hz delivery is visually unchanged.
- **Bidir UDP no longer reports the server's send rate as download throughput** (issue #91) — same root cause as the `-R` fix in 0.9.16 (issue #81), on the other code path: in bidirectional UDP tests the download half of the split (`bytes_received`, `throughput_recv_mbps`) was computed from the server's send-side counters, which track the requested `-b` rate rather than what arrived. The client now overlays its own receive counters onto both the live split and the final result, and the combined totals are rebuilt from the two corrected halves (upload was always receiver-truth — the server counts what it actually received). Per-stream rows still show the server's combined view; splitting those per-direction needs wire changes and is out of scope here.

### Library API (pre-1.0 break)
- `client::ClientConfig.zerocopy` is now a `ZerocopyMode` enum (`Off` / `Auto` / `Requested`) instead of `bool`; `Default` is `Auto`. `Auto` and `Requested` behave identically except `Requested` warns on downgrade. `tcp::TcpConfig.zerocopy` stays `bool`.
- New public module `probe` (`ProbePacket`, `SizeSearch`, `MtuProbeReport`, `run_probe`); `client::ClientConfig` gains `mtu_probe: bool`; `protocol::ControlMessage::TestStart` gains `mtu_probe: bool` and `protocol::TestResult` gains `mtu_probe: Option<MtuProbeReport>` (both serde-default, wire-additive); `udp::respond_mtu_probes` and `net::set_dont_fragment` are new.

## [0.9.16] - 2026-06-10

> v0.9.15 was tagged but never released: its release CI failed on the aarch64-gnu cross build (glibc < 2.27 lacks the `memfd_create` wrapper; now invoked via raw syscall). All v0.9.15 changes ship here.

### Fixed
- **`-R` UDP no longer reports the server's send rate as throughput** (issue #81) — in download mode the server is the UDP sender, and both the live intervals and the final result carried its `bytes_sent`: every `send_to` the kernel accepted counted, so over a constrained link the display tracked the requested `-b` rate (brettowe's 999.7 Mbps over 100 Mbps Wi-Fi) instead of what arrived. The client — the receiver, the only side that knows wire truth — now overlays its own receive counters onto live intervals (TUI, `--json-stream`, CSV, plain) and the final result (total, per-stream, throughput). Forward mode was always correct because there the server is the receiver. Repro: CPU-starved receiver with a 4 KB receive buffer showed 2.6 Gbps sender-side vs 1.18 Gbps actually received; the display previously claimed the former and now reports the latter, exactly matching received-packets × packet-size.
- **`-R` UDP results now include loss and jitter** — the client's `receive_udp` already computed full receiver-side `UdpStats` (loss %, jitter, out-of-order, max jitter) but discarded them; download mode showed no UDP Stats block at all. They're now recorded and attached to the final result, and live loss in download mode is derived from the client's own packet trackers rather than the server's (empty) receiver counters.

### Added
- **Zero-copy TCP sends (`-Z`/`--zerocopy`, Linux)** (issue #33) — the send payload now lives in a `memfd_create` anonymous file and is pushed to the socket with `sendfile(2)`, skipping the userspace-to-kernel copy that `write(2)` performs on every 128 KB chunk. On CPU-bound senders (embedded routers, SBCs) the copy itself is often the throughput bottleneck — iperf3's equivalent `-Z` measured ~3x on a MIPS router. `sendfile` was chosen over `MSG_ZEROCOPY` for the first step because it works on old kernels, needs no error-queue completion reaping, and is MPTCP-compatible; `MSG_ZEROCOPY` remains on the roadmap under the same flag. Opt-in, TCP-only (conflicts with `-u`/`-Q` at parse time), and never fails a test: non-Linux platforms, kernels without `memfd_create`, and sockets that reject `sendfile` all fall back to regular writes with a warning. Payload semantics are unchanged (`--random` default / `--zeros` fill the memfd exactly as they fill the regular buffer).
- **`zerocopy_v1` capability + `TestStart.zerocopy` field** — for `-R`/`--bidir`, the client forwards the zero-copy request in `TestStart` (wire-additive, absent = false) and the server applies it to its own send paths. Servers predating the field silently ignore it, so the client warns when the server doesn't advertise `zerocopy_v1`.

### Library API (pre-1.0 break)
- `tcp::TcpConfig` and `client::ClientConfig` gain `zerocopy: bool`. Struct-literal constructors must supply it (`Default` is `false`).
- `protocol::ControlMessage::TestStart` gains `zerocopy: bool` (serde-default, omitted when false).
- New module `zerocopy` with `ZerocopyPayload` (memfd construction + async sendfile chunk sends).

### Maintenance
- Rust dependencies group bump (PR #86): ratatui 0.30.1, clap_complete 4.6.5, serde_json 1.0.150, hyper 1.10.1, mdns-sd 0.20.0, uuid 1.23.3, chrono 0.4.45, rcgen 0.14.8, dashmap 6.2.1, socket2 0.6.4. No source changes required.
- Bump `Cargo.toml` to `0.9.16`.

## [0.9.14] - 2026-05-03

### Fixed
- **Live UDP loss counter no longer stalls under upload-mode saturation** (issue #70 final fix) — v0.9.13's `TCP_NODELAY` partially addressed the bug but brettowe's retest showed 8 subsequent intervals still bunched at one end-of-test client-side timestamp. Root cause was `tokio::time::interval` defaulting to `MissedTickBehavior::Burst` on the server's stats sampling timer: when `writer.write_all()` stalled under the back-pressure that the saturated UDP uplink induces on TCP control, missed ticks accumulated and fired as a burst when the writer unblocked, producing stale interval samples with fresh client-side arrival timestamps and misleading throughput numbers. `Skip` now drops the stale ticks; cumulative state in `StreamStats` atomics still surfaces correctly on the next live tick and at end-of-test. Applied unconditionally on both `run_test` interval-loop sites; benefits even pre-v0.9.14 clients pairing with a v0.9.14 server.
- **`--omit` no longer folds hidden UDP loss into the first visible interval** — the new cumulative-loss tracker added below was advancing its cache on every progress arrival, but the printed-line baseline only advanced when a line printed. With `--omit 3`, the first visible interval would report all loss accumulated during seconds 0-3 as one jumbo delta, defeating the purpose of `--omit`. The baseline now advances during the omit window so visible lines reflect only loss observed during printed intervals.

### Added
- **UDP receiver feedback (`udp_feedback_v1` capability)** (issue #70 final fix) — when both peers advertise the capability, the server now emits a 36-byte cumulative `(packets_received, packets_lost)` UDP packet back to the client at 2 Hz on the same data socket, sidestepping the TCP control channel for live UDP loss reporting. Wire format: `b"XFRF"` magic + version + kind + flags + `stream_id` + reserved + `elapsed_ms` + cumulative `packets_received` + cumulative `packets_lost`, all big-endian, fixed 36 bytes. Length-first demux at receive sites distinguishes feedback from data packets without inspecting sequence-number bits. Cumulative-not-delta semantics let the client recover from any dropped feedback packet without needing the lost intermediate state. Capability negotiation gates emission so older clients (which wouldn't know to listen) never see a packet they don't understand.
- **Producer-side monotonic-denominator filter on the client** — both the TCP control `udp_progress` decode site and the UDP feedback aggregator funnel updates through `UdpProgressFilter::apply`, which admits only readings whose `(received + lost)` denominator is at-least-as-fresh as anything we've seen before. Atomic CAS via `fetch_update` so two producers cannot race a stale store after a fresh one. Applies in addition to TUI display: plain text, CSV, and JSON-stream output use the cached cumulative as the source of truth for the per-line `lost` field, so the freshest reading from either source flows through to scripted consumers, not just the TUI live counter.
- **Live UDP loss in non-TUI output paths** — `--no-tui --json-stream` / `--csv` / plain interval output now reflects the freshest `udp_progress` from either TCP control or UDP feedback. Previously these consumers used per-stream `streams[].lost` from the most recent TCP `Interval` only, which under control-channel stalls could be several seconds stale. Falls back to the per-stream sum for sessions where `udp_progress` is never sent (paired with a pre-0.9.11 server, or non-UDP tests).
- **Docker repro harness for issue #70** (`docker/Dockerfile.repro`, `docker/repro-issue-70.sh`, `docker/README.md`) — multi-stage build with the current branch and the released v0.9.13 baseline side-by-side. `docker run --rm --cap-add=NET_ADMIN xfr-repro` runs hard assertions on the new build (max bunch ≤ 2, time-to-first-loss < 5s, live mid-run loss observed); `--baseline` prints diagnostics for narrative comparison without gating on a threshold. Stays out of CI — the existing 2× oversubscription `control-channel-skew` job remains the regression floor; the harness is for human-driven A/B at brettowe's 10× recipe before publishing.

### Changed
- **`TestProgress` schema (pre-1.0 break)** — adds `udp_feedback_only: bool` so consumers can distinguish a feedback-only update (only `udp_progress` carries truth; everything else is sentinel/None) from a full TCP `Interval` update. Three consumers handle the partial variant: `App::on_progress` early-returns after updating UDP loss state and preserves all other field values; `main.rs` print loop skips feedback-only entries entirely (the cumulative cache picks up the freshness for the next full interval); cross-version compat test path adopts the new field.
- **Server bidir mode no longer emits UDP feedback** — feedback is upload-mode-only by design. Bidir's server-side recv half was passing `client_supports_udp_feedback` through to `receive_udp` even though the client's bidir recv has no consumer for those packets; emission was pure overhead on the return path. Bidir always passes `false` now.
- **`receive_udp` skips feedback packets in `bytes_received` accounting** — the length-first demux previously rejected feedback before the data path but bumped `bytes_received` first. With server bidir gating that's a moot path post-fix, but defense-in-depth: feedback bytes never count toward `bytes_received`, which tracks test-data wire bandwidth.
- **Capability list factored into a single `SUPPORTED_CAPABILITIES` const** — `client_hello`, `server_hello`, and `server_hello_with_auth` previously each had a duplicated `Vec<String>` literal. Future capability additions now touch one line. New `capability_advertised(&capabilities, name)` helper centralizes the matcher used at both negotiation sites.

### Library API (pre-1.0 break)
- `client::TestProgress` gains `udp_feedback_only: bool`. Constructors must supply it.
- `client::UdpProgressFilter` and `client::UdpFeedbackAggregator` are new public types backing the producer-side filter and aggregator.
- `udp::receive_udp` signature gains a trailing `feedback_enabled: bool` parameter.
- `udp::receive_udp_feedback_only(socket, aggregator, stream_index, cancel)` is new; spawned per-stream on the client in upload mode.
- `udp::UdpFeedbackPacket` and `UDP_FEEDBACK_SIZE` / `UDP_FEEDBACK_MAGIC` / `UDP_FEEDBACK_VERSION` / `UDP_FEEDBACK_KIND_RECEIVER_PROGRESS` constants exported.
- `protocol::SUPPORTED_CAPABILITIES` and `protocol::capability_advertised` exported.
- `stats::StreamStats::udp_progress_snapshot()` exported for callers that need a coherent `(received, lost)` pair.

### Maintenance
- Bump `Cargo.toml` to `0.9.14`.

## [0.9.13] - 2026-05-03

### Fixed
- **Live UDP loss counter no longer stuck at 0% under saturated links** (issue #70 follow-up) — `TCP_NODELAY` was not being set on the control connection. With Nagle still active, the periodic `Interval` messages (~150-byte 1 Hz writes) coalesced waiting for an MSS-sized payload (which never arrives — they're tiny) or a delayed ACK from the peer. Under heavy parallel UDP data load on a saturated path (Wi-Fi, rate-limited links, anything where ACK turnaround stretches), the kernel held every queued segment for the duration of the test and flushed the entire backlog in a single burst when data traffic stopped. The TUI live counter appeared permanently stuck at 0% during the run, then jumped to the final value at quit. iperf3 sets `TCP_NODELAY` on its control channel for exactly this reason. New `tcp::configure_control_stream` helper applies it before splitting the stream into reader/writer halves; called at three sites (server's accepted control connection, client's connecting control connection, server's auth-handshake fallback path). Reproduced and verified with a `tc netem` 50 Mbps + 50ms-delay simulation: the pre-fix binary collapses 3+ interval lines to a single end-of-test timestamp; the post-fix binary spreads them across the run with at most a 2-line tail collision.

### Added
- **CI regression test for the bunching pattern** (`test-control-channel-skew.sh`, runs as the `Control-channel skew (#70 regression)` job). Applies a 50 Mbps shaper + 50ms each-way delay to `lo`, runs an 8-second UDP test at 100 Mbps target (2× oversubscription), and asserts no 3-or-more interval lines share a client-side timestamp. Catches future regressions where the `TCP_NODELAY` plumbing is dropped from any of the three control-stream sites or a new code path forgets to call the helper.

### Maintenance
- Rust dependency group bump (PR #76): `clap_complete` 4.6.2 → 4.6.3, `rustls` 0.23.39 → 0.23.40. Patch-version updates only, no source changes required.

## [0.9.12] - 2026-05-02

### Added
- **`-w`/`--window` now applies to UDP socket buffers** (#70 follow-up) — previously the flag only set TCP `SO_SNDBUF`/`SO_RCVBUF`. UDP sockets used the kernel default regardless. On high-rate UDP flows where the receiver's kernel UDP buffer can saturate (weak/loaded receivers, default `net.core.rmem_max` lower than line-rate × ~1s), the kernel tail-drops new arrivals and the loss only surfaces as a sequence-gap once traffic stops — rendering as live `Packet Loss: 0.0%` while the test is running and a high final loss percent on quit. `-w 16M` is the immediate workaround for that pattern; the value propagates from client to server in `TestStart` (already wired for TCP since v0.9.9) and now lands on UDP `SO_SNDBUF`/`SO_RCVBUF` on both ends.

### Changed
- **`setsockopt` failures on `-w` now surface as warnings** — previously rejections (typically `net.core.rmem_max` exceeded without `CAP_NET_ADMIN`) were swallowed at debug level. Users running `-w 16M` for #70-style troubleshooting need to see the rejection rather than have it disappear silently. Both `SO_SNDBUF` and `SO_RCVBUF` are still attempted independently, and the warning identifies which buffer failed.

### Maintenance
- Rust dependency group bump (PR #71): clap 4.5 → 4.6, clap_complete 4.5 → 4.6, hyper 1.8 → 1.9, mdns-sd 0.17 → 0.19, toml 0.9 → 1.1, rustls 0.23.37 → 0.23.39, hmac 0.12 → 0.13, sha2 0.10 → 0.11, rand 0.9 → 0.10, plus libc, uuid, once_cell, tracing-subscriber, tracing-appender, tempfile patch bumps. Adapted source to API moves in hmac (constructor moved from `Mac` to `KeyInit`) and rand (user-facing `Rng` methods moved to `RngExt`); no behavior change.

## [0.9.11] - 2026-04-30

### Fixed
- **Live UDP packet-loss counter during the run** (issue #70) — the Packet Loss line in the TUI was stuck at 0.0% for the entire test and only updated to the real value at completion. With `-t 0` (infinite mode) the real value was never visible. Server now ships a cumulative packet-counts snapshot (`UdpIntervalProgress { packets_received, packets_lost }`) on every periodic Interval message; client derives the loss percent locally and the TUI updates it live. Cumulative counts are snapshotted into `IntervalStats` at interval emission time so deltas between consecutive samples correspond to the same window. Reported by @brettowe.
- **Final UDP loss accounting only counts valid xfr packets** — `UdpStats.packets_received` and `packets_sent` now exclude short, malformed, or foreign datagrams that can't be header-decoded. Previously such datagrams inflated `packets_received` and silently understated the final loss percent. `bytes_received` continues to count every byte the wire delivered.

### Added
- **Throughput sparkline tints by per-interval loss severity** (issue #70) — lossy intervals are visually distinct from clean intervals at the same height: clean stays the graph color, light loss (<1% per-interval rate) tints warning, heavy loss (≥1%) tints error. Per-interval rate computed from `udp_progress` deltas, so a single-packet hiccup and a heavy drop burst no longer collapse to the same flat tint. Magnitude unknown (TCP run, pre-0.9.11 server, or first UDP sample) stays the graph color — honest "no signal" rather than a misleading tint. Sparkline widget gains a `.styles(&[Style])` per-sample override.
- **Freshness signal for the Packet Loss line** — the line renders dimmed `--%` when paired against a pre-0.9.11 server, or before any UDP traffic has been observed. Without this, an old server would render a stale `0.0%` next to actual loss bursts in the sparkline. `App.udp_lost_percent` is now `Option<f64>` end-to-end.

### Changed
- **Jitter rolling-window label** (issue #72) — the running display now reads `Jitter: 0.86 ms (10s avg: 0.03 ms)`. The previous `(10s: …)` form read like a stuck timer; @pythonwood opened an issue thinking the display was broken on a v0.9.10-client → v0.9.6-server pairing.

## [0.9.10] - 2026-04-22

### Fixed
- **TCP teardown no longer hangs under rate-limited paths** (issue #54) — the v0.9.8 SO_LINGER=0 fix didn't take effect when the send loop was parked in `stream.write().await` under heavy backpressure (tc rate limiting, slow peers, MPTCP subflows filling). The loop would block past the configured deadline, never reaching the drop/close that would trigger the abortive close. `send_data` and `send_data_half` now race the pending `write()` against cancel and deadline in a `biased tokio::select!`, so either signal breaks the loop and lets `SO_LINGER=0` do its job. Confirmed by @matttbe against his MPTCP + tc reproducer.
- **TUI elapsed time stays live during data gaps** (issue #62) — `app.elapsed` was only updated when the server's `Interval` progress message arrived. On lossy paths that starved the control channel (e.g. brettowe's WiFi test with packet-drop bursts), the elapsed counter — and by extension the progress bar position — could freeze for several seconds until the next message landed, creating the impression of a "stall" even though the TUI was still redrawing at 20 Hz. The loop now refreshes `elapsed` from the wall clock on every iteration; `on_progress` no longer writes `elapsed` (doing so was a visual no-op, since the next tick immediately overwrote the server's value). Pause handling shifts `start_time` forward by the pause duration on resume, so the elapsed counter excludes paused time. Reported by @brettowe.
- **Infinite-duration (`-t 0`) TUI now shows a live elapsed counter** — the `{}s/∞` display was relying on the same `elapsed` field that could go stale, so an infinite test on a flaky link looked frozen. Covered by the same fix.

### Added
- **Client/server version in the Configuration panel** (issue #62) — the TUI now shows `xfr/<client-version> ↔ <server-version>` so cross-version test pairings are obvious at a glance. Server version is captured from the `Hello` handshake (already wire-supported; just wasn't surfaced). Requested by @brettowe.

### Changed
- **TUI jitter line shows latest + smoothed together** (issue #48 follow-up) — the running display now reads `Jitter: 0.02 ms (10s: 0.03 ms)` so the latest per-interval aggregate and the 10-second rolling mean are visible side by side. Resolves the confusion where the rolling mean could stay above any single sample's value, making the live display look inconsistent with the server's authoritative final. Completed state still shows just the final value (no smoothing companion — the final is authoritative). Reported by @brettowe.

### Security
- **Sanitize server-advertised version before rendering** — the `Hello.server` field crosses a network trust boundary and was being rendered verbatim into the Configuration panel. A hostile or compromised server could send ANSI escape sequences (clear screen, move cursor, OSC commands) or a very long string and have the user's terminal act on them. Control characters are now stripped, length capped at 32, and empty or all-control inputs fall back to `(unknown)`.
- **Bump rustls-webpki 0.103.12 → 0.103.13** (RUSTSEC-2026-0104) — reachable panic in CRL parsing. Transitive upgrade via Cargo.lock; no manifest change.

## [0.9.9] - 2026-04-21

### Added
- **Max jitter and packet size in UDP summary** (issue #48 follow-up) — the final UDP summary now reports `Jitter Max` (peak of the RFC 3550 running estimate across the test) alongside the average, and `Packet Size` (UDP payload bytes). Surfaced in plain text and JSON. Requested by brettowe for NFS UDP packet-size tuning context.
- **`-w` short alias for `--window`** (issue #60) — matches iperf3 muscle memory.

### Changed
- **Bare-integer duration arguments mean seconds** (issue #61) — `-t 10`, `--max-duration 60`, `--rate-limit-window 30`, and discover `--timeout 5` now accept plain integers as seconds, matching iperf3 muscle memory. Unit-suffixed forms (`10s`, `1min`, `500ms`) continue to work unchanged.
  - Side effect: `--rate-limit-window` now rejects zero (`0`, `0s`, `0ms`) with `Duration must be greater than 0`. Previously `0s` was accepted and would later panic in the rate-limiter's cleanup task because `tokio::time::interval` requires a non-zero duration. Other duration flags (`-t`, `--max-duration`, `discover --timeout`) still accept `0` for their existing meanings (`-t 0` is infinite duration).
- **Smoothed TUI jitter reading** (issue #48) — the UDP stats panel now shows jitter averaged over a 10-second rolling window rather than the raw per-second sample. The data pipeline is unchanged (samples still arrive every second from the server); only the aggregate display is smoothed. Per-stream jitter in the streams view continues to show the latest interval. While the test is running, the label shows `Jitter (10s):`; once completed, it reverts to `Jitter:` with the authoritative final value from the server's result.

### Fixed
- **Duplicate receive-error log on the server** (issue #54) — `tcp::receive_data` and `tcp::receive_data_half` each warned at the read-error site, and the caller then warned again when it saw the returned `Err`. The duplicate inner `warn!` is removed so receive errors now log exactly once, matching the send path's pattern. Reported by @matttbe.
- **Default to kernel TCP autotuning** (issue #60) — xfr no longer forces `SO_SNDBUF`/`SO_RCVBUF` to 4 MB on either side by default; both ends let the kernel autotune unless the user passes `-w`/`--window`. When set, the client's value propagates to the server over the control protocol so both sides apply the socket option symmetrically (matching iperf3). Reported by @matttbe.

  Caveats:
  - Loopback / intra-host benchmark numbers may decrease by roughly 10% — this is expected; the previous numbers were inflated by the oversized app-applied buffer.
  - On high-RTT paths, very short tests (e.g. `-t 1s` at high bitrate) may now show ramp-up-limited throughput in the final summary because kernel autotune takes a handful of RTTs to grow the window. Use a longer `-t`, or pass an explicit `-w` to skip autotune. Note that `-O`/`--omit` only hides the early intervals from output — the server-side final summary is still computed over the full test duration.
  - Explicit window sizes above `c_int::MAX` (≈2.1 GB on 64-bit) are now rejected with `InvalidInput` instead of silently wrapping before `setsockopt`.

### Removed
- **Library API**: pre-1.0 break — `TcpConfig::high_speed()` and `TcpConfig::with_auto_detect()` are gone; construct `TcpConfig` directly with the fields you want set. The `HIGH_SPEED_BUFFER` and `HIGH_SPEED_WINDOW_THRESHOLD` constants (which were private) are also removed. Downstream code that constructs `ControlMessage::TestStart`, `protocol::UdpStats`, or `tui::app::App` by name now needs to supply the new fields (`window_size`, `jitter_max_ms`, `packet_size`, `jitter_history`); these are additive and have sensible None/default values.

## [0.9.8] - 2026-04-17

### Added
- **Separate send/recv reporting in bidir tests** (issue #56) — `--bidir` now reports per-direction bytes and throughput in the summary instead of just the combined total, which was useless on asymmetric links. Plain text shows `Send: X  Recv: Y  (Total: Z)`; JSON adds `bytes_sent`, `bytes_received`, `throughput_send_mbps`, `throughput_recv_mbps`; CSV gets four new columns; TUI shows `↑ X / ↓ Y` in the throughput panel. Unidirectional tests are unchanged (the existing `bytes_total`/`throughput_mbps` is already the single-direction number).

### Fixed
- **Fast, accurate TCP teardown** (issue #54) — replaced the blocking `shutdown()` drain on the send path with `SO_LINGER=0` on Linux, so cancel and natural end-of-test no longer wait for bufferbloated send buffers to ACK through rate-limited paths. Fixes the "Timed out waiting 2s for N data streams to stop" warning matttbe reported with `-P 4 --mptcp -t 1sec`.
- **Sender-side byte-count accuracy** — `stats.bytes_sent` is now clamped to `tcpi_bytes_acked` before abortive close, removing a quiet ~5-10% overcount where the send-buffer tail discarded by RST was being reported as transferred. Download and bidir tests are the primary beneficiaries.
- **macOS preserves graceful shutdown** — non-Linux platforms lack `tcpi_bytes_acked`, so the Linux abortive-close path is cfg-gated; other platforms still use `shutdown()` for accurate accounting.

## [0.9.7] - 2026-04-16

### Added
- **Early exit summary** (issue #35) — Ctrl+C now displays a test summary with accumulated stats instead of silently exiting. Works in both plain text and TUI modes. Double Ctrl+C force-exits immediately.
- **DSCP server-side propagation** — `--dscp` flag is now sent to the server and applied to server-side TCP/UDP sockets for download and bidirectional tests. Previously only client-side sockets were marked.
- **Non-Unix `--dscp` warning** — platforms without socket TOS support now show a visible warning before the test starts, instead of silently no-oping.

### Fixed
- **Cancel flow waits for server result** — client `Cancelled` handler now waits for the server's `Result` message instead of immediately erroring, providing accurate final stats after cancel.
- **Server result ordering** — server sends `Result` before slow post-processing (push gateway, metrics hooks), preventing false cancel timeouts.
- **Rust 1.95 clippy compatibility** — fixed `manual_checked_ops` and `collapsible_match_arms` lints.

### Changed
- Bump `softprops/action-gh-release` from 2 to 3 in CI release workflow.

## [0.9.6] - 2026-03-18

### Added
- **`--dscp` flag** — set DSCP/TOS marking on TCP and UDP client sockets for QoS policy testing. Accepts numeric values (0-255) or standard DSCP names (EF, AF11-AF43, CS0-CS7). QUIC warns and ignores the flag; non-Unix platforms warn instead of applying socket marking.
- **`omit_secs` config support** (issue #43) — `[client] omit_secs = N` in config file sets default `--omit` value.

## [0.9.5] - 2026-03-17

### Added
- **TCP `--cport` support** (issue #44) — `--cport` now pins client-side TCP data-stream source ports. Multi-stream TCP uses sequential ports (`cport`, `cport+1`, ...), matching UDP behavior.

### Changed
- **TCP `--cport` semantics** — TCP control remains on an ephemeral source port while data streams use the requested source port or range. TCP data binds now match the remote address family the same way UDP/QUIC already do, so dual-stack clients can use `--cport` against IPv6 targets.

## [0.9.4] - 2026-03-11

### Added
- **`--no-mdns` flag** (issue #41) — `xfr serve --no-mdns` disables mDNS service registration for environments where multicast is unwanted or another service already uses mDNS.
- **`server.no_mdns` config support** — mDNS registration can now also be disabled from `~/.config/xfr/config.toml` via `[server] no_mdns = true`.

### Changed
- **Delta retransmits in interval reports** (issue #36) — plain text interval lines now show per-interval retransmit deltas instead of cumulative totals, making it easier to spot when retransmits actually occur. Hidden intervals from `--omit`, `--quiet`, or larger `--interval` settings no longer get folded into the next visible `rtx:` value. Final summary still shows cumulative totals.

## [0.9.3] - 2026-03-10

### Added
- **Server `--bind` flag** (issue #38) — `xfr serve --bind <IP>` binds TCP, QUIC, and UDP data listeners to a specific address. Validates against `-4`/`-6` flags and rejects unspecified addresses (`::`, `0.0.0.0`). Requested by Windows users needing interface-specific binding.

### Changed
- **Server sends random payloads** (issue #34) — server-side TCP and UDP send paths now use random bytes by default in reverse and bidirectional modes, matching the client's default-on behavior. `--zeros` only affects client-sent traffic; server payload mode is not negotiated over the wire (future enhancement).

### Fixed
- **QUIC dual-stack on Windows** (issue #39) — QUIC server endpoint now creates its UDP socket via socket2 with explicit `IPV6_V6ONLY` handling instead of relying on Quinn's `Endpoint::server()`, which uses `std::net::UdpSocket::bind()` without dual-stack configuration. On Windows/macOS where `IPV6_V6ONLY` defaults to `true`, binding to `[::]` would only accept IPv6 connections.
- **Server random payload on single-port TCP reverse** (issue #34) — the single-port TCP handler (DataHello path used by all modern clients) was missing `random_payload = true`, causing reverse-mode downloads to still send zeros. Legacy multi-port handler was correct but is dead code for current clients.

### Security
- **quinn-proto DoS fix** — updated quinn-proto 0.11.13 → 0.11.14 (RUSTSEC-2026-0037, severity 8.7)

## [0.9.2] - 2026-03-06

### Changed
- **Random payloads by default** (issue #34) — TCP/UDP payloads now use random bytes by default to avoid silently inflated results on WAN-optimized or compressing paths. `--random` remains as an explicit no-op for clarity, and new `--zeros` forces zero-filled payloads for compression/dedup testing.

### Fixed
- **Windows build regression** (issue #37) — `pacing_rate_bytes_per_sec()` used `libc::c_ulong` without a `#[cfg(target_os = "linux")]` guard, breaking compilation on Windows. The function is only called from the linux-gated `SO_MAX_PACING_RATE` path.
- **MPTCP namespace test realism** (issue #32) — `test-mptcp-ns.sh` now combines `netem` shaping with `fq_codel` on the shaped transit links, matching common Linux defaults more closely and reducing false-positive high-stream failures caused by shallow unfair queues in the test harness.

## [0.9.1] - 2026-03-05

### Added
- **MPTCP support** (`--mptcp`) - Multi-Path TCP on Linux 5.6+ (issue #24). Uses `IPPROTO_MPTCP` at socket creation via socket2 — all TCP features (nodelay, congestion control, window size, bidir, multi-stream, single-port mode) work transparently. The server automatically creates MPTCP listeners when available (no flag needed) — MPTCP listeners accept both MPTCP and regular TCP clients transparently, with silent fallback to TCP if the kernel lacks MPTCP support. Client uses `--mptcp` to opt in. Clear error message on non-Linux clients or kernels without `CONFIG_MPTCP=y`.
- **Kernel TCP pacing via `SO_MAX_PACING_RATE`** (issue #30) - On Linux, TCP bitrate pacing (`-b`) now uses the kernel's FQ scheduler with EDT (Earliest Departure Time) for precise per-packet timing, eliminating burst behavior from userspace sleep/wake cycles. Falls back to userspace pacing on non-Linux, MPTCP sockets (not yet supported in kernel, see [mptcp_net-next#578](https://github.com/multipath-tcp/mptcp_net-next/issues/578)), or if the setsockopt fails. Note: `-b` sets a global bitrate shared across all parallel streams (unlike iperf3 where `-b` is per-stream). Suggested by the kernel MPTCP maintainer.
- **Random payload mode** (`--random`, issue #34) — client can fill TCP/UDP send buffers with random bytes (once at allocation) to reduce compression/dedup artifacts on shaped/WAN links. Current scope is client-sent payloads only: reverse mode sender remains server-side zeros until protocol negotiation is added.

### Changed
- **Library API** — `create_tcp_listener()`, `connect_tcp()`, and `connect_tcp_with_bind()` now take a `mptcp: bool` parameter. Library consumers should pass `false` to preserve existing behavior.

### Fixed
- **High stream-count TCP robustness** (issues #25, #32) — client now stops local data streams at local duration expiry instead of waiting for server `Result`, scales stream join timeout with stream count (`max(2s, streams*50ms)`), and TCP receivers drain briefly after cancel to reduce reset-on-close bursts. For single-port TCP setup, client also limits concurrent `connect + DataHello` handshakes (max 16 in flight) and server initial first-line read timeout is now adaptive to active stream counts (capped at 20s), reducing mid-test handshake-loss failures on constrained links.
- **Best-effort send shutdown** — `send_data()` shutdown no longer propagates errors during normal teardown races, matching `send_data_half()` behavior.
- **Kernel pacing rate width** — `SO_MAX_PACING_RATE` now uses native `c_ulong` instead of `u32`, removing an unintended ~34 Gbps ceiling on 64-bit Linux.
- **JoinHandle panic with many parallel streams** (issue #24) — removed second `join_all` after aborting timed-out stream tasks, which polled already-completed handles
- **Final summary showing 0 retransmits/RTT/cwnd** (issue #26) — each stream task now captures a final sender-side TCP_INFO snapshot before the socket closes; the Result handler overlays these saved snapshots deterministically instead of racing live fd polls
- **Broken pipe / connection reset at teardown** (issue #25) — client now joins stream task handles with timeout before returning, preventing writes to already-closed sockets
- **MPTCP label in server log** — server now displays "MPTCP" instead of "TCP" in the test info log when client uses `--mptcp`; adds backward-compatible `mptcp` field to TestStart control message

## [0.8.0] - 2026-02-12

### Added
- **Client source port pinning** (`--cport`) - pin the client's local port for firewall traversal (issue #16). Works with UDP and QUIC. Multi-stream UDP (`-P N`) assigns sequential ports starting from the specified port (e.g., `--cport 5300 -P 4` uses ports 5300-5303). QUIC multiplexes all streams on the single specified port. TCP rejects `--cport` since single-port mode already handles firewall traversal. Combines with `--bind` for full control (`--bind 10.0.0.1 --cport 5300`). Automatically matches the remote's address family so `--cport` works transparently with both IPv4 and IPv6 targets.

### Fixed
- **`--bind` with IPv6 targets** — `--bind` with an unspecified IP (e.g., `0.0.0.0:0`) now auto-matches the remote's address family at socket creation time across TCP, UDP, and QUIC. Previously failed when connecting to IPv6 targets from dual-stack clients.
- **UDP data_ports length validation** — server returning mismatched port count could panic on `stats.streams[i]`; now validates length before iterating, matching the existing TCP guard

## [0.7.1] - 2026-02-12

### Fixed
- **Server TUI `-0.0 Mbps` after test ends** (issue #20) - IEEE 754 negative zero now normalized via precision-aware `normalize_for_display()` helper across all throughput display paths
- **TCP RTT/retransmits not updating live** (issue #13) - per-interval retransmits now computed from TCP_INFO deltas instead of a dead atomic counter; client stores socket fds for local TCP_INFO polling so sender-side metrics (upload/bidir) update live; download mode correctly uses server-reported metrics
- **Plain-text zero retransmits dropped** - `rtx: 0` was omitted in plain/JSON/CSV interval output when all streams reported zero retransmits; now preserved
- **`mbps_to_human()` unit-switch boundary** - `999.95 Mbps` displayed as `1000.0 Mbps` instead of `1.00 Gbps`; unit branch now uses rounded value

### Changed
- **Consolidated throughput formatting** - server TUI now uses shared `mbps_to_human()` instead of inline formatting; Gbps display changes from 1 to 2 decimal places for consistency

## [0.7.0] - 2026-02-11

### Added
- **Real pause/resume** (`p` key) - pressing `p` now pauses actual data transfer, not just the TUI display. Uses `Pause`/`Resume` protocol messages and a dedicated `watch` channel to stop/resume data loops across TCP, UDP, and QUIC. Capability-gated via `pause_resume` in Hello messages: older servers without support fall back to display-only pause. TCP bitrate pacing resets its baseline on resume to prevent catch-up bursts. UDP receiver resets its inactivity timer during pause to prevent false timeouts. Resolves issue #19.

## [0.6.1] - 2026-02-10

### Added
- **TCP bitrate pacing** (`-b` for TCP) - `-b` flag now works for TCP, not just UDP. Uses byte-budget sleep pacing with interruptible sleeps for responsive cancellation. Buffer size auto-caps to prevent first-write burst at low bitrates. Resolves issue #14.

## [0.6.0] - 2026-02-06

### Added
- **Congestion control selection** (`--congestion`) - Select TCP congestion control algorithm (e.g. cubic, bbr, reno). Applied on both client and server sockets. Useful for BBR vs CUBIC comparison on WAN/cloud links.
- **Live TCP_INFO polling** - RTT, cwnd now reported per interval during tests, not just in final result. Enables real-time TCP metric monitoring in TUI, plain text (`rtt: X.XXms`), JSON streaming, and CSV output. Essential for `-t 0` infinite tests where results are never finalized (issue #13).

### Fixed
- **Congestion config errors surfaced** - Invalid `--congestion` algorithm is now validated before the test starts; client exits non-zero immediately and server sends an error message back to the client
- **TCP_INFO stale fd cleared** - Stream handlers now clear the stored file descriptor on completion and on early-return error paths, preventing `poll_tcp_info()` from reading an unrelated socket if the OS reuses the fd
- **Update banner double "v" prefix** - Version display now strips leading `v` from update-informer output to avoid showing `vv0.5.0`
- **PSK unwrap panics** - Server no longer panics if PSK is misconfigured during auth; returns error instead
- **UDP encode bounds check** - `UdpPacketHeader::encode()` now validates buffer length before writing
- **Timestamp clock skew** - ISO8601/Unix timestamps now derived from monotonic elapsed time instead of calling `SystemTime::now()`

### Code Quality
- **Named constants** - Replaced 12 hardcoded magic numbers in serve.rs with 6 named constants (STATS_INTERVAL, CANCEL_CHECK_TIMEOUT, RESULT_FLUSH_DELAY, STREAM_ACCEPT_TIMEOUT, STREAM_COLLECTION_TIMEOUT, DEFAULT_BITRATE_BPS)

## [0.5.0] - 2026-02-05

### Changed
- **Single-port TCP mode** (issue #16) - TCP tests now use only port 5201 for all connections, making them firewall-friendly. Data connections identify themselves via `DataHello` message instead of using ephemeral ports.
- **Protocol version bump to 1.1** - Signals DataHello support; adds `single_port_tcp` capability for backward compatibility detection
- **Client capabilities in Hello** - Client now advertises supported capabilities (tcp, udp, quic, multistream, single_port_tcp); server falls back to multi-port TCP for legacy clients without `single_port_tcp`
- **Numeric version comparison** - `versions_compatible()` now parses major version as integer instead of string comparison

### Fixed
- **QUIC IPv6 support** (issue #17) - QUIC clients can now connect to IPv6 addresses without requiring `-6` flag; endpoint now binds to matching address family
- **mDNS discovery** (issue #15) - Server now advertises addresses via `enable_addr_auto()`; client uses non-blocking receive with proper timeout handling
- **TCP RTT and retransmits display** (issue #13) - TUI now shows correct retransmit count from stream results (captured after transfer); TCP_INFO captured after transfer for accurate RTT/cwnd
- **Data connections no longer consume rate-limit/semaphore slots** - Only control (Hello) connections acquire permits; DataHello connections route directly without resource consumption
- **Cancel messages processed during TCP stream collection** - Interval loop now starts immediately; stream collection runs concurrently in background
- **Client OOB panic on port mismatch** - Added bounds check when server returns fewer ports than requested streams
- **DoS guard on oversized lines** - `read_first_line_unbuffered()` now returns error instead of truncating
- **DataHello serialization panic** - Replaced `unwrap()` with proper error handling in spawned task
- **One-off mode deadlock** - `--one-off` no longer blocks the accept loop waiting for test completion; uses shutdown channel to signal exit after test finishes
- **QUIC one-off mode** - QUIC accept loop now responds to shutdown signal for proper `--one-off` exit
- **cancel.changed() busy-loop** - Handle sender-dropped error in stream collection select! to prevent CPU spin
- **IPv4-mapped IPv6 comparison** - DataHello IP validation now normalizes `::ffff:x.x.x.x` addresses for correct matching on dual-stack systems

### Security
- **DataHello IP validation** - Server validates DataHello connections come from same IP as control connection to prevent connection hijacking
- **Slow-loris protection** - Accept loop now spawns per-connection tasks with 5-second initial read timeout; slow clients can no longer block the listener
- **DataHello flood protection** - Server validates test_id exists in active_tests before processing DataHello connections; unknown test_ids are dropped immediately
- **Pre-handshake connection gate** - Limits concurrent unclassified connections (4x max_concurrent) to prevent connection-flood DoS before Hello/DataHello routing
- **Multi-port TCP fallback IP validation** - Per-stream listeners validate connecting peer IP against control connection, preventing unauthorized data stream injection
- **One-off mode hardened** - Failed handshakes and auth failures no longer trigger server shutdown in `--one-off` mode; only successful test completion exits

### Testing
- Added regression test for QUIC IPv6 connectivity
- Added `test_tcp_one_off_multi_stream` - verifies 4-stream TCP in `--one-off` mode with stream count assertion
- Added `test_quic_one_off` - verifies 2-stream QUIC in `--one-off` mode with stream count assertion

### Code Quality
- Log panics from `join_all` in QUIC, UDP, and TCP stream handlers instead of silently discarding JoinErrors
- Multi-port fallback listener tasks cleaned up via cancel signal (no leaked tasks on partial connections)

## [0.4.4] - 2026-02-04

### Changed
- **Lower default max_concurrent** - reduced from 1000 to 100 for safer resource defaults

### Fixed
- **Settings modal text truncation** - increased modal width to prevent help text from being cut off
- **UDP session cleanup on client abort** (issue #12) - server now detects inactive UDP sessions after 30 seconds and cleans them up properly
- **UTF-8 handling in protocol parser** - use lossy conversion to handle partial UTF-8 sequences at buffer boundaries
- **Rate limiter cleanup on panic** - use RAII guard to ensure slot release even if task panics
- **PSK length validation** - reject PSKs over 1024 bytes and empty PSKs to prevent abuse
- **UDP per-stream bitrate underflow** - clamp to minimum 1 bps when total bitrate > 0 to prevent unlimited mode
- **QUIC stream accept timeout** - add 30-second timeout and cancellation support to prevent infinite hangs
- **active_tests cleanup order** - cleanup before result write to prevent stale entries on connection failure

### Testing
- Added regression test for UDP bitrate underflow bug

### Code Quality
- Added SAFETY comments to all 4 unsafe blocks (tcp_info.rs, tcp.rs, net.rs)

### Documentation
- Added server memory footprint guide to README
- Clarified Windows support is experimental (WSL2 recommended)
- Emphasized PSK requirement for QUIC on untrusted networks
- Fixed buffer size documentation (256KB → 128KB)
- Fixed UDP bitrate default documentation (1 Gbps, not unlimited; use `-b 0` for unlimited)
- Documented that data ports are unauthenticated by design
- Updated KNOWN_ISSUES with QUIC cert verification, protocol versioning, Windows limitations
- Added KNOWN_ISSUES entries for UDP data plane spoofing risk and IPv6 zone ID limitation
- Added pre-1.0 roadmap items (structured errors, code refactoring, fuzz testing)
- Expanded roadmap with security enhancements, testing, and optimization items

## [0.4.3] - 2026-02-04

### Added
- **In-app update notifications** - checks GitHub releases in background, shows banner with update command
  - Detects install method (Homebrew, Cargo, binary) and shows appropriate update command
  - Press `u` to dismiss the banner
  - Uses 1-hour cache to avoid GitHub API rate limits
- **Android/Termux support** - pre-built `aarch64-linux-android` binary in releases
- **Infinite duration mode** (`-t 0`) - run test indefinitely until manually stopped with `q` or Ctrl+C
- **Local bind address** (`--bind`) - bind to specific local IP or IP:port for multi-homed hosts
- **Theme hint in footer** - `[t] Theme` now shown in TUI status bar

### Fixed
- **UDP cross-platform compatibility** (issue #10) - UDP mode now works between Linux server and macOS client
  - Client UDP socket now matches server's address family instead of using dual-stack
  - macOS handles dual-stack sockets differently than Linux; this fix ensures compatibility
- **`--bind` with explicit port** - disallows explicit port for TCP (control + data connections would conflict)
- **Non-blocking connect** - added EWOULDBLOCK to Unix error handling for edge cases

## [0.4.2] - 2026-02-03

### Changed
- Removed Intel Mac (x86_64-apple-darwin) pre-built binary - use `cargo install xfr`

### Fixed
- UDP download/bidir race condition: client now retries hello packets

## [0.4.1] - 2026-02-03

### Added
- `-Q` short flag for `--quic` mode (uppercase to distinguish from `-q` quiet)
- Security documentation section in README
- 30-second timeout for control-plane handshakes (prevents DoS from idle connections)
- KNOWN_ISSUES.md documenting edge cases and limitations
- "quic" capability in server Hello message

### Changed
- `-b/--bitrate` help text clarifies it only applies to UDP
- Log messages now go to stderr instead of stdout (allows clean JSON/CSV piping)
- Minimum test duration enforced at 1 second
- Protocol documentation corrected (newline-delimited JSON, not length-prefixed)

### Fixed
- UDP reverse mode (`-u -R`) now works - server learns client address before sending
- UDP bidirectional mode on server now waits for client before sending
- Division by zero guard in throughput calculations for zero-duration tests
- Overflow protection in bitrate/size parsing (checked_mul instead of unchecked)
- Conflicting CLI flags now produce clear errors (`--quic --udp`, `--bidir --reverse`, `--json --csv`)
- Parallel streams validated to 1-128 range (prevents `-P 0` crash)
- Documentation: corrected JSON field names in SCRIPTING.md (bytes_total, duration_ms)
- Documentation: fixed Prometheus flag name in FEATURES.md (--prometheus not --prometheus-port)
- QUIC bitrate warning now logged like TCP when -b flag is ignored

## [0.4.0] - 2026-02-02

### Added
- **Per-stream detail view** (`d` key) - toggle between History and Streams panels for multi-stream tests
  - Shows per-stream throughput bars with retransmit counts
  - Uses existing StreamBar widget for consistent visualization
- **Pause overlay** - prominent "PAUSED" overlay when test is paused (not just footer text)
- **History event logging** - automatically logs significant events:
  - Peak throughput moments (10%+ above previous peak)
  - Retransmit spikes (10+ in an interval)
  - UDP packet loss events (5+ packets lost)
- **Settings modal** (`s` key) - adjust display and test settings on the fly:
  - Display tab: Theme, Timestamp format, Units (auto-persist)
  - Test tab: Streams, Protocol, Duration, Direction (session-only)
  - Vim-style navigation (j/k/h/l) and arrow keys supported
  - Tab key switches between categories
- **QUIC transport** (`--quic`) via quinn crate - built-in TLS 1.3 encryption, stream multiplexing
- **TUI visual overhaul** - cleaner design inspired by ttl:
  - Styled title bar and footer with status display
  - Completion results shown as centered modal overlay
  - Color-coded metrics (retransmits, loss, jitter, RTT)
  - Simplified layout with single outer border
- **Documentation overhaul:**
  - `docs/COMPARISON.md` - Feature matrix vs iperf3/iperf2/rperf/nperf, migration guide
  - `docs/SCRIPTING.md` - CI/CD examples, Docker usage, Prometheus integration
  - `docs/FEATURES.md` - Comprehensive feature reference
  - `docs/ARCHITECTURE.md` - Module structure, data flow, threading model
  - Real-world use cases section in README
  - Enhanced module-level rustdoc for lib.rs, protocol.rs, quic.rs
- `install.sh` - Cross-platform installer script (Linux/macOS)
- `.github/FUNDING.yml` - Ko-fi sponsor link
- QUIC supports upload, download, bidirectional, and multi-stream modes
- QUIC works with PSK authentication

### Removed
- TLS over TCP (`--tls`, `--tls-cert`, `--tls-key`, `--tls-ca`) - replaced by QUIC which provides built-in encryption

### Fixed
- Use VecDeque for interval history to avoid O(n) removal on every interval
- Report per-interval retransmit deltas instead of cumulative totals
- Suppress console logging in TUI mode to prevent log messages corrupting display
- Help modal now opens after test completion (was blocked by key handler)
- Settings modal button cycling when Apply is hidden (only Close visible)
- Rate limiter atomic underflow race condition (use fetch_update instead of fetch_sub)
- Progress bar width now adaptive to terminal size (removed arbitrary 40-char max)

### Security
- Add semaphore to limit concurrent handlers (defense against connection floods on public servers)

### Changed
- Use constant for QUIC buffer size (consistency with TCP module)

### Dependencies
- hyper-util 0.1.19 → 0.1.20
- slab 0.4.11 → 0.4.12
- unicode-width 0.2.0 → 0.2.2
- zmij 1.0.18 → 1.0.19

### Testing
- Add integration tests: UDP bidir, UDP multi-stream, QUIC bidir, ACL deny, IPv6 localhost
- Add protocol parsing benchmarks (serialize/deserialize for Hello, TestStart, Interval, Result)

## [0.3.0] - 2026-01-31

### Added
- **Server TUI dashboard** (`xfr serve --tui`):
  - Real-time display of active tests, bandwidth, and client information
  - Shows blocked connections and authentication failures
  - Uptime counter and total test statistics
  - Help overlay with `?` key
- Timestamp format options (`--timestamp-format`) - relative, iso8601, or unix epoch
- Prometheus Push Gateway support (`--push-gateway`) for pushing metrics at test completion
- File logging with daily rotation (`--log-file`, `--log-level`)
- Integration tests for TCP, UDP, download, bidir, and multi-client modes
- **Security & Enterprise features:**
  - Pre-shared key (PSK) authentication (`--psk`, `--psk-file`)
  - Per-IP rate limiting (`--rate-limit`, `--rate-limit-window`)
  - IP access control lists (`--allow`, `--deny`, `--acl-file`)
- **TUI Improvements:**
  - 11 color themes: default, kawaii, cyber, dracula, monochrome, matrix, nord, gruvbox, catppuccin, tokyo_night, solarized
  - Theme selection via `--theme` flag or config file
  - Press `t` to cycle themes during TUI session
  - UDP-specific stats display (jitter, packet loss %) in TUI
  - Target bitrate shown in header for UDP mode
- **Preferences persistence** (`~/.config/xfr/prefs.toml`)
  - Auto-saves last used theme
  - Remembers user preferences across sessions
- **Full IPv6 support:**
  - `-4`/`--ipv4` and `-6`/`--ipv6` flags for address family selection
  - Dual-stack mode (default): server accepts both IPv4 and IPv6 clients
  - Proper `IPV6_V6ONLY` socket option handling via socket2
  - ACL normalizes IPv4-mapped IPv6 addresses for consistent rule matching
- CSV output format (`--csv`)
- JSON streaming output (`--json-stream`) for real-time per-interval JSON
- Quiet mode (`-q/--quiet`) to suppress interval output
- Custom report interval (`-i/--interval`)
- Omit option (`--omit`) to skip initial TCP ramp-up seconds
- Server max duration (`--max-duration`) for server-side test limits
- Environment variable support: `XFR_PORT` and `XFR_DURATION`
- mDNS service registration on server start for discovery
- send_data_half/receive_data_half for split socket operations

### Fixed
- Stats now shared correctly between handlers and TestStats (real-time intervals)
- Bidirectional mode properly splits sockets for concurrent send/receive
- UDP receive uses recv_from for unconnected sockets
- Server signals cancel when test duration elapses
- Client control loop has 30s timeout to prevent hangs
- Dynamic port allocation prevents multi-client port collisions
- Hostname parsing provides proper error messages
- Interval history bounded to 60 entries to prevent memory growth
- Client cancel() method now functional and sends Cancel to server
- Protocol version checking uses proper comparison function
- Hostname resolution uses resolved IP from control connection for data streams
- TUI stream throughput uses correct 1-second interval calculation
- CSV header columns now match data format
- Socket buffer tuning logs failures at debug level

### Security
- Bounded control channel read to prevent memory DoS (max 8KB lines)
- Validate stream count against MAX_STREAMS (128)
- Enforce MAX_TEST_DURATION (1 hour) and server max_duration
- Add 10s timeout on TCP data connection accept

### Changed
- Replaced emoji indicators with ASCII [OK]/[WARN]/[FAIL] for terminal compatibility
- `BackendType::from_str` and `AddressFamily::from_str` now implement `std::str::FromStr` trait

### Removed
- Unused dependencies: thiserror, bytesize, rand

### Dependencies
- ratatui 0.29 → 0.30 (fixes lru and paste warnings)
- crossterm 0.28 → 0.29
- prometheus 0.13 → 0.14 (fixes protobuf vulnerability RUSTSEC-2024-0437)
- mdns-sd 0.11 → 0.17
- toml 0.8 → 0.9
- dirs 5 → 6
- webpki-roots 0.26 → 1.0
- rand 0.8 → 0.9
- ipnetwork 0.20 → 0.21
- criterion 0.5 → 0.6

## [0.2.0] - 2026-01-31

### Added
- Full Prometheus metrics with per-stream and TCP stats
- Config file support (`~/.config/xfr/config.toml`)
- Server presets for bandwidth limits and client restrictions
- Grafana dashboard template (`examples/grafana-dashboard.json`)
- Man page (`doc/xfr.1`)
- CONTRIBUTING.md guide

### Changed
- Prometheus metrics now properly registered and updated
- CLI arguments can be overridden by config file defaults

## [0.1.2] - 2026-01-31

### Added
- Dual MIT/Apache-2.0 licensing
- README documentation

### Fixed
- License attribution

## [0.1.1] - 2026-01-31 [YANKED]

### Added
- Initial README

## [0.1.0] - 2026-01-31 [YANKED]

### Added
- Initial release
- TCP bandwidth testing with configurable streams
- UDP mode with bitrate limiting and jitter calculation
- Live TUI with real-time throughput graphs
- Multi-client server support
- Reverse and bidirectional testing modes
- JSON output format
- Plain text output format
- Prometheus metrics export (optional feature)
- mDNS LAN discovery (optional feature)
- `xfr diff` command to compare test results
- TCP_INFO stats on Linux and macOS
- Configurable TCP window size and nodelay

[0.9.2]: https://github.com/lance0/xfr/compare/v0.9.1...v0.9.2
[0.9.1]: https://github.com/lance0/xfr/compare/v0.8.0...v0.9.1
[0.8.0]: https://github.com/lance0/xfr/compare/v0.7.1...v0.8.0
[0.7.1]: https://github.com/lance0/xfr/compare/v0.7.0...v0.7.1
[0.7.0]: https://github.com/lance0/xfr/compare/v0.6.1...v0.7.0
[0.6.1]: https://github.com/lance0/xfr/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/lance0/xfr/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/lance0/xfr/compare/v0.4.4...v0.5.0
[0.4.4]: https://github.com/lance0/xfr/compare/v0.4.3...v0.4.4
[0.4.3]: https://github.com/lance0/xfr/compare/v0.4.2...v0.4.3
[0.4.2]: https://github.com/lance0/xfr/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/lance0/xfr/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/lance0/xfr/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/lance0/xfr/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/lance0/xfr/compare/v0.1.2...v0.2.0
[0.1.2]: https://github.com/lance0/xfr/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/lance0/xfr/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/lance0/xfr/releases/tag/v0.1.0
