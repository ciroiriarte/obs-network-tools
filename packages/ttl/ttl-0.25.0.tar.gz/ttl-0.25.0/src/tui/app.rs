use anyhow::Result;
use crossterm::ExecutableCommand;
use crossterm::event::{self, Event, KeyCode, KeyEventKind, KeyModifiers};
use crossterm::terminal::{
    EnterAlternateScreen, LeaveAlternateScreen, disable_raw_mode, enable_raw_mode,
};
use ratatui::Terminal;
use ratatui::backend::CrosstermBackend;
use ratatui::layout::{Constraint, Direction, Layout, Rect};
use ratatui::style::{Modifier, Style};
use ratatui::text::Span;
use ratatui::widgets::{LineGauge, Paragraph};
use scopeguard::defer;
use std::io::stdout;
use std::net::IpAddr;
use std::sync::Arc;
use std::time::Duration;
use tokio_util::sync::CancellationToken;

use crate::export::export_json_file;
use crate::lookup::ix::IxLookup;
use crate::prefs::{DisplayMode, Prefs};
#[cfg(test)]
use crate::state::ProbeOutcome;
use crate::state::{ProbeEvent, Session};
use crate::trace::receiver::SessionMap;
use crate::tui::theme::Theme;
use crate::tui::views::{
    AddTargetRequest, HelpView, HopDetailView, MainView, SettingsState, SettingsView, TargetInfo,
    TargetInputState, TargetInputView, TargetListView, extract_target_infos, fit_text, hint_line,
};

/// State for animated replay playback
pub struct ReplayState {
    /// All events to replay
    pub events: Vec<ProbeEvent>,
    /// Current event index
    pub current_index: usize,
    /// When the replay started (monotonic clock)
    pub replay_started_at: std::time::Instant,
    /// Speed multiplier (1.0 = realtime, 10.0 = 10x speed)
    pub speed_multiplier: f32,
    /// Whether replay is paused
    pub paused: bool,
    /// Whether replay is complete
    pub finished: bool,
    /// Adjusted elapsed ms at time of pause (for accurate resume)
    pub paused_at_elapsed_ms: u64,
    /// The loaded session, source of the per-responder enrichment (hostname,
    /// ASN, geo, IX, ICMP extensions) that events don't carry
    pub source: Option<Session>,
}

impl ReplayState {
    pub fn new(mut events: Vec<ProbeEvent>, speed: f32) -> Self {
        // Sort events by offset to prevent stalled replay from out-of-order events
        events.sort_by_key(|e| e.offset_ms);
        Self {
            events,
            current_index: 0,
            replay_started_at: std::time::Instant::now(),
            speed_multiplier: speed.max(0.1), // Prevent zero/negative speed
            paused: false,
            finished: false,
            paused_at_elapsed_ms: 0,
            source: None,
        }
    }

    /// Apply `events[range]` to `session`, then fill in enrichment for the
    /// responders they introduced from the loaded session.
    fn apply_events(&self, session: &mut Session, range: std::ops::Range<usize>) {
        for event in &self.events[range] {
            session.apply_replay_event(event);
        }
        if let Some(source) = &self.source {
            session.copy_enrichment_from(source);
        }
    }
}

/// Information about skipped IPs during resolution
#[derive(Clone, Default)]
pub struct ResolveInfo {
    pub skipped_ipv4: usize,
    pub skipped_ipv6: usize,
}

/// UI state
#[derive(Default)]
pub struct UiState {
    /// Currently selected hop index (0-indexed into displayed hops)
    pub selected: Option<usize>,
    /// Whether probing is paused
    pub paused: bool,
    /// Show help overlay
    pub show_help: bool,
    /// Scroll offset within help.
    pub help_scroll: u16,
    /// Show expanded hop view
    pub show_hop_detail: bool,
    /// Scroll offset within the expanded hop view.
    pub hop_detail_scroll: u16,
    /// Show settings modal
    pub show_settings: bool,
    /// Settings modal state
    pub settings: SettingsState,
    /// Status message to display
    pub status_message: Option<(String, std::time::Instant)>,
    /// Current theme index
    pub theme_index: usize,
    /// Display mode for column widths (auto/compact/wide)
    pub display_mode: DisplayMode,
    /// Currently selected target index (for multi-target mode)
    pub selected_target: usize,
    /// Show target list overlay
    pub show_target_list: bool,
    /// Selected index in target list overlay
    pub target_list_index: usize,
    /// Update available notification (version string)
    pub update_available: Option<String>,
    /// Receiver for background update check result
    pub update_rx: Option<std::sync::mpsc::Receiver<Option<String>>>,
    /// Replay animation state (None = live mode or static replay)
    pub replay_state: Option<ReplayState>,
    /// Cached target list info (populated when overlay is open, refreshed every 30 ticks)
    pub target_list_cache: Option<Vec<TargetInfo>>,
    /// Tick counter for target list cache refresh
    pub target_list_tick: u32,
    /// Show target input modal
    pub show_target_input: bool,
    /// Target input modal state
    pub target_input: TargetInputState,
    /// Update check is off for this run via --no-update-check or env opt-out,
    /// so the settings toggle shows off and can't be flipped.
    pub update_check_locked: bool,
}

impl UiState {
    pub fn set_status(&mut self, msg: impl Into<String>) {
        self.status_message = Some((msg.into(), std::time::Instant::now()));
    }

    pub fn clear_old_status(&mut self) {
        if let Some((_, time)) = &self.status_message
            && time.elapsed() > Duration::from_secs(3)
        {
            self.status_message = None;
        }
    }
}

/// Address, name, hops, loss and RTT of one target-list row.
type TargetRow = (IpAddr, String, String, String, String);

/// Post-poll render fingerprint. Built after status expiry,
/// add-target, update check, IX cache status, and target-list refresh so
/// idle skip cannot leave those chrome surfaces stale.
#[derive(Clone, Debug, PartialEq, Eq)]
struct RenderFingerprint {
    session_generation: Option<u64>,
    selected: Option<usize>,
    paused: bool,
    show_help: bool,
    help_scroll: u16,
    show_hop_detail: bool,
    hop_detail_scroll: u16,
    show_settings: bool,
    show_target_list: bool,
    show_target_input: bool,
    theme_index: usize,
    display_mode: crate::prefs::DisplayMode,
    selected_target: usize,
    num_targets: usize,
    target_list_index: usize,
    status: Option<String>,
    update_available: Option<String>,
    replay: Option<(bool, bool, usize, u64, u32)>,
    target_input: (String, usize, Option<String>, bool),
    settings: (
        usize,
        usize,
        usize,
        crate::prefs::DisplayMode,
        String,
        usize,
        bool,
    ),
    ix_cache: Option<(bool, usize, Option<u64>, bool, bool)>,
    target_list_rows: Option<Vec<TargetRow>>,
}

fn render_fingerprint(
    ui_state: &UiState,
    num_targets: usize,
    session_generation: Option<u64>,
    cache_status: Option<&crate::lookup::ix::CacheStatus>,
) -> RenderFingerprint {
    // Exhaustive destructures, deliberately without `..`: adding a field to
    // any of these structs fails to compile here until it is either
    // fingerprinted or explicitly bound to `_`, so new render-relevant state
    // cannot silently render late.
    let UiState {
        selected,
        paused,
        show_help,
        help_scroll,
        show_hop_detail,
        hop_detail_scroll,
        show_settings,
        settings,
        status_message,
        theme_index,
        display_mode,
        selected_target,
        show_target_list,
        target_list_index,
        update_available,
        update_rx: _,
        replay_state,
        target_list_cache,
        target_list_tick: _,
        show_target_input,
        target_input,
        update_check_locked: _, // fixed for the whole run; settings.update_check is hashed
    } = ui_state;
    let SettingsState {
        selected_section,
        theme_scroll,
        theme_index: settings_theme_index,
        display_mode: settings_display_mode,
        api_key,
        api_key_cursor,
        update_check,
    } = settings;
    let TargetInputState {
        input,
        cursor,
        error,
        resolving,
        pending: _,
    } = target_input;
    let replay = replay_state.as_ref().map(|r| {
        let ReplayState {
            events: _, // fixed after load
            current_index,
            replay_started_at: _, // both clock fields feed replay_current_ms(r)
            speed_multiplier,
            paused: replay_paused,
            finished,
            paused_at_elapsed_ms: _,
            source: _, // fixed after load
        } = r;
        (
            *replay_paused,
            *finished,
            *current_index,
            replay_current_ms(r),
            speed_multiplier.to_bits(),
        )
    });
    RenderFingerprint {
        session_generation,
        selected: *selected,
        paused: *paused,
        show_help: *show_help,
        help_scroll: *help_scroll,
        show_hop_detail: *show_hop_detail,
        hop_detail_scroll: *hop_detail_scroll,
        show_settings: *show_settings,
        show_target_list: *show_target_list,
        show_target_input: *show_target_input,
        theme_index: *theme_index,
        display_mode: *display_mode,
        selected_target: *selected_target,
        num_targets,
        target_list_index: *target_list_index,
        status: status_message.as_ref().map(|(m, _)| m.clone()),
        update_available: update_available.clone(),
        replay,
        target_input: (input.clone(), *cursor, error.clone(), *resolving),
        settings: (
            *selected_section,
            *theme_scroll,
            *settings_theme_index,
            *settings_display_mode,
            api_key.clone(),
            *api_key_cursor,
            *update_check,
        ),
        ix_cache: cache_status.map(|c| {
            let crate::lookup::ix::CacheStatus {
                loaded,
                prefix_count,
                fetched_at,
                expired,
                refreshing,
            } = c;
            (*loaded, *prefix_count, *fetched_at, *expired, *refreshing)
        }),
        target_list_rows: target_list_cache.as_ref().map(|rows| {
            rows.iter()
                .map(|t| {
                    let TargetInfo {
                        ip,
                        hostname,
                        hops_str,
                        loss_str,
                        rtt_str,
                    } = t;
                    (
                        *ip,
                        hostname.clone(),
                        hops_str.clone(),
                        loss_str.clone(),
                        rtt_str.clone(),
                    )
                })
                .collect()
        }),
    }
}

fn poll_update_check(ui_state: &mut UiState) {
    if let (None, Some(rx)) = (&ui_state.update_available, &ui_state.update_rx) {
        match rx.try_recv() {
            Ok(result) => {
                ui_state.update_available = result;
                ui_state.update_rx = None;
            }
            Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                ui_state.update_rx = None;
            }
            Err(std::sync::mpsc::TryRecvError::Empty) => {}
        }
    }
}

fn refresh_target_list_cache(ui_state: &mut UiState, sessions: &SessionMap, targets: &[IpAddr]) {
    if ui_state.show_target_list {
        ui_state.target_list_tick += 1;
        if ui_state.target_list_cache.is_none() || ui_state.target_list_tick.is_multiple_of(30) {
            ui_state.target_list_cache = Some(extract_target_infos(sessions, targets));
        }
    } else {
        ui_state.target_list_cache = None;
        ui_state.target_list_tick = 0;
    }
}

/// Help overlay keys: page by the visible rows so PgUp/PgDn never skip lines;
/// any other key closes it.
fn handle_help_key(ui_state: &mut UiState, code: KeyCode, area: Rect, theme: &Theme) {
    let page = HelpView::visible_rows(area).max(1);
    let max_scroll = HelpView::new(theme)
        .with_replay(ui_state.replay_state.is_some())
        .with_update(ui_state.update_available.is_some())
        .max_scroll(area);
    let scroll = ui_state.help_scroll.min(max_scroll);
    ui_state.help_scroll = match code {
        KeyCode::PageUp => scroll.saturating_sub(page),
        KeyCode::PageDown => scroll.saturating_add(page).min(max_scroll),
        KeyCode::Home => 0,
        KeyCode::End => max_scroll,
        _ => {
            ui_state.show_help = false;
            scroll
        }
    };
}

/// Run the TUI application. Returns the final preferences for persistence.
#[allow(clippy::too_many_arguments)]
pub async fn run_tui(
    sessions: SessionMap,
    targets: Vec<IpAddr>,
    cancel: CancellationToken,
    initial_prefs: Prefs,
    resolve_info: Option<ResolveInfo>,
    ix_lookup: Option<Arc<IxLookup>>,
    update_rx: Option<std::sync::mpsc::Receiver<Option<String>>>,
    replay_state: Option<ReplayState>,
    add_target_tx: Option<tokio::sync::mpsc::UnboundedSender<AddTargetRequest>>,
    update_check_locked: bool,
) -> Result<Prefs> {
    // Setup terminal
    enable_raw_mode()?;
    stdout().execute(EnterAlternateScreen)?;

    // Ensure terminal is restored on any exit (success, error, or panic)
    defer! {
        let _ = disable_raw_mode();
        let _ = stdout().execute(LeaveAlternateScreen);
    }

    let backend = CrosstermBackend::new(stdout());
    let mut terminal = Terminal::new(backend)?;

    // Find initial theme index
    let theme_names = Theme::list();
    let initial_theme = Theme::by_name(initial_prefs.theme.as_deref().unwrap_or("default"));
    let initial_index = theme_names
        .iter()
        .position(|&name| Theme::by_name(name).name() == initial_theme.name())
        .unwrap_or(0);

    let display_mode = initial_prefs.display_mode.unwrap_or_default();
    let api_key = initial_prefs.peeringdb_api_key.clone();

    let mut settings = SettingsState::new(initial_index, display_mode, api_key);
    // Toggle shows "enabled"; the pref stores the negated "disabled" form.
    let saved_no_update_check = initial_prefs.no_update_check;
    settings.update_check = !update_check_locked && !saved_no_update_check.unwrap_or(false);

    let mut ui_state = UiState {
        theme_index: initial_index,
        display_mode,
        settings,
        update_rx,
        replay_state,
        update_check_locked,
        ..Default::default()
    };
    let tick_rate = Duration::from_millis(16); // ~60fps for responsive per-probe updates

    // Show initial status if resolve_info is present and multiple targets
    if let Some(info) = resolve_info {
        let skip_msg = if info.skipped_ipv6 > 0 {
            format!(" ({} IPv6 skipped)", info.skipped_ipv6)
        } else if info.skipped_ipv4 > 0 {
            format!(" ({} IPv4 skipped)", info.skipped_ipv4)
        } else {
            String::new()
        };
        if targets.len() > 1 {
            ui_state.set_status(format!(
                "Resolved {} targets{}; press l to list",
                targets.len(),
                skip_msg
            ));
        }
    }

    let event_rx = spawn_event_reader(tick_rate, cancel.clone());
    run_app(
        &mut terminal,
        sessions,
        targets,
        &mut ui_state,
        cancel.clone(),
        tick_rate,
        ix_lookup.clone(),
        add_target_tx,
        event_rx,
    )
    .await?;

    // Return final preferences for persistence
    let final_api_key = if ui_state.settings.api_key.is_empty() {
        None
    } else {
        Some(ui_state.settings.api_key.clone())
    };

    Ok(Prefs {
        theme: Some(theme_names[ui_state.theme_index].to_string()),
        display_mode: Some(ui_state.display_mode),
        peeringdb_api_key: final_api_key,
        // Toggle holds "enabled"; persist the negated "disabled" form. A
        // flag/env lock is per-run, so leave the saved choice alone.
        no_update_check: if update_check_locked {
            saved_no_update_check
        } else {
            Some(!ui_state.settings.update_check)
        },
    })
}

/// Flip the settings update-check toggle unless --no-update-check / env
/// opt-out has it locked off for this run.
fn toggle_update_check(ui_state: &mut UiState) {
    if ui_state.update_check_locked {
        ui_state.set_status(
            "Update check disabled by --no-update-check or DO_NOT_TRACK/TTL_NO_UPDATE_CHECK",
        );
    } else {
        ui_state.settings.update_check = !ui_state.settings.update_check;
    }
}

/// Toggle pause/resume for replay animation
fn toggle_replay_pause(ui_state: &mut UiState) {
    if let Some(ref mut replay) = ui_state.replay_state {
        if replay.paused {
            // RESUMING: Restore start time from the elapsed time we recorded at pause
            rebase_replay_start(replay, replay.paused_at_elapsed_ms);
            replay.paused = false;
            ui_state.set_status("Replay resumed");
        } else {
            // PAUSING: Record exactly how far into the replay we are (in adjusted ms)
            replay.paused_at_elapsed_ms = replay_current_ms(replay);
            replay.paused = true;
            ui_state.set_status("Replay paused. Press p or Space to resume.");
        }
    }
}

/// Format milliseconds as human-readable time (e.g., "1:23.4" or "5.2s")
fn format_replay_time(ms: u64) -> String {
    let secs = ms / 1000;
    let frac = (ms % 1000) / 100;
    let mins = secs / 60;
    let secs_rem = secs % 60;
    if mins > 0 {
        format!("{}:{:02}.{}", mins, secs_rem, frac)
    } else {
        format!("{}.{}s", secs_rem, frac)
    }
}

/// Get the current adjusted elapsed time in replay milliseconds
fn replay_current_ms(replay: &ReplayState) -> u64 {
    if replay.paused {
        replay.paused_at_elapsed_ms
    } else if replay.finished {
        replay.events.last().map_or(0, |e| e.offset_ms)
    } else {
        let elapsed_ms = replay.replay_started_at.elapsed().as_secs_f64() * 1000.0;
        let adjusted = elapsed_ms * replay.speed_multiplier as f64;
        adjusted.clamp(0.0, u64::MAX as f64) as u64
    }
}

/// Convert replay timeline ms into wall-clock duration at the current speed.
fn replay_wall_offset(replay_ms: u64, speed_multiplier: f32) -> Duration {
    let speed = speed_multiplier.max(0.1) as f64;
    let wall_ms = (replay_ms as f64 / speed).clamp(0.0, u64::MAX as f64);
    Duration::from_millis(wall_ms as u64)
}

/// Rebase replay start instant so replay_current_ms() resolves to target replay ms.
fn rebase_replay_start(replay: &mut ReplayState, replay_ms: u64) {
    let now = std::time::Instant::now();
    let offset = replay_wall_offset(replay_ms, replay.speed_multiplier);
    // Guard against malformed/very-large replay timestamps.
    replay.replay_started_at = now.checked_sub(offset).unwrap_or(now);
}

/// Compute replay event index for a requested timeline position.
/// target_ms=0 maps to index 0 (pre-first-event) for Home key semantics.
fn replay_event_index_for_time(events: &[ProbeEvent], target_ms: u64) -> usize {
    if target_ms == 0 {
        0
    } else {
        events.partition_point(|e| e.offset_ms <= target_ms)
    }
}

/// Human-friendly replay position label for status messages.
fn format_replay_position(
    target_ms: u64,
    total_duration: u64,
    target_index: usize,
    total_events: usize,
) -> String {
    if total_events == 0 {
        "empty replay (0/0 events)".to_string()
    } else if target_index == 0 {
        format!("start (event 0/{})", total_events)
    } else if target_index >= total_events {
        if total_duration == 0 {
            format!(
                "end (event {}/{}, instant timeline)",
                target_index, total_events
            )
        } else {
            format!(
                "end {} (event {}/{})",
                format_replay_time(total_duration),
                target_index,
                total_events
            )
        }
    } else {
        format!(
            "{} (event {}/{})",
            format_replay_time(target_ms),
            target_index,
            total_events
        )
    }
}

/// Seek replay to an absolute time position (in replay milliseconds).
/// Rebuilds session state from scratch for backward seeks.
fn seek_replay_to(
    ui_state: &mut UiState,
    sessions: &SessionMap,
    target_ip: IpAddr,
    target_ms: u64,
) {
    // Extract what we need from replay_state, then release the borrow
    let (total_duration, target_index, current_index, total_events) = {
        let replay = match ui_state.replay_state.as_ref() {
            Some(r) => r,
            None => return,
        };
        let total_duration = replay.events.last().map_or(0, |e| e.offset_ms);
        let target_ms = target_ms.min(total_duration);
        let target_index = replay_event_index_for_time(&replay.events, target_ms);
        (
            total_duration,
            target_index,
            replay.current_index,
            replay.events.len(),
        )
    };

    let target_ms = target_ms.min(total_duration);

    if target_index == current_index {
        let replay = ui_state.replay_state.as_mut().unwrap();
        replay.paused = true;
        replay.paused_at_elapsed_ms = target_ms;
        replay.finished = target_index >= total_events;
        ui_state.set_status(format!(
            "Already at {}",
            format_replay_position(target_ms, total_duration, target_index, total_events)
        ));
        return;
    }

    if target_index <= current_index {
        // Backward seek: rebuild session from scratch
        let replay = ui_state.replay_state.as_ref().unwrap();
        let sessions_read = sessions.read();
        if let Some(session_lock) = sessions_read.get(&target_ip) {
            let mut session = session_lock.write();
            let target = session.target.clone();
            let config = session.config.clone();
            *session = Session::new(target, config);
            replay.apply_events(&mut session, 0..target_index);
        }
    } else {
        // Forward seek: apply events incrementally
        let replay = ui_state.replay_state.as_ref().unwrap();
        let sessions_read = sessions.read();
        if let Some(session_lock) = sessions_read.get(&target_ip) {
            let mut session = session_lock.write();
            replay.apply_events(&mut session, current_index..target_index);
        }
    }

    // Now mutate replay state
    let replay = ui_state.replay_state.as_mut().unwrap();
    replay.paused = true;
    replay.paused_at_elapsed_ms = target_ms;
    replay.finished = target_index >= total_events;
    replay.current_index = target_index;

    ui_state.set_status(format!(
        "Moved to {}",
        format_replay_position(target_ms, total_duration, target_index, total_events)
    ));
}

/// Seek replay to the final event position (all events applied).
fn seek_replay_to_end(ui_state: &mut UiState, sessions: &SessionMap, target_ip: IpAddr) {
    let (total_duration, target_index, current_index) = {
        let replay = match ui_state.replay_state.as_ref() {
            Some(r) => r,
            None => return,
        };
        (
            replay.events.last().map_or(0, |e| e.offset_ms),
            replay.events.len(),
            replay.current_index,
        )
    };

    if target_index > current_index {
        let replay = ui_state.replay_state.as_ref().unwrap();
        let sessions_read = sessions.read();
        if let Some(session_lock) = sessions_read.get(&target_ip) {
            let mut session = session_lock.write();
            replay.apply_events(&mut session, current_index..target_index);
        }
    }

    let replay = ui_state.replay_state.as_mut().unwrap();
    replay.paused = true;
    replay.paused_at_elapsed_ms = total_duration;
    replay.finished = true;
    replay.current_index = target_index;

    ui_state.set_status(format!(
        "Moved to {}",
        format_replay_position(total_duration, total_duration, target_index, target_index)
    ));
}

/// Compute a replay target time from current position + signed delta using saturation.
fn replay_target_ms_from_delta(current_ms: u64, delta_ms: i64) -> u64 {
    if delta_ms >= 0 {
        current_ms.saturating_add(delta_ms as u64)
    } else {
        current_ms.saturating_sub(delta_ms.unsigned_abs())
    }
}

/// Seek replay by a relative delta (in replay milliseconds). Negative values seek backward.
fn seek_replay(ui_state: &mut UiState, sessions: &SessionMap, target_ip: IpAddr, delta_ms: i64) {
    let current_ms = match ui_state.replay_state.as_ref() {
        Some(r) => replay_current_ms(r),
        None => return,
    };
    let target_ms = replay_target_ms_from_delta(current_ms, delta_ms);
    seek_replay_to(ui_state, sessions, target_ip, target_ms);
}

/// Adjust replay speed by delta, preserving current position
fn adjust_replay_speed(ui_state: &mut UiState, delta: f32) {
    let new_speed = {
        let replay = match ui_state.replay_state.as_mut() {
            Some(r) => r,
            None => return,
        };
        let current_ms = replay_current_ms(replay);
        replay.speed_multiplier = (replay.speed_multiplier + delta).clamp(0.1, 1000.0);

        if !replay.paused {
            rebase_replay_start(replay, current_ms);
        }

        replay.speed_multiplier
    };

    ui_state.set_status(format!("Speed: {:.1}x", new_speed));
}

/// Spawn a dedicated blocking thread to read crossterm events.
///
/// `event::poll` and `event::read` are blocking calls that must not run on the
/// async executor — they'd stall the tokio runtime for up to `tick_rate` each
/// iteration. A bounded channel wakes the async loop as input arrives while
/// applying backpressure to large pastes without an unbounded event queue.
///
/// The thread exits when `cancel` fires or the receiver is dropped.
fn spawn_event_reader(
    tick_rate: Duration,
    cancel: CancellationToken,
) -> tokio::sync::mpsc::Receiver<Event> {
    let (tx, rx) = tokio::sync::mpsc::channel::<Event>(256);

    std::thread::spawn(move || {
        while !cancel.is_cancelled() && !tx.is_closed() {
            if event::poll(tick_rate).unwrap_or(false)
                && let Ok(ev) = event::read()
                && tx.blocking_send(ev).is_err()
            {
                // Receiver dropped — TUI is shutting down.
                break;
            }
        }
    });

    rx
}

#[allow(clippy::too_many_arguments)]
async fn run_app<B>(
    terminal: &mut Terminal<B>,
    sessions: SessionMap,
    mut targets: Vec<IpAddr>,
    ui_state: &mut UiState,
    cancel: CancellationToken,
    tick_rate: Duration,
    ix_lookup: Option<Arc<IxLookup>>,
    add_target_tx: Option<tokio::sync::mpsc::UnboundedSender<AddTargetRequest>>,
    mut event_rx: tokio::sync::mpsc::Receiver<Event>,
) -> Result<()>
where
    B: ratatui::backend::Backend,
    B::Error: Send + Sync + 'static,
{
    let theme_names = Theme::list();
    let mut next_frame = tokio::time::Instant::now();
    let mut last_draw: Option<RenderFingerprint> = None;
    let ix_enabled = ix_lookup.is_some();

    loop {
        // Check cancellation
        if cancel.is_cancelled() {
            break;
        }

        let now = tokio::time::Instant::now();
        let frame_due = now >= next_frame;
        if frame_due {
            next_frame = now + tick_rate;
        }

        // Clear old status messages
        ui_state.clear_old_status();

        // Poll for a pending add-target result (non-blocking)
        poll_add_target_result(ui_state, &mut targets, &sessions);

        // Targets can grow at runtime via the add-target modal.
        // Compute count AFTER polling so newly added targets are reflected this tick.
        let num_targets = targets.len();

        poll_update_check(ui_state);

        // Process replay animation tick
        if let Some(ref mut replay) = ui_state.replay_state
            && !replay.paused
            && !replay.finished
        {
            // Calculate elapsed replay time (adjusted for speed)
            let adjusted_elapsed = replay_current_ms(replay);

            // Capture target before acquiring locks to prevent race condition
            // (replay mode always has exactly one target)
            if let Some(target_ip) = targets.get(ui_state.selected_target).copied() {
                // Find all events up to current adjusted time
                let start = replay.current_index;
                let mut end = start;
                while end < replay.events.len() && replay.events[end].offset_ms <= adjusted_elapsed
                {
                    end += 1;
                }

                // Apply all events in a single lock acquisition (no per-event lock churn)
                if end > start {
                    let sessions_read = sessions.read();
                    if let Some(session_lock) = sessions_read.get(&target_ip) {
                        let mut session = session_lock.write();
                        replay.apply_events(&mut session, start..end);
                    }
                    replay.current_index = end;
                }

                // Check if replay is complete
                if replay.current_index >= replay.events.len() {
                    replay.finished = true;
                    ui_state.set_status("Replay complete");
                }
            }
        }

        // Get current theme
        let theme = Theme::by_name(theme_names[ui_state.theme_index]);

        // Get current target's session. With no targets yet (interactive empty
        // mode) the unspecified sentinel never matches a session, so all
        // session-dependent key handlers below no-op gracefully.
        let current_target = targets
            .get(ui_state.selected_target)
            .copied()
            .unwrap_or(IpAddr::V4(std::net::Ipv4Addr::UNSPECIFIED));

        // Get cache status for settings modal
        let cache_status = ix_lookup.as_ref().map(|ix| ix.get_cache_status());

        // Snapshot only when dirty so no locks are held during rendering.
        if frame_due || (ui_state.show_target_list && ui_state.target_list_cache.is_none()) {
            refresh_target_list_cache(ui_state, &sessions, &targets);
        }

        // Fingerprint after polls so status expiry, add-target, update
        // check, IX cache, and target-list rows participate.
        let session_generation = {
            let sessions_read = sessions.read();
            sessions_read
                .get(&current_target)
                .map(|state| state.read().render_generation)
        };
        let fingerprint = render_fingerprint(
            ui_state,
            num_targets,
            session_generation,
            cache_status.as_ref(),
        );
        let dirty = last_draw.as_ref() != Some(&fingerprint);

        if dirty && frame_due {
            let session_snapshot = {
                let sessions_read = sessions.read();
                sessions_read
                    .get(&current_target)
                    .map(|state| state.read().snapshot_for_render())
            };

            if let Some(ref session) = session_snapshot {
                terminal.draw(|f| {
                    draw_ui(
                        f,
                        session,
                        ui_state,
                        &theme,
                        num_targets,
                        cache_status.clone(),
                        ix_enabled,
                    );
                })?;
            } else {
                terminal.draw(|f| {
                    draw_empty_state(f, ui_state, &theme, cache_status.clone(), ix_enabled);
                })?;
            }
            last_draw = Some(fingerprint);
        }
        // Input and cancellation wake immediately. Rendering stays capped at
        // the frame interval, so a burst changes state without drawing/sleeping
        // once per key. The timer still polls probe/update/status changes.
        let event = tokio::select! {
            biased;
            _ = cancel.cancelled() => break,
            received = event_rx.recv() => match received {
                Some(event) => Some(event),
                None => break,
            },
            _ = tokio::time::sleep_until(next_frame) => None,
        };
        // A resize changes the layout without touching any fingerprinted state,
        // so force the next tick to draw (terminal.draw re-measures the area).
        if matches!(event, Some(Event::Resize(..))) {
            last_draw = None;
        }
        if let Some(Event::Key(key)) = event {
            if key.kind != KeyEventKind::Press {
                continue;
            }

            // Ctrl-C is global, including overlays that accept text input.
            if (key.code == KeyCode::Char('c') && key.modifiers.contains(KeyModifiers::CONTROL))
                || key.code == KeyCode::Char('\x03')
            {
                cancel.cancel();
                break;
            }

            // Handle overlays first
            if ui_state.show_help {
                let size = terminal.size()?;
                handle_help_key(
                    ui_state,
                    key.code,
                    Rect::new(0, 0, size.width, size.height),
                    &theme,
                );
                continue;
            }

            if ui_state.show_target_input {
                handle_target_input_key(key.code, key.modifiers, ui_state, &add_target_tx);
                continue;
            }

            if ui_state.show_settings {
                // PeeringDB section (section 2) - handle text input
                if ui_state.settings.selected_section == 2 && ix_enabled {
                    match key.code {
                        KeyCode::Esc => {
                            // Close settings and apply changes
                            ui_state.theme_index = ui_state.settings.theme_index;
                            ui_state.display_mode = ui_state.settings.display_mode;
                            // Update IxLookup with new API key if provided
                            if let Some(ref ix) = ix_lookup {
                                let key = if ui_state.settings.api_key.is_empty() {
                                    None
                                } else {
                                    Some(ui_state.settings.api_key.clone())
                                };
                                ix.set_api_key(key);
                            }
                            ui_state.show_settings = false;
                        }
                        KeyCode::Tab => {
                            ui_state.settings.next_section(ix_enabled);
                        }
                        KeyCode::Char('r') if key.modifiers.contains(KeyModifiers::CONTROL) => {
                            // Ctrl+R: Refresh PeeringDB cache
                            if let Some(ref ix) = ix_lookup {
                                ix.refresh_cache();
                                ui_state.set_status("Refreshing PeeringDB cache...");
                            }
                        }
                        KeyCode::Backspace => {
                            ui_state.settings.handle_backspace();
                        }
                        KeyCode::Delete => {
                            ui_state.settings.handle_delete();
                        }
                        KeyCode::Left => {
                            ui_state.settings.move_cursor_left();
                        }
                        KeyCode::Right => {
                            ui_state.settings.move_cursor_right();
                        }
                        KeyCode::Char(c) => {
                            // Insert character (except 'r' which is handled above)
                            ui_state.settings.handle_char(c);
                        }
                        _ => {}
                    }
                    continue;
                }

                // Theme/Display Mode sections - normal navigation
                match key.code {
                    KeyCode::Esc => {
                        // Close settings and apply changes
                        ui_state.theme_index = ui_state.settings.theme_index;
                        ui_state.display_mode = ui_state.settings.display_mode;
                        // Update IxLookup with new API key if provided
                        if let Some(ref ix) = ix_lookup {
                            let key = if ui_state.settings.api_key.is_empty() {
                                None
                            } else {
                                Some(ui_state.settings.api_key.clone())
                            };
                            ix.set_api_key(key);
                        }
                        ui_state.show_settings = false;
                    }
                    KeyCode::Up | KeyCode::Char('k') => {
                        ui_state.settings.move_up(theme_names.len());
                        // Live preview theme changes
                        ui_state.theme_index = ui_state.settings.theme_index;
                    }
                    KeyCode::Down | KeyCode::Char('j') => {
                        ui_state.settings.move_down(theme_names.len());
                        // Live preview theme changes
                        ui_state.theme_index = ui_state.settings.theme_index;
                    }
                    KeyCode::Tab => {
                        ui_state.settings.next_section(ix_enabled);
                    }
                    KeyCode::Enter | KeyCode::Char(' ') => {
                        if ui_state.settings.selected_section
                            == SettingsState::update_check_section(ix_enabled)
                        {
                            toggle_update_check(ui_state);
                        } else {
                            ui_state.settings.select();
                            // Live preview display mode changes
                            ui_state.display_mode = ui_state.settings.display_mode;
                        }
                    }
                    _ => {}
                }
                continue;
            }

            if ui_state.show_hop_detail {
                let size = terminal.size()?;
                let area = Rect::new(0, 0, size.width, size.height);
                // Page by the visible rows so PgUp/PgDn never skip detail lines.
                let page = HopDetailView::visible_rows(area).max(1);
                let (hop_count, max_scroll) = {
                    let sessions_read = sessions.read();
                    let current_target = targets[ui_state.selected_target];
                    sessions_read
                        .get(&current_target)
                        .map(|state| {
                            let session = state.read();
                            let hops: Vec<_> = session.hops.iter().filter(|h| h.sent > 0).collect();
                            let max_scroll = ui_state
                                .selected
                                .and_then(|selected| hops.get(selected))
                                .map(|hop| {
                                    HopDetailView::new(hop, &Theme::default()).max_scroll(area)
                                })
                                .unwrap_or(0);
                            (hops.len(), max_scroll)
                        })
                        .unwrap_or((0, 0))
                };
                ui_state.hop_detail_scroll = ui_state.hop_detail_scroll.min(max_scroll);

                match key.code {
                    KeyCode::Up | KeyCode::Char('k') => {
                        ui_state.hop_detail_scroll = 0;
                        if let Some(sel) = ui_state.selected {
                            ui_state.selected = Some(sel.saturating_sub(1));
                        }
                    }
                    KeyCode::Down | KeyCode::Char('j') => {
                        ui_state.hop_detail_scroll = 0;
                        if let Some(sel) = ui_state.selected {
                            ui_state.selected = Some((sel + 1).min(hop_count.saturating_sub(1)));
                        }
                    }
                    KeyCode::Char(c @ '1'..='9') => {
                        ui_state.hop_detail_scroll = 0;
                        let idx = (c as usize - '1' as usize).min(hop_count.saturating_sub(1));
                        ui_state.selected = Some(idx);
                    }
                    KeyCode::PageUp => {
                        ui_state.hop_detail_scroll =
                            ui_state.hop_detail_scroll.saturating_sub(page);
                    }
                    KeyCode::PageDown => {
                        ui_state.hop_detail_scroll = ui_state
                            .hop_detail_scroll
                            .saturating_add(page)
                            .min(max_scroll);
                    }
                    KeyCode::Home => ui_state.hop_detail_scroll = 0,
                    KeyCode::End => ui_state.hop_detail_scroll = max_scroll,
                    KeyCode::Esc | KeyCode::Enter | KeyCode::Char('q') => {
                        ui_state.show_hop_detail = false;
                    }
                    _ => {}
                }
                continue;
            }

            if ui_state.show_target_list {
                match key.code {
                    KeyCode::Esc => {
                        ui_state.show_target_list = false;
                    }
                    KeyCode::Enter => {
                        // Extract pause state BEFORE closing dialog to avoid lock contention
                        let new_target_idx = ui_state.target_list_index;
                        let target = targets[new_target_idx];
                        let paused = {
                            let sessions_read = sessions.read();
                            sessions_read
                                .get(&target)
                                .map(|state| state.read().paused)
                                .unwrap_or(false)
                        };
                        // Now update UI state (no locks held)
                        ui_state.selected_target = new_target_idx;
                        ui_state.selected = None;
                        ui_state.show_target_list = false;
                        ui_state.paused = paused;
                    }
                    KeyCode::Up | KeyCode::Char('k') => {
                        if ui_state.target_list_index > 0 {
                            ui_state.target_list_index -= 1;
                        } else {
                            ui_state.target_list_index = num_targets - 1;
                        }
                    }
                    KeyCode::Down | KeyCode::Char('j') => {
                        ui_state.target_list_index = (ui_state.target_list_index + 1) % num_targets;
                    }
                    KeyCode::Char(c) if c.is_ascii_digit() => {
                        // Jump to target by number (1-9) and select
                        let num = c.to_digit(10).unwrap() as usize;
                        if num >= 1 && num <= num_targets {
                            let new_target_idx = num - 1;
                            let target = targets[new_target_idx];
                            let paused = {
                                let sessions_read = sessions.read();
                                sessions_read
                                    .get(&target)
                                    .map(|state| state.read().paused)
                                    .unwrap_or(false)
                            };
                            ui_state.selected_target = new_target_idx;
                            ui_state.target_list_index = new_target_idx;
                            ui_state.selected = None;
                            ui_state.show_target_list = false;
                            ui_state.paused = paused;
                        }
                    }
                    _ => {}
                }
                continue;
            }

            match key.code {
                KeyCode::Char('q') => {
                    cancel.cancel();
                    break;
                }
                KeyCode::Char('?') | KeyCode::Char('h') => {
                    ui_state.show_help = true;
                    ui_state.help_scroll = 0;
                }
                // Target switching
                KeyCode::Tab | KeyCode::Char('n') if num_targets > 1 => {
                    let new_idx = (ui_state.selected_target + 1) % num_targets;
                    let target = targets[new_idx];
                    // Extract pause state before updating UI to avoid lock contention
                    let paused = {
                        let sessions_read = sessions.read();
                        sessions_read
                            .get(&target)
                            .map(|state| state.read().paused)
                            .unwrap_or(false)
                    };
                    ui_state.selected_target = new_idx;
                    ui_state.selected = None;
                    ui_state.paused = paused;
                    ui_state.set_status(format!(
                        "Target {}/{}: {}",
                        new_idx + 1,
                        num_targets,
                        target
                    ));
                }
                KeyCode::BackTab | KeyCode::Char('N') if num_targets > 1 => {
                    let new_idx = if ui_state.selected_target == 0 {
                        num_targets - 1
                    } else {
                        ui_state.selected_target - 1
                    };
                    let target = targets[new_idx];
                    // Extract pause state before updating UI to avoid lock contention
                    let paused = {
                        let sessions_read = sessions.read();
                        sessions_read
                            .get(&target)
                            .map(|state| state.read().paused)
                            .unwrap_or(false)
                    };
                    ui_state.selected_target = new_idx;
                    ui_state.selected = None;
                    ui_state.paused = paused;
                    ui_state.set_status(format!(
                        "Target {}/{}: {}",
                        new_idx + 1,
                        num_targets,
                        target
                    ));
                }
                KeyCode::Char('p') => {
                    if ui_state.replay_state.is_some() {
                        // In replay mode, 'p' toggles replay pause (same as Space)
                        toggle_replay_pause(ui_state);
                    } else {
                        // In live mode, 'p' toggles probe engine pause
                        match toggle_live_pause(&mut *ui_state, &sessions, current_target) {
                            Some(true) => ui_state.set_status("Paused"),
                            Some(false) => ui_state.set_status("Resumed"),
                            None => ui_state.set_status(READ_ONLY_STATUS),
                        }
                    }
                }
                KeyCode::Char('r') => {
                    // Reset the selected target's statistics. A session loaded
                    // from a file has no live epoch, so resetting it would only
                    // blank a read-only view and poison a later `e` export.
                    let reset = reset_stats_if_live(ui_state, &sessions, current_target);
                    ui_state.set_status(if reset {
                        "Stats reset"
                    } else {
                        READ_ONLY_STATUS
                    });
                }
                KeyCode::Char('t') => {
                    // Cycle through themes
                    ui_state.theme_index = (ui_state.theme_index + 1) % theme_names.len();
                    ui_state.settings.theme_index = ui_state.theme_index;
                    let new_theme = theme_names[ui_state.theme_index];
                    ui_state.set_status(format!("Theme: {}", new_theme));
                }
                KeyCode::Char('w') => {
                    // Cycle through display modes (auto -> compact -> wide -> auto)
                    ui_state.display_mode = ui_state.display_mode.next();
                    ui_state.settings.display_mode = ui_state.display_mode;
                    ui_state.set_status(format!("Display: {}", ui_state.display_mode.label()));
                }
                KeyCode::Char('s') => {
                    // Open settings modal - preserve existing API key and the
                    // update-check toggle across opens.
                    let current_api_key = if ui_state.settings.api_key.is_empty() {
                        None
                    } else {
                        Some(ui_state.settings.api_key.clone())
                    };
                    let update_check = ui_state.settings.update_check;
                    ui_state.settings = SettingsState::new(
                        ui_state.theme_index,
                        ui_state.display_mode,
                        current_api_key,
                    );
                    ui_state.settings.update_check = update_check;
                    ui_state.show_settings = true;
                }
                // Open target input modal (live mode only)
                KeyCode::Char('o')
                    if ui_state.replay_state.is_none() && add_target_tx.is_some() =>
                {
                    ui_state.target_input = TargetInputState::default();
                    ui_state.show_target_input = true;
                }
                // Open target list overlay (only in multi-target mode)
                KeyCode::Char('l') if num_targets > 1 => {
                    ui_state.target_list_index = ui_state.selected_target;
                    ui_state.show_target_list = true;
                    ui_state.target_list_cache = Some(extract_target_infos(&sessions, &targets));
                    ui_state.target_list_tick = 0;
                }
                // Dismiss update notification
                KeyCode::Char('u') if ui_state.update_available.is_some() => {
                    ui_state.update_available = None;
                }
                KeyCode::Char('e') => {
                    // Clone session data before releasing lock to avoid holding lock during I/O
                    let session_clone = {
                        let sessions_read = sessions.read();
                        sessions_read
                            .get(&current_target)
                            .map(|state| state.read().clone())
                    };
                    if let Some(session) = session_clone {
                        match export_json_file(&session) {
                            Ok(filename) => {
                                ui_state.set_status(format!("Exported to {}", filename));
                            }
                            Err(e) => {
                                ui_state.set_status(format!("Export failed: {}", e));
                            }
                        }
                    }
                }
                KeyCode::Char(' ') => {
                    // Space works the same as 'p': replay pause or live pause
                    if ui_state.replay_state.is_some() {
                        toggle_replay_pause(ui_state);
                    } else {
                        match toggle_live_pause(&mut *ui_state, &sessions, current_target) {
                            Some(true) => ui_state.set_status("Paused"),
                            Some(false) => ui_state.set_status("Resumed"),
                            None => ui_state.set_status(READ_ONLY_STATUS),
                        }
                    }
                }
                KeyCode::Up | KeyCode::Char('k') => {
                    // Extract hop_count quickly, then release lock before updating UI
                    let hop_count = {
                        let sessions_read = sessions.read();
                        sessions_read
                            .get(&current_target)
                            .map(|state| state.read().hops.iter().filter(|h| h.sent > 0).count())
                            .unwrap_or(0)
                    };
                    if hop_count > 0 {
                        ui_state.selected = Some(match ui_state.selected {
                            Some(i) if i > 0 => i - 1,
                            Some(_) => hop_count - 1,
                            None => hop_count - 1,
                        });
                    }
                }
                KeyCode::Down | KeyCode::Char('j') => {
                    let hop_count = {
                        let sessions_read = sessions.read();
                        sessions_read
                            .get(&current_target)
                            .map(|state| state.read().hops.iter().filter(|h| h.sent > 0).count())
                            .unwrap_or(0)
                    };
                    if hop_count > 0 {
                        ui_state.selected = Some(match ui_state.selected {
                            Some(i) if i < hop_count - 1 => i + 1,
                            Some(_) => 0,
                            None => 0,
                        });
                    }
                }
                KeyCode::Enter if ui_state.selected.is_some() => {
                    ui_state.hop_detail_scroll = 0;
                    ui_state.show_hop_detail = true;
                }
                KeyCode::Esc => {
                    ui_state.selected = None;
                }
                // Replay controls
                KeyCode::Left if ui_state.replay_state.is_some() => {
                    seek_replay(ui_state, &sessions, current_target, -500);
                }
                KeyCode::Right if ui_state.replay_state.is_some() => {
                    seek_replay(ui_state, &sessions, current_target, 500);
                }
                KeyCode::Char('[') if ui_state.replay_state.is_some() => {
                    seek_replay(ui_state, &sessions, current_target, -5000);
                }
                KeyCode::Char(']') if ui_state.replay_state.is_some() => {
                    seek_replay(ui_state, &sessions, current_target, 5000);
                }
                KeyCode::Char('+') | KeyCode::Char('>') if ui_state.replay_state.is_some() => {
                    adjust_replay_speed(ui_state, 0.5);
                }
                KeyCode::Char('-') | KeyCode::Char('<') if ui_state.replay_state.is_some() => {
                    adjust_replay_speed(ui_state, -0.5);
                }
                KeyCode::Home if ui_state.replay_state.is_some() => {
                    seek_replay_to(ui_state, &sessions, current_target, 0);
                }
                KeyCode::End if ui_state.replay_state.is_some() => {
                    seek_replay_to_end(ui_state, &sessions, current_target);
                }
                _ => {}
            }
        }
    }

    Ok(())
}

/// Status shown when a read-only (replay) session is asked to change state.
const READ_ONLY_STATUS: &str = "Replay is read-only";

/// Toggle the probe-engine pause for a live session, returning the new state.
/// `None` for a session loaded from a file: it has no engine to pause, so
/// toggling it would only mislabel the title badge.
fn toggle_live_pause(
    ui_state: &mut UiState,
    sessions: &SessionMap,
    target: IpAddr,
) -> Option<bool> {
    let sessions_read = sessions.read();
    let state = sessions_read.get(&target)?;
    let mut session = state.write();
    // A session loaded from a file has no live epoch and no engine to pause.
    session.started_instant?;
    session.paused = !session.paused;
    ui_state.paused = session.paused;
    Some(session.paused)
}

/// Reset a live session's statistics. Returns false when the session came from
/// a file, where resetting would erase the recording from the view and from a
/// later `e` export. An animated replay draws into a fresh session that does
/// have a live epoch, so it is checked separately: a reset there would blank
/// the hops mid-playback and later events would rebuild only part of them.
fn reset_stats_if_live(ui_state: &UiState, sessions: &SessionMap, target: IpAddr) -> bool {
    if ui_state.replay_state.is_some() {
        return false;
    }
    let sessions_read = sessions.read();
    let Some(state) = sessions_read.get(&target) else {
        return false;
    };
    let mut session = state.write();
    if session.started_instant.is_none() {
        return false;
    }
    session.reset_stats();
    true
}

/// Poll the pending add-target reply; on success the new target joins the
/// rotation and becomes selected.
fn poll_add_target_result(
    ui_state: &mut UiState,
    targets: &mut Vec<IpAddr>,
    sessions: &SessionMap,
) {
    let Some(rx) = ui_state.target_input.pending.as_mut() else {
        return;
    };
    match rx.try_recv() {
        Ok(Ok(added)) => {
            ui_state.target_input = TargetInputState::default();
            ui_state.show_target_input = false;
            if !targets.contains(&added.ip) {
                targets.push(added.ip);
            }
            if let Some(idx) = targets.iter().position(|t| *t == added.ip) {
                ui_state.selected_target = idx;
                ui_state.selected = None;
            }
            // A target that joins while monitoring is paused must not start
            // probing: the title badge and the engine would otherwise disagree.
            // Re-adding a target that already exists only selects it, so the
            // badge follows that session instead of pausing it.
            if let Some(state) = sessions.read().get(&added.ip) {
                if added.existed {
                    ui_state.paused = state.read().paused;
                } else if ui_state.paused {
                    state.write().paused = true;
                }
            }
            if added.existed {
                ui_state.set_status(format!("Already tracing {} ({})", added.name, added.ip));
            } else {
                ui_state.set_status(format!("Added target {} ({})", added.name, added.ip));
            }
        }
        Ok(Err(msg)) => {
            ui_state.target_input.pending = None;
            ui_state.target_input.resolving = false;
            ui_state.target_input.error = Some(msg);
        }
        Err(tokio::sync::oneshot::error::TryRecvError::Empty) => {}
        Err(tokio::sync::oneshot::error::TryRecvError::Closed) => {
            ui_state.target_input.pending = None;
            ui_state.target_input.resolving = false;
            ui_state.target_input.error = Some("Target manager unavailable".to_string());
        }
    }
}

/// Key handling for the target input modal
fn handle_target_input_key(
    code: KeyCode,
    modifiers: KeyModifiers,
    ui_state: &mut UiState,
    add_target_tx: &Option<tokio::sync::mpsc::UnboundedSender<AddTargetRequest>>,
) {
    match code {
        KeyCode::Esc => {
            ui_state.target_input = TargetInputState::default();
            ui_state.show_target_input = false;
        }
        KeyCode::Enter => {
            let host = ui_state.target_input.input.trim().to_string();
            if host.is_empty() || ui_state.target_input.resolving {
                return;
            }
            let Some(tx) = add_target_tx else { return };
            let (reply_tx, reply_rx) = tokio::sync::oneshot::channel();
            if tx
                .send(AddTargetRequest {
                    host,
                    reply: reply_tx,
                })
                .is_ok()
            {
                ui_state.target_input.pending = Some(reply_rx);
                ui_state.target_input.resolving = true;
                ui_state.target_input.error = None;
            } else {
                ui_state.target_input.error = Some("Target manager unavailable".to_string());
            }
        }
        KeyCode::Backspace => ui_state.target_input.handle_backspace(),
        KeyCode::Delete => ui_state.target_input.handle_delete(),
        KeyCode::Left => ui_state.target_input.move_cursor_left(),
        KeyCode::Right => ui_state.target_input.move_cursor_right(),
        KeyCode::Char(c) if !modifiers.contains(KeyModifiers::CONTROL) => {
            ui_state.target_input.handle_char(c);
        }
        _ => {}
    }
}

/// Replay position label: `▶ 0:45 / 4:23 · 5× `.
fn replay_label(replay: &ReplayState, current_ms: u64, total_ms: u64) -> String {
    let icon = if replay.finished {
        "■"
    } else if replay.paused {
        "‖"
    } else {
        "▶"
    };
    let speed = replay.speed_multiplier;
    let speed = if speed.fract() == 0.0 {
        format!("{speed:.0}×")
    } else {
        format!("{speed:.1}×")
    };
    let clock = |ms: u64| format!("{}:{:02}", ms / 60_000, ms / 1000 % 60);
    let time = if total_ms == 0 && !replay.events.is_empty() {
        "instant".to_string()
    } else {
        format!("{} / {}", clock(current_ms), clock(total_ms))
    };
    format!("{icon} {time} · {speed} ")
}

/// Bottom row: key hints on the left. A transient status message sits
/// right-aligned on the same row, so it never hides the hints entirely.
fn draw_status_bar(
    f: &mut ratatui::Frame,
    area: Rect,
    hints: &[(&str, &str)],
    ui_state: &UiState,
    theme: &Theme,
) {
    // Inset to line up with the table content inside its border.
    let area = Rect {
        x: area.x.saturating_add(1),
        width: area.width.saturating_sub(2),
        ..area
    };
    let mut hint_width = area.width;
    if let Some((message, _)) = &ui_state.status_message {
        // Keep room for the highest-priority hint: a message that spans the
        // whole bar would otherwise blank every key hint on the row.
        let reserved =
            hint_line(&hints[..hints.len().min(1)], area.width, theme).width() as u16 + 2;
        let message = fit_text(message, area.width.saturating_sub(reserved));
        let width = Span::raw(&message).width() as u16;
        hint_width = area.width.saturating_sub(width + 2);
        f.render_widget(
            Paragraph::new(message).style(Style::default().fg(theme.text)),
            Rect {
                x: area.right() - width,
                width,
                ..area
            },
        );
    }
    f.render_widget(
        Paragraph::new(hint_line(hints, hint_width, theme)),
        Rect {
            width: hint_width,
            ..area
        },
    );
}

/// Draw the empty state shown when no targets are being traced yet
fn draw_empty_state(
    f: &mut ratatui::Frame,
    ui_state: &UiState,
    theme: &Theme,
    cache_status: Option<crate::lookup::ix::CacheStatus>,
    ix_enabled: bool,
) {
    let area = f.area();
    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Min(0), Constraint::Length(1)])
        .split(area);

    let lines = vec![
        ratatui::text::Line::default(),
        ratatui::text::Line::styled(
            format!("ttl v{}", env!("CARGO_PKG_VERSION")),
            Style::default().fg(theme.header),
        ),
        ratatui::text::Line::default(),
        ratatui::text::Line::styled("No targets yet", Style::default().fg(theme.text_dim)),
        ratatui::text::Line::default(),
        ratatui::text::Line::styled("Press 'o' to add a target", Style::default().fg(theme.text)),
    ];
    let empty = Paragraph::new(lines).alignment(ratatui::layout::Alignment::Center);
    f.render_widget(empty, chunks[0]);

    draw_status_bar(
        f,
        chunks[1],
        &[
            ("?", "help"),
            ("q", "quit"),
            ("o", "add target"),
            ("t", "theme"),
            ("s", "settings"),
        ],
        ui_state,
        theme,
    );

    // Overlays available in empty mode
    if ui_state.show_help {
        f.render_widget(
            HelpView::new(theme)
                .with_replay(false)
                .with_update(ui_state.update_available.is_some())
                .with_scroll(ui_state.help_scroll),
            area,
        );
    }
    if ui_state.show_settings {
        let theme_names = Theme::list();
        f.render_widget(
            SettingsView::new(
                theme,
                &ui_state.settings,
                theme_names,
                cache_status,
                ix_enabled,
            )
            .with_update_locked(ui_state.update_check_locked),
            area,
        );
    }
    if ui_state.show_target_input {
        f.render_widget(TargetInputView::new(theme, &ui_state.target_input), area);
    }
}

#[allow(clippy::too_many_arguments)]
fn draw_ui(
    f: &mut ratatui::Frame,
    session: &Session,
    ui_state: &UiState,
    theme: &Theme,
    num_targets: usize,
    cache_status: Option<crate::lookup::ix::CacheStatus>,
    ix_enabled: bool,
) {
    let area = f.area();

    // Layout: optional update banner + main view + optional replay progress + status bar
    let has_update = ui_state.update_available.is_some();
    let has_replay = ui_state.replay_state.is_some();
    let mut constraints = Vec::new();
    if has_update {
        constraints.push(Constraint::Length(1)); // Update banner
    }
    constraints.push(Constraint::Min(0)); // Main view
    if has_replay {
        constraints.push(Constraint::Length(1)); // Replay progress bar
    }
    constraints.push(Constraint::Length(1)); // Status bar

    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints(constraints)
        .split(area);

    // Assign chunk indices based on which optional rows are present
    let mut idx = 0;

    // Update notification banner (if available)
    if has_update {
        if let Some(ref version) = ui_state.update_available {
            let chunk = Rect {
                x: chunks[idx].x.saturating_add(1),
                width: chunks[idx].width.saturating_sub(2),
                ..chunks[idx]
            };
            let mut line = ratatui::text::Line::from(vec![
                Span::styled(
                    " UPDATE ",
                    Style::default()
                        .fg(theme.warning)
                        .add_modifier(Modifier::BOLD | Modifier::REVERSED),
                ),
                Span::styled(
                    format!(" v{} → {}  ", env!("CARGO_PKG_VERSION"), version),
                    Style::default().fg(theme.text),
                ),
            ]);
            let room = chunk.width.saturating_sub(line.width() as u16);
            line.spans
                .extend(hint_line(&[("u", "dismiss"), ("?", "update command")], room, theme).spans);
            f.render_widget(Paragraph::new(line), chunk);
        }
        idx += 1;
    }

    let main_chunk = chunks[idx];
    idx += 1;

    let progress_chunk = if has_replay {
        let chunk = chunks[idx];
        idx += 1;
        Some(chunk)
    } else {
        None
    };

    let status_chunk = chunks[idx];

    // Main view (with target indicator and display mode)
    let main_view = MainView::new(session, ui_state.selected, ui_state.paused, theme)
        .with_target_info(ui_state.selected_target + 1, num_targets)
        .with_display_mode(ui_state.display_mode);
    f.render_widget(main_view, main_chunk);

    // Replay progress bar
    if let (Some(chunk), Some(replay)) = (progress_chunk, &ui_state.replay_state) {
        let current_ms = replay_current_ms(replay);
        let total_ms = replay.events.last().map_or(0, |e| e.offset_ms);
        let label = replay_label(replay, current_ms, total_ms);
        let ratio = if total_ms > 0 {
            (current_ms as f64 / total_ms as f64).clamp(0.0, 1.0)
        } else {
            0.0
        };
        let gauge = LineGauge::default()
            .filled_style(Style::default().fg(theme.header))
            .unfilled_style(Style::default().fg(theme.text_dim))
            .label(Span::styled(label, Style::default().fg(theme.text)))
            .ratio(ratio);
        // Inset to line up with the table content.
        f.render_widget(
            gauge,
            Rect {
                x: chunk.x.saturating_add(1),
                width: chunk.width.saturating_sub(2),
                ..chunk
            },
        );
    }

    // Hints in priority order; the lowest-priority pairs drop first.
    let hints: &[(&str, &str)] = if ui_state.replay_state.is_some() {
        &[
            ("?", "help"),
            ("q", "quit"),
            ("p", "pause"),
            ("←/→", "seek"),
            ("[/]", "seek 5s"),
            ("+/-", "speed"),
            ("Home/End", "jump"),
            ("Enter", "details"),
        ]
    } else if num_targets > 1 {
        &[
            ("?", "help"),
            ("q", "quit"),
            ("Enter", "details"),
            ("p", "pause"),
            ("Tab", "next"),
            ("l", "list"),
            ("o", "add"),
            ("s", "settings"),
            ("t", "theme"),
            ("w", "display"),
            ("r", "reset"),
            ("e", "export"),
        ]
    } else if session.started_instant.is_none() {
        // Static replay of a loaded file: nothing probes, so pausing, resetting
        // and adding targets do nothing.
        &[
            ("?", "help"),
            ("q", "quit"),
            ("Enter", "details"),
            ("s", "settings"),
            ("t", "theme"),
            ("w", "display"),
            ("e", "export"),
        ]
    } else {
        &[
            ("?", "help"),
            ("q", "quit"),
            ("Enter", "details"),
            ("p", "pause"),
            ("o", "add"),
            ("s", "settings"),
            ("t", "theme"),
            ("w", "display"),
            ("r", "reset"),
            ("e", "export"),
        ]
    };
    draw_status_bar(f, status_chunk, hints, ui_state, theme);

    // Overlays
    if ui_state.show_help {
        f.render_widget(
            HelpView::new(theme)
                .with_replay(ui_state.replay_state.is_some())
                .with_update(ui_state.update_available.is_some())
                .with_scroll(ui_state.help_scroll),
            area,
        );
    }

    if ui_state.show_settings {
        let theme_names = Theme::list();
        f.render_widget(
            SettingsView::new(
                theme,
                &ui_state.settings,
                theme_names,
                cache_status,
                ix_enabled,
            )
            .with_update_locked(ui_state.update_check_locked),
            area,
        );
    }

    if ui_state.show_hop_detail
        && let Some(selected) = ui_state.selected
    {
        let hops: Vec<_> = session.hops.iter().filter(|h| h.sent > 0).collect();
        if let Some(hop) = hops.get(selected) {
            f.render_widget(
                HopDetailView::new(hop, theme).with_scroll(ui_state.hop_detail_scroll),
                area,
            );
        }
    }

    if ui_state.show_target_list
        && let Some(ref infos) = ui_state.target_list_cache
    {
        f.render_widget(
            TargetListView::new(theme, infos, ui_state.target_list_index),
            area,
        );
    }

    if ui_state.show_target_input {
        f.render_widget(TargetInputView::new(theme, &ui_state.target_input), area);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::Config;
    use crate::state::SessionLock;
    use crate::state::Target;
    use std::collections::HashMap;
    use std::net::{IpAddr, Ipv4Addr};
    use std::sync::Arc;

    fn make_single_session_map(target: IpAddr, session: Session) -> SessionMap {
        let mut map = HashMap::new();
        map.insert(target, Arc::new(SessionLock::new(session)));
        Arc::new(parking_lot::RwLock::new(map))
    }

    fn key(code: KeyCode, modifiers: KeyModifiers) -> Event {
        Event::Key(crossterm::event::KeyEvent::new(code, modifiers))
    }

    #[tokio::test]
    async fn queued_input_is_processed_without_waiting_for_frames() {
        use ratatui::backend::TestBackend;
        let ip: IpAddr = "192.0.2.1".parse().unwrap();
        let mut session = Session::new(Target::new("example.net".into(), ip), Config::default());
        for hop in &mut session.hops {
            hop.sent = 1;
        }
        let sessions = make_single_session_map(ip, session);
        let (tx, rx) = tokio::sync::mpsc::channel(256);
        for _ in 0..80 {
            tx.try_send(key(KeyCode::Char('j'), KeyModifiers::NONE))
                .unwrap();
        }
        tx.try_send(key(KeyCode::Char('p'), KeyModifiers::NONE))
            .unwrap();
        tx.try_send(key(KeyCode::Char('c'), KeyModifiers::CONTROL))
            .unwrap();
        let mut terminal = Terminal::new(TestBackend::new(80, 24)).unwrap();
        let mut state = UiState::default();
        let cancel = CancellationToken::new();
        tokio::time::timeout(
            Duration::from_millis(500),
            run_app(
                &mut terminal,
                sessions.clone(),
                vec![ip],
                &mut state,
                cancel.clone(),
                Duration::from_secs(1),
                None,
                None,
                rx,
            ),
        )
        .await
        .unwrap()
        .unwrap();
        assert!(state.selected.is_some());
        assert!(state.paused);
        assert!(sessions.read().get(&ip).unwrap().read().paused);
        assert!(cancel.is_cancelled());
        assert_eq!(
            terminal.get_frame().count(),
            1,
            "burst should not draw per key"
        );
    }

    #[tokio::test]
    async fn ctrl_c_quits_from_every_overlay_and_text_input() {
        use ratatui::backend::TestBackend;
        for code in [
            key(KeyCode::Char('c'), KeyModifiers::CONTROL),
            key(KeyCode::Char('\x03'), KeyModifiers::NONE),
        ] {
            for overlay in 0..6 {
                let ip: IpAddr = "192.0.2.1".parse().unwrap();
                let sessions = make_single_session_map(
                    ip,
                    Session::new(Target::new("example.net".into(), ip), Config::default()),
                );
                let mut state = UiState {
                    show_help: overlay == 0,
                    show_settings: overlay == 1,
                    show_hop_detail: overlay == 2,
                    show_target_list: overlay == 3,
                    show_target_input: overlay == 4,
                    ..UiState::default()
                };
                let (tx, rx) = tokio::sync::mpsc::channel(2);
                tx.try_send(code.clone()).unwrap();
                let cancel = CancellationToken::new();
                let mut terminal = Terminal::new(TestBackend::new(80, 24)).unwrap();
                tokio::time::timeout(
                    Duration::from_millis(500),
                    run_app(
                        &mut terminal,
                        sessions,
                        vec![ip],
                        &mut state,
                        cancel.clone(),
                        Duration::from_secs(1),
                        None,
                        None,
                        rx,
                    ),
                )
                .await
                .unwrap()
                .unwrap();
                assert!(cancel.is_cancelled(), "overlay {overlay}");
                assert!(state.target_input.input.is_empty());
            }
        }
    }

    #[tokio::test]
    async fn cancellation_wakes_an_idle_ui_without_waiting_for_a_frame() {
        use ratatui::backend::TestBackend;
        let cancel = CancellationToken::new();
        let trigger = cancel.clone();
        let (tx, rx) = tokio::sync::mpsc::channel(1);
        let mut terminal = Terminal::new(TestBackend::new(80, 24)).unwrap();
        let mut state = UiState::default();
        let sessions = Arc::new(parking_lot::RwLock::new(HashMap::new()));
        let stop = async {
            tokio::task::yield_now().await;
            trigger.cancel();
        };
        let run = run_app(
            &mut terminal,
            sessions,
            vec![],
            &mut state,
            cancel,
            Duration::from_secs(60),
            None,
            None,
            rx,
        );
        let (result, ()) = tokio::time::timeout(Duration::from_millis(500), async {
            tokio::join!(run, stop)
        })
        .await
        .unwrap();
        result.unwrap();
        drop(tx);
    }

    fn make_timeout_event(offset_ms: u64, ttl: u8, seq: u8) -> ProbeEvent {
        ProbeEvent {
            offset_ms,
            ttl,
            seq,
            flow_id: 0,
            outcome: ProbeOutcome::Timeout,
        }
    }

    #[test]
    fn replay_label_shows_clock_and_speed_without_event_counts() {
        let mut replay = ReplayState::new(vec![make_timeout_event(263_000, 1, 0)], 5.0);
        assert_eq!(
            replay_label(&replay, 45_000, 263_000),
            "▶ 0:45 / 4:23 · 5× "
        );
        replay.paused = true;
        replay.speed_multiplier = 2.5;
        assert_eq!(replay_label(&replay, 0, 263_000), "‖ 0:00 / 4:23 · 2.5× ");
    }

    #[test]
    fn test_replay_event_index_for_time_home_is_empty() {
        let events = vec![make_timeout_event(0, 1, 0), make_timeout_event(100, 1, 1)];
        assert_eq!(replay_event_index_for_time(&events, 0), 0);
    }

    #[test]
    fn test_replay_event_index_for_time_end_includes_all() {
        let events = vec![make_timeout_event(0, 1, 0), make_timeout_event(100, 1, 1)];
        assert_eq!(replay_event_index_for_time(&events, 100), 2);
    }

    #[test]
    fn test_adjust_replay_speed_clamps() {
        let mut ui_state = UiState {
            replay_state: Some(ReplayState::new(Vec::new(), 0.1)),
            ..UiState::default()
        };
        adjust_replay_speed(&mut ui_state, -0.5);
        assert_eq!(
            ui_state.replay_state.as_ref().unwrap().speed_multiplier,
            0.1
        );

        ui_state.replay_state.as_mut().unwrap().speed_multiplier = 1000.0;
        adjust_replay_speed(&mut ui_state, 0.5);
        assert_eq!(
            ui_state.replay_state.as_ref().unwrap().speed_multiplier,
            1000.0
        );
    }

    #[test]
    fn test_rebase_replay_start_handles_large_timestamps() {
        let mut replay = ReplayState::new(Vec::new(), 1.0);
        rebase_replay_start(&mut replay, u64::MAX);
    }

    #[test]
    fn test_replay_target_ms_from_delta_saturates() {
        assert_eq!(replay_target_ms_from_delta(1000, -500), 500);
        assert_eq!(replay_target_ms_from_delta(1000, -5000), 0);
        assert_eq!(replay_target_ms_from_delta(u64::MAX - 10, 100), u64::MAX);
        assert_eq!(replay_target_ms_from_delta(u64::MAX, i64::MAX), u64::MAX);
    }

    #[test]
    fn test_seek_replay_to_end_applies_all_zero_offset_events() {
        let target = IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8));
        let session = Session::new(Target::new("t".to_string(), target), Config::default());
        let sessions = make_single_session_map(target, session);
        let events = vec![make_timeout_event(0, 1, 0), make_timeout_event(0, 2, 1)];

        let mut ui_state = UiState {
            replay_state: Some(ReplayState {
                events,
                current_index: 0,
                replay_started_at: std::time::Instant::now(),
                speed_multiplier: 1.0,
                paused: false,
                finished: false,
                paused_at_elapsed_ms: 0,
                source: None,
            }),
            ..UiState::default()
        };

        seek_replay_to_end(&mut ui_state, &sessions, target);

        let session_lock = sessions.read().get(&target).cloned().unwrap();
        let session = session_lock.read();
        assert_eq!(session.total_sent, 2);
        assert_eq!(session.hop(1).unwrap().timeouts, 1);
        assert_eq!(session.hop(2).unwrap().timeouts, 1);

        let replay = ui_state.replay_state.as_ref().unwrap();
        assert!(replay.finished);
        assert_eq!(replay.current_index, 2);
    }

    #[test]
    fn animated_replay_carries_enrichment_from_loaded_session() {
        use crate::state::session::AsnInfo;
        let target = IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8));
        let router = IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1));
        let fresh = || Session::new(Target::new("t".to_string(), target), Config::default());

        // Loaded session: hop 1 responder enriched by the original run
        let mut loaded = fresh();
        let hop = loaded.hop_mut(1).unwrap();
        hop.record_response(router, Duration::from_millis(1));
        let stats = hop.responders.get_mut(&router).unwrap();
        stats.hostname = Some("gw.example".into());
        stats.asn = Some(AsnInfo {
            number: 64500,
            name: "EXAMPLE".into(),
            prefix: Some("10.0.0.0/8".into()),
        });

        let sessions = make_single_session_map(target, fresh());
        let mut replay = ReplayState::new(
            vec![ProbeEvent {
                offset_ms: 0,
                ttl: 1,
                seq: 0,
                flow_id: 0,
                outcome: ProbeOutcome::Reply {
                    addr: router,
                    rtt_us: 1000,
                },
            }],
            1.0,
        );
        replay.source = Some(loaded);
        let mut ui_state = UiState {
            replay_state: Some(replay),
            ..UiState::default()
        };

        seek_replay_to_end(&mut ui_state, &sessions, target);

        let session_lock = sessions.read().get(&target).cloned().unwrap();
        let session = session_lock.read();
        let stats = &session.hop(1).unwrap().responders[&router];
        assert_eq!(stats.hostname.as_deref(), Some("gw.example"));
        assert_eq!(stats.asn.as_ref().map(|a| a.number), Some(64500));
    }

    #[test]
    fn test_seek_replay_to_same_position_is_noop_for_session_state() {
        let target = IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1));
        let session = Session::new(Target::new("t".to_string(), target), Config::default());
        let sessions = make_single_session_map(target, session);
        let events = vec![make_timeout_event(100, 1, 0)];

        let mut ui_state = UiState {
            replay_state: Some(ReplayState {
                events,
                current_index: 0,
                replay_started_at: std::time::Instant::now(),
                speed_multiplier: 1.0,
                paused: false,
                finished: false,
                paused_at_elapsed_ms: 0,
                source: None,
            }),
            ..UiState::default()
        };

        seek_replay_to(&mut ui_state, &sessions, target, 0);

        let session_lock = sessions.read().get(&target).cloned().unwrap();
        let session = session_lock.read();
        assert_eq!(session.total_sent, 0);
        assert_eq!(session.hop(1).unwrap().sent, 0);

        let replay = ui_state.replay_state.as_ref().unwrap();
        assert_eq!(replay.current_index, 0);
        assert!(replay.paused);
    }

    #[test]
    fn test_fingerprint_changes_when_status_expires() {
        let mut ui_state = UiState {
            status_message: Some((
                "Working".to_string(),
                std::time::Instant::now() - Duration::from_secs(4),
            )),
            ..UiState::default()
        };
        let before = render_fingerprint(&ui_state, 1, Some(0), None);
        ui_state.clear_old_status();
        let after = render_fingerprint(&ui_state, 1, Some(0), None);
        assert!(ui_state.status_message.is_none());
        assert_ne!(before, after);
    }

    #[test]
    fn test_fingerprint_changes_on_add_target_poll() {
        let existing = IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1));
        let added = IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8));
        let mut targets = vec![existing];
        let mut ui_state = UiState {
            target_input: TargetInputState {
                resolving: true,
                ..TargetInputState::default()
            },
            show_target_input: true,
            ..UiState::default()
        };
        let (tx, rx) = tokio::sync::oneshot::channel();
        ui_state.target_input.pending = Some(rx);
        let sessions: SessionMap = make_single_session_map(existing, {
            Session::new(
                Target::new("one.one.one.one".into(), existing),
                Config::default(),
            )
        });
        let before = render_fingerprint(&ui_state, targets.len(), Some(0), None);
        tx.send(Ok(crate::tui::views::AddedTarget {
            ip: added,
            name: "dns.google".to_string(),
            existed: false,
        }))
        .unwrap();
        poll_add_target_result(&mut ui_state, &mut targets, &sessions);
        let after = render_fingerprint(&ui_state, targets.len(), Some(0), None);
        assert_eq!(targets, vec![existing, added]);
        assert_eq!(ui_state.selected_target, 1);
        assert!(!ui_state.show_target_input);
        assert!(ui_state.status_message.is_some());
        assert_ne!(before, after);
    }

    #[test]
    fn target_added_while_paused_does_not_start_probing() {
        let added = IpAddr::V4(Ipv4Addr::new(8, 8, 8, 8));
        for paused in [true, false] {
            let session = Session::new(Target::new("dns.google".into(), added), Config::default());
            let sessions = make_single_session_map(added, session);
            let mut targets = Vec::new();
            let mut ui_state = UiState {
                paused,
                ..UiState::default()
            };
            let (tx, rx) = tokio::sync::oneshot::channel();
            ui_state.target_input.pending = Some(rx);
            tx.send(Ok(crate::tui::views::AddedTarget {
                ip: added,
                name: "dns.google".to_string(),
                existed: false,
            }))
            .unwrap();
            poll_add_target_result(&mut ui_state, &mut targets, &sessions);
            let observed = sessions.read().get(&added).unwrap().read().paused;
            assert_eq!(
                observed, paused,
                "a target added while paused={paused} ended up paused={observed}"
            );
            assert_eq!(ui_state.paused, paused);
        }

        // Re-adding a running target while another one is paused selects it
        // without pausing it, and the badge follows the selected session.
        let session = Session::new(Target::new("dns.google".into(), added), Config::default());
        let sessions = make_single_session_map(added, session);
        let mut targets = vec![added];
        let mut ui_state = UiState {
            paused: true,
            ..UiState::default()
        };
        let (tx, rx) = tokio::sync::oneshot::channel();
        ui_state.target_input.pending = Some(rx);
        tx.send(Ok(crate::tui::views::AddedTarget {
            ip: added,
            name: "dns.google".to_string(),
            existed: true,
        }))
        .unwrap();
        poll_add_target_result(&mut ui_state, &mut targets, &sessions);
        assert!(!sessions.read().get(&added).unwrap().read().paused);
        assert!(!ui_state.paused);
    }

    #[test]
    fn update_check_toggle_respects_flag_or_env_lock() {
        let mut ui_state = UiState::default();
        ui_state.settings.update_check = true;
        toggle_update_check(&mut ui_state);
        assert!(!ui_state.settings.update_check);

        let mut locked = UiState {
            update_check_locked: true,
            ..UiState::default()
        };
        locked.settings.update_check = false;
        toggle_update_check(&mut locked);
        assert!(!locked.settings.update_check, "locked toggle must stay off");
        assert!(locked.status_message.is_some());
    }

    #[test]
    fn test_fingerprint_changes_on_update_check_recv() {
        let mut ui_state = UiState::default();
        let (tx, rx) = std::sync::mpsc::channel();
        ui_state.update_rx = Some(rx);
        let before = render_fingerprint(&ui_state, 1, Some(0), None);
        tx.send(Some("0.22.0".to_string())).unwrap();
        poll_update_check(&mut ui_state);
        let after = render_fingerprint(&ui_state, 1, Some(0), None);
        assert_eq!(ui_state.update_available.as_deref(), Some("0.22.0"));
        assert!(ui_state.update_rx.is_none());
        assert_ne!(before, after);
    }

    #[test]
    fn test_fingerprint_changes_when_open_target_list_refreshes() {
        let current = IpAddr::V4(Ipv4Addr::new(1, 1, 1, 1));
        let other = IpAddr::V4(Ipv4Addr::new(9, 9, 9, 9));
        let current_session =
            Session::new(Target::new("a".to_string(), current), Config::default());
        let other_session = Session::new(Target::new("b".to_string(), other), Config::default());
        let mut map = HashMap::new();
        map.insert(current, Arc::new(SessionLock::new(current_session)));
        map.insert(other, Arc::new(SessionLock::new(other_session)));
        let sessions: SessionMap = Arc::new(parking_lot::RwLock::new(map));
        let targets = vec![current, other];

        let mut ui_state = UiState {
            show_target_list: true,
            target_list_tick: 29,
            target_list_cache: Some(extract_target_infos(&sessions, &targets)),
            ..UiState::default()
        };
        let current_gen = sessions
            .read()
            .get(&current)
            .unwrap()
            .read()
            .render_generation;
        let before = render_fingerprint(&ui_state, targets.len(), Some(current_gen), None);

        {
            let sessions_read = sessions.read();
            let mut other_session = sessions_read.get(&other).unwrap().write();
            other_session.dest_ttl = Some(1);
            if let Some(hop) = other_session.hop_mut(1) {
                hop.sent = 10;
                hop.received = 5;
            }
        }

        refresh_target_list_cache(&mut ui_state, &sessions, &targets);
        let current_gen_after = sessions
            .read()
            .get(&current)
            .unwrap()
            .read()
            .render_generation;
        let after = render_fingerprint(&ui_state, targets.len(), Some(current_gen_after), None);

        assert_eq!(current_gen, current_gen_after);
        assert_eq!(ui_state.target_list_tick, 30);
        assert_ne!(before, after);
    }

    #[test]
    fn loaded_sessions_ignore_pause_and_reset() {
        let ip: IpAddr = "192.0.2.1".parse().unwrap();
        let mut session = Session::new(Target::new("example.net".into(), ip), Config::default());
        {
            let hop = session.hop_mut(1).unwrap();
            hop.record_sent();
            hop.record_timeout();
        }
        session.started_instant = None; // as loaded by --replay
        let sessions = make_single_session_map(ip, session);
        let mut ui_state = UiState::default();

        assert!(!reset_stats_if_live(&ui_state, &sessions, ip));
        assert_eq!(toggle_live_pause(&mut ui_state, &sessions, ip), None);
        assert!(!ui_state.paused, "a loaded session must not show PAUSED");
        {
            let sessions_read = sessions.read();
            let state = sessions_read.get(&ip).unwrap().read();
            assert!(!state.paused);
            assert_eq!(state.hops[0].sent, 1, "a loaded session must not be reset");
            assert_eq!(state.hops[0].timeouts, 1);
        }

        // The same session, once live, resets and pauses normally.
        sessions.read().get(&ip).unwrap().write().started_instant = Some(std::time::Instant::now());

        // An animated replay draws into a fresh session with a live epoch, but
        // it is still a recording: `r` must not blank it mid-playback.
        let animated = UiState {
            replay_state: Some(ReplayState::new(Vec::new(), 1.0)),
            ..UiState::default()
        };
        assert!(!reset_stats_if_live(&animated, &sessions, ip));
        assert_eq!(sessions.read().get(&ip).unwrap().read().hops[0].sent, 1);

        assert!(reset_stats_if_live(&ui_state, &sessions, ip));
        assert_eq!(toggle_live_pause(&mut ui_state, &sessions, ip), Some(true));
        assert!(ui_state.paused);
        {
            let sessions_read = sessions.read();
            let state = sessions_read.get(&ip).unwrap().read();
            assert!(state.paused);
            assert_eq!(state.hops[0].sent, 0);
        }
    }

    #[test]
    fn static_replay_hints_omit_live_only_keys() {
        use ratatui::backend::TestBackend;
        let ip: IpAddr = "192.0.2.1".parse().unwrap();
        let mut session = Session::new(Target::new("example.net".into(), ip), Config::default());
        let status = |session: &Session| {
            let mut terminal = Terminal::new(TestBackend::new(140, 12)).unwrap();
            terminal
                .draw(|f| {
                    draw_ui(
                        f,
                        session,
                        &UiState::default(),
                        &Theme::default(),
                        1,
                        None,
                        false,
                    )
                })
                .unwrap();
            let buf = terminal.backend().buffer();
            (0..140).map(|x| buf[(x, 11)].symbol()).collect::<String>()
        };
        let live = status(&session);
        assert!(live.contains("p pause") && live.contains("o add"), "{live}");
        session.started_instant = None; // loaded from a file
        let replay = status(&session);
        assert!(
            !replay.contains("p pause") && !replay.contains("o add"),
            "{replay}"
        );
        assert!(
            !replay.contains("r reset"),
            "a loaded session cannot be reset: {replay}"
        );
        assert!(replay.contains("e export"), "{replay}");
    }

    #[test]
    fn status_hints_are_never_clipped() {
        use ratatui::backend::TestBackend;
        let ip: IpAddr = "192.0.2.1".parse().unwrap();
        let session = Session::new(Target::new("example.net".into(), ip), Config::default());
        let labels = [
            "help", "quit", "details", "pause", "next", "list", "add", "settings", "theme",
            "display", "reset", "export",
        ];
        for width in 20..140 {
            for targets in [1, 2] {
                for message in [None, Some("Exported to ttl-192.0.2.1-20261016.json")] {
                    let mut state = UiState::default();
                    if let Some(message) = message {
                        state.set_status(message);
                    }
                    let mut terminal = Terminal::new(TestBackend::new(width, 12)).unwrap();
                    terminal
                        .draw(|f| {
                            draw_ui(f, &session, &state, &Theme::default(), targets, None, false)
                        })
                        .unwrap();
                    let buf = terminal.backend().buffer();
                    let status: String = (0..width).map(|x| buf[(x, 11)].symbol()).collect();
                    let hints = match message {
                        // The message keeps its row slot at the right edge.
                        Some(message) if status.trim_end().ends_with(message) => {
                            &status[..status.len() - message.len() - 1]
                        }
                        _ => &status[..],
                    };
                    let hints = hints.trim_end();
                    if message.is_some() {
                        // A transient message must never remove the first hint,
                        // however long it is for the width.
                        assert!(hints.contains("? help"), "{width}: {status}");
                    } else {
                        assert!(
                            hints.is_empty() || labels.iter().any(|l| hints.ends_with(l)),
                            "{width}: clipped {status}"
                        );
                    }
                    if width >= 40 && message.is_none() {
                        assert!(hints.contains("? help  q quit  Enter details"), "{status}");
                    }
                }
            }
        }
    }

    #[test]
    fn help_paging_reaches_every_line_on_short_terminals() {
        use ratatui::buffer::Buffer;
        use ratatui::widgets::Widget;
        let theme = Theme::default();
        let area = Rect::new(0, 0, 60, 14);
        let mut state = UiState {
            show_help: true,
            ..UiState::default()
        };
        let mut seen = Vec::new();
        loop {
            let mut buf = Buffer::empty(area);
            HelpView::new(&theme)
                .with_scroll(state.help_scroll)
                .render(area, &mut buf);
            seen.extend(
                buf.content
                    .chunks(60)
                    .map(|row| row.iter().map(|cell| cell.symbol()).collect::<String>()),
            );
            let before = state.help_scroll;
            handle_help_key(&mut state, KeyCode::PageDown, area, &theme);
            if state.help_scroll == before {
                break;
            }
        }
        assert!(state.show_help);
        for line in HelpView::new(&theme).wrapped_lines(area) {
            let line = line.to_string();
            let line = line.trim();
            assert!(
                line.is_empty() || seen.iter().any(|row| row.contains(line)),
                "{line:?} never shown"
            );
        }
        handle_help_key(&mut state, KeyCode::Esc, area, &theme);
        assert!(!state.show_help);
    }

    #[test]
    fn test_fingerprint_updates_when_hop_details_scroll() {
        let mut state = UiState {
            show_hop_detail: true,
            ..UiState::default()
        };
        let before = render_fingerprint(&state, 1, Some(0), None);
        state.hop_detail_scroll = 10;
        assert_ne!(before, render_fingerprint(&state, 1, Some(0), None));
    }

    #[test]
    fn test_fingerprint_includes_ix_fetched_at() {
        let stale = crate::lookup::ix::CacheStatus {
            loaded: true,
            prefix_count: 3,
            fetched_at: Some(1),
            expired: false,
            refreshing: false,
        };
        let fresh = crate::lookup::ix::CacheStatus {
            fetched_at: Some(2),
            ..stale.clone()
        };
        let ui_state = UiState::default();
        let a = render_fingerprint(&ui_state, 0, None, Some(&stale));
        let b = render_fingerprint(&ui_state, 0, None, Some(&fresh));
        assert_ne!(a, b);
    }
}
