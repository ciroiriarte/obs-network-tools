use crate::probe::tcp::extract_probe_id_from_tcp;
use crate::probe::udp::extract_probe_id_from_udp_payload;
use crate::state::{IcmpInterfaceInfo, IcmpResponseType, InterfaceRole, MplsLabel, ProbeId};
use pnet_packet::icmp::{IcmpPacket, IcmpTypes};
use pnet_packet::ipv4::Ipv4Packet;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};

// IP protocol numbers
const IPPROTO_ICMP: u8 = 1;
const IPPROTO_TCP: u8 = 6;
const IPPROTO_UDP: u8 = 17;
const IPPROTO_ICMPV6: u8 = 58;

// ICMPv6 type codes
const ICMPV6_ECHO_REPLY: u8 = 129;
const ICMPV6_PACKET_TOO_BIG: u8 = 2;
const ICMPV6_TIME_EXCEEDED: u8 = 3;
const ICMPV6_DEST_UNREACHABLE: u8 = 1;
const ICMPV6_PARAMETER_PROBLEM: u8 = 4;

// ICMPv6 Echo Request type (for error payload validation)
const ICMPV6_ECHO_REQUEST: u8 = 128;

/// Parsed ICMP response
#[derive(Debug, Clone)]
pub struct ParsedResponse {
    pub responder: IpAddr,
    pub probe_id: ProbeId,
    pub response_type: IcmpResponseType,
    /// True if the probe was a PMTUD probe (detected via payload marker)
    pub is_pmtud: bool,
    /// MPLS labels from ICMP extensions (RFC 4950), if present
    pub mpls_labels: Option<Vec<MplsLabel>>,
    /// RFC 5837 interface and next-hop identification, if present
    pub interface_info: Option<Vec<IcmpInterfaceInfo>>,
    /// Source port from original UDP/TCP packet (for flow identification in Paris/Dublin traceroute)
    /// This allows the receiver to compute flow_id = src_port - base_src_port
    pub src_port: Option<u16>,
    /// MTU from ICMP Fragmentation Needed (Type 3 Code 4) or ICMPv6 Packet Too Big (Type 2)
    /// Used for Path MTU Discovery
    pub mtu: Option<u16>,
    /// TTL from quoted IP header in ICMP error (for TTL manipulation detection)
    /// For Time Exceeded, this should be 0 or 1 per RFC; values > 1 suggest manipulation
    pub quoted_ttl: Option<u8>,
    /// Original destination IP from quoted packet in ICMP error
    /// Used to disambiguate multi-target responses
    pub original_dest: Option<IpAddr>,
}

// ICMP extension constants (RFC 4884, RFC 4950, RFC 5837)
const ICMP_EXT_VERSION: u8 = 2;
const MPLS_LABEL_STACK_CLASS: u8 = 1;
const MPLS_LABEL_STACK_TYPE: u8 = 1;
const INTERFACE_INFO_CLASS: u8 = 2;
const MIN_ORIGINAL_DATAGRAM: usize = 128;

#[derive(Debug, Default)]
struct ParsedIcmpExtensions {
    mpls_labels: Option<Vec<MplsLabel>>,
    interface_info: Option<Vec<IcmpInterfaceInfo>>,
}

/// Parse ICMP extensions from an error message payload (RFC 4884)
/// Returns parsed MPLS labels (RFC 4950) and Interface Information (RFC 5837)
///
/// The icmp_payload parameter should be the ICMP error payload starting
/// after the 8-byte ICMP header (i.e., starting with the original datagram).
/// The icmp_length parameter is the "length" field from the ICMP header
/// (byte 5 in 32-bit words for IPv4, byte 4 in 64-bit words for IPv6).
fn parse_icmp_extensions(
    icmp_payload: &[u8],
    icmp_length: u8,
    is_ipv6: bool,
) -> ParsedIcmpExtensions {
    // RFC 4884:
    // - For IPv4: byte 5 of ICMP header, measured in 32-bit words (4 octets)
    // - For IPv6: byte 4 of ICMPv6 header, measured in 64-bit words (8 octets)
    // RFC 4884 §4 requires at least 128 bytes of padded original datagram.
    // Some routers advertise the unpadded quote length instead, so honor the
    // minimum even for a non-zero length. Larger advertised quotes still win.
    // A zero length uses the same minimum for legacy extensions.
    let word = if is_ipv6 { 8 } else { 4 };
    let ext_start = (icmp_length as usize * word).max(MIN_ORIGINAL_DATAGRAM);

    if icmp_payload.len() < ext_start + 4 {
        return ParsedIcmpExtensions::default();
    }

    let ext_header = &icmp_payload[ext_start..];

    // Version (high nibble of first byte) must be 2
    let version = (ext_header[0] >> 4) & 0x0F;
    if version != ICMP_EXT_VERSION {
        return ParsedIcmpExtensions::default();
    }

    // RFC 4884 §§5.2, 5.5: without an explicit quote length, version alone
    // cannot distinguish extensions from quoted packet data. Legacy detection
    // requires a transmitted, valid checksum. With an explicit length, zero
    // means no checksum was transmitted (§7); validate every nonzero checksum.
    let checksum = u16::from_be_bytes([ext_header[2], ext_header[3]]);
    if checksum == 0 {
        if icmp_length == 0 {
            return ParsedIcmpExtensions::default();
        }
    } else if !validate_icmp_checksum(ext_header) {
        return ParsedIcmpExtensions::default();
    }

    // Parse extension objects starting at offset 4
    let mut offset = 4;
    let mut labels = Vec::new();
    let mut interfaces = Vec::new();
    let mut seen_roles: u8 = 0;

    while offset + 4 <= ext_header.len() {
        // Object header: length (16 bits), class (8 bits), type (8 bits)
        let obj_length = u16::from_be_bytes([ext_header[offset], ext_header[offset + 1]]) as usize;
        let obj_class = ext_header[offset + 2];
        let obj_type = ext_header[offset + 3];

        // Validate object length (must be >= 4 to contain header and advance)
        if obj_length < 4 || !obj_length.is_multiple_of(4) || offset + obj_length > ext_header.len()
        {
            break;
        }

        let obj_payload = &ext_header[offset + 4..offset + obj_length];

        // Check for MPLS Label Stack (class=1, type=1, RFC 4950)
        if obj_class == MPLS_LABEL_STACK_CLASS && obj_type == MPLS_LABEL_STACK_TYPE {
            for chunk in obj_payload.as_chunks::<4>().0 {
                let bytes: [u8; 4] = *chunk;
                let label = MplsLabel::from_bytes(&bytes);
                labels.push(label);
                if label.bottom {
                    break;
                }
            }
        } else if obj_class == INTERFACE_INFO_CLASS {
            // Interface Information Object (RFC 5837)
            // C-Type bit-fields:
            // bits 0-1: role (0: incoming, 1: sub-IP, 2: outgoing, 3: next-hop)
            // bits 2-3: reserved (ignore)
            // bit 4: ifIndex (0x08)
            // bit 5: IP address (0x04)
            // bit 6: name (0x02)
            // bit 7: MTU (0x01)
            let c_type = obj_type;
            let role_val = (c_type >> 6) & 0x03;
            let role_mask = 1 << role_val;

            // RFC 5837 §4.5 forbids two objects with the same role and says the
            // whole message "MUST be silently discarded". Deliberately lenient
            // here: keep the first object per role and ignore repeats, so a
            // buggy router still yields the rest of its trace data.
            if seen_roles & role_mask == 0 {
                seen_roles |= role_mask;

                let role = match role_val {
                    0 => InterfaceRole::IncomingIp,
                    1 => InterfaceRole::SubIpComponent,
                    2 => InterfaceRole::OutgoingIp,
                    3 => InterfaceRole::IpNextHop,
                    _ => unreachable!(),
                };

                let mut pos = 0;
                let mut if_index = None;
                let mut ip_addr = None;
                let mut name = None;
                let mut mtu = None;
                let mut malformed = false;

                // 1. ifIndex (bit 4, 0x08)
                if (c_type & 0x08) != 0 {
                    if pos + 4 <= obj_payload.len() {
                        let bytes: [u8; 4] = obj_payload[pos..pos + 4].try_into().unwrap();
                        if_index = Some(u32::from_be_bytes(bytes));
                        pos += 4;
                    } else {
                        malformed = true;
                    }
                }

                // 2. IP Address Sub-Object (bit 5, 0x04)
                if !malformed && (c_type & 0x04) != 0 {
                    if pos + 4 <= obj_payload.len() {
                        let afi = u16::from_be_bytes([obj_payload[pos], obj_payload[pos + 1]]);
                        pos += 4; // AFI (2) + Reserved (2)
                        match afi {
                            1 => {
                                // IPv4: 4 bytes
                                if pos + 4 <= obj_payload.len() {
                                    let bytes: [u8; 4] =
                                        obj_payload[pos..pos + 4].try_into().unwrap();
                                    ip_addr = Some(IpAddr::V4(Ipv4Addr::from(bytes)));
                                    pos += 4;
                                } else {
                                    malformed = true;
                                }
                            }
                            2 => {
                                // IPv6: 16 bytes
                                if pos + 16 <= obj_payload.len() {
                                    let bytes: [u8; 16] =
                                        obj_payload[pos..pos + 16].try_into().unwrap();
                                    ip_addr = Some(IpAddr::V6(Ipv6Addr::from(bytes)));
                                    pos += 16;
                                } else {
                                    malformed = true;
                                }
                            }
                            _ => {
                                // Unknown AFI: the address length is unknowable, so
                                // the remaining sub-objects cannot be located.
                                malformed = true;
                            }
                        }
                    } else {
                        malformed = true;
                    }
                }

                // 3. Interface Name Sub-Object (bit 6, 0x02)
                if !malformed && (c_type & 0x02) != 0 {
                    if pos < obj_payload.len() {
                        let name_len = obj_payload[pos] as usize;
                        if name_len >= 1 && pos + name_len <= obj_payload.len() {
                            let raw_name = &obj_payload[pos + 1..pos + name_len];
                            let trimmed = match raw_name.iter().position(|&b| b == 0) {
                                Some(null_pos) => &raw_name[..null_pos],
                                None => raw_name,
                            };
                            let s = String::from_utf8_lossy(trimmed).trim().to_string();
                            if !s.is_empty() {
                                name = Some(s);
                            }
                            pos += name_len;
                        } else {
                            malformed = true;
                        }
                    } else {
                        malformed = true;
                    }
                }

                // 4. MTU (bit 7, 0x01)
                if !malformed && (c_type & 0x01) != 0 {
                    if pos + 4 <= obj_payload.len() {
                        let bytes: [u8; 4] = obj_payload[pos..pos + 4].try_into().unwrap();
                        mtu = Some(u32::from_be_bytes(bytes));
                    } else {
                        malformed = true;
                    }
                }

                if !malformed {
                    interfaces.push(IcmpInterfaceInfo {
                        role,
                        if_index,
                        ip_addr,
                        name,
                        mtu,
                    });
                }
            }
        }

        offset += obj_length;
    }

    ParsedIcmpExtensions {
        mpls_labels: if labels.is_empty() {
            None
        } else {
            Some(labels)
        },
        interface_info: if interfaces.is_empty() {
            None
        } else {
            Some(interfaces)
        },
    }
}

/// Calculate ICMP checksum (RFC 1071)
/// Returns true if checksum is valid (sums to 0xFFFF or 0x0000 after folding)
fn validate_icmp_checksum(data: &[u8]) -> bool {
    if data.len() < 4 {
        return false;
    }

    let mut sum: u32 = 0;

    // Sum 16-bit words
    let mut i = 0;
    while i + 1 < data.len() {
        sum += u16::from_be_bytes([data[i], data[i + 1]]) as u32;
        i += 2;
    }

    // Handle odd byte
    if i < data.len() {
        sum += (data[i] as u32) << 8;
    }

    // Fold 32-bit sum to 16 bits
    while sum >> 16 != 0 {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }

    // Valid checksum results in 0xFFFF (or 0x0000 for zero checksum)
    sum == 0xFFFF || sum == 0x0000
}

/// Parse an ICMP response and correlate it to our probe
///
/// When `is_dgram` is true, the packet starts directly at the ICMP header
/// (no IP header, as returned by macOS DGRAM sockets).
///
/// Returns None if:
/// - Packet is malformed
/// - Packet is not a response to our probe (wrong identifier)
/// - ICMP checksum is invalid (for Echo Reply only)
pub fn parse_icmp_response(
    data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
    is_dgram: bool,
) -> Option<ParsedResponse> {
    if data.is_empty() {
        return None;
    }

    if is_dgram {
        // DGRAM socket: no IP header, use responder address to determine version
        if responder.is_ipv4() {
            parse_icmp_response_v4_dgram(data, responder, our_identifier)
        } else {
            parse_icmp_response_v6_dgram(data, responder, our_identifier)
        }
    } else if responder.is_ipv6() {
        // RAW IPv6 socket: Linux kernel strips IPv6 header, delivers ICMPv6 directly
        // Use DGRAM parser which expects no IP header
        parse_icmp_response_v6_dgram(data, responder, our_identifier)
    } else {
        // RAW IPv4 socket: has IP header
        parse_icmp_response_v4(data, responder, our_identifier)
    }
}

/// Parse IPv4 ICMP response
fn parse_icmp_response_v4(
    data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
) -> Option<ParsedResponse> {
    let ip_packet = Ipv4Packet::new(data)?;
    let ip_header_len = (ip_packet.get_header_length() as usize) * 4;

    if data.len() < ip_header_len + 8 {
        return None;
    }

    let icmp_data = &data[ip_header_len..];
    let icmp_packet = IcmpPacket::new(icmp_data)?;

    let icmp_type = icmp_packet.get_icmp_type();

    match icmp_type {
        IcmpTypes::EchoReply => {
            // Echo Reply: identifier and sequence are in bytes 4-7
            if icmp_data.len() < 8 {
                return None;
            }

            // Validate ICMP checksum for Echo Reply
            if !validate_icmp_checksum(icmp_data) {
                return None;
            }

            let identifier = u16::from_be_bytes([icmp_data[4], icmp_data[5]]);
            let sequence = u16::from_be_bytes([icmp_data[6], icmp_data[7]]);

            if identifier == our_identifier {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(sequence),
                    response_type: IcmpResponseType::EchoReply,
                    is_pmtud: is_pmtud_payload(&icmp_data[8..]),
                    mpls_labels: None,
                    interface_info: None,
                    src_port: None,
                    mtu: None,
                    quoted_ttl: None,
                    // For Echo Reply, responder IS the target
                    original_dest: Some(responder),
                });
            }

            // Payload fallback: macOS DGRAM send may modify identifier
            // ICMP header is 8 bytes, payload starts at icmp_data[8]
            if icmp_data.len() >= 12
                && let Some((_, payload_seq)) =
                    extract_id_from_payload(&icmp_data[8..], our_identifier)
            {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(payload_seq),
                    response_type: IcmpResponseType::EchoReply,
                    is_pmtud: is_pmtud_payload(&icmp_data[8..]),
                    mpls_labels: None,
                    interface_info: None,
                    src_port: None,
                    mtu: None,
                    quoted_ttl: None,
                    // For Echo Reply, responder IS the target
                    original_dest: Some(responder),
                });
            }
            None
        }
        IcmpTypes::TimeExceeded => {
            let code = icmp_packet.get_icmp_code().0;
            parse_icmp_error_payload_v4_with_mtu(
                icmp_data,
                responder,
                our_identifier,
                IcmpResponseType::TimeExceeded(code),
                None,
            )
        }
        IcmpTypes::DestinationUnreachable => {
            let code = icmp_packet.get_icmp_code().0;
            // For Fragmentation Needed (code 4), extract MTU from bytes 6-7
            let mtu = if code == 4 && icmp_data.len() >= 8 {
                let mtu_val = u16::from_be_bytes([icmp_data[6], icmp_data[7]]);
                if mtu_val > 0 { Some(mtu_val) } else { None }
            } else {
                None
            };
            parse_icmp_error_payload_v4_with_mtu(
                icmp_data,
                responder,
                our_identifier,
                IcmpResponseType::DestUnreachable(code),
                mtu,
            )
        }
        _ => None,
    }
}

// IPv6 Next Header protocol numbers
// Note: These are currently unused because Linux strips the IPv6 header from raw
// ICMPv6 sockets before delivery. Kept for potential future use on other platforms.
#[allow(dead_code)]
const IPV6_NH_HOP_BY_HOP: u8 = 0;
const IPV6_NH_ROUTING: u8 = 43;
const IPV6_NH_FRAGMENT: u8 = 44;
const IPV6_NH_ICMPV6: u8 = 58;
const IPV6_NH_NO_NEXT: u8 = 59;
const IPV6_NH_DEST_OPTS: u8 = 60;

/// Skip IPv6 extension headers and return offset to ICMPv6 payload
/// Returns None if ICMPv6 is not the upper layer protocol
///
/// Note: Currently unused because Linux strips IPv6 headers from raw ICMPv6 sockets.
/// Kept for potential future use on platforms that include the IPv6 header.
#[allow(dead_code)]
fn skip_ipv6_extension_headers(data: &[u8]) -> Option<usize> {
    const IPV6_HEADER_LEN: usize = 40;

    if data.len() < IPV6_HEADER_LEN {
        return None;
    }

    // Next Header field is at byte 6 of IPv6 header
    let mut next_header = data[6];
    let mut offset = IPV6_HEADER_LEN;

    // Walk through extension headers until we find ICMPv6 or something else
    loop {
        match next_header {
            IPV6_NH_ICMPV6 => {
                // Found ICMPv6
                return Some(offset);
            }
            IPV6_NH_HOP_BY_HOP | IPV6_NH_ROUTING | IPV6_NH_DEST_OPTS => {
                // Variable-length extension header
                // Byte 0: Next Header, Byte 1: Length (in 8-octet units, excluding first 8)
                if data.len() < offset + 2 {
                    return None;
                }
                next_header = data[offset];
                let ext_len = (data[offset + 1] as usize + 1) * 8;
                offset += ext_len;
                if offset > data.len() {
                    return None;
                }
            }
            IPV6_NH_FRAGMENT => {
                // Fragment headers indicate fragmented packets
                // We can't reassemble fragments, so reject them
                return None;
            }
            IPV6_NH_NO_NEXT => {
                // No upper layer payload
                return None;
            }
            _ => {
                // Unknown or unsupported protocol (ESP, AH, etc.)
                // Can't safely skip, so reject
                return None;
            }
        }
    }
}

/// Walk extension headers in a *quoted* IPv6 packet (embedded in an ICMPv6 error)
/// and return (offset_to_transport, final_next_header).
///
/// Unlike `skip_ipv6_extension_headers`, this returns the transport protocol
/// (not just ICMPv6 offset) since the quoted packet may contain UDP or TCP,
/// and extension headers shift where the transport header actually starts.
/// Returns None if extension headers are malformed, fragmented, or use
/// unsupported protocols (ESP, AH).
fn skip_ipv6_ext_headers_quoted(ipv6_data: &[u8]) -> Option<(usize, u8)> {
    const IPV6_HEADER_LEN: usize = 40;

    if ipv6_data.len() < IPV6_HEADER_LEN {
        return None;
    }

    let mut next_header = ipv6_data[6];
    let mut offset = IPV6_HEADER_LEN;

    loop {
        match next_header {
            IPV6_NH_HOP_BY_HOP | IPV6_NH_ROUTING | IPV6_NH_DEST_OPTS => {
                // Variable-length extension header:
                // Byte 0: Next Header, Byte 1: Length (in 8-octet units, excluding first 8)
                if ipv6_data.len() < offset + 2 {
                    return None;
                }
                next_header = ipv6_data[offset];
                let ext_len = (ipv6_data[offset + 1] as usize + 1) * 8;
                offset += ext_len;
                if offset > ipv6_data.len() {
                    return None;
                }
            }
            IPV6_NH_FRAGMENT => {
                // Fragment header — can't reassemble quoted fragments
                return None;
            }
            IPV6_NH_NO_NEXT => {
                return None;
            }
            _ => {
                // Reached the transport protocol (ICMPv6, UDP, TCP, or unknown)
                return Some((offset, next_header));
            }
        }
    }
}

/// Parse IPv6 ICMPv6 response
///
/// Note: ICMPv6 checksum validation is intentionally omitted. Unlike ICMPv4,
/// ICMPv6 checksums require the IPv6 pseudo-header (source/dest addresses,
/// payload length, next header) which isn't available after extension header
/// parsing. The kernel validates ICMPv6 checksums before delivery to raw sockets.
///
/// Currently unused because Linux strips IPv6 headers from raw ICMPv6 sockets.
/// The DGRAM parser is used instead. Kept for potential future use.
#[allow(dead_code)]
fn parse_icmp_response_v6(
    data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
) -> Option<ParsedResponse> {
    // Skip any extension headers to find ICMPv6
    let icmp_offset = skip_ipv6_extension_headers(data)?;

    if data.len() < icmp_offset + 8 {
        return None;
    }

    let icmp_data = &data[icmp_offset..];
    let icmp_type = icmp_data[0];
    let icmp_code = icmp_data[1];

    match icmp_type {
        ICMPV6_ECHO_REPLY => {
            if icmp_data.len() < 8 {
                return None;
            }
            let identifier = u16::from_be_bytes([icmp_data[4], icmp_data[5]]);
            let sequence = u16::from_be_bytes([icmp_data[6], icmp_data[7]]);

            if identifier == our_identifier {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(sequence),
                    response_type: IcmpResponseType::EchoReply,
                    is_pmtud: is_pmtud_payload(&icmp_data[8..]),
                    mpls_labels: None,
                    interface_info: None,
                    src_port: None,
                    mtu: None,
                    quoted_ttl: None,
                    // For Echo Reply, responder IS the target
                    original_dest: Some(responder),
                });
            }

            // Payload fallback: macOS DGRAM send may modify identifier
            if icmp_data.len() >= 12
                && let Some((_, payload_seq)) =
                    extract_id_from_payload(&icmp_data[8..], our_identifier)
            {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(payload_seq),
                    response_type: IcmpResponseType::EchoReply,
                    is_pmtud: is_pmtud_payload(&icmp_data[8..]),
                    mpls_labels: None,
                    interface_info: None,
                    src_port: None,
                    mtu: None,
                    quoted_ttl: None,
                    // For Echo Reply, responder IS the target
                    original_dest: Some(responder),
                });
            }
            None
        }
        ICMPV6_PACKET_TOO_BIG => {
            // ICMPv6 Packet Too Big (Type 2) - for PMTUD
            // MTU is in bytes 4-7 (32-bit field)
            let mtu = if icmp_data.len() >= 8 {
                let mtu_val =
                    u32::from_be_bytes([icmp_data[4], icmp_data[5], icmp_data[6], icmp_data[7]]);
                if mtu_val > 0 && mtu_val <= 65535 {
                    Some(mtu_val as u16)
                } else {
                    None
                }
            } else {
                None
            };
            parse_icmp_error_payload_v6_with_mtu(
                icmp_data,
                responder,
                our_identifier,
                IcmpResponseType::PacketTooBig,
                mtu,
            )
        }
        ICMPV6_TIME_EXCEEDED => parse_icmp_error_payload_v6_with_mtu(
            icmp_data,
            responder,
            our_identifier,
            IcmpResponseType::TimeExceeded(icmp_code),
            None,
        ),
        ICMPV6_PARAMETER_PROBLEM => parse_icmp_error_payload_v6_with_mtu(
            icmp_data,
            responder,
            our_identifier,
            IcmpResponseType::ParameterProblem(icmp_code),
            None,
        ),
        ICMPV6_DEST_UNREACHABLE => parse_icmp_error_payload_v6_with_mtu(
            icmp_data,
            responder,
            our_identifier,
            IcmpResponseType::DestUnreachable(icmp_code),
            None,
        ),
        _ => None,
    }
}

/// Parse the payload of an IPv4 ICMP error message (Time Exceeded or Dest Unreachable)
fn parse_icmp_error_payload_v4_with_mtu(
    icmp_data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
    response_type: IcmpResponseType,
    mtu: Option<u16>,
) -> Option<ParsedResponse> {
    // ICMP error format (RFC 4884):
    // [0]    Type
    // [1]    Code
    // [2-3]  Checksum
    // [4]    Unused
    // [5]    Length (original datagram length in 32-bit words, 0 = legacy)
    // [6-7]  Unused
    // [8..]  Original IP header + first 8 bytes of original payload
    // [8 + length*4..] ICMP extensions (if length > 0)
    // [136..] ICMP extensions (if length == 0, legacy mode)

    if icmp_data.len() < 8 + 20 + 8 {
        // Need at least ICMP header + IP header + 8 bytes of original payload
        return None;
    }

    // Extract RFC 4884 length field (byte 5 of ICMP header)
    let icmp_length = icmp_data[5];

    let original_ip_data = &icmp_data[8..];
    let original_ip = Ipv4Packet::new(original_ip_data)?;
    let orig_ihl = (original_ip.get_header_length() as usize) * 4;
    let orig_protocol = original_ip.get_next_level_protocol().0;
    // Extract quoted TTL for TTL manipulation detection
    let quoted_ttl = original_ip.get_ttl();
    // Extract original destination for multi-target disambiguation
    let original_dest = Some(IpAddr::V4(original_ip.get_destination()));

    if original_ip_data.len() < orig_ihl + 8 {
        return None;
    }

    let original_payload = &original_ip_data[orig_ihl..];

    // Try to parse ICMP extensions using RFC 4884 length field
    let exts = parse_icmp_extensions(&icmp_data[8..], icmp_length, false);

    // Handle based on original protocol
    match orig_protocol {
        IPPROTO_ICMP => {
            // Original packet was ICMP Echo Request
            // [0]    Type (should be 8 for Echo Request)
            // [1]    Code (should be 0)
            // [2-3]  Checksum
            // [4-5]  Identifier
            // [6-7]  Sequence

            if original_payload[0] != 8 {
                // Not an Echo Request
                return None;
            }

            let identifier = u16::from_be_bytes([original_payload[4], original_payload[5]]);
            let sequence = u16::from_be_bytes([original_payload[6], original_payload[7]]);

            if identifier == our_identifier {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(sequence),
                    response_type,
                    is_pmtud: false,
                    mpls_labels: exts.mpls_labels,
                    interface_info: exts.interface_info,
                    src_port: None,
                    mtu,
                    quoted_ttl: Some(quoted_ttl),
                    original_dest,
                });
            }

            // Payload fallback: macOS DGRAM send may modify identifier
            // Original ICMP: [0-7] header, [8..] payload
            //
            // NOTE: RFC 792 allows routers to quote only 8 bytes of original payload.
            // If a router quotes the minimum AND macOS rewrites the ICMP identifier,
            // this hop will be unmatchable (shows as timeout). This is rare in practice
            // as most modern routers quote more data per RFC 4884.
            if original_payload.len() >= 12
                && let Some((_, payload_seq)) =
                    extract_id_from_payload(&original_payload[8..], our_identifier)
            {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(payload_seq),
                    response_type,
                    is_pmtud: false,
                    mpls_labels: exts.mpls_labels,
                    interface_info: exts.interface_info,
                    src_port: None,
                    mtu,
                    quoted_ttl: Some(quoted_ttl),
                    original_dest,
                });
            }
            None
        }
        IPPROTO_TCP => {
            // Original packet was TCP SYN probe
            // TCP header: [0-1] src port, [2-3] dst port, [4-7] seq number, ...
            // Probe ID is encoded in seq number (high 16 bits)

            if original_payload.len() < 8 {
                // Need at least 8 bytes for seq number extraction
                return None;
            }

            // Extract source port for flow identification (Paris/Dublin traceroute)
            let src_port = u16::from_be_bytes([original_payload[0], original_payload[1]]);
            let probe_id = extract_probe_id_from_tcp(original_payload)?;

            Some(ParsedResponse {
                responder,
                probe_id,
                response_type,
                is_pmtud: false,
                mpls_labels: exts.mpls_labels,
                interface_info: exts.interface_info,
                src_port: Some(src_port),
                mtu,
                quoted_ttl: Some(quoted_ttl),
                original_dest,
            })
        }
        IPPROTO_UDP => {
            // Original packet was UDP probe
            // UDP header: [0-1] src port, [2-3] dst port, [4-5] length, [6-7] checksum
            // Our payload starts at offset 8

            if original_payload.len() < 8 + 6 {
                // Need UDP header + at least 6 bytes of payload
                return None;
            }

            // Extract source port for flow identification (Paris/Dublin traceroute)
            let src_port = u16::from_be_bytes([original_payload[0], original_payload[1]]);
            let udp_payload = &original_payload[8..];
            let probe_id = extract_probe_id_from_udp_payload(udp_payload)?;

            Some(ParsedResponse {
                responder,
                probe_id,
                response_type,
                is_pmtud: false,
                mpls_labels: exts.mpls_labels,
                interface_info: exts.interface_info,
                src_port: Some(src_port),
                mtu,
                quoted_ttl: Some(quoted_ttl),
                original_dest,
            })
        }
        _ => None,
    }
}

/// Parse the payload of an IPv6 ICMPv6 error message (Time Exceeded, Dest Unreachable, or Packet Too Big)
///
/// Note: The embedded original IPv6 packet may contain extension headers
/// (e.g. from routers that add Hop-by-Hop or Routing headers). These are
/// skipped via `skip_ipv6_ext_headers_quoted` to find the transport header.
///
/// Currently unused because Linux strips IPv6 headers from raw ICMPv6 sockets.
/// The DGRAM error parser is used instead. Kept for potential future use.
#[allow(dead_code)]
fn parse_icmp_error_payload_v6_with_mtu(
    icmp_data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
    response_type: IcmpResponseType,
    mtu: Option<u16>,
) -> Option<ParsedResponse> {
    // ICMPv6 error format (RFC 4884):
    // [0]    Type
    // [1]    Code
    // [2-3]  Checksum
    // [4-7]  Type-specific (MTU for Packet Too Big, unused for others)
    // [8..]  Original IPv6 header (40 bytes) + first 8 bytes of original payload
    // [8 + length*4..] ICMP extensions (if length > 0)
    // [136..] ICMP extensions (if length == 0, legacy mode)

    const IPV6_HEADER_LEN: usize = 40;

    // Require: 8 (ICMPv6 header) + 40 (IPv6 header) + 8 (original ICMP/UDP header) = 56 bytes
    // Some routers send shorter payloads; log when this happens for debugging
    if icmp_data.len() < 8 + IPV6_HEADER_LEN + 8 {
        #[cfg(debug_assertions)]
        eprintln!(
            "ICMPv6 error dropped: payload too short ({} bytes, need 56) from {:?}",
            icmp_data.len(),
            responder
        );
        return None;
    }

    // Extract RFC 4884 length field (byte 4 of ICMPv6 header, in 64-bit words)
    let icmp_length = icmp_data[4];

    let original_ipv6_data = &icmp_data[8..];
    // Next header field is at byte 6 of IPv6 header
    let next_header = original_ipv6_data[6];
    // Hop limit (IPv6 equivalent of TTL) is at byte 7
    let quoted_ttl = original_ipv6_data[7];
    // Extract original destination for multi-target disambiguation (bytes 24-39)
    let original_dest = Some(IpAddr::V6(std::net::Ipv6Addr::new(
        u16::from_be_bytes([original_ipv6_data[24], original_ipv6_data[25]]),
        u16::from_be_bytes([original_ipv6_data[26], original_ipv6_data[27]]),
        u16::from_be_bytes([original_ipv6_data[28], original_ipv6_data[29]]),
        u16::from_be_bytes([original_ipv6_data[30], original_ipv6_data[31]]),
        u16::from_be_bytes([original_ipv6_data[32], original_ipv6_data[33]]),
        u16::from_be_bytes([original_ipv6_data[34], original_ipv6_data[35]]),
        u16::from_be_bytes([original_ipv6_data[36], original_ipv6_data[37]]),
        u16::from_be_bytes([original_ipv6_data[38], original_ipv6_data[39]]),
    )));
    // Walk extension headers to find the transport offset
    let (transport_offset, final_next_header) =
        match skip_ipv6_ext_headers_quoted(original_ipv6_data) {
            Some((off, nh)) => (off, nh),
            None => (IPV6_HEADER_LEN, next_header),
        };
    if transport_offset > original_ipv6_data.len() {
        return None;
    }
    let original_payload = &original_ipv6_data[transport_offset..];
    let next_header = final_next_header;

    // Try to parse ICMP extensions using RFC 4884 length field. Parameter
    // Problem has a pointer there instead and carries no extensions (§4.6).
    let exts = if matches!(response_type, IcmpResponseType::ParameterProblem(_)) {
        ParsedIcmpExtensions::default()
    } else {
        parse_icmp_extensions(&icmp_data[8..], icmp_length, true)
    };

    // Handle based on original protocol
    match next_header {
        IPPROTO_ICMPV6 => {
            // Original packet was ICMPv6 Echo Request
            // [0]    Type (should be 128 for Echo Request)
            // [1]    Code (should be 0)
            // [2-3]  Checksum
            // [4-5]  Identifier
            // [6-7]  Sequence

            if original_payload.len() < 8 {
                return None;
            }

            if original_payload[0] != ICMPV6_ECHO_REQUEST {
                // Not our Echo Request
                return None;
            }

            let identifier = u16::from_be_bytes([original_payload[4], original_payload[5]]);
            let sequence = u16::from_be_bytes([original_payload[6], original_payload[7]]);

            if identifier == our_identifier {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(sequence),
                    response_type,
                    is_pmtud: false,
                    mpls_labels: exts.mpls_labels,
                    interface_info: exts.interface_info,
                    src_port: None,
                    mtu,
                    quoted_ttl: Some(quoted_ttl),
                    original_dest,
                });
            }

            // Payload fallback: macOS DGRAM send may modify identifier
            // Original ICMPv6: [0-7] header, [8..] payload
            //
            // NOTE: RFC 4443 allows routers to quote minimum data. If a router quotes
            // only the minimum AND macOS rewrites the ICMPv6 identifier, this hop will
            // be unmatchable (shows as timeout). Rare in practice.
            if original_payload.len() >= 12
                && let Some((_, payload_seq)) =
                    extract_id_from_payload(&original_payload[8..], our_identifier)
            {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(payload_seq),
                    response_type,
                    is_pmtud: false,
                    mpls_labels: exts.mpls_labels,
                    interface_info: exts.interface_info,
                    src_port: None,
                    mtu,
                    quoted_ttl: Some(quoted_ttl),
                    original_dest,
                });
            }
            None
        }
        IPPROTO_TCP => {
            // Original packet was TCP SYN probe
            // TCP header: [0-1] src port, [2-3] dst port, [4-7] seq number, ...
            // Probe ID is encoded in seq number (high 16 bits)

            if original_payload.len() < 8 {
                // Need at least 8 bytes for seq number extraction
                return None;
            }

            // Extract source port for flow identification (Paris/Dublin traceroute)
            let src_port = u16::from_be_bytes([original_payload[0], original_payload[1]]);
            let probe_id = extract_probe_id_from_tcp(original_payload)?;

            Some(ParsedResponse {
                responder,
                probe_id,
                response_type,
                is_pmtud: false,
                mpls_labels: exts.mpls_labels,
                interface_info: exts.interface_info,
                src_port: Some(src_port),
                mtu,
                quoted_ttl: Some(quoted_ttl),
                original_dest,
            })
        }
        IPPROTO_UDP => {
            // Original packet was UDP probe
            // UDP header: [0-1] src port, [2-3] dst port, [4-5] length, [6-7] checksum
            // Our payload starts at offset 8

            if original_payload.len() < 8 + 6 {
                // Need UDP header + at least 6 bytes of payload
                return None;
            }

            // Extract source port for flow identification (Paris/Dublin traceroute)
            let src_port = u16::from_be_bytes([original_payload[0], original_payload[1]]);
            let udp_payload = &original_payload[8..];
            let probe_id = extract_probe_id_from_udp_payload(udp_payload)?;

            Some(ParsedResponse {
                responder,
                probe_id,
                response_type,
                is_pmtud: false,
                mpls_labels: exts.mpls_labels,
                interface_info: exts.interface_info,
                src_port: Some(src_port),
                mtu,
                quoted_ttl: Some(quoted_ttl),
                original_dest,
            })
        }
        _ => None,
    }
}

// ============================================================================
// DGRAM socket parsing (no IP header - used on macOS)
// ============================================================================

/// Helper to extract identifier from payload (fallback for macOS DGRAM id override)
/// Payload layout: [0-1] identifier, [2-3] sequence, [4-7] timestamp
fn extract_id_from_payload(payload: &[u8], our_identifier: u16) -> Option<(u16, u16)> {
    if payload.len() < 4 {
        return None;
    }
    let payload_id = u16::from_be_bytes([payload[0], payload[1]]);
    let payload_seq = u16::from_be_bytes([payload[2], payload[3]]);
    if payload_id == our_identifier {
        Some((payload_id, payload_seq))
    } else {
        None
    }
}

/// Check if an Echo Reply payload contains the PMTUD marker at byte 8.
/// Normal probes have 0x00 there (pattern fill index 0); PMTUD probes set 0x50.
fn is_pmtud_payload(payload: &[u8]) -> bool {
    payload.len() > 8 && payload[8] == crate::probe::icmp::PMTUD_MARKER
}

/// Parse IPv4 ICMP from DGRAM socket (no IP header)
fn parse_icmp_response_v4_dgram(
    icmp_data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
) -> Option<ParsedResponse> {
    if icmp_data.len() < 8 {
        return None;
    }

    let icmp_type = icmp_data[0];
    let icmp_code = icmp_data[1];

    match icmp_type {
        0 => {
            // Echo Reply
            // Validate checksum
            if !validate_icmp_checksum(icmp_data) {
                return None;
            }

            // Try header identifier first
            let identifier = u16::from_be_bytes([icmp_data[4], icmp_data[5]]);
            let sequence = u16::from_be_bytes([icmp_data[6], icmp_data[7]]);

            if identifier == our_identifier {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(sequence),
                    response_type: IcmpResponseType::EchoReply,
                    is_pmtud: is_pmtud_payload(&icmp_data[8..]),
                    mpls_labels: None,
                    interface_info: None,
                    src_port: None,
                    mtu: None,
                    quoted_ttl: None,
                    // For Echo Reply, responder IS the target
                    original_dest: Some(responder),
                });
            }

            // Fallback: check payload bytes 0-3 (macOS may override identifier)
            // ICMP header is 8 bytes, payload starts at icmp_data[8]
            if icmp_data.len() >= 12
                && let Some((_, payload_seq)) =
                    extract_id_from_payload(&icmp_data[8..], our_identifier)
            {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(payload_seq),
                    response_type: IcmpResponseType::EchoReply,
                    is_pmtud: is_pmtud_payload(&icmp_data[8..]),
                    mpls_labels: None,
                    interface_info: None,
                    src_port: None,
                    mtu: None,
                    quoted_ttl: None,
                    // For Echo Reply, responder IS the target
                    original_dest: Some(responder),
                });
            }
            None
        }
        11 => {
            // Time Exceeded
            parse_icmp_error_payload_v4_dgram(
                icmp_data,
                responder,
                our_identifier,
                IcmpResponseType::TimeExceeded(icmp_code),
                None,
            )
        }
        3 => {
            // Destination Unreachable
            let mtu = if icmp_code == 4 && icmp_data.len() >= 8 {
                let mtu_val = u16::from_be_bytes([icmp_data[6], icmp_data[7]]);
                if mtu_val > 0 { Some(mtu_val) } else { None }
            } else {
                None
            };
            parse_icmp_error_payload_v4_dgram(
                icmp_data,
                responder,
                our_identifier,
                IcmpResponseType::DestUnreachable(icmp_code),
                mtu,
            )
        }
        _ => None,
    }
}

/// Parse ICMP error (Time Exceeded, Dest Unreachable) from DGRAM socket
fn parse_icmp_error_payload_v4_dgram(
    icmp_data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
    response_type: IcmpResponseType,
    mtu: Option<u16>,
) -> Option<ParsedResponse> {
    // ICMP error: [0-7] ICMP header, [8..] original IP packet
    if icmp_data.len() < 8 + 20 + 8 {
        return None;
    }

    let icmp_length = icmp_data[5];
    let original_ip_data = &icmp_data[8..];
    let original_ip = Ipv4Packet::new(original_ip_data)?;
    let orig_ihl = (original_ip.get_header_length() as usize) * 4;
    let orig_protocol = original_ip.get_next_level_protocol().0;
    let quoted_ttl = original_ip.get_ttl();
    let original_dest = Some(IpAddr::V4(original_ip.get_destination()));

    if original_ip_data.len() < orig_ihl + 8 {
        return None;
    }

    let original_payload = &original_ip_data[orig_ihl..];
    let exts = parse_icmp_extensions(&icmp_data[8..], icmp_length, false);

    match orig_protocol {
        IPPROTO_ICMP => {
            if original_payload[0] != 8 {
                return None;
            }

            // Try header identifier first
            // Note: macOS DGRAM sockets may override the ICMP identifier. If the identifier
            // is overwritten AND the router quotes only 8 bytes of the original ICMP (just
            // the header per RFC 792 minimum), the payload fallback below won't work.
            // In practice, most modern routers quote more data, and macOS may preserve
            // the identifier for outgoing packets even in DGRAM mode.
            let identifier = u16::from_be_bytes([original_payload[4], original_payload[5]]);
            let sequence = u16::from_be_bytes([original_payload[6], original_payload[7]]);

            if identifier == our_identifier {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(sequence),
                    response_type,
                    is_pmtud: false,
                    mpls_labels: exts.mpls_labels,
                    interface_info: exts.interface_info,
                    src_port: None,
                    mtu,
                    quoted_ttl: Some(quoted_ttl),
                    original_dest,
                });
            }

            // Fallback: check quoted ICMP payload bytes 0-3 for embedded ProbeId
            // Only works if router quotes at least 12 bytes (ICMP header + 4 payload)
            // Original ICMP: [0-7] header, [8..] payload
            if original_payload.len() >= 12
                && let Some((_, payload_seq)) =
                    extract_id_from_payload(&original_payload[8..], our_identifier)
            {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(payload_seq),
                    response_type,
                    is_pmtud: false,
                    mpls_labels: exts.mpls_labels,
                    interface_info: exts.interface_info,
                    src_port: None,
                    mtu,
                    quoted_ttl: Some(quoted_ttl),
                    original_dest,
                });
            }
            None
        }
        IPPROTO_TCP => {
            if original_payload.len() < 8 {
                return None;
            }
            let src_port = u16::from_be_bytes([original_payload[0], original_payload[1]]);
            let probe_id = extract_probe_id_from_tcp(original_payload)?;

            Some(ParsedResponse {
                responder,
                probe_id,
                response_type,
                is_pmtud: false,
                mpls_labels: exts.mpls_labels,
                interface_info: exts.interface_info,
                src_port: Some(src_port),
                mtu,
                quoted_ttl: Some(quoted_ttl),
                original_dest,
            })
        }
        IPPROTO_UDP => {
            if original_payload.len() < 8 + 6 {
                return None;
            }
            let src_port = u16::from_be_bytes([original_payload[0], original_payload[1]]);
            let udp_payload = &original_payload[8..];
            let probe_id = extract_probe_id_from_udp_payload(udp_payload)?;

            Some(ParsedResponse {
                responder,
                probe_id,
                response_type,
                is_pmtud: false,
                mpls_labels: exts.mpls_labels,
                interface_info: exts.interface_info,
                src_port: Some(src_port),
                mtu,
                quoted_ttl: Some(quoted_ttl),
                original_dest,
            })
        }
        _ => None,
    }
}

/// Parse IPv6 ICMPv6 from DGRAM socket (no IP header)
fn parse_icmp_response_v6_dgram(
    icmp_data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
) -> Option<ParsedResponse> {
    if icmp_data.len() < 8 {
        return None;
    }

    let icmp_type = icmp_data[0];
    let icmp_code = icmp_data[1];

    match icmp_type {
        ICMPV6_ECHO_REPLY => {
            let identifier = u16::from_be_bytes([icmp_data[4], icmp_data[5]]);
            let sequence = u16::from_be_bytes([icmp_data[6], icmp_data[7]]);

            if identifier == our_identifier {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(sequence),
                    response_type: IcmpResponseType::EchoReply,
                    is_pmtud: is_pmtud_payload(&icmp_data[8..]),
                    mpls_labels: None,
                    interface_info: None,
                    src_port: None,
                    mtu: None,
                    quoted_ttl: None,
                    // For Echo Reply, responder IS the target
                    original_dest: Some(responder),
                });
            }

            // Fallback: check payload
            if icmp_data.len() >= 12
                && let Some((_, payload_seq)) =
                    extract_id_from_payload(&icmp_data[8..], our_identifier)
            {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(payload_seq),
                    response_type: IcmpResponseType::EchoReply,
                    is_pmtud: is_pmtud_payload(&icmp_data[8..]),
                    mpls_labels: None,
                    interface_info: None,
                    src_port: None,
                    mtu: None,
                    quoted_ttl: None,
                    // For Echo Reply, responder IS the target
                    original_dest: Some(responder),
                });
            }
            None
        }
        ICMPV6_PACKET_TOO_BIG => {
            let mtu = if icmp_data.len() >= 8 {
                let mtu_val =
                    u32::from_be_bytes([icmp_data[4], icmp_data[5], icmp_data[6], icmp_data[7]]);
                if mtu_val > 0 && mtu_val <= 65535 {
                    Some(mtu_val as u16)
                } else {
                    None
                }
            } else {
                None
            };
            parse_icmp_error_payload_v6_dgram(
                icmp_data,
                responder,
                our_identifier,
                IcmpResponseType::PacketTooBig,
                mtu,
            )
        }
        ICMPV6_TIME_EXCEEDED => parse_icmp_error_payload_v6_dgram(
            icmp_data,
            responder,
            our_identifier,
            IcmpResponseType::TimeExceeded(icmp_code),
            None,
        ),
        ICMPV6_PARAMETER_PROBLEM => parse_icmp_error_payload_v6_dgram(
            icmp_data,
            responder,
            our_identifier,
            IcmpResponseType::ParameterProblem(icmp_code),
            None,
        ),
        ICMPV6_DEST_UNREACHABLE => parse_icmp_error_payload_v6_dgram(
            icmp_data,
            responder,
            our_identifier,
            IcmpResponseType::DestUnreachable(icmp_code),
            None,
        ),
        _ => None,
    }
}

/// Parse ICMPv6 error payload from DGRAM socket
fn parse_icmp_error_payload_v6_dgram(
    icmp_data: &[u8],
    responder: IpAddr,
    our_identifier: u16,
    response_type: IcmpResponseType,
    mtu: Option<u16>,
) -> Option<ParsedResponse> {
    const IPV6_HEADER_LEN: usize = 40;

    // Require: 8 (ICMPv6 header) + 40 (IPv6 header) + 8 (original ICMP/UDP header) = 56 bytes
    // Some routers send shorter payloads; log when this happens for debugging
    if icmp_data.len() < 8 + IPV6_HEADER_LEN + 8 {
        #[cfg(debug_assertions)]
        eprintln!(
            "ICMPv6 error dropped (dgram): payload too short ({} bytes, need 56) from {:?}",
            icmp_data.len(),
            responder
        );
        return None;
    }

    let icmp_length = icmp_data[4];
    let original_ipv6_data = &icmp_data[8..];
    let next_header = original_ipv6_data[6];
    let quoted_ttl = original_ipv6_data[7]; // Hop limit
    // Extract original destination for multi-target disambiguation (bytes 24-39)
    let original_dest = Some(IpAddr::V6(std::net::Ipv6Addr::new(
        u16::from_be_bytes([original_ipv6_data[24], original_ipv6_data[25]]),
        u16::from_be_bytes([original_ipv6_data[26], original_ipv6_data[27]]),
        u16::from_be_bytes([original_ipv6_data[28], original_ipv6_data[29]]),
        u16::from_be_bytes([original_ipv6_data[30], original_ipv6_data[31]]),
        u16::from_be_bytes([original_ipv6_data[32], original_ipv6_data[33]]),
        u16::from_be_bytes([original_ipv6_data[34], original_ipv6_data[35]]),
        u16::from_be_bytes([original_ipv6_data[36], original_ipv6_data[37]]),
        u16::from_be_bytes([original_ipv6_data[38], original_ipv6_data[39]]),
    )));
    // Walk extension headers in the quoted IPv6 packet to find the actual
    // transport header offset. Without this, extension headers shift
    // the transport header past byte 40 and we mis-correlate.
    let (transport_offset, final_next_header) =
        match skip_ipv6_ext_headers_quoted(original_ipv6_data) {
            Some((off, nh)) => (off, nh),
            None => {
                // No extension headers (or malformed): use the raw next_header
                // field and fixed 40-byte offset as before.
                (IPV6_HEADER_LEN, next_header)
            }
        };
    if transport_offset > original_ipv6_data.len() {
        return None;
    }
    let original_payload = &original_ipv6_data[transport_offset..];
    let next_header = final_next_header;

    // Parameter Problem: pointer, not length, and no extensions (RFC 4884 §4.6)
    let exts = if matches!(response_type, IcmpResponseType::ParameterProblem(_)) {
        ParsedIcmpExtensions::default()
    } else {
        parse_icmp_extensions(&icmp_data[8..], icmp_length, true)
    };

    match next_header {
        IPPROTO_ICMPV6 => {
            if original_payload.len() < 8 {
                return None;
            }

            if original_payload[0] != ICMPV6_ECHO_REQUEST {
                return None;
            }

            let identifier = u16::from_be_bytes([original_payload[4], original_payload[5]]);
            let sequence = u16::from_be_bytes([original_payload[6], original_payload[7]]);

            if identifier == our_identifier {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(sequence),
                    response_type,
                    is_pmtud: false,
                    mpls_labels: exts.mpls_labels,
                    interface_info: exts.interface_info,
                    src_port: None,
                    mtu,
                    quoted_ttl: Some(quoted_ttl),
                    original_dest,
                });
            }

            // Fallback: check quoted ICMPv6 payload
            if original_payload.len() >= 12
                && let Some((_, payload_seq)) =
                    extract_id_from_payload(&original_payload[8..], our_identifier)
            {
                return Some(ParsedResponse {
                    responder,
                    probe_id: ProbeId::from_sequence(payload_seq),
                    response_type,
                    is_pmtud: false,
                    mpls_labels: exts.mpls_labels,
                    interface_info: exts.interface_info,
                    src_port: None,
                    mtu,
                    quoted_ttl: Some(quoted_ttl),
                    original_dest,
                });
            }
            None
        }
        IPPROTO_TCP => {
            if original_payload.len() < 8 {
                return None;
            }
            let src_port = u16::from_be_bytes([original_payload[0], original_payload[1]]);
            let probe_id = extract_probe_id_from_tcp(original_payload)?;

            Some(ParsedResponse {
                responder,
                probe_id,
                response_type,
                src_port: Some(src_port),
                is_pmtud: false,
                mtu,
                mpls_labels: exts.mpls_labels,
                interface_info: exts.interface_info,
                quoted_ttl: Some(quoted_ttl),
                original_dest,
            })
        }
        IPPROTO_UDP => {
            if original_payload.len() < 8 + 6 {
                return None;
            }
            let src_port = u16::from_be_bytes([original_payload[0], original_payload[1]]);
            let udp_payload = &original_payload[8..];
            let probe_id = extract_probe_id_from_udp_payload(udp_payload)?;

            Some(ParsedResponse {
                responder,
                probe_id,
                response_type,
                src_port: Some(src_port),
                is_pmtud: false,
                mtu,
                mpls_labels: exts.mpls_labels,
                interface_info: exts.interface_info,
                quoted_ttl: Some(quoted_ttl),
                original_dest,
            })
        }
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Helper to compute and set ICMP checksum for a packet slice
    /// Assumes checksum field is at offset 2-3 of the ICMP section
    fn set_icmp_checksum(icmp_data: &mut [u8]) {
        // Clear checksum field first
        icmp_data[2] = 0;
        icmp_data[3] = 0;

        let mut sum: u32 = 0;
        let mut i = 0;
        while i + 1 < icmp_data.len() {
            sum += u16::from_be_bytes([icmp_data[i], icmp_data[i + 1]]) as u32;
            i += 2;
        }
        if i < icmp_data.len() {
            sum += (icmp_data[i] as u32) << 8;
        }
        while sum >> 16 != 0 {
            sum = (sum & 0xFFFF) + (sum >> 16);
        }
        let checksum = !sum as u16;
        icmp_data[2] = (checksum >> 8) as u8;
        icmp_data[3] = (checksum & 0xFF) as u8;
    }

    #[test]
    fn ipv6_parameter_problem_correlates_without_extensions() {
        let responder: IpAddr = "2001:db8::1".parse().unwrap();
        let sequence = ProbeId::new(5, 2).to_sequence();
        // Parameter Problem, code 1; pointer 0x10000000 would read as an
        // RFC 4884 length of 16 words (128 bytes) if misparsed.
        let mut packet = vec![4, 1, 0, 0, 0x10, 0, 0, 0];
        let mut quote = vec![0; 128];
        quote[0] = 0x60;
        quote[6] = IPPROTO_ICMPV6;
        quote[40] = ICMPV6_ECHO_REQUEST;
        quote[44..46].copy_from_slice(&0x1234u16.to_be_bytes());
        quote[46..48].copy_from_slice(&sequence.to_be_bytes());
        packet.extend_from_slice(&quote);
        packet.extend_from_slice(&[0x20, 0, 0, 0, 0, 8, 1, 1, 0x05, 0xdc, 0x07, 0x3e]);
        set_icmp_checksum(&mut packet[136..]);

        let mut raw = vec![0; 40];
        raw[0] = 0x60;
        raw[6] = IPPROTO_ICMPV6;
        raw.extend_from_slice(&packet);
        for parsed in [
            parse_icmp_response(&packet, responder, 0x1234, true).unwrap(),
            parse_icmp_response(&packet, responder, 0x1234, false).unwrap(),
            parse_icmp_response_v6(&raw, responder, 0x1234).unwrap(),
        ] {
            assert_eq!(parsed.probe_id, ProbeId::new(5, 2));
            assert_eq!(parsed.response_type, IcmpResponseType::ParameterProblem(1));
            assert!(parsed.mpls_labels.is_none());
        }
        assert!(parse_icmp_response(&packet, responder, 0x5678, true).is_none());
    }

    #[test]
    fn extension_checksum_and_legacy_detection() {
        for is_ipv6 in [false, true] {
            for quote_len in [128, 160] {
                let length = (quote_len / if is_ipv6 { 8 } else { 4 }) as u8;
                let mut payload = vec![0; quote_len];
                // An unknown object followed by a known MPLS object. The
                // checksum covers both objects, including the unknown one.
                payload.extend_from_slice(&[
                    0x20, 0, 0, 0, 0, 8, 250, 1, 1, 2, 3, 4, 0, 8, 1, 1, 0x05, 0xdc, 0x07, 0x3e,
                ]);
                assert_eq!(
                    parse_icmp_extensions(&payload, length, is_ipv6)
                        .mpls_labels
                        .unwrap()[0]
                        .label,
                    24000
                ); // Explicit length permits an omitted checksum.
                assert!(
                    parse_icmp_extensions(&payload, 0, is_ipv6)
                        .mpls_labels
                        .is_none()
                );

                set_icmp_checksum(&mut payload[quote_len..]);
                assert!(
                    parse_icmp_extensions(&payload, length, is_ipv6)
                        .mpls_labels
                        .is_some()
                );
                if quote_len == 128 {
                    assert!(
                        parse_icmp_extensions(&payload, 0, is_ipv6)
                            .mpls_labels
                            .is_some()
                    );
                }

                // Corrupt an unknown object's payload: validating just the
                // known object would miss this damage.
                payload[quote_len + 8] ^= 1;
                assert!(
                    parse_icmp_extensions(&payload, length, is_ipv6)
                        .mpls_labels
                        .is_none()
                );
                assert!(
                    parse_icmp_extensions(&payload, 0, is_ipv6)
                        .mpls_labels
                        .is_none()
                );
            }
        }
    }

    #[test]
    fn invalid_extension_checksum_keeps_correlated_response() {
        for (base, responder, is_v6, ext_start) in [
            (&ARISTA_PKT1_V4[14..], "198.51.100.33", false, 20 + 8 + 128),
            (&ARISTA_PKT1_V6[54..], "2001:db8:1::33", true, 8 + 128),
        ] {
            let mut packet = base.to_vec();
            // Damage the advertised interface MTU, leaving a valid ICMP
            // envelope. The response must still correlate, without metadata.
            packet[ext_start + 4 + 7] ^= 1;
            if !is_v6 {
                set_icmp_checksum(&mut packet[20..]);
            }
            let parsed = parse_icmp_response(&packet, responder.parse().unwrap(), 1, is_v6)
                .expect("extension damage must not turn a response into a timeout");
            assert_eq!(parsed.response_type, IcmpResponseType::TimeExceeded(0));
            assert!(parsed.interface_info.is_none());
            assert!(parsed.mpls_labels.is_none());
        }
    }

    #[test]
    fn extension_objects_require_whole_words() {
        let mut payload = vec![0; 128];
        payload.extend_from_slice(&[0x20, 0, 0, 0, 0, 9, 1, 1, 0x05, 0xdc, 0x07, 0x3e, 0]);
        set_icmp_checksum(&mut payload[128..]);
        assert!(
            parse_icmp_extensions(&payload, 32, false)
                .mpls_labels
                .is_none()
        );
    }

    #[test]
    fn test_probe_id_round_trip() {
        let original = ProbeId::new(15, 42);
        let sequence = original.to_sequence();
        let decoded = ProbeId::from_sequence(sequence);
        assert_eq!(original.ttl, decoded.ttl);
        assert_eq!(original.seq, decoded.seq);
    }

    #[test]
    fn test_probe_id_boundary_values() {
        // Test max TTL and seq values
        let max = ProbeId::new(255, 255);
        let decoded = ProbeId::from_sequence(max.to_sequence());
        assert_eq!(max.ttl, decoded.ttl);
        assert_eq!(max.seq, decoded.seq);

        // Test zero values
        let zero = ProbeId::new(0, 0);
        let decoded = ProbeId::from_sequence(zero.to_sequence());
        assert_eq!(zero.ttl, decoded.ttl);
        assert_eq!(zero.seq, decoded.seq);
    }

    #[test]
    fn test_empty_packet_returns_none() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        assert!(parse_icmp_response(&[], responder, 0x1234, false).is_none());
    }

    #[test]
    fn test_truncated_packet_returns_none() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        // Just an IP version nibble, nothing else
        let truncated = [0x45]; // IPv4, IHL=5
        assert!(parse_icmp_response(&truncated, responder, 0x1234, false).is_none());
    }

    #[test]
    fn test_invalid_ip_version_returns_none() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        // IP version 3 doesn't exist
        let invalid = [0x30, 0x00, 0x00, 0x00];
        assert!(parse_icmp_response(&invalid, responder, 0x1234, false).is_none());
    }

    #[test]
    fn test_identifier_mismatch_returns_none() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        // Build a valid-looking Echo Reply packet with wrong identifier
        // IPv4 header (20 bytes minimum with IHL=5) + ICMP header (8 bytes)
        let mut packet = vec![0u8; 28];

        // IPv4 header
        packet[0] = 0x45; // Version 4, IHL 5
        packet[9] = 1; // Protocol: ICMP

        // ICMP Echo Reply
        packet[20] = 0; // Type: Echo Reply
        packet[21] = 0; // Code: 0
        // Identifier: 0x5678 (wrong - we're looking for 0x1234)
        packet[24] = 0x56;
        packet[25] = 0x78;
        // Sequence
        packet[26] = 0x00;
        packet[27] = 0x01;

        assert!(parse_icmp_response(&packet, responder, 0x1234, false).is_none());
    }

    #[test]
    fn test_parse_echo_reply_v4() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));
        let our_id = 0x1234;

        // Build Echo Reply packet
        let mut packet = vec![0u8; 28];

        // IPv4 header
        packet[0] = 0x45; // Version 4, IHL 5 (20 bytes)
        packet[9] = 1; // Protocol: ICMP

        // ICMP Echo Reply
        packet[20] = 0; // Type: Echo Reply
        packet[21] = 0; // Code: 0
        // Identifier
        packet[24] = 0x12;
        packet[25] = 0x34;
        // Sequence (TTL=10, seq=5)
        let probe_id = ProbeId::new(10, 5);
        let seq = probe_id.to_sequence();
        packet[26] = (seq >> 8) as u8;
        packet[27] = (seq & 0xFF) as u8;

        // Set valid ICMP checksum
        set_icmp_checksum(&mut packet[20..]);

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.responder, responder);
        assert_eq!(parsed.probe_id.ttl, 10);
        assert_eq!(parsed.probe_id.seq, 5);
        assert_eq!(parsed.response_type, IcmpResponseType::EchoReply);
    }

    #[test]
    fn test_parse_time_exceeded_v4() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        let our_id = 0xABCD;

        // Build Time Exceeded packet
        // Outer IPv4 (20) + ICMP header (8) + Original IPv4 (20) + Original ICMP (8) = 56 bytes
        let mut packet = vec![0u8; 56];

        // Outer IPv4 header
        packet[0] = 0x45;
        packet[9] = 1; // ICMP

        // ICMP Time Exceeded
        packet[20] = 11; // Type: Time Exceeded
        packet[21] = 0; // Code: TTL exceeded

        // Original IP header (inside ICMP payload at offset 28)
        packet[28] = 0x45; // Version 4, IHL 5
        packet[37] = 1; // Protocol: ICMP

        // Original ICMP Echo Request (at offset 48)
        packet[48] = 8; // Type: Echo Request
        packet[49] = 0; // Code: 0
        // Identifier
        packet[52] = 0xAB;
        packet[53] = 0xCD;
        // Sequence (TTL=5, seq=3)
        let probe_id = ProbeId::new(5, 3);
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 5);
        assert_eq!(parsed.probe_id.seq, 3);
        assert_eq!(parsed.response_type, IcmpResponseType::TimeExceeded(0));
    }

    #[test]
    fn test_variable_ihl_v4() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));
        let our_id = 0x1234;

        // Build Echo Reply with IHL=6 (24 byte IP header with options)
        let mut packet = vec![0u8; 32]; // 24 IP + 8 ICMP

        // IPv4 header with IHL=6
        packet[0] = 0x46; // Version 4, IHL 6 (24 bytes)
        packet[9] = 1; // Protocol: ICMP

        // ICMP Echo Reply at offset 24
        packet[24] = 0; // Type: Echo Reply
        packet[25] = 0; // Code: 0
        // Identifier
        packet[28] = 0x12;
        packet[29] = 0x34;
        // Sequence
        let probe_id = ProbeId::new(7, 2);
        let seq = probe_id.to_sequence();
        packet[30] = (seq >> 8) as u8;
        packet[31] = (seq & 0xFF) as u8;

        // Set valid ICMP checksum (ICMP starts at offset 24)
        set_icmp_checksum(&mut packet[24..]);

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 7);
        assert_eq!(parsed.probe_id.seq, 2);
    }

    #[test]
    fn test_parse_echo_reply_v6() {
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(
            0x2001, 0x4860, 0x4860, 0, 0, 0, 0, 0x8888,
        ));
        let our_id = 0x1234;

        // Build ICMPv6 Echo Reply packet (no IPv6 header - kernel strips it on Linux)
        // ICMPv6 Echo Reply: 8 bytes header + payload
        let mut packet = vec![0u8; 12]; // 8 header + 4 payload for identifier backup

        // ICMPv6 Echo Reply
        packet[0] = 129; // Type: Echo Reply
        packet[1] = 0; // Code: 0
        // Checksum (bytes 2-3, kernel validates)
        // Identifier
        packet[4] = 0x12;
        packet[5] = 0x34;
        // Sequence (TTL=8, seq=4)
        let probe_id = ProbeId::new(8, 4);
        let seq = probe_id.to_sequence();
        packet[6] = (seq >> 8) as u8;
        packet[7] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.responder, responder);
        assert_eq!(parsed.probe_id.ttl, 8);
        assert_eq!(parsed.probe_id.seq, 4);
        assert_eq!(parsed.response_type, IcmpResponseType::EchoReply);
    }

    #[test]
    fn test_parse_time_exceeded_v6() {
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1));
        let our_id = 0xABCD;

        // Build ICMPv6 Time Exceeded packet (no outer IPv6 header - kernel strips it)
        // ICMPv6 header (8) + Original IPv6 (40) + Original ICMPv6 (8) = 56 bytes
        let mut packet = vec![0u8; 56];

        // ICMPv6 Time Exceeded
        packet[0] = 3; // Type: Time Exceeded
        packet[1] = 0; // Code: Hop limit exceeded
        // Checksum (bytes 2-3)
        // Unused (bytes 4-7)

        // Original IPv6 header (inside ICMPv6 payload at offset 8)
        packet[8] = 0x60; // Version 6
        packet[14] = 58; // Next Header: ICMPv6

        // Original ICMPv6 Echo Request (at offset 48 = 8 + 40)
        packet[48] = 128; // Type: Echo Request
        packet[49] = 0; // Code: 0
        // Identifier
        packet[52] = 0xAB;
        packet[53] = 0xCD;
        // Sequence (TTL=6, seq=2)
        let probe_id = ProbeId::new(6, 2);
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 6);
        assert_eq!(parsed.probe_id.seq, 2);
        assert_eq!(parsed.response_type, IcmpResponseType::TimeExceeded(0));
    }

    // Test: ICMPv6 error with quoted IPv6 packet containing extension headers.
    // Without extension header parsing, the transport header would be mis-aligned.
    #[test]
    fn test_parse_time_exceeded_v6_with_ext_headers() {
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1));
        let our_id = 0xABCD;

        // Layout:
        // [0-7]   ICMPv6 Time Exceeded header
        // [8-47]  Original IPv6 header (40 bytes) — Next Header = Hop-by-Hop (0)
        // [48-55] Hop-by-Hop extension header (8 bytes) — Next Header = ICMPv6 (58)
        // [56-63] Original ICMPv6 Echo Request (8 bytes)
        // Total: 64 bytes
        let mut packet = vec![0u8; 64];

        // ICMPv6 Time Exceeded
        packet[0] = 3; // Type: Time Exceeded
        packet[1] = 0; // Code: Hop limit exceeded

        // Original IPv6 header (offset 8)
        packet[8] = 0x60; // Version 6
        packet[14] = 0; // Next Header: Hop-by-Hop (0)
        packet[15] = 1; // Hop limit (quoted TTL)

        // Hop-by-Hop extension header (offset 48 = 8 + 40)
        packet[48] = 58; // Next Header: ICMPv6 (58)
        packet[49] = 0; // Length: 0 (8 bytes total, excluding first 8 → (0+1)*8=8)

        // Original ICMPv6 Echo Request (offset 56 = 48 + 8)
        packet[56] = 128; // Type: Echo Request
        packet[57] = 0; // Code: 0
        packet[60] = 0xAB; // Identifier high
        packet[61] = 0xCD; // Identifier low
        let probe_id = ProbeId::new(6, 2);
        let seq = probe_id.to_sequence();
        packet[62] = (seq >> 8) as u8;
        packet[63] = (seq & 0xFF) as u8;

        // Parse as DGRAM (no outer IP header, starts at ICMPv6)
        let result = parse_icmp_response(&packet, responder, our_id, true);
        assert!(result.is_some(), "should parse with extension headers");

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 6);
        assert_eq!(parsed.probe_id.seq, 2);
        assert_eq!(parsed.response_type, IcmpResponseType::TimeExceeded(0));
        assert_eq!(parsed.quoted_ttl, Some(1));
    }

    // Test: extension header with Routing header type should also be skipped
    #[test]
    fn test_parse_time_exceeded_v6_with_routing_ext_header() {
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1));
        let our_id = 0xABCD;

        // Layout with Routing extension header (NH=43):
        // [0-7]   ICMPv6 Time Exceeded
        // [8-47]  IPv6 header — Next Header = Routing (43)
        // [48-55] Routing ext header (8 bytes) — Next Header = ICMPv6 (58)
        // [56-63] ICMPv6 Echo Request
        let mut packet = vec![0u8; 64];

        packet[0] = 3;
        packet[8] = 0x60;
        packet[14] = 43; // Next Header: Routing
        packet[15] = 2; // Hop limit

        // Routing extension header (offset 48)
        packet[48] = 58; // Next Header: ICMPv6
        packet[49] = 0; // Length: 0 → 8 bytes

        // ICMPv6 Echo Request (offset 56)
        packet[56] = 128;
        packet[60] = 0xAB;
        packet[61] = 0xCD;
        let probe_id = ProbeId::new(8, 3);
        let seq = probe_id.to_sequence();
        packet[62] = (seq >> 8) as u8;
        packet[63] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, true);
        assert!(result.is_some());
        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 8);
        assert_eq!(parsed.probe_id.seq, 3);
        assert_eq!(parsed.quoted_ttl, Some(2));
    }

    // Test: fragment extension header in quoted packet should be rejected
    #[test]
    fn test_parse_v6_error_quoted_fragment_rejected() {
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1));
        let our_id = 0xABCD;

        // IPv6 header with Next Header = Fragment (44)
        let mut packet = vec![0u8; 64];
        packet[0] = 3;
        packet[8] = 0x60;
        packet[14] = 44; // Next Header: Fragment
        packet[15] = 1;

        // Fragment header (offset 48)
        packet[48] = 58; // Next Header: ICMPv6

        // ICMPv6 at offset 56
        packet[56] = 128;
        packet[60] = 0xAB;
        packet[61] = 0xCD;
        let probe_id = ProbeId::new(4, 1);
        let seq = probe_id.to_sequence();
        packet[62] = (seq >> 8) as u8;
        packet[63] = (seq & 0xFF) as u8;

        // Fragment headers in quoted packets should be rejected (can't reassemble)
        let result = parse_icmp_response(&packet, responder, our_id, true);
        assert!(result.is_none());
    }

    #[test]
    fn test_parse_v6_error_quoted_ext_header_without_transport_rejected() {
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1));
        let our_id = 0xABCD;

        // ICMPv6 Time Exceeded quoting an IPv6 packet whose Hop-by-Hop header
        // points to ICMPv6, but the quote ends before the ICMPv6 header. This
        // must return None rather than indexing an empty transport payload.
        let mut packet = vec![0u8; 56];
        packet[0] = 3; // Time Exceeded
        packet[1] = 0; // Hop limit exceeded
        packet[8] = 0x60; // Quoted IPv6 version
        packet[14] = 0; // Next Header: Hop-by-Hop
        packet[15] = 1; // Quoted hop limit
        packet[48] = 58; // Hop-by-Hop Next Header: ICMPv6
        packet[49] = 0; // 8-byte extension header, no transport bytes follow

        let result = parse_icmp_response(&packet, responder, our_id, true);
        assert!(result.is_none());
    }

    #[test]
    fn test_ipv6_fragment_header_rejected() {
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(
            0x2001, 0x4860, 0x4860, 0, 0, 0, 0, 0x8888,
        ));
        let our_id = 0x1234;

        // Build IPv6 with Fragment header - should be rejected
        let mut packet = vec![0u8; 56];

        // IPv6 header
        packet[0] = 0x60;
        packet[6] = 44; // Next Header: Fragment

        // Fragment header at offset 40
        packet[40] = 58; // Next Header: ICMPv6
        // Fragment header is 8 bytes

        // ICMPv6 at offset 48
        packet[48] = 129; // Echo Reply
        packet[52] = 0x12;
        packet[53] = 0x34;

        // Fragments are rejected (we don't handle reassembly)
        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_none());
    }

    #[test]
    fn test_invalid_icmp_checksum_rejected() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));
        let our_id = 0x1234;

        // Build Echo Reply with invalid checksum
        let mut packet = vec![0u8; 28];

        // IPv4 header
        packet[0] = 0x45;
        packet[9] = 1; // ICMP

        // ICMP Echo Reply with bad checksum
        packet[20] = 0; // Type: Echo Reply
        packet[21] = 0; // Code: 0
        packet[22] = 0xFF; // Invalid checksum
        packet[23] = 0xFF;
        packet[24] = 0x12;
        packet[25] = 0x34;
        let probe_id = ProbeId::new(1, 1);
        let seq = probe_id.to_sequence();
        packet[26] = (seq >> 8) as u8;
        packet[27] = (seq & 0xFF) as u8;

        // Should be rejected due to invalid checksum
        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_none());
    }

    #[test]
    fn test_dest_unreachable_v4() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        let our_id = 0xDEAD;

        // Build Destination Unreachable packet (similar structure to Time Exceeded)
        let mut packet = vec![0u8; 56];

        // Outer IPv4 header
        packet[0] = 0x45;
        packet[9] = 1;

        // ICMP Destination Unreachable
        packet[20] = 3; // Type: Destination Unreachable
        packet[21] = 1; // Code: Host Unreachable

        // Original IP header at offset 28
        packet[28] = 0x45;
        packet[37] = 1;

        // Original ICMP at offset 48
        packet[48] = 8; // Echo Request
        packet[52] = 0xDE;
        packet[53] = 0xAD;
        let probe_id = ProbeId::new(12, 3);
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 12);
        assert_eq!(parsed.probe_id.seq, 3);
        assert!(matches!(
            parsed.response_type,
            IcmpResponseType::DestUnreachable(1)
        ));
    }

    #[test]
    fn test_mpls_label_parsing() {
        // Test MplsLabel::from_bytes parsing
        // Label = 24000 (0x5DC0), Exp = 3, Bottom = true, TTL = 62
        // Binary: 0000 0101 1101 1100 0000 0111 0011 1110
        //         |------- label (20) ------||exp||S|TTL|
        let bytes: [u8; 4] = [0x05, 0xDC, 0x07, 0x3E];
        let label = MplsLabel::from_bytes(&bytes);
        assert_eq!(label.label, 24000);
        assert_eq!(label.exp, 3);
        assert!(label.bottom);
        assert_eq!(label.ttl, 62);
    }

    #[test]
    fn test_mpls_label_stack_parsing() {
        // Test parsing MPLS label stack from ICMP extension
        // Label 1: 16000, Exp=0, S=0, TTL=64
        // Label 2: 24000, Exp=3, S=1, TTL=62
        let label1 = MplsLabel {
            label: 16000,
            exp: 0,
            bottom: false,
            ttl: 64,
        };
        let label2 = MplsLabel {
            label: 24000,
            exp: 3,
            bottom: true,
            ttl: 62,
        };

        // Encode labels
        fn encode_label(l: &MplsLabel) -> [u8; 4] {
            let word = (l.label << 12)
                | ((l.exp as u32) << 9)
                | (if l.bottom { 1 << 8 } else { 0 })
                | (l.ttl as u32);
            word.to_be_bytes()
        }

        let l1_bytes = encode_label(&label1);
        let l2_bytes = encode_label(&label2);

        // Verify parsing roundtrip
        let parsed1 = MplsLabel::from_bytes(&l1_bytes);
        assert_eq!(parsed1.label, 16000);
        assert_eq!(parsed1.exp, 0);
        assert!(!parsed1.bottom);
        assert_eq!(parsed1.ttl, 64);

        let parsed2 = MplsLabel::from_bytes(&l2_bytes);
        assert_eq!(parsed2.label, 24000);
        assert_eq!(parsed2.exp, 3);
        assert!(parsed2.bottom);
        assert_eq!(parsed2.ttl, 62);
    }

    // Reporter-supplied frame from issue #134, Ethernet header removed:
    // https://www.ltri.net/download/19b9cd22-2f03-4d38-9a5e-21b6bd908b33/icmp-mpls-trace-1-frame.pcap
    // The router reports the unpadded quote length (17 words), but places the
    // extension after 128 bytes. Its checksum is valid and label is 416760.
    const MPLS_SHORT_LENGTH_V4: &[u8] = &[
        69, 0, 0, 168, 233, 158, 0, 0, 245, 1, 110, 186, 62, 115, 140, 202, 159, 69, 2, 121, 11, 0,
        244, 238, 0, 17, 0, 0, 69, 0, 0, 84, 19, 211, 0, 0, 1, 1, 142, 205, 159, 69, 2, 121, 162,
        33, 211, 41, 8, 0, 43, 67, 75, 229, 9, 0, 75, 229, 9, 0, 240, 42, 8, 133, 0, 1, 2, 3, 4, 5,
        6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
        30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 248, 53, 0, 8, 1, 1, 101, 191, 129, 1,
    ];

    #[test]
    fn test_mpls_capture_with_unpadded_length() {
        let packet = MPLS_SHORT_LENGTH_V4;
        let our_id = u16::from_be_bytes([packet[52], packet[53]]);
        let responder = IpAddr::V4(Ipv4Addr::new(
            packet[12], packet[13], packet[14], packet[15],
        ));
        let parsed = parse_icmp_response(packet, responder, our_id, false).unwrap();
        let labels = parsed.mpls_labels.expect("MPLS stack after padded quote");
        assert_eq!(labels.len(), 1);
        assert_eq!(labels[0].label, 416760);
        assert_eq!(labels[0].exp, 0);
        assert!(labels[0].bottom);
        assert_eq!(labels[0].ttl, 1);
    }

    #[test]
    fn test_ipv6_extensions_with_unpadded_length() {
        let mut payload = vec![0; 128];
        payload.extend_from_slice(&[0x20, 0, 0, 0, 0, 8, 1, 1, 0x65, 0xbf, 0x81, 1]);
        // 8 * 8 = 64 quoted bytes; the extension follows the required padding.
        let labels = parse_icmp_extensions(&payload, 8, true)
            .mpls_labels
            .unwrap();
        assert_eq!(labels[0].label, 416760);
    }

    #[test]
    fn test_short_extension_length_still_requires_padding() {
        // Do not interpret bytes inside a short, unpadded quote as extensions.
        let mut payload = vec![0; 68];
        payload.extend_from_slice(&[0x20, 0, 0, 0, 0, 8, 1, 1, 0x65, 0xbf, 0x81, 1]);
        let parsed = parse_icmp_extensions(&payload, 17, false);
        assert!(parsed.mpls_labels.is_none());
        assert!(parsed.interface_info.is_none());
    }

    #[test]
    fn test_time_exceeded_with_mpls_extension() {
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(10, 0, 0, 1));
        let our_id = 0x1234;

        // Build Time Exceeded with MPLS extension
        // Layout:
        // [0-19]   Outer IPv4 header (20 bytes)
        // [20-27]  ICMP header (8 bytes: type, code, checksum, unused)
        // [28-155] Original datagram (padded to 128 bytes for extensions)
        // [156-159] Extension header (4 bytes: version, reserved, checksum)
        // [160-163] MPLS object header (4 bytes: length, class, type)
        // [164-167] MPLS label entry (4 bytes)

        let mut packet = vec![0u8; 168];

        // Outer IPv4 header
        packet[0] = 0x45;
        packet[9] = 1; // ICMP

        // ICMP Time Exceeded
        packet[20] = 11; // Type: Time Exceeded
        packet[21] = 0; // Code: TTL exceeded

        // Original IP header (at offset 28)
        packet[28] = 0x45;
        packet[37] = 1; // Protocol: ICMP

        // Original ICMP Echo Request (at offset 48)
        packet[48] = 8; // Type: Echo Request
        packet[49] = 0; // Code: 0
        packet[52] = 0x12; // Identifier
        packet[53] = 0x34;
        let probe_id = ProbeId::new(5, 1);
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        // ICMP Extension header (at offset 156 = 28 + 128)
        // Version 2, reserved, checksum
        packet[156] = 0x20; // Version 2 in high nibble
        packet[157] = 0x00;
        packet[158] = 0x00; // Filled below after the objects
        packet[159] = 0x00;

        // MPLS extension object header (at offset 160)
        packet[160] = 0x00; // Length high byte
        packet[161] = 0x08; // Length = 8 (header + 1 label)
        packet[162] = 0x01; // Class = 1 (MPLS)
        packet[163] = 0x01; // Type = 1 (Label Stack)

        // MPLS label: label=24000, exp=3, S=1, TTL=62
        // word = (24000 << 12) | (3 << 9) | (1 << 8) | 62
        let label_word: u32 = (24000 << 12) | (3 << 9) | (1 << 8) | 62;
        let label_bytes = label_word.to_be_bytes();
        packet[164..168].copy_from_slice(&label_bytes);

        set_icmp_checksum(&mut packet[156..]);

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 5);
        assert_eq!(parsed.probe_id.seq, 1);
        assert_eq!(parsed.response_type, IcmpResponseType::TimeExceeded(0));

        // Verify MPLS labels were parsed
        assert!(parsed.mpls_labels.is_some());
        let labels = parsed.mpls_labels.unwrap();
        assert_eq!(labels.len(), 1);
        assert_eq!(labels[0].label, 24000);
        assert_eq!(labels[0].exp, 3);
        assert!(labels[0].bottom);
        assert_eq!(labels[0].ttl, 62);
    }

    #[test]
    fn test_time_exceeded_with_mpls_rfc4884_length() {
        // Test RFC 4884 compliant packet with non-zero length field
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(10, 0, 0, 1));
        let our_id = 0x1234;

        // Layout with RFC 4884 length field:
        // Original datagram = 160 bytes (40 * 4), so length field = 40
        // Extensions start at offset 28 + 160 = 188
        let mut packet = vec![0u8; 200];

        // Outer IPv4 header
        packet[0] = 0x45;
        packet[9] = 1; // ICMP

        // ICMP Time Exceeded with RFC 4884 length field
        packet[20] = 11; // Type: Time Exceeded
        packet[21] = 0; // Code: TTL exceeded
        packet[25] = 40; // Length = 40 (160 bytes of padded original datagram)

        // Original IP header (at offset 28)
        packet[28] = 0x45;
        packet[37] = 1; // Protocol: ICMP

        // Original ICMP Echo Request (at offset 48)
        packet[48] = 8; // Type: Echo Request
        packet[52] = 0x12; // Identifier
        packet[53] = 0x34;
        let probe_id = ProbeId::new(3, 2);
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        // Extension header at offset 188 (28 + 160)
        packet[188] = 0x20; // Version 2
        packet[189] = 0x00;
        packet[190] = 0x00; // Checksum
        packet[191] = 0x00;

        // MPLS object header at offset 192
        packet[192] = 0x00;
        packet[193] = 0x08; // Length = 8
        packet[194] = 0x01; // Class = 1 (MPLS)
        packet[195] = 0x01; // Type = 1

        // MPLS label: label=16000, exp=0, S=1, TTL=64
        let label_word: u32 = (16000 << 12) | (1 << 8) | 64;
        let label_bytes = label_word.to_be_bytes();
        packet[196..200].copy_from_slice(&label_bytes);

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 3);
        assert_eq!(parsed.probe_id.seq, 2);

        // Verify MPLS labels were parsed using RFC 4884 length field
        assert!(parsed.mpls_labels.is_some());
        let labels = parsed.mpls_labels.unwrap();
        assert_eq!(labels.len(), 1);
        assert_eq!(labels[0].label, 16000);
        assert_eq!(labels[0].ttl, 64);
    }

    #[test]
    fn test_time_exceeded_without_extension() {
        // Same test as test_parse_time_exceeded_v4 but verify no MPLS labels
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        let our_id = 0xABCD;

        // Packet without extensions (too short for extensions)
        let mut packet = vec![0u8; 56];

        packet[0] = 0x45;
        packet[9] = 1;
        packet[20] = 11;
        packet[21] = 0;
        packet[28] = 0x45;
        packet[37] = 1;
        packet[48] = 8;
        packet[52] = 0xAB;
        packet[53] = 0xCD;
        let probe_id = ProbeId::new(5, 3);
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());

        let parsed = result.unwrap();
        // Should have no MPLS labels (packet too short)
        assert!(parsed.mpls_labels.is_none());
    }

    // ========================================================================
    // DGRAM socket tests (macOS - no IP header in packets)
    // ========================================================================

    #[test]
    fn test_parse_echo_reply_dgram() {
        // DGRAM sockets don't include IP header - packet starts at ICMP
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));
        let our_id = 0x1234;

        // ICMP Echo Reply (no IP header): 8 bytes header + 8 bytes payload
        let mut packet = vec![0u8; 16];

        // ICMP header
        packet[0] = 0; // Type: Echo Reply
        packet[1] = 0; // Code: 0
        // Checksum will be set below
        packet[4] = 0x12; // Identifier high byte
        packet[5] = 0x34; // Identifier low byte

        // Sequence (TTL=10, seq=5)
        let probe_id = ProbeId::new(10, 5);
        let seq = probe_id.to_sequence();
        packet[6] = (seq >> 8) as u8;
        packet[7] = (seq & 0xFF) as u8;

        // Payload: embedded ProbeId at bytes 0-3 (for macOS DGRAM fallback)
        packet[8] = 0x12; // Identifier high byte
        packet[9] = 0x34; // Identifier low byte
        packet[10] = (seq >> 8) as u8; // Sequence high byte
        packet[11] = (seq & 0xFF) as u8; // Sequence low byte

        // Set valid ICMP checksum
        set_icmp_checksum(&mut packet);

        let result = parse_icmp_response(&packet, responder, our_id, true); // is_dgram=true
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.responder, responder);
        assert_eq!(parsed.probe_id.ttl, 10);
        assert_eq!(parsed.probe_id.seq, 5);
        assert_eq!(parsed.response_type, IcmpResponseType::EchoReply);
    }

    #[test]
    fn test_parse_time_exceeded_dgram() {
        // DGRAM sockets don't include outer IP header - packet starts at ICMP
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        let our_id = 0xABCD;

        // ICMP Time Exceeded (8) + Original IPv4 (20) + Original ICMP (12) = 40 bytes
        // Note: 12 bytes of original ICMP to include payload for fallback test
        let mut packet = vec![0u8; 40];

        // ICMP Time Exceeded header
        packet[0] = 11; // Type: Time Exceeded
        packet[1] = 0; // Code: TTL exceeded
        // Checksum at [2-3] - not validated for error messages
        // Unused at [4-7]

        // Original IP header (inside ICMP payload at offset 8)
        packet[8] = 0x45; // Version 4, IHL 5
        packet[17] = 1; // Protocol: ICMP

        // Original ICMP Echo Request (at offset 28 = 8 + 20)
        packet[28] = 8; // Type: Echo Request
        packet[29] = 0; // Code: 0
        // Checksum at [30-31]
        packet[32] = 0xAB; // Identifier high byte
        packet[33] = 0xCD; // Identifier low byte

        // Sequence (TTL=5, seq=3)
        let probe_id = ProbeId::new(5, 3);
        let seq = probe_id.to_sequence();
        packet[34] = (seq >> 8) as u8;
        packet[35] = (seq & 0xFF) as u8;

        // Original ICMP payload: embedded ProbeId at bytes 0-3 (offset 36-39)
        packet[36] = 0xAB; // Identifier high byte
        packet[37] = 0xCD; // Identifier low byte
        packet[38] = (seq >> 8) as u8;
        packet[39] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, true); // is_dgram=true
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 5);
        assert_eq!(parsed.probe_id.seq, 3);
        assert!(matches!(
            parsed.response_type,
            IcmpResponseType::TimeExceeded(0)
        ));
    }

    #[test]
    fn test_parse_echo_reply_dgram_payload_fallback() {
        // Test the payload-based identifier fallback when ICMP header identifier differs
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));
        let our_id = 0x1234;

        let mut packet = vec![0u8; 16];

        // ICMP header with DIFFERENT identifier (simulating macOS override)
        packet[0] = 0; // Type: Echo Reply
        packet[1] = 0; // Code: 0
        packet[4] = 0xFF; // Wrong identifier high byte
        packet[5] = 0xFF; // Wrong identifier low byte

        let probe_id = ProbeId::new(10, 5);
        let seq = probe_id.to_sequence();
        packet[6] = (seq >> 8) as u8;
        packet[7] = (seq & 0xFF) as u8;

        // Payload: CORRECT identifier (fallback should find this)
        packet[8] = 0x12; // Identifier high byte
        packet[9] = 0x34; // Identifier low byte
        packet[10] = (seq >> 8) as u8;
        packet[11] = (seq & 0xFF) as u8;

        set_icmp_checksum(&mut packet);

        let result = parse_icmp_response(&packet, responder, our_id, true);
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 10);
        assert_eq!(parsed.probe_id.seq, 5);
    }

    #[test]
    fn test_parse_echo_reply_raw_payload_fallback() {
        // Test RAW socket payload fallback when ICMP header identifier differs
        // This happens on macOS when send uses DGRAM (kernel may modify ID) but recv uses RAW
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));
        let our_id = 0x1234;

        // RAW packet: 20 IP + 8 ICMP header + 8 payload = 36 bytes
        let mut packet = vec![0u8; 36];

        // IPv4 header
        packet[0] = 0x45; // Version 4, IHL 5 (20 bytes)
        packet[9] = 1; // Protocol: ICMP

        // ICMP Echo Reply with WRONG identifier (offset 20)
        packet[20] = 0; // Type: Echo Reply
        packet[21] = 0; // Code: 0
        packet[24] = 0xFF; // Wrong ID high
        packet[25] = 0xFF; // Wrong ID low

        let probe_id = ProbeId::new(10, 5);
        let seq = probe_id.to_sequence();
        packet[26] = (seq >> 8) as u8;
        packet[27] = (seq & 0xFF) as u8;

        // Payload with CORRECT identifier (offset 28)
        packet[28] = 0x12; // our_id high
        packet[29] = 0x34; // our_id low
        packet[30] = (seq >> 8) as u8;
        packet[31] = (seq & 0xFF) as u8;

        // Set valid ICMP checksum (ICMP starts at offset 20)
        set_icmp_checksum(&mut packet[20..]);

        let result = parse_icmp_response(&packet, responder, our_id, false); // is_dgram=false (RAW)
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 10);
        assert_eq!(parsed.probe_id.seq, 5);
        assert_eq!(parsed.response_type, IcmpResponseType::EchoReply);
    }

    #[test]
    fn test_parse_time_exceeded_raw_payload_fallback() {
        // Test RAW socket Time Exceeded payload fallback when ICMP header identifier differs
        // This is the intermediate router case - the actual traceroute hops
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
        let our_id = 0x1234;

        // RAW Time Exceeded packet structure:
        // [0-19]   Outer IP header (20 bytes)
        // [20-27]  ICMP Time Exceeded header (8 bytes): type=11, code=0, checksum, unused
        // [28-47]  Original IP header (20 bytes)
        // [48-63]  Original ICMP Echo Request (8 header + 8 payload = 16 bytes)
        let mut packet = vec![0u8; 64];

        // Outer IPv4 header
        packet[0] = 0x45; // Version 4, IHL 5 (20 bytes)
        packet[9] = 1; // Protocol: ICMP

        // ICMP Time Exceeded header (offset 20)
        packet[20] = 11; // Type: Time Exceeded
        packet[21] = 0; // Code: TTL exceeded in transit

        // Original IP header (offset 28)
        packet[28] = 0x45; // Version 4, IHL 5
        packet[37] = 1; // Protocol: ICMP

        // Original ICMP Echo Request (offset 48)
        packet[48] = 8; // Type: Echo Request
        packet[49] = 0; // Code: 0
        // Wrong identifier in ICMP header
        packet[52] = 0xFF; // Wrong ID high
        packet[53] = 0xFF; // Wrong ID low

        let probe_id = ProbeId::new(3, 1); // TTL 3, seq 1
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        // Payload with CORRECT identifier (offset 56 = 48 + 8)
        packet[56] = 0x12; // our_id high
        packet[57] = 0x34; // our_id low
        packet[58] = (seq >> 8) as u8;
        packet[59] = (seq & 0xFF) as u8;

        // Set ICMP checksum for outer Time Exceeded (offset 20, length 44)
        set_icmp_checksum(&mut packet[20..]);

        let result = parse_icmp_response(&packet, responder, our_id, false); // is_dgram=false (RAW)
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 3);
        assert_eq!(parsed.probe_id.seq, 1);
        assert!(matches!(
            parsed.response_type,
            IcmpResponseType::TimeExceeded(0)
        ));
    }

    #[test]
    fn test_parse_echo_reply_v6_raw_payload_fallback() {
        // IPv6 RAW receive path on Linux uses ICMPv6 payload without outer IPv6 header.
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0x1));
        let our_id = 0x1234;

        // ICMPv6 Echo Reply: 8-byte header + 4-byte payload fallback
        let mut packet = vec![0u8; 12];
        packet[0] = 129; // Echo Reply
        packet[1] = 0; // Code
        packet[4] = 0xFF; // Wrong identifier high
        packet[5] = 0xFF; // Wrong identifier low

        let probe_id = ProbeId::new(9, 4);
        let seq = probe_id.to_sequence();
        packet[6] = (seq >> 8) as u8;
        packet[7] = (seq & 0xFF) as u8;

        // Payload with correct identifier/sequence for fallback.
        packet[8] = 0x12;
        packet[9] = 0x34;
        packet[10] = (seq >> 8) as u8;
        packet[11] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, false); // RAW path
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 9);
        assert_eq!(parsed.probe_id.seq, 4);
        assert_eq!(parsed.response_type, IcmpResponseType::EchoReply);
    }

    #[test]
    fn test_parse_time_exceeded_v6_raw_payload_fallback() {
        let responder = IpAddr::V6(std::net::Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0x2));
        let our_id = 0x1234;

        // ICMPv6 Time Exceeded (8) + original IPv6 (40) + original ICMPv6 (12)
        // Include 4 bytes of quoted payload to exercise fallback path.
        let mut packet = vec![0u8; 60];
        packet[0] = 3; // Time Exceeded
        packet[1] = 0; // Hop limit exceeded

        // Original IPv6 header (offset 8)
        packet[8] = 0x60; // Version 6
        packet[14] = 58; // Next Header: ICMPv6
        packet[15] = 1; // Quoted hop limit

        // Original ICMPv6 Echo Request (offset 48)
        packet[48] = 128; // Echo Request
        packet[49] = 0; // Code
        packet[52] = 0xFF; // Wrong identifier high
        packet[53] = 0xFF; // Wrong identifier low

        let probe_id = ProbeId::new(6, 7);
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        // Quoted ICMPv6 payload fallback (offset 56)
        packet[56] = 0x12; // Correct identifier high
        packet[57] = 0x34; // Correct identifier low
        packet[58] = (seq >> 8) as u8;
        packet[59] = (seq & 0xFF) as u8;

        let result = parse_icmp_response(&packet, responder, our_id, false); // RAW path
        assert!(result.is_some());

        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 6);
        assert_eq!(parsed.probe_id.seq, 7);
        assert!(matches!(
            parsed.response_type,
            IcmpResponseType::TimeExceeded(0)
        ));
    }

    // ========================================================================
    // Property-based tests (proptest)
    // ========================================================================

    use proptest::prelude::*;

    proptest! {
        /// ProbeId should roundtrip through sequence encoding for all values
        #[test]
        fn proptest_probe_id_roundtrip(ttl in 0u8..=255, seq in 0u8..=255) {
            let original = ProbeId::new(ttl, seq);
            let encoded = original.to_sequence();
            let decoded = ProbeId::from_sequence(encoded);

            prop_assert_eq!(decoded.ttl, original.ttl);
            prop_assert_eq!(decoded.seq, original.seq);
        }

        /// Any u16 sequence should decode and re-encode to the same value
        #[test]
        fn proptest_probe_id_from_any_sequence(seq in 0u16..=65535) {
            let decoded = ProbeId::from_sequence(seq);
            let re_encoded = decoded.to_sequence();

            prop_assert_eq!(re_encoded, seq);
        }

        /// MplsLabel should correctly parse label, exp, bottom, and ttl fields
        #[test]
        fn proptest_mpls_label_parsing(
            label in 0u32..=0xFFFFF,  // 20 bits
            exp in 0u8..=7,           // 3 bits
            bottom in prop::bool::ANY,
            ttl in 0u8..=255          // 8 bits
        ) {
            let bottom_bit = if bottom { 1u32 } else { 0u32 };
            let word = (label << 12) | ((exp as u32) << 9) | (bottom_bit << 8) | (ttl as u32);
            let bytes = word.to_be_bytes();

            let parsed = MplsLabel::from_bytes(&bytes);

            prop_assert_eq!(parsed.label, label);
            prop_assert_eq!(parsed.exp, exp);
            prop_assert_eq!(parsed.bottom, bottom);
            prop_assert_eq!(parsed.ttl, ttl);
        }

        /// Any 4 bytes should parse as MplsLabel without panicking
        #[test]
        fn proptest_mpls_label_no_panic(b0 in 0u8..=255, b1 in 0u8..=255, b2 in 0u8..=255, b3 in 0u8..=255) {
            let bytes = [b0, b1, b2, b3];
            let _ = MplsLabel::from_bytes(&bytes);
        }

        /// Random bytes should not panic when parsed as ICMP
        #[test]
        fn proptest_parse_icmp_no_panic(data in prop::collection::vec(0u8..=255, 0..9216)) {
            let responder = IpAddr::V4(std::net::Ipv4Addr::new(192, 168, 1, 1));
            let _ = parse_icmp_response(&data, responder, 0x1234, false);
        }

        /// Packets with random IP version nibbles should not panic
        #[test]
        fn proptest_parse_icmp_random_version(version in 0u8..=15, rest in prop::collection::vec(0u8..=255, 20..100)) {
            let mut data = rest;
            if !data.is_empty() {
                data[0] = (version << 4) | (data[0] & 0x0F);
            }

            let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));
            let _ = parse_icmp_response(&data, responder, 0x5678, false);
        }

        /// IPv4 packets with various IHL values should not panic
        #[test]
        fn proptest_parse_ipv4_variable_ihl(
            ihl in 5u8..=15,
            payload in prop::collection::vec(0u8..=255, 0..200)
        ) {
            let header_len = (ihl as usize) * 4;
            let mut data = vec![0u8; header_len.max(20) + payload.len()];

            data[0] = 0x40 | ihl;
            let len = data.len() as u16;
            data[2] = (len >> 8) as u8;
            data[3] = len as u8;
            data[9] = 1; // ICMP

            if header_len < data.len() {
                let copy_len = payload.len().min(data.len() - header_len);
                data[header_len..header_len + copy_len].copy_from_slice(&payload[..copy_len]);
            }

            let responder = IpAddr::V4(std::net::Ipv4Addr::new(172, 16, 0, 1));
            let _ = parse_icmp_response(&data, responder, 0x9999, false);
        }

        /// ICMP checksum validation should handle all byte patterns
        #[test]
        fn proptest_checksum_no_panic(data in prop::collection::vec(0u8..=255, 0..100)) {
            let _ = validate_icmp_checksum(&data);
        }

        /// Valid checksums should validate correctly
        #[test]
        fn proptest_valid_checksum_validates(
            identifier in 0u16..=65535,
            sequence in 0u16..=65535
        ) {
            // Build Echo Reply with correct checksum
            let mut packet = vec![
                0,    // Type: Echo Reply
                0,    // Code
                0, 0, // Checksum (placeholder)
                (identifier >> 8) as u8,
                identifier as u8,
                (sequence >> 8) as u8,
                sequence as u8,
            ];

            set_icmp_checksum(&mut packet);
            prop_assert!(validate_icmp_checksum(&packet));
        }

        /// Packets too short for valid IP headers should return None
        #[test]
        fn proptest_short_packets_return_none(size in 0usize..20) {
            let data = vec![0x45u8; size]; // IPv4 version nibble but too short
            let responder = IpAddr::V4(std::net::Ipv4Addr::new(1, 1, 1, 1));
            prop_assert!(parse_icmp_response(&data, responder, 0x1234, false).is_none());
        }
    }

    /// End-to-end test: build a PMTUD Echo Request, convert to Echo Reply,
    /// parse it, and verify is_pmtud is true. This catches offset bugs
    /// (icmp_data vs payload slice) that builder-only tests miss.
    #[test]
    fn test_parse_pmtud_echo_reply_v4_dgram() {
        use crate::probe::icmp::build_echo_request;

        let our_id = 0x1234;
        let probe_id = ProbeId::new(10, 5);
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));

        // Build a PMTUD Echo Request via the real builder
        let request = build_echo_request(
            our_id,
            probe_id.to_sequence(),
            56,
            false,
            None,
            true, // pmtud
        );

        // Convert to Echo Reply: change type from 8 (Echo Request) to 0 (Echo Reply)
        let mut reply = request.clone();
        reply[0] = 0; // Echo Reply type
        // Recompute ICMP checksum
        set_icmp_checksum(&mut reply);

        // Parse as DGRAM (no IP header)
        let result = parse_icmp_response(&reply, responder, our_id, true);
        assert!(result.is_some(), "PMTUD Echo Reply should parse");
        let parsed = result.unwrap();
        assert_eq!(parsed.response_type, IcmpResponseType::EchoReply);
        assert!(
            parsed.is_pmtud,
            "PMTUD Echo Reply should have is_pmtud=true"
        );
        assert_eq!(parsed.probe_id.ttl, 10);
        assert_eq!(parsed.probe_id.seq, 5);
    }

    #[test]
    fn test_parse_normal_echo_reply_v4_dgram_is_not_pmtud() {
        use crate::probe::icmp::build_echo_request;

        let our_id = 0x1234;
        let probe_id = ProbeId::new(10, 5);
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 8, 8));

        // Build a normal Echo Request
        let request = build_echo_request(
            our_id,
            probe_id.to_sequence(),
            56,
            false,
            None,
            false, // not pmtud
        );

        // Convert to Echo Reply
        let mut reply = request.clone();
        reply[0] = 0;
        set_icmp_checksum(&mut reply);

        let result = parse_icmp_response(&reply, responder, our_id, true);
        assert!(result.is_some());
        let parsed = result.unwrap();
        assert!(
            !parsed.is_pmtud,
            "Normal Echo Reply should have is_pmtud=false"
        );
    }

    #[test]
    fn test_parse_pmtud_echo_reply_v4_raw() {
        use crate::probe::icmp::build_echo_request;

        let our_id = 0x1234;
        let probe_id = ProbeId::new(12, 3);
        let responder = IpAddr::V4(std::net::Ipv4Addr::new(8, 8, 4, 4));

        // Build PMTUD Echo Request
        let icmp = build_echo_request(our_id, probe_id.to_sequence(), 56, false, None, true);

        // Wrap in an IPv4 header for RAW socket parsing
        let mut packet = vec![0u8; 20 + icmp.len()];
        packet[0] = 0x45; // Version 4, IHL 5
        packet[9] = 1; // Protocol: ICMP
        packet[20..].copy_from_slice(&icmp);

        // Convert ICMP type to Echo Reply
        packet[20] = 0;
        // Recompute ICMP checksum (starts at IP header offset 20)
        set_icmp_checksum(&mut packet[20..]);

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some(), "PMTUD Echo Reply via RAW should parse");
        let parsed = result.unwrap();
        assert!(
            parsed.is_pmtud,
            "PMTUD Echo Reply via RAW should have is_pmtud=true"
        );
        assert_eq!(parsed.probe_id.ttl, 12);
        assert_eq!(parsed.probe_id.seq, 3);
    }

    #[test]
    fn test_rfc5837_ipv4_time_exceeded() {
        let responder = IpAddr::V4(Ipv4Addr::new(198, 51, 100, 33));
        let our_id = 0x4321;
        let probe_id = ProbeId::new(4, 1);

        let mut packet = vec![0u8; 20 + 8 + 128 + 4 + 52];
        packet[0] = 0x45;
        packet[9] = 1; // ICMP

        packet[20] = 11; // Time Exceeded
        packet[21] = 0;
        packet[25] = 32; // Length = 32 words (128 bytes)

        // Original IP header at 28
        packet[28] = 0x45;
        packet[37] = 1; // Protocol: ICMP

        // Original ICMP Echo Request at 48
        packet[48] = 8;
        packet[52] = (our_id >> 8) as u8;
        packet[53] = (our_id & 0xFF) as u8;
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        // Extension header at 20 + 8 + 128 = 156
        let ext_off = 156;
        packet[ext_off] = 0x20; // Version 2

        // Interface Information Object at 160: length 52
        let obj_off = ext_off + 4;
        let obj_len = 52u16;
        packet[obj_off..obj_off + 2].copy_from_slice(&obj_len.to_be_bytes());
        packet[obj_off + 2] = 2; // Class 2: Interface Information Object
        // C-Type: Role = 0 (incoming), ifIndex (0x08), IP (0x04), Name (0x02), MTU (0x01) -> 0x0F
        packet[obj_off + 3] = 0x0F;

        let mut p = obj_off + 4;
        // 1. ifIndex (4 bytes): 1
        packet[p..p + 4].copy_from_slice(&1u32.to_be_bytes());
        p += 4;
        // 2. IP Address (AFI=1, Reserved=0, 198.51.100.33)
        packet[p..p + 2].copy_from_slice(&1u16.to_be_bytes());
        packet[p + 4..p + 8].copy_from_slice(&[198, 51, 100, 33]);
        p += 8;
        // 3. Name: subobj_len = 32, "Ethernet1@arista-rfc5837-rt1" (27 bytes)
        let name = b"Ethernet1@arista-rfc5837-rt1";
        packet[p] = 32;
        packet[p + 1..p + 1 + name.len()].copy_from_slice(name);
        p += 32;
        // 4. MTU: 1500
        packet[p..p + 4].copy_from_slice(&1500u32.to_be_bytes());

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());
        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 4);
        assert_eq!(parsed.probe_id.seq, 1);

        assert!(parsed.interface_info.is_some());
        let ifaces = parsed.interface_info.unwrap();
        assert_eq!(ifaces.len(), 1);
        let iface = &ifaces[0];
        assert_eq!(iface.role, InterfaceRole::IncomingIp);
        assert_eq!(iface.if_index, Some(1));
        assert_eq!(
            iface.ip_addr,
            Some(IpAddr::V4(Ipv4Addr::new(198, 51, 100, 33)))
        );
        assert_eq!(iface.name.as_deref(), Some("Ethernet1@arista-rfc5837-rt1"));
        assert_eq!(iface.mtu, Some(1500));
    }

    #[test]
    fn test_rfc5837_ipv6_time_exceeded() {
        let responder = IpAddr::V6("2001:db8:1::33".parse().unwrap());
        let our_id = 0x5678;
        let probe_id = ProbeId::new(6, 2);

        // ICMPv6 DGRAM layout:
        // ICMPv6 header: 8 bytes (byte 4 = length in 64-bit words)
        // Original IPv6 header: 40 bytes
        // Original ICMPv6 Echo Request: 8 bytes
        // Padding to 128 bytes (length = 16 64-bit words = 128 bytes)
        // Extension header: 4 bytes
        // Interface Info Object: 4 (header) + 4 (ifIndex) + 20 (IPv6 AFI) + 32 (name) + 4 (MTU) = 64 bytes
        let mut icmp_data = vec![0u8; 8 + 128 + 4 + 64];
        icmp_data[0] = 3; // ICMPv6 Time Exceeded
        icmp_data[1] = 0;
        icmp_data[4] = 16; // Length in 64-bit words (16 * 8 = 128)

        // Original IPv6 header at offset 8
        let orig_v6 = &mut icmp_data[8..48];
        orig_v6[0] = 0x60;
        orig_v6[6] = 58; // Next header: ICMPv6

        // Original ICMPv6 Echo Request at offset 48
        icmp_data[48] = 128; // Echo Request
        icmp_data[52] = (our_id >> 8) as u8;
        icmp_data[53] = (our_id & 0xFF) as u8;
        let seq = probe_id.to_sequence();
        icmp_data[54] = (seq >> 8) as u8;
        icmp_data[55] = (seq & 0xFF) as u8;

        // Extension header at 8 + 128 = 136
        let ext_off = 136;
        icmp_data[ext_off] = 0x20; // Version 2

        // Interface Info Object at 140
        let obj_off = ext_off + 4;
        let obj_len = 64u16;
        icmp_data[obj_off..obj_off + 2].copy_from_slice(&obj_len.to_be_bytes());
        icmp_data[obj_off + 2] = 2; // Class 2
        icmp_data[obj_off + 3] = 0x0F; // Role 0, all 4 fields present

        let mut p = obj_off + 4;
        // ifIndex: 1
        icmp_data[p..p + 4].copy_from_slice(&1u32.to_be_bytes());
        p += 4;
        // IP address: AFI=2 (IPv6: 2001:db8:1::33)
        icmp_data[p..p + 2].copy_from_slice(&2u16.to_be_bytes());
        let v6_addr: std::net::Ipv6Addr = "2001:db8:1::33".parse().unwrap();
        icmp_data[p + 4..p + 20].copy_from_slice(&v6_addr.octets());
        p += 20;
        // Name: 32 bytes
        let name = b"Ethernet1@arista-rfc5837-rt1";
        icmp_data[p] = 32;
        icmp_data[p + 1..p + 1 + name.len()].copy_from_slice(name);
        p += 32;
        // MTU: 1500
        icmp_data[p..p + 4].copy_from_slice(&1500u32.to_be_bytes());

        let result = parse_icmp_response(&icmp_data, responder, our_id, true);
        assert!(result.is_some());
        let parsed = result.unwrap();
        assert_eq!(parsed.probe_id.ttl, 6);
        assert_eq!(parsed.probe_id.seq, 2);

        assert!(parsed.interface_info.is_some());
        let ifaces = parsed.interface_info.unwrap();
        assert_eq!(ifaces.len(), 1);
        let iface = &ifaces[0];
        assert_eq!(iface.role, InterfaceRole::IncomingIp);
        assert_eq!(iface.if_index, Some(1));
        assert_eq!(iface.ip_addr, Some(IpAddr::V6(v6_addr)));
        assert_eq!(iface.name.as_deref(), Some("Ethernet1@arista-rfc5837-rt1"));
        assert_eq!(iface.mtu, Some(1500));
    }

    #[test]
    fn test_rfc5837_multiple_interface_roles() {
        let responder = IpAddr::V4(Ipv4Addr::new(192, 0, 2, 2));
        let our_id = 0x1111;
        let probe_id = ProbeId::new(2, 1);

        let mut packet = vec![0u8; 20 + 8 + 128 + 4 + 16 + 24];
        packet[0] = 0x45;
        packet[9] = 1;
        packet[20] = 11;
        packet[25] = 32;
        packet[28] = 0x45;
        packet[37] = 1;
        packet[48] = 8;
        packet[52] = 0x11;
        packet[53] = 0x11;
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        let ext_off = 156;
        packet[ext_off] = 0x20;

        // Object 1: Incoming IP (role=0), ifIndex=10, name="ge0" (len=8) -> obj_len = 4 + 4 + 8 = 16
        let obj1 = ext_off + 4;
        packet[obj1..obj1 + 2].copy_from_slice(&16u16.to_be_bytes());
        packet[obj1 + 2] = 2; // Class 2
        packet[obj1 + 3] = 0x08 | 0x02; // Role 0, ifIndex, Name
        packet[obj1 + 4..obj1 + 8].copy_from_slice(&10u32.to_be_bytes());
        packet[obj1 + 8] = 8;
        packet[obj1 + 9..obj1 + 12].copy_from_slice(b"ge0");

        // Object 2: Outgoing IP (role=2), ifIndex=20, MTU=9000, name="ge1" (len=8) -> obj_len = 4 + 4 + 8 + 4 = 20
        // Padded to 24
        let obj2 = obj1 + 16;
        packet[obj2..obj2 + 2].copy_from_slice(&24u16.to_be_bytes());
        packet[obj2 + 2] = 2; // Class 2
        packet[obj2 + 3] = (2 << 6) | 0x08 | 0x02 | 0x01; // Role 2, ifIndex, Name, MTU
        packet[obj2 + 4..obj2 + 8].copy_from_slice(&20u32.to_be_bytes());
        packet[obj2 + 8] = 8;
        packet[obj2 + 9..obj2 + 12].copy_from_slice(b"ge1");
        packet[obj2 + 16..obj2 + 20].copy_from_slice(&9000u32.to_be_bytes());

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());
        let parsed = result.unwrap();
        let ifaces = parsed
            .interface_info
            .expect("interface info should be parsed");
        assert_eq!(ifaces.len(), 2);
        assert_eq!(ifaces[0].role, InterfaceRole::IncomingIp);
        assert_eq!(ifaces[0].if_index, Some(10));
        assert_eq!(ifaces[0].name.as_deref(), Some("ge0"));

        assert_eq!(ifaces[1].role, InterfaceRole::OutgoingIp);
        assert_eq!(ifaces[1].if_index, Some(20));
        assert_eq!(ifaces[1].name.as_deref(), Some("ge1"));
        assert_eq!(ifaces[1].mtu, Some(9000));
    }

    #[test]
    fn test_rfc5837_duplicate_role_ignored() {
        let responder = IpAddr::V4(Ipv4Addr::new(192, 0, 2, 3));
        let our_id = 0x2222;
        let probe_id = ProbeId::new(3, 1);

        let mut packet = vec![0u8; 20 + 8 + 128 + 4 + 16 + 16];
        packet[0] = 0x45;
        packet[9] = 1;
        packet[20] = 11;
        packet[25] = 32;
        packet[28] = 0x45;
        packet[37] = 1;
        packet[48] = 8;
        packet[52] = 0x22;
        packet[53] = 0x22;
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        let ext_off = 156;
        packet[ext_off] = 0x20;

        // Object 1: Role 0 (incoming), ifIndex=100
        let obj1 = ext_off + 4;
        packet[obj1..obj1 + 2].copy_from_slice(&8u16.to_be_bytes());
        packet[obj1 + 2] = 2;
        packet[obj1 + 3] = 0x08; // Role 0, ifIndex
        packet[obj1 + 4..obj1 + 8].copy_from_slice(&100u32.to_be_bytes());

        // Object 2: Duplicate Role 0 (incoming), ifIndex=200
        let obj2 = obj1 + 8;
        packet[obj2..obj2 + 2].copy_from_slice(&8u16.to_be_bytes());
        packet[obj2 + 2] = 2;
        packet[obj2 + 3] = 0x08; // Role 0, ifIndex
        packet[obj2 + 4..obj2 + 8].copy_from_slice(&200u32.to_be_bytes());

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());
        let parsed = result.unwrap();
        let ifaces = parsed
            .interface_info
            .expect("interface info should be parsed");
        // Duplicate role: first object wins, the repeat is ignored (lenient vs RFC 5837 §4.5)
        assert_eq!(ifaces.len(), 1);
        assert_eq!(ifaces[0].if_index, Some(100));
    }

    #[test]
    fn test_rfc5837_and_mpls_together() {
        let responder = IpAddr::V4(Ipv4Addr::new(192, 0, 2, 4));
        let our_id = 0x3333;
        let probe_id = ProbeId::new(4, 1);

        let mut packet = vec![0u8; 20 + 8 + 128 + 4 + 8 + 16];
        packet[0] = 0x45;
        packet[9] = 1;
        packet[20] = 11;
        packet[25] = 32;
        packet[28] = 0x45;
        packet[37] = 1;
        packet[48] = 8;
        packet[52] = 0x33;
        packet[53] = 0x33;
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        let ext_off = 156;
        packet[ext_off] = 0x20;

        // Object 1: MPLS label stack (class=1, type=1)
        let obj1 = ext_off + 4;
        packet[obj1..obj1 + 2].copy_from_slice(&8u16.to_be_bytes());
        packet[obj1 + 2] = 1; // Class 1
        packet[obj1 + 3] = 1; // Type 1
        let label_word: u32 = (18000 << 12) | (1 << 8) | 64;
        packet[obj1 + 4..obj1 + 8].copy_from_slice(&label_word.to_be_bytes());

        // Object 2: RFC 5837 Interface info (class=2)
        let obj2 = obj1 + 8;
        packet[obj2..obj2 + 2].copy_from_slice(&16u16.to_be_bytes());
        packet[obj2 + 2] = 2; // Class 2
        packet[obj2 + 3] = 0x08 | 0x02; // Role 0, ifIndex, Name
        packet[obj2 + 4..obj2 + 8].copy_from_slice(&5u32.to_be_bytes());
        packet[obj2 + 8] = 8;
        packet[obj2 + 9..obj2 + 12].copy_from_slice(b"lo0");

        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());
        let parsed = result.unwrap();

        // Verify BOTH MPLS and Interface info are parsed
        assert!(parsed.mpls_labels.is_some());
        assert_eq!(parsed.mpls_labels.unwrap()[0].label, 18000);

        assert!(parsed.interface_info.is_some());
        let ifaces = parsed.interface_info.unwrap();
        assert_eq!(ifaces.len(), 1);
        assert_eq!(ifaces[0].if_index, Some(5));
        assert_eq!(ifaces[0].name.as_deref(), Some("lo0"));
    }

    #[test]
    fn test_rfc5837_malformed_resilience() {
        let responder = IpAddr::V4(Ipv4Addr::new(192, 0, 2, 5));
        let our_id = 0x4444;
        let probe_id = ProbeId::new(5, 1);

        let mut packet = vec![0u8; 20 + 8 + 128 + 4 + 8];
        packet[0] = 0x45;
        packet[9] = 1;
        packet[20] = 11;
        packet[25] = 32;
        packet[28] = 0x45;
        packet[37] = 1;
        packet[48] = 8;
        packet[52] = 0x44;
        packet[53] = 0x44;
        let seq = probe_id.to_sequence();
        packet[54] = (seq >> 8) as u8;
        packet[55] = (seq & 0xFF) as u8;

        let ext_off = 156;
        packet[ext_off] = 0x20;

        // Object with claims of ifIndex (0x08) and IP (0x04) but payload is only 2 bytes
        let obj = ext_off + 4;
        packet[obj..obj + 2].copy_from_slice(&6u16.to_be_bytes()); // obj len = 6, payload = 2 bytes
        packet[obj + 2] = 2; // Class 2
        packet[obj + 3] = 0x0C; // ifIndex + IP

        // Must not panic, gracefully returns None for interface_info
        let result = parse_icmp_response(&packet, responder, our_id, false);
        assert!(result.is_some());
        let parsed = result.unwrap();
        assert!(parsed.interface_info.is_none());
    }

    /// Arista EOS 4.36 lab frame (issue #134): ICMPv4 Time Exceeded with an RFC 5837 Interface Information Object
    const ARISTA_PKT1_V4: &[u8] = &[
        104, 52, 33, 178, 14, 88, 4, 244, 28, 40, 230, 9, 8, 0, 69, 0, 0, 244, 109, 96, 64, 0, 63,
        1, 152, 110, 198, 51, 100, 33, 10, 0, 0, 230, 11, 0, 244, 223, 0, 32, 0, 0, 69, 0, 0, 92,
        22, 180, 0, 0, 1, 1, 109, 171, 10, 0, 0, 230, 198, 51, 100, 41, 8, 0, 246, 202, 0, 1, 1,
        52, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 86, 229, 0, 52, 2, 15, 0, 0, 0, 1, 0, 1, 0, 0, 198,
        51, 100, 33, 32, 69, 116, 104, 101, 114, 110, 101, 116, 49, 64, 97, 114, 105, 115, 116, 97,
        45, 114, 102, 99, 53, 56, 51, 55, 45, 114, 116, 49, 0, 0, 0, 0, 0, 5, 220, 0, 32, 4, 6, 0,
        1, 0, 0, 192, 0, 2, 11, 20, 97, 114, 105, 115, 116, 97, 45, 114, 102, 99, 53, 56, 51, 55,
        45, 114, 116, 49, 0,
    ];

    /// Arista EOS 4.36 lab frame (issue #134): ICMPv6 Time Exceeded with an RFC 5837 Interface Information Object
    const ARISTA_PKT1_V6: &[u8] = &[
        104, 52, 33, 178, 14, 88, 4, 244, 28, 40, 230, 9, 134, 221, 96, 10, 214, 179, 0, 248, 58,
        63, 32, 1, 13, 184, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 51, 32, 1, 13, 184, 222, 173, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 5, 3, 0, 23, 173, 16, 0, 0, 0, 96, 0, 0, 0, 0, 72, 58, 1, 32, 1, 13, 184,
        222, 173, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 32, 1, 13, 184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        65, 128, 0, 68, 203, 0, 1, 0, 75, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 32, 0, 152, 226, 0, 64, 2, 15, 0, 0, 0, 1, 0, 2, 0, 0, 32, 1, 13, 184, 0, 1, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 51, 32, 69, 116, 104, 101, 114, 110, 101, 116, 49, 64, 97, 114, 105, 115,
        116, 97, 45, 114, 102, 99, 53, 56, 51, 55, 45, 114, 116, 49, 0, 0, 0, 0, 0, 5, 220, 0, 44,
        4, 6, 0, 2, 0, 0, 222, 173, 190, 239, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 222, 173, 20, 97, 114,
        105, 115, 116, 97, 45, 114, 102, 99, 53, 56, 51, 55, 45, 114, 116, 49, 0,
    ];

    #[test]
    fn test_arista_real_world_pcaps() {
        // Real Arista EOS capture packet 1 (IPv4, Ethernet1@arista-rfc5837-rt1, MTU 1500)
        let pkt1_v4 = ARISTA_PKT1_V4;
        let ip_payload = &pkt1_v4[14..];
        let responder = IpAddr::V4(Ipv4Addr::new(198, 51, 100, 33));
        let parsed_v4 =
            parse_icmp_response(ip_payload, responder, 1, false).expect("pkt1_v4 should parse");
        let ifaces_v4 = parsed_v4.interface_info.expect("pkt1_v4 interface_info");
        assert_eq!(ifaces_v4.len(), 1);
        assert_eq!(ifaces_v4[0].role, InterfaceRole::IncomingIp);
        assert_eq!(ifaces_v4[0].if_index, Some(1));
        assert_eq!(
            ifaces_v4[0].ip_addr,
            Some(IpAddr::V4(Ipv4Addr::new(198, 51, 100, 33)))
        );
        assert_eq!(
            ifaces_v4[0].name.as_deref(),
            Some("Ethernet1@arista-rfc5837-rt1")
        );
        assert_eq!(ifaces_v4[0].mtu, Some(1500));

        // Real Arista EOS capture packet 3 (IPv4, Port-Channel1, MTU 1470)
        let pkt3_v4: &[u8] = &[
            104, 52, 33, 178, 14, 88, 4, 244, 28, 40, 230, 9, 8, 0, 69, 0, 0, 196, 113, 246, 64, 0,
            62, 1, 149, 6, 198, 51, 100, 35, 10, 0, 0, 230, 11, 0, 244, 223, 0, 32, 0, 0, 69, 0, 0,
            92, 22, 183, 0, 0, 1, 1, 109, 168, 10, 0, 0, 230, 198, 51, 100, 41, 8, 0, 246, 199, 0,
            1, 1, 55, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 248, 8, 0, 36, 2, 15, 0, 15, 66,
            65, 0, 1, 0, 0, 198, 51, 100, 35, 16, 80, 111, 114, 116, 45, 67, 104, 97, 110, 110,
            101, 108, 49, 0, 0, 0, 0, 5, 190,
        ];
        let parsed_pkt3 = parse_icmp_response(
            &pkt3_v4[14..],
            IpAddr::V4(Ipv4Addr::new(198, 51, 100, 35)),
            1,
            false,
        )
        .unwrap();
        let ifaces_pkt3 = parsed_pkt3.interface_info.unwrap();
        assert_eq!(ifaces_pkt3[0].role, InterfaceRole::IncomingIp);
        assert_eq!(ifaces_pkt3[0].if_index, Some(1000001));
        assert_eq!(ifaces_pkt3[0].name.as_deref(), Some("Port-Channel1"));
        assert_eq!(ifaces_pkt3[0].mtu, Some(1470));

        // Real Arista EOS capture packet 7 (IPv4, Outgoing IP, Ethernet2@arista-rfc5837-rt3, MTU 1430)
        let pkt7_v4: &[u8] = &[
            104, 52, 33, 178, 14, 88, 4, 244, 28, 40, 230, 9, 8, 0, 69, 0, 0, 244, 112, 221, 64, 0,
            61, 1, 150, 237, 198, 51, 100, 37, 10, 0, 0, 230, 3, 1, 252, 222, 0, 32, 0, 0, 69, 0,
            0, 92, 22, 189, 0, 0, 1, 1, 109, 162, 10, 0, 0, 230, 198, 51, 100, 41, 8, 0, 246, 193,
            0, 1, 1, 61, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 85, 144, 0, 52, 2, 143, 0, 0,
            0, 2, 0, 1, 0, 0, 198, 51, 100, 38, 32, 69, 116, 104, 101, 114, 110, 101, 116, 50, 64,
            97, 114, 105, 115, 116, 97, 45, 114, 102, 99, 53, 56, 51, 55, 45, 114, 116, 51, 0, 0,
            0, 0, 0, 5, 150, 0, 32, 1, 6, 0, 1, 0, 0, 192, 0, 2, 31, 20, 97, 114, 105, 115, 116,
            97, 45, 114, 102, 99, 53, 56, 51, 55, 45, 114, 116, 51, 0,
        ];
        let parsed_pkt7 = parse_icmp_response(
            &pkt7_v4[14..],
            IpAddr::V4(Ipv4Addr::new(198, 51, 100, 37)),
            1,
            false,
        )
        .unwrap();
        let ifaces_pkt7 = parsed_pkt7.interface_info.unwrap();
        assert_eq!(ifaces_pkt7[0].role, InterfaceRole::OutgoingIp);
        assert_eq!(ifaces_pkt7[0].if_index, Some(2));
        assert_eq!(
            ifaces_pkt7[0].name.as_deref(),
            Some("Ethernet2@arista-rfc5837-rt3")
        );
        assert_eq!(ifaces_pkt7[0].mtu, Some(1430));

        // Real Arista EOS capture packet 1 (IPv6, Ethernet1@arista-rfc5837-rt1, MTU 1500)
        let pkt1_v6 = ARISTA_PKT1_V6;
        let icmp6_payload = &pkt1_v6[54..];
        let responder_v6 = IpAddr::V6("2001:db8:1::33".parse().unwrap());
        let parsed_v6 = parse_icmp_response(icmp6_payload, responder_v6, 1, true)
            .expect("pkt1_v6 should parse");
        let ifaces_v6 = parsed_v6.interface_info.expect("pkt1_v6 interface_info");
        assert_eq!(ifaces_v6.len(), 1);
        assert_eq!(ifaces_v6[0].role, InterfaceRole::IncomingIp);
        assert_eq!(ifaces_v6[0].if_index, Some(1));
        assert_eq!(ifaces_v6[0].ip_addr, Some(responder_v6));
        assert_eq!(
            ifaces_v6[0].name.as_deref(),
            Some("Ethernet1@arista-rfc5837-rt1")
        );
        assert_eq!(ifaces_v6[0].mtu, Some(1500));

        // Real Arista EOS capture packet 3 (IPv6, Port-Channel1, MTU 1470)
        let pkt3_v6: &[u8] = &[
            104, 52, 33, 178, 14, 88, 4, 244, 28, 40, 230, 9, 134, 221, 96, 13, 23, 51, 0, 188, 58,
            62, 32, 1, 13, 184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 53, 32, 1, 13, 184, 222, 173, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 5, 3, 0, 23, 232, 16, 0, 0, 0, 96, 0, 0, 0, 0, 72, 58, 1, 32,
            1, 13, 184, 222, 173, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 32, 1, 13, 184, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 65, 128, 0, 68, 200, 0, 1, 0, 78, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 244, 100, 0, 48, 2, 15, 0, 15, 66, 65, 0, 2, 0, 0,
            32, 1, 13, 184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 53, 16, 80, 111, 114, 116, 45, 67,
            104, 97, 110, 110, 101, 108, 49, 0, 0, 0, 0, 5, 190,
        ];
        let parsed_v6_3 = parse_icmp_response(
            &pkt3_v6[54..],
            IpAddr::V6("2001:db8::35".parse().unwrap()),
            1,
            true,
        )
        .unwrap();
        let ifaces_v6_3 = parsed_v6_3.interface_info.unwrap();
        assert_eq!(ifaces_v6_3[0].role, InterfaceRole::IncomingIp);
        assert_eq!(ifaces_v6_3[0].if_index, Some(1000001));
        assert_eq!(ifaces_v6_3[0].name.as_deref(), Some("Port-Channel1"));
        assert_eq!(ifaces_v6_3[0].mtu, Some(1470));

        // Real Arista EOS capture packet 7 (IPv6, Outgoing IP, Ethernet2@arista-rfc5837-rt3, MTU 1430)
        let pkt7_v6: &[u8] = &[
            104, 52, 33, 178, 14, 88, 4, 244, 28, 40, 230, 9, 134, 221, 96, 5, 171, 221, 0, 248,
            58, 61, 32, 1, 13, 184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 32, 1, 13, 184, 222, 173,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 1, 3, 25, 167, 16, 0, 0, 0, 96, 0, 0, 0, 0, 72, 58, 1,
            32, 1, 13, 184, 222, 173, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 32, 1, 13, 184, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 65, 128, 0, 68, 194, 0, 1, 0, 84, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 151, 130, 0, 64, 2, 143, 0, 0, 0, 2, 0, 2, 0, 0,
            32, 1, 13, 184, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 56, 32, 69, 116, 104, 101, 114, 110,
            101, 116, 50, 64, 97, 114, 105, 115, 116, 97, 45, 114, 102, 99, 53, 56, 51, 55, 45,
            114, 116, 51, 0, 0, 0, 0, 0, 5, 150, 0, 44, 1, 6, 0, 2, 0, 0, 222, 173, 190, 239, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 49, 222, 173, 20, 97, 114, 105, 115, 116, 97, 45, 114, 102, 99,
            53, 56, 51, 55, 45, 114, 116, 51, 0,
        ];
        let parsed_v6_7 = parse_icmp_response(
            &pkt7_v6[54..],
            IpAddr::V6("2001:db8::37".parse().unwrap()),
            1,
            true,
        )
        .unwrap();
        let ifaces_v6_7 = parsed_v6_7.interface_info.unwrap();
        assert_eq!(ifaces_v6_7[0].role, InterfaceRole::OutgoingIp);
        assert_eq!(ifaces_v6_7[0].if_index, Some(2));
        assert_eq!(
            ifaces_v6_7[0].name.as_deref(),
            Some("Ethernet2@arista-rfc5837-rt3")
        );
        assert_eq!(ifaces_v6_7[0].mtu, Some(1430));
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(20_000))]
        /// Every router on the path can hand this parser arbitrary bytes: mutating
        /// and truncating real RFC 5837 frames must never panic.
        #[test]
        fn proptest_icmp_extension_parser_never_panics(
            is_v6 in any::<bool>(),
            idx in 0usize..320,
            byte in any::<u8>(),
            cut in 1usize..320,
        ) {
            let base: &[u8] = if is_v6 { &ARISTA_PKT1_V6[54..] } else { &ARISTA_PKT1_V4[14..] };
            let mut pkt = base.to_vec();
            if idx < pkt.len() {
                pkt[idx] = byte;
            }
            pkt.truncate(cut.min(pkt.len()));
            let responder = if is_v6 {
                IpAddr::V6(Ipv6Addr::LOCALHOST)
            } else {
                IpAddr::V4(Ipv4Addr::LOCALHOST)
            };
            let _ = parse_icmp_response(&pkt, responder, 1, is_v6);
        }
    }
}
