# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in ttl, please report it responsibly:

1. **Do not** open a public GitHub issue
2. Email lance@lance0.com or use GitHub's private vulnerability reporting
3. Include steps to reproduce the issue
4. Allow reasonable time for a fix before public disclosure

## Scope

Security issues of interest include:
- Memory safety issues in packet parsing
- Parsing of untrusted saved sessions (`--replay`, `--diff`) or GeoIP databases
- Privilege escalation vulnerabilities
- Information disclosure bugs

## Supported Versions

Only the latest release is supported with security updates.

| Version | Supported |
|---------|-----------|
| 0.25.x  | Yes       |
| < 0.25  | No        |
