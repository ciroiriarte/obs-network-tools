# ttl Roadmap

Current release: **v0.24.1**. Changes since then are listed under [Unreleased](CHANGELOG.md#unreleased) in the changelog.

## Market Context

**mtr is the de facto standard** for interactive traceroute but hasn't seen major feature development in years. **trippy** (Rust) is the main modern alternative but focuses on a different feature set.

**Key advantages ttl already has:**
- ECMP path enumeration with per-flow/per-packet classification (`--flows`)
- NAT detection (source port rewrite analysis)
- ICMP rate limit detection (distinguish rate limiting from real loss)
- Route flap and asymmetric routing detection
- TTL manipulation detection (transparent proxies, middleboxes)
- Path MTU discovery (`--pmtud`)
- IX detection via PeeringDB
- Animated session replay
- Dual-stack `--resolve-all` (trace IPv4 and IPv6 simultaneously)

---

## Completed (v0.1.x - v0.6.x)

- [x] ICMP Echo probing with TTL sweep
- [x] IPv4 and IPv6 support with extension header handling
- [x] Real-time TUI with ratatui (11 built-in themes)
- [x] Hop statistics (loss, min/avg/max, stddev, jitter, percentiles)
- [x] Reverse DNS resolution (parallel lookups)
- [x] MPLS label detection (RFC 4884/4950 ICMP extensions)
- [x] JSON, CSV, and report export formats
- [x] Session replay from saved JSON
- [x] Multiple simultaneous targets (`ttl 8.8.8.8 1.1.1.1`)
- [x] NAT detection (source port rewrite analysis)
- [x] Paris/Dublin traceroute (`--flows` for ECMP path enumeration)
- [x] UDP probing (`-p udp`) and TCP SYN probing (`-p tcp`)
- [x] Protocol auto-detection (`-p auto`, default)
- [x] ASN lookup (Team Cymru DNS), GeoIP (MaxMind), IX detection (PeeringDB)
- [x] Terminal injection protection (sanitize external data)
- [x] Terminal state cleanup on error/panic

## Completed (v0.7.x - v0.12.x)

- [x] Interface binding (`--interface`, `--recv-any`)
- [x] Shell completions (`--completions bash/zsh/fish/powershell`)
- [x] Settings modal (theme, display mode, PeeringDB API key)
- [x] Target list overlay for multi-target mode
- [x] Autosize columns (auto/compact/wide with `w` key cycling)
- [x] Linux binary compatibility (musl libc for broad distro support)

## Completed (v0.13.x - v0.14.x)

- [x] Path MTU discovery (`--pmtud`) with binary search
- [x] Packet size control (`--size`) with DF flag
- [x] DSCP/ToS marking (`--dscp`) for QoS policy testing
- [x] ICMP rate limit detection with TUI indicators
- [x] Route flap detection (primary responder IP changes)
- [x] Asymmetric routing detection (forward vs return path hops)
- [x] TTL manipulation detection (transparent proxies, middleboxes)
- [x] First-hop gateway detection via kernel APIs (netlink/sysctl)
- [x] Rate limiting (`--rate`) for slow links
- [x] Source IP selection (`--source-ip`)
- [x] Update notifications (checks GitHub releases, install-method-aware)
- [x] FreeBSD support (experimental, raw sockets)

## Completed (v0.15.x - v0.19.1)

- [x] Animated replay (`--replay file --animate`) with speed control
- [x] Probe event recording for replay accuracy
- [x] TUI refresh rate increased to 60fps (#17)
- [x] Jumbo frame support (`--size` up to 9216, `--jumbo` for PMTUD)
- [x] Immediate sent counting (mtr parity — increments at probe send, not response)
- [x] Dual-stack `--resolve-all` (trace IPv4 and IPv6 simultaneously)
- [x] FreeBSD ICMP socket fix (RAW sockets, not DGRAM)
- [x] Last RTT column in main table (mtr parity — `Loss% Snt Last Avg Min Max StdDev`)
- [x] JAvg and JMax columns in Wide display mode
- [x] Wider ASN column for full AS name visibility
- [x] ECMP classification: per-flow vs per-packet detection with primary_ratio heuristic (#46)
- [x] Paths column reflects actual responder count for per-packet ECMP (#46)
- [x] `E` indicator for ECMP detected vs `!` for route flap (#46)
- [x] Effective flow capability: `--flows` + ICMP warns and collapses to single-flow (#46)
- [x] Receiver flow attribution hardening: unknown flows only match when unambiguous (#46)
- [x] NetBSD platform support (experimental, raw sockets, IPv6 PMTUD only) (#47)
- [x] NetBSD UDP source IP auto-detection (fixes EHOSTUNREACH on DGRAM sockets) (#47)
- [x] Update checker: non-blocking `try_recv()` polling in TUI (replaces blocking `recv_timeout(1s)`)
- [x] Update checker: first-run immediate network check (`interval(Duration::ZERO)`)
- [x] Interactive replay controls (seek, speed, progress bar) shipped in v0.19.0
- [x] Pre-commit hooks (`.pre-commit-config.yaml` for `cargo fmt`/`clippy`/`test`)
- [x] CI: `cargo clippy --all-targets -- -D warnings` on Linux, macOS, and FreeBSD
- [x] hickory-resolver 0.26 upgrade (closes RUSTSEC-2026-0118 and RUSTSEC-2026-0119)

## Completed (v0.20.0)

- [x] Trace diffing (`--diff before.json after.json`): added/lost hops, path changes, latency shifts; `--json` for machine-readable output
- [x] Streaming JSON output (`--stream-json`): line-delimited probe events + per-target summary, composable with jq/grep
- [x] Daemon mode (`--daemon`) with graceful SIGTERM shutdown (clean `docker stop`)
- [x] Prometheus/OpenMetrics exporter (`--prometheus :9090`) with `/healthz` for orchestration
- [x] Official Dockerfile + multi-arch (amd64/arm64) GHCR images (`ghcr.io/lance0/ttl`)
- [x] Interactive target selection: `ttl` with no args opens an empty session; `o` adds targets mid-session with runtime engine/receiver spawning
- [x] IX prefix lookup via binary radix trie (O(prefix_len) instead of O(n) linear scan)
- [x] New `aarch64-unknown-linux-musl` release artifact

---

## Completed (v0.21.0)

- [x] Opt out of the startup update check (#110): `--no-update-check` flag, `DO_NOT_TRACK`/`TTL_NO_UPDATE_CHECK` env vars, `no_update_check` config key, a TUI Settings toggle, and a `--no-default-features` build that compiles the check (and `update-informer`) out entirely

---

## Completed (v0.22.0)

- [x] TUI renders only on change (#129, #131): a per-tick render fingerprint skips the session snapshot and the redraw when nothing moved — 1.4% → 0.4% of one CPU core on a 9-hop trace, scaling with hop count. Session mutations mark the view dirty through the lock's write guard, so no writer can leave the display stale.
- [x] Published crate excludes the demo GIF/tape, halving the crates.io tarball (1.14 MB → 0.56 MB compressed)
- [x] Security: rkyv 0.8.18 (RUSTSEC-2026-0233/0234/0235) and lru 0.18.2 (RUSTSEC-2026-0253)

---

## Completed (v0.23.0)

- [x] RFC 5837 interface and next-hop identification (#134, #137): Interface Information Objects in ICMP Time Exceeded / Destination Unreachable messages — ifIndex, IP, interface name, MTU for the incoming/outgoing/sub-IP/next-hop roles — parsed alongside RFC 4950 MPLS labels, shown in the hop detail view and JSON export. Validated against Arista EOS captures. Fixed the ICMPv6 RFC 4884 length field, which had blocked all ICMPv6 extensions.
- [x] `scripts/fakertr`: a containerised fake RFC 5837 router for end-to-end smoke tests of the ICMP extension path with real packets
- [x] Security: rustls 0.23.45 (RUSTSEC-2026-0285), maxminddb 0.31 (MMDB decode DoS hardening)

---

## Completed (v0.24.0, v0.24.1)

- [x] Native Windows build (#141): the crate compiles and its tests run on Windows in CI; live tracing points to WSL2, `--replay`/`--diff` work natively
- [x] One visual language across the TUI (#164): right-aligned stats, badge title flags, one popup and hint style, reworked hop detail, help legend, default theme readable on light terminals, ≥4.5:1 contrast enforced for every theme
- [x] Correctness: PMTUD reports only destination-confirmed sizes (#159); random per-process ICMP identifier so concurrent instances never cross-talk (#163); enrichment no longer starves later hops (#156); ICMP extension checksums and padding (#144, #158); ICMPv6 Parameter Problem correlation (#160)
- [x] Robustness: atomic saves (#157), bounded headless memory (#155), fragment-safe metrics endpoint (#150), conflicting output modes rejected (#148)
- [x] MPLS/interface details in text reports (#146); `--replay-size-limit` for large trusted recordings (#157)
- [x] Docs reorganized around a short README front door, `docs/INSTALL.md` and a docs index (#162); demo re-recorded to show only the TUI (#165)
- [x] Security: rustls 0.23.46 (RUSTSEC-2026-0346..0349), quinn-proto 0.11.19 (RUSTSEC-2026-0338..0342)
- [x] Security (v0.24.1): drop trust in the breached emSign CA's intermediates — webpki-roots / webpki-root-certs 1.0.10 (RUSTSEC-2026-0381, RUSTSEC-2026-0383), rustls-webpki 0.103.16 (RUSTSEC-2026-0382)

---

## Planned Features

### Before next release — TTL send-path correctness (follow-ups to #12)

The macOS single-hop fix (#12) removes the stale-TTL race from the probe send paths, now **complete across IPv4 and IPv6 on every platform**. IPv4 is unified on `IP_HDRINCL` (TTL written into a hand-built IP header sent through one raw socket); IPv6 sends each probe from a fresh socket on the BSD-derived platforms (`per_probe_send` = macOS/FreeBSD/NetBSD). The rapid probe sweeps are race-free, so the interim timing delay is gone; the lone IPv6 PMTUD probe per round still uses the shared socket but is an isolated send. Validated on real Linux, macOS, and FreeBSD kernels in CI.

- [x] **Unify the IPv4 send path on `IP_HDRINCL`.** TTL in the IP header; per-OS `ip_len`/`ip_off` byte order handled (host order on macOS/NetBSD, network order on Linux/FreeBSD ≥11); transport (ICMP/UDP/TCP) checksums built in; CI runs a privileged real-kernel send test on Linux/macOS/FreeBSD. Also fixes IPv4 PMTUD on NetBSD (DF set in the header, not via the missing `IP_DONTFRAG`).
- [x] **IPv6: deterministic per-packet hop limit on FreeBSD/NetBSD.** Extended the per-probe-socket path (previously macOS-only) to FreeBSD/NetBSD via the new `per_probe_send` cfg (`build.rs`). Linux keeps one shared socket (no race there).
- [x] **Dropped the 500µs `apply_rate_limit` delay.** Redundant now that IPv4 uses `IP_HDRINCL` and IPv6 uses per-probe sockets on all BSD-derived platforms; only the explicit `--rate` delay remains.

### Next — ECMP Improvements

**Why this matters:** Per-packet load balancing (common on Arista, Juniper, Cisco) is undercounted by the current flow-primary model. Users see 8 responders in the detail view but "Paths: 1" in the main table. Related: #46

- [x] Detect per-packet vs per-flow ECMP (primary_ratio heuristic per flow)
- [x] Paths column reflects actual responder count for per-packet ECMP
- [x] Separate indicators: `E` for ECMP detected vs `!` for route flap
- [x] Warn when `--flows > 1` with effective ICMP probing (`-p icmp`, or `-p auto` when auto-select resolves to ICMP)
- [x] Define `-p auto` warning semantics for multi-target/mixed-family runs (warn if any target resolves to effective ICMP, avoid duplicate spam)
- [x] Track effective flow capability at runtime (requested `--flows` vs effective protocol) and use it for flap detection + NAT/Paths column visibility
- [x] Add CLI/TUI hint that flow-based ECMP detection is meaningful with UDP/TCP probes
- [x] Keep Paths value + highlight + host indicator driven by one shared ECMP classification (avoid count/style drift)
- [x] Handle out-of-range returned src ports as unknown flow (not forced flow 0) to avoid false per-flow attribution behind NAT/CGNAT
- [x] Update indicator/UI budget for new `E` marker (host width autosize currently assumes `" !~^"`)
- [x] Update user-facing indicator docs/help (`E` vs `!`) in CLI help + docs pages
- [x] Add tests for per-packet ECMP classification, `-p auto` ICMP warning behavior, and out-of-range src-port flow attribution
- [x] #46 acceptance: per-packet ECMP no longer presents as misleading `Paths: 1` when many responders are observed
- [x] #46 acceptance: `E` (ECMP) and `!` (route flap) are no longer conflated in the same scenario
- [ ] Paris strategy for UDP (`--strategy paris` — fixed 5-tuple, checksum encodes sequence) *(follow-on after #46 core fix)*
- [ ] Dublin strategy for UDP (`--strategy dublin` — IP ID field encodes sequence) *(follow-on after #46 core fix)*

---

## Future Ideas

*Prioritized by effort vs user impact. Quick wins first, then bigger lifts.*

### Quick Wins (low effort, high impact)
- [x] **Progress indicator in replay** — show position in timeline during animated replay
- [x] **Interactive replay** — step through events, jump to time, speed control
- [x] **Last metric semantics** — documented as primary-responder-most-recent; TUI/CSV aligned
- [x] **IPv6 RAW payload fallback tests** — unit tests for IPv6 Echo Reply and Time Exceeded parsing
- [x] **Main table layout tests** — verify header/cell/width count parity across Auto/Compact/Wide × single-flow/multi-flow modes

### Medium Effort (moderate effort, high impact)
- [ ] **PCAP export** — write probe/response packets to .pcap for Wireshark analysis
- [x] **IX lookup performance** — radix trie for O(prefix_len) instead of O(n) linear scan
- [ ] **Customizable columns** — choose which stats to display in TUI
- [x] **Container image** — pre-built multi-arch image on GHCR for CI/monitoring pipelines

### Larger Projects (high effort, high impact)
- [ ] **ICMP checksum flow variation** — Paris traceroute for ICMP (vary checksum to create distinct flows). Neither ttl nor trippy implements this today. Requires platform-specific raw socket work (kernel checksum offloading on Linux, IP_HDRINCL). **Note:** Real-world value may be limited — Arista hardware flow-hashing platforms don't use ICMP checksum as entropy, so this approach won't create distinct flows on most switch hardware. TCP/UDP remain the reliable methods for multi-path detection. May still be useful on software load balancers.
- [ ] **BGP & routing integration** — looking glass queries, AS path display, RPKI/ROA validation
- [ ] **Baseline comparison** — save baseline, alert on latency/loss/path deviations
- [ ] **Continuous logging mode** — log path changes over hours/days
- [ ] **Historical data storage** — SQLite/file-based path history

### Nice to Have
- [ ] **Custom keybindings** — user-configurable key mappings
- [ ] **World map visualization** — ASCII/Unicode geographic path display
- [ ] **Advanced protocol testing** — TCP MSS clamping, ECN, fragmentation testing
- [ ] **Multi-path validation** — verify all ECMP paths are functional

---

## Pre-1.0 Requirements

### Code Quality
- [ ] Library API stabilization (stable `lib.rs` for third-party integrations)
- [ ] Comprehensive documentation for library consumers
- [ ] Semantic versioning commitment

### Testing
- [x] Integration tests for probe-receive-state pipeline
- [x] Property-based/fuzz tests for packet parsing (correlate.rs)
- [x] RAW payload fallback unit tests (IPv4)
- [x] IPv6 RAW payload fallback unit tests
- [x] Concurrent multi-target stress tests

---

## Low Priority

### Windows Native
- [x] Crate builds and tests pass on native Windows (CI job; binary points to WSL2)
- [ ] Basic ICMP traceroute (Npcap or Winsock raw sockets)
- [ ] TUI compatibility with Windows Terminal
- [ ] Pre-built binaries

*Rationale: Massive Npcap effort. WSL2 works well. Revisit if demand warrants.*

### Bidirectional Probing
- [ ] Remote agent for measuring both directions
- [ ] One-way delay estimation (detect latency asymmetry)

*Rationale: Requires deploying an agent on the remote side, which changes the tool's simplicity model.*

### Advanced Network Analysis
- [ ] Bandwidth/capacity estimation (pathchar-style probing)
- [ ] SNMP integration (query router interface stats)
- [ ] Network topology learning (build graph from multiple traces)

*Rationale: These push ttl toward being a full network management tool. Better served by purpose-built tools.*

---

## Competitive Landscape

| Tool | Language | ECMP | MTU Discovery | Rate Limit Detection | TUI | Active Development |
|------|----------|------|---------------|---------------------|-----|-------------------|
| mtr | C | No | No | No | Yes | Maintenance |
| trippy | Rust | Yes (UDP) | No | No | Yes | Active |
| traceroute | C | No | Yes | No | No | Maintenance |
| tracepath | C | No | Yes | No | No | Maintenance |
| **ttl** | Rust | Yes (per-flow + per-packet) | Yes | Yes | Yes | Active |

---

## Scope Creep / Non-Goals

ttl is a **CLI traceroute tool**. The following are explicitly out of scope:

- **Web/mobile UI** — this is a CLI tool, SSH into a box
- **Shareable URLs / hosted trace service** — JSON files are the sharing format
- **Webhook/event streaming** — use `--stream-json | curl` instead
- **Monitor mode with alerting** — use Smokeping/Nagios for long-running monitoring
- **Modular output plugins** — Unix pipes are the plugin system
- **Hop privacy mode** (mask IPs for screenshots) — users can redact manually
- **Multi-language TUI** (i18n) — English-only is fine for CLI tools
- **Full packet capture** — use tcpdump/wireshark
- **Bandwidth testing** — use [xfr](https://github.com/lance0/xfr) or iperf
- **Port scanning** — use nmap
- **Enterprise collaboration platform** — not a SaaS product

If you need these features, combine ttl with purpose-built tools.

---

## Known Limitations

See [KNOWN_ISSUES.md](KNOWN_ISSUES.md) for documented edge cases and limitations.

---

## Infrastructure

- [x] GitHub Actions CI (build, test, clippy, FreeBSD)
- [x] Binary releases (Linux x86_64/aarch64, macOS x86_64/aarch64)
- [x] Homebrew core formula (`brew install ttl`) + `lance0/tap/ttl` tap
- [x] Curl installer (`install.sh`)
- [x] Dependabot (Cargo + GitHub Actions)
- [x] AUR package (`ttl-bin`, community-maintained)
- [x] Gentoo package (`net-analyzer/ttl`, official repository)
- [x] Container image on GHCR (`ghcr.io/lance0/ttl`, multi-arch, published on release)
- [ ] Docker Hub mirror (optional — needs registry credentials; GHCR covers the use case)

---

## Contributing

See issues labeled `good first issue` for entry points. PRs welcome for any roadmap item.
