use ratatui::buffer::Buffer;
use ratatui::layout::Rect;
use ratatui::style::{Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Paragraph, Widget};

use crate::lookup::ix::CacheStatus;
use crate::prefs::DisplayMode;
use crate::tui::theme::Theme;

/// Settings state for the modal
#[derive(Default, Clone)]
pub struct SettingsState {
    /// 0 = theme section, 1 = display mode section, 2 = PeeringDB section
    pub selected_section: usize,
    /// Scroll offset for theme list
    pub theme_scroll: usize,
    /// Selected theme index
    pub theme_index: usize,
    /// Display mode for column widths (auto/compact/wide)
    pub display_mode: DisplayMode,
    /// PeeringDB API key input value
    pub api_key: String,
    /// Cursor position in API key input
    pub api_key_cursor: usize,
    /// Whether the startup update check is enabled (persisted to prefs)
    pub update_check: bool,
}

impl SettingsState {
    pub fn new(theme_index: usize, display_mode: DisplayMode, api_key: Option<String>) -> Self {
        let api_key = api_key.unwrap_or_default();
        let cursor = api_key.len();
        Self {
            selected_section: 0,
            theme_scroll: 0,
            theme_index,
            display_mode,
            api_key,
            api_key_cursor: cursor,
            // Caller overrides from prefs; enabled is the default.
            update_check: true,
        }
    }

    /// Section index of the Update Check toggle. It sits after the optional
    /// PeeringDB section, so its index depends on whether IX detection is on.
    pub fn update_check_section(ix_enabled: bool) -> usize {
        if ix_enabled { 3 } else { 2 }
    }

    /// Insert a character at the cursor position
    pub fn handle_char(&mut self, c: char) {
        self.api_key.insert(self.api_key_cursor, c);
        self.api_key_cursor += c.len_utf8();
    }

    /// Delete the character before the cursor (backspace)
    pub fn handle_backspace(&mut self) {
        if self.api_key_cursor > 0 {
            // Find the start of the previous character boundary
            let mut prev = self.api_key_cursor - 1;
            while prev > 0 && !self.api_key.is_char_boundary(prev) {
                prev -= 1;
            }
            self.api_key.remove(prev);
            self.api_key_cursor = prev;
        }
    }

    /// Delete the character at the cursor position (delete key)
    pub fn handle_delete(&mut self) {
        if self.api_key_cursor < self.api_key.len() {
            // Find the end of the current character
            let mut next = self.api_key_cursor + 1;
            while next < self.api_key.len() && !self.api_key.is_char_boundary(next) {
                next += 1;
            }
            self.api_key.replace_range(self.api_key_cursor..next, "");
        }
    }

    /// Move cursor left
    pub fn move_cursor_left(&mut self) {
        if self.api_key_cursor > 0 {
            let mut prev = self.api_key_cursor - 1;
            while prev > 0 && !self.api_key.is_char_boundary(prev) {
                prev -= 1;
            }
            self.api_key_cursor = prev;
        }
    }

    /// Move cursor right
    pub fn move_cursor_right(&mut self) {
        if self.api_key_cursor < self.api_key.len() {
            let mut next = self.api_key_cursor + 1;
            while next < self.api_key.len() && !self.api_key.is_char_boundary(next) {
                next += 1;
            }
            self.api_key_cursor = next;
        }
    }

    /// Move selection up within current section
    pub fn move_up(&mut self, _theme_count: usize) {
        if self.selected_section == 0 {
            // Theme section
            if self.theme_index > 0 {
                self.theme_index -= 1;
                // Adjust scroll if needed
                if self.theme_index < self.theme_scroll {
                    self.theme_scroll = self.theme_index;
                }
            }
        }
        // Display mode section has no up/down navigation
    }

    /// Move selection down within current section
    pub fn move_down(&mut self, theme_count: usize) {
        if self.selected_section == 0 {
            // Theme section
            if theme_count > 0 && self.theme_index + 1 < theme_count {
                self.theme_index += 1;
                // Adjust scroll if needed (show 5 themes at once)
                let visible_themes = 5;
                if self.theme_index >= self.theme_scroll + visible_themes {
                    self.theme_scroll = self.theme_index - visible_themes + 1;
                }
            }
        }
        // Display mode section has no up/down navigation
    }

    /// Switch between sections. Order: 0=Theme, 1=Display Mode,
    /// 2=PeeringDB (only when IX detection is enabled), then Update Check last.
    pub fn next_section(&mut self, ix_enabled: bool) {
        let num_sections = if ix_enabled { 4 } else { 3 };
        self.selected_section = (self.selected_section + 1) % num_sections;
    }

    /// Select current theme (when in theme section) or cycle display mode
    pub fn select(&mut self) {
        if self.selected_section == 1 {
            self.display_mode = self.display_mode.next();
        }
        // Theme is already selected by navigation
    }
}

/// Settings modal view
pub struct SettingsView<'a> {
    theme: &'a Theme,
    state: &'a SettingsState,
    theme_names: &'a [&'static str],
    cache_status: Option<CacheStatus>,
    ix_enabled: bool,
    /// Why the update check is locked off for this run, if it is.
    update_lock: Option<&'static str>,
}

impl<'a> SettingsView<'a> {
    /// Mark the update check as locked off (by the build, environment or
    /// --no-update-check), so the row says why instead of looking broken.
    pub fn with_update_locked(mut self, locked: bool) -> Self {
        self.update_lock = locked.then(|| {
            if !crate::update::ENABLED {
                "not in this build"
            } else if crate::update::env_opt_out() {
                "set by environment"
            } else {
                "set by --no-update-check"
            }
        });
        self
    }

    pub fn new(
        theme: &'a Theme,
        state: &'a SettingsState,
        theme_names: &'a [&'static str],
        cache_status: Option<CacheStatus>,
        ix_enabled: bool,
    ) -> Self {
        Self {
            theme,
            state,
            theme_names,
            cache_status,
            ix_enabled,
            update_lock: None,
        }
    }

    /// Format the cache age as a human-readable string
    fn format_cache_age(fetched_at: u64) -> String {
        use std::time::SystemTime;
        let now = SystemTime::now()
            .duration_since(SystemTime::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        let age_secs = now.saturating_sub(fetched_at);

        if age_secs < 60 {
            "just now".to_string()
        } else if age_secs < 3600 {
            format!("{}m ago", age_secs / 60)
        } else if age_secs < 86400 {
            format!("{}h ago", age_secs / 3600)
        } else {
            format!("{}d ago", age_secs / 86400)
        }
    }
}

impl Widget for SettingsView<'_> {
    fn render(self, area: Rect, buf: &mut Buffer) {
        // Taller when the PeeringDB section is shown.
        let popup_width = 48.min(area.width.saturating_sub(4));
        let content_height = if self.ix_enabled { 21 } else { 16 };
        let popup_height = (content_height + super::POPUP_ROWS).min(area.height.saturating_sub(4));
        let inner = super::popup(
            area,
            buf,
            (popup_width, popup_height),
            "Settings",
            &[
                ("Esc", "close"),
                ("Tab", "section"),
                ("↑/↓", "move"),
                ("Enter", "select"),
            ],
            self.theme,
        );

        let mut lines = Vec::new();
        let mut section_starts = vec![0];

        // Theme section header
        let theme_header_style = if self.state.selected_section == 0 {
            Style::default()
                .fg(self.theme.header)
                .add_modifier(Modifier::BOLD)
        } else {
            Style::default().fg(self.theme.text_dim)
        };
        lines.push(Line::from(vec![Span::styled("Theme", theme_header_style)]));

        // Show visible themes (5 at a time)
        let visible_themes = 5.min(self.theme_names.len());
        let start = self.state.theme_scroll;
        let end = (start + visible_themes).min(self.theme_names.len());

        // Scroll indicator (up)
        if start > 0 {
            lines.push(Line::from(vec![Span::styled(
                "  \u{25b2} more",
                Style::default().fg(self.theme.text_dim),
            )]));
        } else {
            lines.push(Line::from(""));
        }

        // Theme list
        for (i, name) in self.theme_names[start..end].iter().enumerate() {
            let idx = start + i;
            let is_selected = idx == self.state.theme_index;
            let bullet = if is_selected { "\u{25cf}" } else { "\u{25cb}" };
            let style = if is_selected && self.state.selected_section == 0 {
                Style::default()
                    .fg(self.theme.header)
                    .add_modifier(Modifier::BOLD)
            } else if is_selected {
                Style::default().fg(self.theme.text)
            } else {
                Style::default().fg(self.theme.text_dim)
            };
            lines.push(Line::from(vec![Span::styled(
                format!("  {} {}", bullet, name),
                style,
            )]));
        }

        // Scroll indicator (down)
        if end < self.theme_names.len() {
            lines.push(Line::from(vec![Span::styled(
                "  \u{25bc} more",
                Style::default().fg(self.theme.text_dim),
            )]));
        } else {
            lines.push(Line::from(""));
        }

        lines.push(Line::from(""));

        section_starts.push(lines.len());
        // Display mode section header
        let display_header_style = if self.state.selected_section == 1 {
            Style::default()
                .fg(self.theme.header)
                .add_modifier(Modifier::BOLD)
        } else {
            Style::default().fg(self.theme.text_dim)
        };
        lines.push(Line::from(vec![Span::styled(
            "Display Mode",
            display_header_style,
        )]));

        // Display mode selector
        let mode_text = format!("  [{}]  (Enter to cycle)", self.state.display_mode.label());
        let mode_style = if self.state.selected_section == 1 {
            Style::default()
                .fg(self.theme.header)
                .add_modifier(Modifier::BOLD)
        } else {
            Style::default().fg(self.theme.text_dim)
        };
        lines.push(Line::from(vec![Span::styled(mode_text, mode_style)]));

        // Mode description
        let desc = match self.state.display_mode {
            DisplayMode::Auto => "fit columns to content",
            DisplayMode::Compact => "minimal column widths",
            DisplayMode::Wide => "generous column widths",
        };
        lines.push(Line::from(vec![Span::styled(
            format!("  {}", desc),
            Style::default().fg(self.theme.text_dim),
        )]));

        // PeeringDB section (only if IX detection is enabled)
        if self.ix_enabled {
            lines.push(Line::from(""));

            section_starts.push(lines.len());
            // PeeringDB section header
            let pdb_header_style = if self.state.selected_section == 2 {
                Style::default()
                    .fg(self.theme.header)
                    .add_modifier(Modifier::BOLD)
            } else {
                Style::default().fg(self.theme.text_dim)
            };
            lines.push(Line::from(vec![Span::styled(
                "PeeringDB (IX Detection)",
                pdb_header_style,
            )]));

            // API key input
            let api_key_style = if self.state.selected_section == 2 {
                Style::default().fg(self.theme.text)
            } else {
                Style::default().fg(self.theme.text_dim)
            };

            // Build the API key display with cursor
            let label = "  API Key: ";
            let display_key = if self.state.api_key.is_empty() {
                "(not set)".to_string()
            } else {
                // Show the key with cursor indicator when section is selected
                if self.state.selected_section == 2 {
                    let (before, after) = self.state.api_key.split_at(self.state.api_key_cursor);
                    let budget = usize::from(inner.width).saturating_sub(label.len() + 1);
                    let mut start = before.len();
                    let mut used = 0;
                    for (index, _) in before.char_indices().rev() {
                        let cells = Span::raw(&before[index..start]).width();
                        if used + cells > budget {
                            break;
                        }
                        start = index;
                        used += cells;
                    }
                    let after = super::fit_text(after, budget.saturating_sub(used) as u16);
                    format!("{}│{}", &before[start..], after)
                } else {
                    self.state.api_key.clone()
                }
            };
            lines.push(Line::from(vec![
                Span::styled(label, api_key_style),
                Span::styled(
                    display_key,
                    if self.state.selected_section == 2 {
                        Style::default()
                            .fg(self.theme.header)
                            .add_modifier(Modifier::BOLD)
                    } else {
                        api_key_style
                    },
                ),
            ]));

            // Cache status
            if let Some(ref status) = self.cache_status {
                let status_text = if status.refreshing {
                    "  Cache: Refreshing...".to_string()
                } else if !status.loaded && status.prefix_count == 0 {
                    "  Cache: Not loaded".to_string()
                } else {
                    let age_str = status
                        .fetched_at
                        .map(Self::format_cache_age)
                        .unwrap_or_else(|| "unknown".to_string());
                    let status_indicator = if status.expired { " (expired)" } else { "" };
                    format!(
                        "  Cache: {} prefixes, {}{}",
                        status.prefix_count, age_str, status_indicator
                    )
                };
                lines.push(Line::from(vec![Span::styled(
                    status_text,
                    Style::default().fg(self.theme.text_dim),
                )]));

                // Refresh hint when in PeeringDB section
                if self.state.selected_section == 2 && !status.refreshing {
                    lines.push(Line::from(vec![Span::styled(
                        "  Press Ctrl+R to refresh cache",
                        Style::default().fg(self.theme.text_dim),
                    )]));
                } else {
                    lines.push(Line::from(""));
                }
            }
        }

        // Update Check section (always shown; sits after the optional PeeringDB
        // section so its index shifts with ix_enabled).
        lines.push(Line::from(""));
        section_starts.push(lines.len());
        let uc_section = SettingsState::update_check_section(self.ix_enabled);
        let uc_selected = self.state.selected_section == uc_section;
        let uc_header_style = if uc_selected {
            Style::default()
                .fg(self.theme.header)
                .add_modifier(Modifier::BOLD)
        } else {
            Style::default().fg(self.theme.text_dim)
        };
        lines.push(Line::from(vec![Span::styled(
            "Update Check",
            uc_header_style,
        )]));
        let uc_state = if self.state.update_check { "on" } else { "off" };
        let uc_style = if uc_selected {
            Style::default()
                .fg(self.theme.header)
                .add_modifier(Modifier::BOLD)
        } else {
            Style::default().fg(self.theme.text_dim)
        };
        // A locked toggle names what locked it instead of offering Enter.
        lines.push(Line::from(vec![
            Span::styled(format!("  [{uc_state}]  "), uc_style),
            match self.update_lock {
                Some(reason) => Span::styled(reason, Style::default().fg(self.theme.text_dim)),
                None => Span::styled("(Enter to toggle)", uc_style),
            },
        ]));
        lines.push(Line::from(vec![Span::styled(
            "  check GitHub for new releases at startup",
            Style::default().fg(self.theme.text_dim),
        )]));

        // Keep the active section and close/navigation hints visible when
        // the terminal is shorter than the settings content.
        section_starts.push(lines.len());
        let mut wrapped = Vec::new();
        let mut offsets = Vec::new();
        for line in lines {
            offsets.push(wrapped.len());
            wrapped.extend(super::hop::wrap_lines(vec![line], inner.width));
        }
        offsets.push(wrapped.len());
        let section = self.state.selected_section.min(section_starts.len() - 2);
        let start = offsets[section_starts[section]];
        let end = offsets[section_starts[section + 1]];
        let body_height = inner.height;
        let focus = if section == 0 {
            start
                + 2
                + self
                    .state
                    .theme_index
                    .saturating_sub(self.state.theme_scroll)
        } else {
            start + 1
        };
        let offset = if end.saturating_sub(start) <= usize::from(body_height) {
            end.saturating_sub(usize::from(body_height))
        } else {
            focus.saturating_sub(usize::from(body_height).saturating_sub(1))
        };
        Paragraph::new(wrapped)
            .scroll((offset.min(usize::from(u16::MAX)) as u16, 0))
            .render(inner, buf);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn locked_update_check_says_why_on_one_line() {
        use ratatui::{buffer::Buffer, layout::Rect};
        let theme = Theme::default();
        let mut state = SettingsState::new(0, DisplayMode::Auto, None);
        state.update_check = false;
        state.selected_section = SettingsState::update_check_section(false);
        let rows = |locked: bool| {
            let area = Rect::new(0, 0, 80, 30);
            let mut buf = Buffer::empty(area);
            SettingsView::new(&theme, &state, Theme::list(), None, false)
                .with_update_locked(locked)
                .render(area, &mut buf);
            (0..30)
                .map(|y| (0..80).map(|x| buf[(x, y)].symbol()).collect::<String>())
                .collect::<Vec<_>>()
        };
        assert!(
            rows(false)
                .iter()
                .any(|r| r.contains("[off]  (Enter to toggle)"))
        );
        let locked = rows(true);
        let row = locked.iter().find(|r| r.contains("[off]")).unwrap();
        assert!(
            row.contains("[off]  set by") || row.contains("[off]  not in this build"),
            "{row}"
        );
        assert!(!locked.iter().any(|r| r.contains("Enter to toggle")));
    }

    #[test]
    fn test_settings_state_new() {
        let state = SettingsState::new(2, DisplayMode::Auto, Some("test_key".to_string()));
        assert_eq!(state.theme_index, 2);
        assert_eq!(state.display_mode, DisplayMode::Auto);
        assert_eq!(state.api_key, "test_key");
        assert_eq!(state.api_key_cursor, 8); // "test_key".len()
        assert_eq!(state.selected_section, 0);
        assert_eq!(state.theme_scroll, 0);
    }

    #[test]
    fn test_settings_state_new_no_api_key() {
        let state = SettingsState::new(0, DisplayMode::Wide, None);
        assert_eq!(state.theme_index, 0);
        assert_eq!(state.display_mode, DisplayMode::Wide);
        assert_eq!(state.api_key, "");
        assert_eq!(state.api_key_cursor, 0);
    }

    #[test]
    fn test_settings_state_select_cycles_display_mode() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, None);

        // Section 0 (theme) - select does nothing to display_mode
        state.selected_section = 0;
        state.select();
        assert_eq!(state.display_mode, DisplayMode::Auto);

        // Section 1 (display mode) - select cycles
        state.selected_section = 1;
        state.select();
        assert_eq!(state.display_mode, DisplayMode::Compact);

        state.select();
        assert_eq!(state.display_mode, DisplayMode::Wide);

        state.select();
        assert_eq!(state.display_mode, DisplayMode::Auto);
    }

    #[test]
    fn test_settings_state_next_section() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, None);

        // Without IX enabled: 3 sections (theme, display, update-check)
        assert_eq!(state.selected_section, 0);
        state.next_section(false);
        assert_eq!(state.selected_section, 1);
        state.next_section(false);
        assert_eq!(state.selected_section, 2); // update-check
        state.next_section(false);
        assert_eq!(state.selected_section, 0); // Wraps

        // With IX enabled: 4 sections (theme, display, peeringdb, update-check)
        state.selected_section = 0;
        state.next_section(true);
        assert_eq!(state.selected_section, 1);
        state.next_section(true);
        assert_eq!(state.selected_section, 2);
        state.next_section(true);
        assert_eq!(state.selected_section, 3); // update-check
        state.next_section(true);
        assert_eq!(state.selected_section, 0); // Wraps

        // Update-check section index tracks ix_enabled.
        assert_eq!(SettingsState::update_check_section(false), 2);
        assert_eq!(SettingsState::update_check_section(true), 3);
    }

    #[test]
    fn test_settings_state_theme_navigation() {
        let mut state = SettingsState::new(5, DisplayMode::Auto, None);
        state.selected_section = 0;

        // Move up
        state.move_up(11);
        assert_eq!(state.theme_index, 4);

        // Move up at 0 stays at 0
        state.theme_index = 0;
        state.move_up(11);
        assert_eq!(state.theme_index, 0);

        // Move down
        state.theme_index = 5;
        state.move_down(11);
        assert_eq!(state.theme_index, 6);

        // Move down at max stays at max
        state.theme_index = 10;
        state.move_down(11);
        assert_eq!(state.theme_index, 10);
    }

    #[test]
    fn test_settings_state_api_key_input() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, None);

        // Type characters
        state.handle_char('a');
        state.handle_char('b');
        state.handle_char('c');
        assert_eq!(state.api_key, "abc");
        assert_eq!(state.api_key_cursor, 3);

        // Backspace
        state.handle_backspace();
        assert_eq!(state.api_key, "ab");
        assert_eq!(state.api_key_cursor, 2);

        // Backspace at empty string
        state.api_key = String::new();
        state.api_key_cursor = 0;
        state.handle_backspace();
        assert_eq!(state.api_key, "");
        assert_eq!(state.api_key_cursor, 0);
    }

    #[test]
    fn test_settings_state_cursor_movement() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, Some("hello".to_string()));
        assert_eq!(state.api_key_cursor, 5);

        // Move left
        state.move_cursor_left();
        assert_eq!(state.api_key_cursor, 4);

        // Move left to beginning
        state.api_key_cursor = 0;
        state.move_cursor_left();
        assert_eq!(state.api_key_cursor, 0); // Stays at 0

        // Move right
        state.api_key_cursor = 2;
        state.move_cursor_right();
        assert_eq!(state.api_key_cursor, 3);

        // Move right at end
        state.api_key_cursor = 5;
        state.move_cursor_right();
        assert_eq!(state.api_key_cursor, 5); // Stays at end
    }

    #[test]
    fn test_settings_state_handle_delete() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, Some("hello".to_string()));
        state.api_key_cursor = 2; // Position at 'l'

        state.handle_delete();
        assert_eq!(state.api_key, "helo"); // Deleted 'l' at position 2
        assert_eq!(state.api_key_cursor, 2); // Cursor stays

        // Delete at end does nothing
        state.api_key_cursor = 4;
        state.handle_delete();
        assert_eq!(state.api_key, "helo");
    }

    #[test]
    fn test_settings_state_delete_multibyte_char() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, Some("a日b".to_string()));
        state.api_key_cursor = 1; // Position at '日' (3-byte char)

        state.handle_delete();

        assert_eq!(state.api_key, "ab");
        assert_eq!(state.api_key_cursor, 1);
        assert!(state.api_key.is_char_boundary(state.api_key_cursor));
    }

    #[test]
    fn test_settings_state_move_cursor_right_multibyte_char() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, Some("a日b".to_string()));
        state.api_key_cursor = 0;

        state.move_cursor_right();
        assert_eq!(state.api_key_cursor, 1); // after 'a'

        state.move_cursor_right();
        assert_eq!(state.api_key_cursor, 4); // after '日'

        state.move_cursor_right();
        assert_eq!(state.api_key_cursor, 5); // after 'b'

        state.move_cursor_right();
        assert_eq!(state.api_key_cursor, 5); // stays at end
    }

    #[test]
    fn test_settings_state_default() {
        let state = SettingsState::default();
        assert_eq!(state.theme_index, 0);
        assert_eq!(state.display_mode, DisplayMode::Auto);
        assert_eq!(state.api_key, "");
        assert_eq!(state.selected_section, 0);
    }

    #[test]
    fn test_settings_state_multibyte_char_input() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, None);

        // Insert a multi-byte character (é = 2 bytes)
        state.handle_char('é');
        assert_eq!(state.api_key, "é");
        assert_eq!(state.api_key_cursor, 2); // byte offset, not char count

        // Insert another multi-byte char
        state.handle_char('ä');
        assert_eq!(state.api_key, "éä");
        assert_eq!(state.api_key_cursor, 4);

        // Backspace removes the last char (2 bytes)
        state.handle_backspace();
        assert_eq!(state.api_key, "é");
        assert_eq!(state.api_key_cursor, 2);

        // Move cursor left to start
        state.move_cursor_left();
        assert_eq!(state.api_key_cursor, 0);

        // Insert at beginning
        state.handle_char('x');
        assert_eq!(state.api_key, "xé");
        assert_eq!(state.api_key_cursor, 1);
    }

    #[test]
    fn test_settings_state_move_down_empty_themes() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, None);
        state.selected_section = 0;

        // Should not panic with theme_count == 0
        state.move_down(0);
        assert_eq!(state.theme_index, 0);
    }

    #[test]
    fn test_settings_state_split_at_safe_with_multibyte() {
        let mut state = SettingsState::new(0, DisplayMode::Auto, None);
        state.handle_char('日');
        state.handle_char('本');
        state.handle_char('語');

        // Move cursor to middle (after 本)
        state.move_cursor_left(); // before 語
        state.move_cursor_left(); // before 本

        // split_at should not panic — cursor is on a char boundary
        let (before, after) = state.api_key.split_at(state.api_key_cursor);
        assert_eq!(before, "日");
        assert_eq!(after, "本語");
    }
}
